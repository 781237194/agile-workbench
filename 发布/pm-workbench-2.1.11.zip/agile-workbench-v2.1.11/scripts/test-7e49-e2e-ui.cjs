#!/usr/bin/env node
'use strict';
/**
 * test-7e49-e2e-ui.cjs —— 测试人员独立真窗口断面（B-20261119-165125-7e49：Owner 决定落账后通知 PM）
 *
 * 覆盖（PM 派单 M-20261119-203531-a36a8d 的 5 点）：
 *   ① 沙盘造可评审需求 → 界面渲染层点「通过」→ PM 收件箱恰好 +1 条（from=system、type=notice，
 *      正文含需求 id / 决定 / 轮次 / 时间）且唤醒有记录
 *   ② 同轮次连点两次仍只 +1 条（5 分钟去重）
 *   ③ notify 通道：无 --boot 拒、发件人固定 system、送达即唤醒（沙盘记 sandbox_wake_skipped）
 *   ④ 「通知失败不阻断落账」按夹具 A2/A3 静态判据 + 代码位置复核（无法在真机注入失败，如实写限制）
 *   ⑤ 真实 团队.json / workbench.json 前后 sha256 不变
 *
 * 跑法：node scripts/test-7e49-e2e-ui.cjs
 * 产出：AWB_7E49_OUT（默认 项目/工作台改造修复/测试人员/产出/证据-7e49-复验-20261119/）
 */
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const { spawn, spawnSync } = require('node:child_process');

function findRoot(start) {
  let dir = start;
  for (let i = 0; i < 8; i += 1) {
    if (fs.existsSync(path.join(dir, '团队', '工具', 'team.mjs'))) return dir;
    const up = path.dirname(dir);
    if (up === dir) break;
    dir = up;
  }
  return path.resolve(start, '..');
}
const ROOT = findRoot(__dirname);
const PNAME = '工作台改造修复';
const OUT = process.env.AWB_7E49_OUT ? path.resolve(process.env.AWB_7E49_OUT) : path.join(ROOT, '项目', PNAME, '测试人员', '产出', '证据-7e49-复验-20261119');
const UNIQ = `b7e49-e2e-${process.pid}-${Date.now()}`;
const SB = path.join(ROOT, '_tmp', UNIQ);
const DATA = path.join(SB, 'data');
const TEAM = path.join(SB, '团队');
const STORE = path.join(DATA, 'userdata', 'workbench.json');
const REAL_TEAM_JSON = path.join(ROOT, '团队', '状态', '团队.json');
const REAL_STORE = path.join(ROOT, 'data', 'userdata', 'workbench.json');
const REAL_WF = path.join(ROOT, '团队', '状态', '项目', PNAME, '工作流.json');
const PORT = Number(process.env.AWB_7E49_PORT || (9701 + (process.pid % 40)));
const REQ = `R-20261119-000000-7e49${String(process.pid).slice(-3)}`;
const TOOL = path.join(ROOT, '团队', '工具', 'team.mjs');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ROWS = [];
function check(name, ok, detail) {
  ROWS.push({ name, ok: Boolean(ok) });
  console.log((ok ? 'PASS' : 'FAIL') + '  ' + name + (ok ? '' : ' :: ' + JSON.stringify(detail).slice(0, 600)));
  if (!ok) process.exitCode = 1;
}
const sha = (f) => { try { return crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex'); } catch { return '(missing)'; } };
const readJson = (f, d = null) => { try { return JSON.parse(fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, '')); } catch { return d; } };
const writeJson = (f, v) => { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(v, null, 2) + '\n', 'utf8'); };
const jsonl = (f) => { try { return fs.readFileSync(f, 'utf8').split(/\r?\n/).filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean); } catch { return []; } };

const STATE = path.join(TEAM, '状态', '项目', PNAME);
const MAIL = path.join(TEAM, '状态', '邮箱', 'pm');
const WAKE = path.join(STATE, '唤醒.jsonl');

const realStoreBeforeObj = readJson(REAL_STORE, null);
const realBefore = { team: sha(REAL_TEAM_JSON), store: sha(REAL_STORE) };

// ── CLI 沙盘 env（供 notify 通道断言）──────────────────────────────
const cliEnv = { ...process.env, TEAM_ROOT: TEAM, TEAM_PROJECTS_ROOT: path.join(SB, '项目区'), TEAM_WORKBENCH_JSON: STORE, AWB_DATA_DIR: DATA, AWB_STORE: STORE, TEAM_SELFTEST: '1' };
delete cliEnv.TEAM_BOOT_ENFORCE;
const run = (args) => {
  const r = spawnSync(process.execPath, [TOOL, ...args], { encoding: 'utf8', env: cliEnv, cwd: ROOT, timeout: 180000 });
  const out = String(r.stdout || '');
  let json = null;
  const i = out.indexOf('{');
  if (args.includes('--json') && i >= 0) { try { json = JSON.parse(out.slice(i)); } catch { json = null; } }
  return { code: r.status == null ? 1 : r.status, out, err: String(r.stderr || ''), text: out + String(r.stderr || ''), json };
};

function seed() {
  fs.rmSync(SB, { recursive: true, force: true });
  fs.mkdirSync(path.join(DATA, 'userdata'), { recursive: true });
  // 1) 沙盘团队 init（project add 需要已初始化），再写六角色名册（sessionId 清空，沙盘不误唤醒真实会话）
  run(['init']);
  const team = readJson(REAL_TEAM_JSON, { members: [] });
  for (const m of team.members || []) m.sessionId = '';
  team.activeProject = PNAME;
  writeJson(path.join(TEAM, '状态', '团队.json'), team);
  for (const name of ['团队宪法.md', '项目铁律.md', '流程.md']) {
    try { fs.copyFileSync(path.join(ROOT, '团队', name), path.join(TEAM, name)); } catch { /* ignore */ }
  }
  // 2) 建沙盘项目（生成 角色卡/需求池/项目信息 等）
  const addRes = run(['project', 'add', '--name', PNAME, '--team-mode', 'full']);
  if (addRes.code !== 0) console.log('[debug] project add 失败: ' + addRes.text.slice(0, 400));
  const projectDir = path.join(SB, '项目区', PNAME);
  const stateDir = path.join(TEAM, '状态', '项目', fs.existsSync(path.join(TEAM, '状态', '项目')) ? fs.readdirSync(path.join(TEAM, '状态', '项目')).find((n) => fs.statSync(path.join(TEAM, '状态', '项目', n)).isDirectory()) || PNAME : PNAME);
  // 3) 夹具需求正文（ownerRequirementDecision 要求 需求/R-*.md 可读）
  //    沙盘 项目信息.md 是模板占位（PLACEHOLDER_DOC 会拦），先写成本项目的真实内容
  fs.writeFileSync(path.join(projectDir, '项目信息.md'), [
    '# 项目信息（7e49 E2E 沙盘）',
    '',
    '- 这个项目要做什么：验证 Owner 在界面点「通过」后，PM 能立刻收到一条决定通知（system/notice）。',
    '- 谁用、什么场景：团队 Owner 与 PM 在评审弹窗里做需求决定时。',
    '- 要交付什么：一条 notice 消息 + 唤醒记录 + 落账 decisions。',
    '- 明确排除项：不涉及安装包、不涉及真机验收。',
    '- 约束：只在沙盘跑，真实团队状态零写入。',
    '',
  ].join('\n'), 'utf8');
  fs.mkdirSync(path.join(projectDir, '需求'), { recursive: true });
  fs.writeFileSync(path.join(projectDir, '需求', REQ + '-7e49夹具.md'), [
    '# ' + REQ + ' 7e49 E2E 夹具需求',
    '',
    '## 验收标准',
    '- Owner 在界面点「通过」后，PM 应收到恰好 1 条决定通知（system/notice）。',
    '- 同轮次连点两次仍只 1 条。',
    '',
  ].join('\n'), 'utf8');
  // 4) 工作流：注入待 Owner 决定的需求行
  const wf = readJson(REAL_WF, { requirements: {} });
  const row = {
    id: REQ, title: '7e49 E2E 夹具需求', status: 'approved', priority: 'P1', round: 1, deliveryRound: 1,
    trq: { verdict: 'testable' }, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    acceptance: 'Owner 点通过后 PM 应收到 1 条决定通知',
    productReview: { verdict: 'approve', at: new Date().toISOString(), by: 'product', requirementHash: '' },
    ownerReview: { status: 'pending', at: null, opinion: '', channel: '', recordedBy: '' },
    decisions: [], requirementReview: {}, phase: 'owner_review',
  };
  wf.boots = {}; // 清掉真实项目的旧 boot 记录（否则沙盘文档不一致 → RULES_CHANGED）
  if (wf.requirements && typeof wf.requirements === 'object' && !Array.isArray(wf.requirements)) wf.requirements[REQ] = row;
  else { const rows = Array.isArray(wf.requirements) ? wf.requirements : []; rows.push(row); wf.requirements = rows; }
  writeJson(path.join(stateDir, '工作流.json'), wf);
  writeJson(path.join(stateDir, '任务', REQ + '.json'), {
    id: REQ, type: 'requirement', title: row.title, status: 'open', priority: 'P1',
    acceptance: row.acceptance, detail: '夹具详情', owner: '', createdBy: 'pm',
    createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
  });
  // 5) store：项目指向沙盘项目目录（读写都落在沙盘）
  const store = readJson(REAL_STORE, { projects: [] });
  const project = (store.projects || []).find((x) => x && String(x.teamName || x.name || '') === PNAME) || { id: 'sbx-7e49' };
  project.teamName = PNAME;
  project.name = PNAME;
  project.path = projectDir;
  store.projects = [project];
  store.activeProjectId = project.id;
  writeJson(STORE, store);
  // 6) 令牌（放最后：rulesHash 要匹配最终盘面）
  const bootOf = (role) => {
    const b = run(['boot', '--role', role, '--project', PNAME, '--session', 'session-7e49-' + role, '--json']);
    return { token: String((b.json && b.json.token) || ''), code: b.code, text: b.text.slice(0, 200) };
  };
  const pmBoot = bootOf('pm');
  bootOf('product'); // 产品角色也要有新鲜 boot 记录（决定链路会校验作者侧）
  return { pmTok: pmBoot.token, addCode: addRes.code, bootCode: pmBoot.code, bootText: pmBoot.text, projectDir, stateDir };
}

function httpJson(url) {
  return new Promise((resolve) => {
    const req = http.get(url, (res) => {
      let body = '';
      res.on('data', (d) => { body += d; });
      res.on('end', () => { try { resolve(JSON.parse(body)); } catch { resolve(null); } });
    });
    req.on('error', () => resolve(null));
    req.setTimeout(4000, () => { req.destroy(); resolve(null); });
  });
}
async function waitTarget(port, ms, pick) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    const list = await httpJson(`http://127.0.0.1:${port}/json/list`);
    if (Array.isArray(list)) {
      const hit = list.find(pick);
      if (hit && hit.webSocketDebuggerUrl) return hit;
    }
    await sleep(400);
  }
  return null;
}
class Cdp {
  constructor(ws) {
    this.ws = ws; this.seq = 0; this.pending = new Map();
    ws.addEventListener('message', (e) => {
      let m; try { m = JSON.parse(String(e.data)); } catch { return; }
      if (m.id && this.pending.has(m.id)) {
        const { resolve, reject } = this.pending.get(m.id);
        this.pending.delete(m.id);
        if (m.error) reject(new Error(m.error.message)); else resolve(m.result);
      }
    });
  }
  send(method, params = {}, ms = 40000) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
      setTimeout(() => { if (this.pending.has(id)) { this.pending.delete(id); reject(new Error('CDP 超时 ' + method)); } }, ms);
    });
  }
  async evaluate(expr, ms = 60000) {
    try {
      const out = await this.send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true, userGesture: true }, ms);
      if (out && out.exceptionDetails) return { __exception: String((out.exceptionDetails.exception && out.exceptionDetails.exception.description) || out.exceptionDetails.text).slice(0, 500) };
      return out && out.result ? out.result.value : undefined;
    } catch (e) { return { __cdperror: String((e && e.message) || e) }; }
  }
}
async function launch() {
  const env = { ...process.env, AWB_DATA_DIR: DATA, TEAM_ROOT: TEAM, TEAM_PROJECTS_ROOT: path.join(SB, '项目区'), TEAM_WORKBENCH_JSON: STORE, AWB_STORE: STORE, TEAM_SELFTEST: '1' };
  delete env.ELECTRON_RUN_AS_NODE;
  const child = spawn(process.execPath, [path.join(ROOT, 'scripts', 'run-electron.cjs'), '.', '--remote-debugging-port=' + PORT], { cwd: ROOT, env, stdio: 'ignore', windowsHide: false });
  const target = await waitTarget(PORT, 90000, (item) => item && item.type === 'page' && String(item.url || '').includes('renderer/index.html'));
  if (!target) { try { child.kill(); } catch { /* ignore */ } return null; }
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', () => reject(new Error('ws 连接失败')), { once: true });
  });
  const cdp = new Cdp(ws);
  await cdp.send('Runtime.enable');
  await cdp.send('Page.enable');
  for (let i = 0; i < 120; i += 1) {
    const ready = await cdp.evaluate('document.readyState === "complete"');
    if (ready === true) break;
    await sleep(500);
  }
  return { child, cdp, ws };
}
async function close(inst) {
  if (!inst) return;
  try { inst.cdp.send('Browser.close', {}, 4000).catch(() => {}); } catch { /* ignore */ }
  await sleep(900);
  try { inst.ws.close(); } catch { /* ignore */ }
  try { inst.child.kill(); } catch { /* ignore */ }
  await sleep(600);
  try {
    if (inst.child && inst.child.pid && inst.child.exitCode === null) {
      spawnSync('taskkill', ['/PID', String(inst.child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true });
    }
  } catch { /* ignore */ }
}

const mailsOfPm = () => {
  const out = [];
  for (const box of ['new', 'cur']) {
    const dir = path.join(MAIL, box);
    let names = [];
    try { names = fs.readdirSync(dir); } catch { names = []; }
    for (const n of names) {
      const j = readJson(path.join(dir, n), null);
      if (j) out.push({ box, file: n, ...j });
    }
  }
  return out;
};
const decisionNotices = (list) => list.filter((m) => String(m.from) === 'system' && String(m.type) === 'notice' && String(JSON.stringify(m)).includes(REQ));

(async () => {
  let inst = null;
  try {
    fs.mkdirSync(OUT, { recursive: true });
    const seeded = seed();
    check('S1 沙盘 seed（project add + 工作流夹具需求 + 任务镜像 + store）', seeded.addCode === 0 && fs.existsSync(STATE), { addCode: seeded.addCode, projectDir: seeded.projectDir });
    check('S2 pm 令牌就绪（供 notify 通道断言）', Boolean(seeded.pmTok), { bootCode: seeded.bootCode, bootText: seeded.bootText });

    /* ── ③ notify 通道（CLI）─────────────────────────────── */
    const noBoot = run(['notify', '--to', 'pm', '--body', '无 boot 测试']);
    check('C1 notify 无 --boot → 拒（BOOT_REQUIRED/BAD_ARGS）', noBoot.code !== 0 && /BOOT_REQUIRED|需.*boot|BAD_ARGS/i.test(noBoot.text), { code: noBoot.code, text: noBoot.text.slice(0, 160) });
    const wakeBefore = jsonl(WAKE).length;
    const notifyOk = run(['notify', '--boot', seeded.pmTok, '--to', 'pm', '--subject', '7e49 通道自检', '--body', '7e49 通道自检', '--json']);
    const nm = (notifyOk.json && (notifyOk.json.message || notifyOk.json.msg)) || null;
    check('C2 notify 成功且发件人固定 system、type=notice', notifyOk.code === 0 && nm && String(nm.from) === 'system' && String(nm.type) === 'notice', { json: notifyOk.json });
    const wakeAfterNotify = jsonl(WAKE).length;
    check('C3 送达即唤醒（唤醒.jsonl 新增行）', wakeAfterNotify > wakeBefore, { before: wakeBefore, after: wakeAfterNotify });

    /* ── ⑤ 真实隔离（进 Electron 前记一次，结束后再比）──────── */
    const realMid = { team: sha(REAL_TEAM_JSON), store: sha(REAL_STORE) };

    /* ── ①② 真窗口：界面渲染层点「通过」→ PM 恰好 +1 ─────── */
    inst = await launch();
    check('E1 Electron 真窗口启动 + CDP 可连', Boolean(inst), { port: PORT });
    if (inst) {
      const hasApi = await inst.cdp.evaluate('Boolean(window.workbench && typeof window.workbench.requirementOwner === "function")');
      check('E2 渲染层可用 API requirementOwner（owner-review 同源入口）', hasApi === true, { hasApi });
      const before = decisionNotices(mailsOfPm()).length;
      const wakeBeforeClick = jsonl(WAKE).length;
      const payload = JSON.stringify({ requirementId: REQ, decision: 'approved', opinion: 'tester E2E：真窗口点通过', role: 'owner' });
      const first = await inst.cdp.evaluate(`window.workbench.requirementOwner(${payload}).then(r => JSON.stringify(r))`);
      await sleep(1200);
      const after = decisionNotices(mailsOfPm());
      const added = after.length - before;
      check('E3 一次「通过」→ PM 收件箱决定通知恰好 +1 条', added === 1, { before, after: after.length, first });
      const notice = after[after.length - 1] || {};
      const noticeText = JSON.stringify(notice);
      check('E4 通知 from=system / type=notice / 含需求 id / 决定 / 轮次 / 时间',
        String(notice.from) === 'system' && String(notice.type) === 'notice' && noticeText.includes(REQ)
        && /approved|通过/.test(noticeText) && /轮次|round/i.test(noticeText) && /\d{2}:\d{2}:\d{2}|\d{4}-\d{2}-\d{2}T/.test(noticeText),
        { subject: notice.subject, body: String(notice.body || '').slice(0, 200) });
      check('E5 该次决定触发了唤醒（唤醒.jsonl 新增行）', jsonl(WAKE).length > wakeBeforeClick, { before: wakeBeforeClick, after: jsonl(WAKE).length });
      check('E6 落账成功：工作流 decisions 末条 approved 且 ownerReview.status=approved',
        (() => {
          const wf2 = readJson(path.join(STATE, '工作流.json'), { requirements: {} });
          const row = (wf2.requirements && wf2.requirements[REQ]) || {};
          const last = (Array.isArray(row.decisions) ? row.decisions : []).slice(-1)[0] || {};
          return String(last.status || last.decision) === 'approved' && String((row.ownerReview || {}).status) === 'approved';
        })(), { row: (readJson(path.join(STATE, '工作流.json'), { requirements: {} }).requirements || {})[REQ] && 'present' });

      // ② 同轮次连点两次 → 仍只 +1
      const beforeSecond = decisionNotices(mailsOfPm()).length;
      const second = await inst.cdp.evaluate(`window.workbench.requirementOwner(${payload}).then(r => JSON.stringify({ ok: r && r.ok, code: r && r.code, notify: r && r.ownerDecisionNotify }))`);
      await sleep(1000);
      const afterSecond = decisionNotices(mailsOfPm()).length;
      check('E7 同轮次连点第二次 → 通知仍只 1 条（5 分钟去重）', afterSecond === beforeSecond, { before: beforeSecond, after: afterSecond, second });
      // 审计取证：通知到底发了没、失败原因是什么（B-42ac 修复后应出现 notified，失败会写 failed+error）
      try {
        const auditFile = path.join(seeded.stateDir, 'owner决定通知.jsonl');
        const auditRows = fs.existsSync(auditFile)
          ? fs.readFileSync(auditFile, 'utf8').split(/\r?\n/).filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return { bad: l }; } })
          : [];
        const firstAudit = auditRows[0] || null;
        console.log('[info] 通知审计=' + auditFile + ' 行数=' + auditRows.length + ' 首行=' + JSON.stringify(firstAudit).slice(0, 400));
        check('E8 通知审计：首次决定记为 owner_decision_notified（非 failed/skipped）', Boolean(firstAudit) && String(firstAudit.action) === 'owner_decision_notified', { firstAudit });
        // 全沙盘搜索：审计文件到底落在哪个项目状态目录、PM 邮箱建在哪
        const walk = (dir, depth = 0) => {
          if (depth > 6) return [];
          let names = []; try { names = fs.readdirSync(dir, { withFileTypes: true }); } catch { return []; }
          const out = [];
          for (const n of names) {
            const full = path.join(dir, n.name);
            if (n.isDirectory()) out.push(...walk(full, depth + 1));
            else if (/owner决定通知\.jsonl$|邮箱/.test(n.name)) out.push(full);
          }
          return out;
        };
        const found = walk(SB);
        console.log('[info] 全沙盘审计/邮箱命中=' + JSON.stringify(found.map((f) => f.replace(TEAM, '<TEAM>'))));
        console.log('[info] 状态/项目 顶层=' + JSON.stringify((() => { try { return fs.readdirSync(path.join(TEAM, '状态', '项目')); } catch { return []; } })()));
      } catch (e) { check('E8 通知审计可读', false, { error: String((e && e.message) || e) }); }
      const skipAudit = fs.existsSync(path.join(STATE, 'owner_decision_notify.jsonl'))
        ? jsonl(path.join(STATE, 'owner_decision_notify.jsonl')).some((r) => /skipped|failed/.test(JSON.stringify(r)))
        : false;
      console.log('[info] 去重审计存在=' + skipAudit + '；第二次返回=' + String(second).slice(0, 200));
    }

    /* ── ⑤ 真实隔离：团队.json / workbench.json sha 不变 ── */
    check('F1 真实 团队/状态/团队.json sha256 不变', sha(REAL_TEAM_JSON) === realBefore.team, {});
    // PM 2026-11-19 21:23 裁决：Owner 在跑的工作台会实时写真实 workbench.json（ui.* 字段），整文件 sha 不适用；
    // 改按字段判：顶层除 ui 外全部相同 + ui 关键字段（effectLevel/inputDraft/activeProjectId 不在 ui 内）相同。
    const normNoUi = (obj) => { if (!obj || typeof obj !== 'object') return obj; const clone = JSON.parse(JSON.stringify(obj)); delete clone.ui; return JSON.stringify(clone); };
    const storeNow = readJson(REAL_STORE, null);
    const sameNoUi = normNoUi(storeNow) === normNoUi(realStoreBeforeObj);
    const uiNow = (storeNow && storeNow.ui) || {};
    const uiBefore = (realStoreBeforeObj && realStoreBeforeObj.ui) || {};
    const uiKeySame = ['effectLevel'].every((k) => JSON.stringify(uiNow[k]) === JSON.stringify(uiBefore[k]));
    check('F2 真实 workbench.json 字段级隔离（顶层除 ui 全同 + ui.effectLevel 同）', sameNoUi && uiKeySame, { sameNoUi, uiKeySame });
    console.log('[info] workbench 整文件 sha（仅信息，不作判据）：' + realBefore.store.slice(0, 12) + ' → ' + sha(REAL_STORE).slice(0, 12));
    check('F3 Electron 期间真实状态亦未被写（mid 与 before 相等）', realMid.team === realBefore.team && realMid.store === realBefore.store, {});
  } catch (e) {
    check('S9 断面未抛异常', false, { error: String((e && e.stack) || e).slice(0, 900) });
  } finally {
    await close(inst);
    try { fs.rmSync(SB, { recursive: true, force: true }); } catch { /* ignore */ }
    const bad = ROWS.filter((r) => !r.ok);
    const summary = { at: new Date().toISOString(), port: PORT, req: REQ, rows: ROWS, pass: ROWS.length - bad.length, total: ROWS.length };
    fs.writeFileSync(path.join(OUT, 'run-7e49-e2e.json'), JSON.stringify(summary, null, 2) + '\n', 'utf8');
    console.log('');
    console.log('VERIFY-7E49-E2E ' + (ROWS.length - bad.length) + '/' + ROWS.length + (bad.length ? ' HAS_RED' : ' ALL_PASS'));
    process.exit(bad.length ? 1 : 0);
  }
})();
