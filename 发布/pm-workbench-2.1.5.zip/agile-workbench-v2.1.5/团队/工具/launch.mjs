#!/usr/bin/env node
// 一键建团队会话：调 DSH /api/session/create + /api/session/prompt
// 只在本机回环；不打印密钥。默认只建空会话，不烧 token。
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { PATHS, appendEvent, appendLine, jsonOut, textOut, nowIso, fail } from './lib/core.mjs';
import { ROLE_NAMES, ROLES, loadTeam, mutateTeam, getMember, projectStatePaths, setActiveProject, loadProject, projectTeamMode, sendMessage } from './lib/store.mjs';
import {
  TEAM_MODES, TEAM_MODE_LABELS, isTeamMode, normalizeTeamMode, rolesForMode, teamModeDescription, MODEL_BY_ROLE,
} from './lib/roles.mjs';
// R-20261119：开局提示词独立成 lib（可单测）——建团队 seed 与启动 prompt 都必须先让角色读规则+本人目录再回就位。
import { startupText, seedTextFor } from './lib/seed-prompt.mjs';
import { DshClient } from './lib/dsh-session.mjs';
// B-20261118-080052-207b：三源复用判定 + 轮换记账（纯逻辑单元，Node 可测）。
import launchReuse from './lib/launch-reuse.mjs';
const { pickReuse, buildRotation } = launchReuse;
// B-20261117-113925-b64d：团队工具的状态文件写入也走 ad44 的原子写（tmp→fsync→bak→rename + 锁），
// 不再裸 fs.writeFileSync（崩溃时会留半截 JSON）。
import { writeJsonAtomic } from './lib/json-atomic.mjs';
// B-20261118-083150-4b2f（AC-W1）：名册 sessionId 的赋值/入册只允许在 lib/roster-writer.mjs 里。
import { setMemberSession, pushRosterMember } from './lib/roster-writer.mjs';

function parse(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const k = a.slice(2);
      const n = argv[i + 1];
      if (n !== undefined && !n.startsWith('--')) { out[k] = n; i++; } else out[k] = true;
    } else out._.push(a);
  }
  return out;
}

const args = parse(process.argv.slice(2));
const project = String(args.project || '');
const defaultProjectDir = path.join(PATHS.projects, project);
const workspace = path.resolve(String(args.workspace || (project && fs.existsSync(defaultProjectDir) ? defaultProjectDir : PATHS.workspace)));
const team = loadTeam();
if (!project) fail('NO_PROJECT', '需要 --project（先 team.mjs project add）');
if (!fs.existsSync(workspace)) fail('NO_WORKSPACE', `工作区目录不存在：${workspace}`);

// 团队模式：显式 --team-mode > 已登记项目 项目.json > 工作区 workspace.json > full。
// 角色集随模式动态变化：fast 只建/只要求 PM、需求分析师、程序员A、测试人员。
const modeArg = args['team-mode'];
if (modeArg !== undefined && (modeArg === true || !isTeamMode(modeArg))) {
  fail('BAD_TEAM_MODE', `--team-mode 只能是 ${TEAM_MODES.join(' / ')}：${modeArg === true ? '（缺值）' : modeArg}`, { allowed: TEAM_MODES });
}
let teamMode = modeArg !== undefined ? normalizeTeamMode(modeArg) : '';
if (!teamMode) {
  try { teamMode = projectTeamMode(loadProject(project)); } catch { /* 项目还没登记 */ }
}
if (!teamMode) {
  try {
    const meta = JSON.parse(fs.readFileSync(path.join(workspace, 'workspace.json'), 'utf8').replace(/^\uFEFF/, ''));
    if (meta.teamMode) teamMode = normalizeTeamMode(meta.teamMode);
  } catch { /* 老工作区没有 workspace.json */ }
}
teamMode = teamMode || 'full';
const modeRoles = rolesForMode(teamMode);
const roles = String(args.roles || modeRoles.join(','))
  .split(',').map((s) => s.trim()).filter(Boolean);
for (const r of roles) {
  if (!ROLES.includes(r)) fail('BAD_ROLE', `未知角色：${r}`);
  if (!modeRoles.includes(r)) {
    fail('ROLE_NOT_IN_MODE', `项目 ${project} 当前是 ${teamMode} 模式（${modeRoles.join('/')}），不能建 ${r} 会话；要建请先把项目切到 full：project ensure --name "${project}" --team-mode full`, {
      role: r, teamMode, roles: modeRoles,
    });
  }
}
const promptAll = Boolean(args['prompt-all']);
const promptRoles = promptAll ? roles : (args.prompt ? ['pm'].filter((r) => roles.includes(r)) : []);
const noPrompt = Boolean(args['no-prompt']) || promptRoles.length === 0;
const addMembers = Boolean(args['add-members']);
const restoreMode = Boolean(args.restore);
// DSH 左侧工作区会把“从未产生一轮对话”的空白会话隐藏；可选给空白角色发一句就位，
// 让成员真正出现在工作区里。不是开工卡，不要求分析/写文件。
const seedVisible = Boolean(args['seed-visible']);
const dryRun = Boolean(args['dry-run']);
const engineUrl = String(args['engine-url'] || process.env.DSH_WEB_URL || '');

const plan = roles.map((role) => ({
  role,
  title: `团队·${ROLE_NAMES[role] || role}`,
  inRoster: Boolean(getMember(team, role)),
  model: MODEL_BY_ROLE[role] || null,
  prompt: startupText(role, project, workspace, teamMode),
}));

if (dryRun) {
  out({ ok: true, dryRun: true, engineUrl: engineUrl || '(env DSH_WEB_URL)', workspace, project, teamMode, plan, addMembers, noPrompt, promptRoles });
  process.exit(0);
}

// 指定旧目录/非标准工作区时，先按团队模式补齐角色目录、角色卡、项目信息、铁律和索引
const workspaceTool = path.join(PATHS.teamRoot, '工具', 'workspace.mjs');
if (fs.existsSync(workspaceTool)) {
  const relWs = path.relative(PATHS.workspace, workspace);
  const externalWorkspace = !relWs || relWs.startsWith('..') || path.isAbsolute(relWs);
  const ensureArgs = [workspaceTool, 'ensure', '--name', project, '--path', workspace, '--team-mode', teamMode, '--json'];
  if (externalWorkspace) ensureArgs.push('--allow-external');
  if (engineUrl) ensureArgs.push('--engine-url', engineUrl);
  const e = spawnSync(process.execPath, ensureArgs, { encoding: 'utf8', timeout: 60000 });
  if (e.status !== 0) {
    fail('WORKSPACE_ENSURE_FAILED', `工作区文件补齐失败：${(e.stderr || e.stdout || '').slice(-800)}`);
  }
}
if (!fs.existsSync(projectStatePaths(project).config)) fail('NO_PROJECT', `项目不存在：${project}（先 project add）`);

const client = new DshClient(engineUrl || undefined);
const workspaceResult = await client.workspaceCreate({ path: workspace });
const dshWorkspace = workspaceResult.workspace;
// B-20261118-080052-207b：不再用 workspace.sessionIds 当复用前提（三源判定见 lib/launch-reuse.mjs）。
// 程序把真实 workspaceId 写回项目元数据，后续恢复不再依赖猜测。
try {
  const metaFile = path.join(workspace, 'workspace.json');
  const meta = JSON.parse(fs.readFileSync(metaFile, 'utf8').replace(/^\uFEFF/, ''));
  meta.dshWorkspaceId = dshWorkspace.workspaceId;
  meta.updatedAt = nowIso();
  // B-20261118-163847-5e11：工作区元数据参与恢复判定，与 团队会话.json 同口径走原子写（不裸写）。
  writeJsonAtomic(metaFile, meta, { case: 'launch-workspace-meta', allowedRoots: [workspace] });
} catch { /* 旧目录没有 workspace.json 也继续 */ }
const existingList = await client.list();
// B-20261118-080052-207b：三源复用（title + 团队.json 名册 + 项目映射 团队会话.json）。
// 旧实现只认 workspace.sessionIds → 工作区重建/归档/标题轻微不一致时静默新建并覆盖名册（07:39 PM 被换）。
const rosterSessions = new Map(roles.map((r) => {
  const m = getMember(team, r);
  return [r, String((m && m.sessionId) || '')];
}));
const manifestSessions = (() => {
  const map = new Map();
  try {
    const mf = JSON.parse(fs.readFileSync(path.join(workspace, '团队会话.json'), 'utf8').replace(/^\uFEFF/, ''));
    for (const row of (mf.roles || [])) if (row && row.role) map.set(String(row.role), String(row.sessionId || ''));
  } catch { /* 旧工作区没有 团队会话.json：只靠名册/标题 */ }
  return map;
})();
const sessions = [];
const errors = [];
const rotations = [];
for (const p of plan) {
  try {
    const pick = pickReuse({
      role: p.role, title: p.title,
      rosterSessionId: rosterSessions.get(p.role), manifestSessionId: manifestSessions.get(p.role),
      sessions: existingList.items, workspace, workspaceSessionIds: dshWorkspace.sessionIds || [],
    });
    let sessionId;
    let reused = false;
    let reuseSource = pick.source;
    if (pick.sessionId) {
      sessionId = pick.sessionId;
      reused = true;
      // 工作区被归档时，成员可能仍在 sessionIds 里但处于 archived 集合；先恢复再复用。
      // 名册指向的会话不在 workspace.sessionIds 时同样走这一步（把它重新加回工作区）。
      try { await client.workspaceUnarchiveSession({ sessionId }); } catch { /* 未归档时可能报错，忽略 */ }
    } else {
      const created = await client.create({ workspaceId: dshWorkspace.workspaceId });
      sessionId = created.sessionId;
      // 名册原本绑过别的会话 → 这是「换了这个人」，必须留轮换记录，不能静默覆盖。
      const priorRoster = String(rosterSessions.get(p.role) || '').trim();
      const priorManifest = String(manifestSessions.get(p.role) || '').trim();
      const prior = priorRoster || priorManifest;
      if (prior && prior !== sessionId) rotations.push({ role: p.role, from: prior, to: sessionId });
    }
    try { await client.rename({ sessionId, title: p.title }); } catch { /* 标题失败不影响 */ }
    let modelSelected = null;
    if (p.model) {
      try {
        modelSelected = await client.selectModel({ sessionId, provider: p.model.provider, model: p.model.model, reasoningEffort: p.model.reasoningEffort });
      } catch (e) {
        errors.push({ role: p.role, stage: 'model', message: e.message, code: e.code || '' });
      }
    }
    let prompted = false;
    if (!noPrompt && promptRoles.includes(p.role)) {
      try {
        await client.prompt({ sessionId, text: p.prompt, mode: 'queue' });
        prompted = true;
      } catch (e) {
        errors.push({ role: p.role, stage: 'prompt', message: e.message, code: e.code || '' });
      }
    }
    sessions.push({ role: p.role, name: ROLE_NAMES[p.role], title: p.title, sessionId, reused, reuseSource, prompted, model: p.model, modelSelected: Boolean(modelSelected) });
  } catch (e) {
    errors.push({ role: p.role, stage: 'create', message: e.message, code: e.code || '' });
  }
}

// B-20261118-080052-207b：新建替换必须留痕——会话轮换/<role>.json + 项目 会话轮换.jsonl +
// 事件 session_rotate(by=launch) + 旧会话标 retired/归档 + 广播重 boot。
// 放在写名册之前：任何「名册指向新会话但没有轮换记录」的状态都不允许出现。
const rotationResults = [];
for (const rot of rotations) {
  try {
    const built = buildRotation({
      role: rot.role, from: rot.from, to: rot.to, project,
      at: nowIso(), members: (loadTeam().members || []),
    });
    if (!built) continue;
    const rotateDir = path.join(projectStatePaths(project).dir, '会话轮换');
    fs.mkdirSync(rotateDir, { recursive: true });
    let oldArchived = false;
    try {
      await client.workspaceArchiveSession({ sessionId: rot.from, stopActivity: false });
      oldArchived = true;
    } catch (e) {
      errors.push({ role: rot.role, stage: 'archive-old', message: String((e && e.message) || e), code: e.code || '' });
    }
    const record = { ...built.record, archivedOld: oldArchived };
    writeJsonAtomic(path.join(rotateDir, `${rot.role}.json`), record);
    writeJsonAtomic(path.join(rotateDir, `${record.id}.json`), record);
    appendLine(path.join(projectStatePaths(project).dir, '会话轮换.jsonl'), JSON.stringify({ ...built.jsonl, archivedOld: oldArchived }));
    appendEvent({
      role: 'launch', sessionId: '', action: 'session_rotate', project, target: rot.role,
      note: `${rot.from} → ${rot.to}（launch 未找到可复用会话，新建后替换名册）`,
      data: { from: rot.from, to: rot.to, by: 'launch', mode: 'auto', created: true, archivedOld: oldArchived },
    });
    // 广播：本人去新会话 boot + 其余 active 成员重 boot（名册变更=全员旧令牌失效）
    const bcast = [];
    try {
      sendMessage({
        from: 'system', to: rot.role, project, type: 'notice',
        subject: `会话已更换：请在新会话 boot（${rot.role}）`,
        body: `${rot.role} 的会话已由「启动团队」新建替换：${rot.from} → ${rot.to}。\n请在新会话执行：node 团队\\工具\\team.mjs boot --role ${rot.role} --project ${project} --session ${rot.to}\n旧会话已标 retired${oldArchived ? '（已归档）' : '（归档失败，见 errors）'}。`,
      });
      bcast.push(rot.role);
    } catch (e) { errors.push({ role: rot.role, stage: 'broadcast-self', message: String((e && e.message) || e) }); }
    for (const other of built.broadcasts.others) {
      try {
        sendMessage({
          from: 'system', to: other, project, type: 'notice',
          subject: '名册已变更：请重新 boot（旧令牌已失效）',
          body: `${rot.role} 的会话已由 launch 替换（${rot.from} → ${rot.to}），团队名册随之变更，全员旧令牌失效。\n请重新执行：node 团队\\工具\\team.mjs boot --role ${other} --project ${project}`,
        });
        bcast.push(other);
      } catch (e) { errors.push({ role: other, stage: 'broadcast-other', message: String((e && e.message) || e) }); }
    }
    rotationResults.push({ role: rot.role, from: rot.from, to: rot.to, recordId: record.id, archivedOld: oldArchived, broadcasts: bcast });
  } catch (e) {
    errors.push({ role: rot.role, stage: 'rotation', message: String((e && e.message) || e) });
  }
}

// 空白会话在 DSH 工作区里不显示成员；按需发一句“已就位”，让成员可见。
const seedResults = [];
if (seedVisible) {
  for (const s of sessions) {
    const info = existingList.items.find((x) => x.sessionId === s.sessionId);
    if (info && info.blank === false) continue;
    try {
      await client.prompt({
        sessionId: s.sessionId,
        text: seedTextFor(s.role, s.name, project),
        mode: 'queue',
      });
      s.seeded = true;
      seedResults.push({ role: s.role, sessionId: s.sessionId, ok: true });
      // 逐个显示：等上一位的 turn 建立后再下一位，避免六个会话同时启动。
      await new Promise((resolve) => setTimeout(resolve, 1200));
    } catch (e) {
      seedResults.push({ role: s.role, sessionId: s.sessionId, ok: false, why: String(e.message || e).slice(-180) });
    }
  }
}

// 程序清理工作区自带的空白占位会话，避免“有工作区、成员为空”。
// 只处理 blank=true 且无标题的会话；不碰有标题/在跑的成员。
const createdSessionIds = new Set(sessions.map((s) => s.sessionId));
const cleanup = [];
try {
  const after = await client.workspaceCreate({ path: workspace });
  for (const sid of (after.workspace.sessionIds || [])) {
    if (createdSessionIds.has(sid)) continue;
    const info = existingList.items.find((x) => x.sessionId === sid);
    if (!info || !info.blank) continue;
    if (info.projections?.values?.title) continue;
    try {
      await client.workspaceArchiveSession({ sessionId: sid, stopActivity: false });
      cleanup.push({ sessionId: sid, action: 'archived_blank' });
    } catch (e) {
      cleanup.push({ sessionId: sid, action: 'archive_failed', why: String(e.message || e).slice(-180) });
    }
  }
} catch (e) {
  cleanup.push({ action: 'workspace_query_failed', why: String(e.message || e).slice(-180) });
}

// 程序写项目级会话清单：每个工作区自己的 sessionId，绝不手抄/不跨项目复用
const sessionManifest = {
  project,
  teamMode,
  workspace,
  workspaceId: dshWorkspace.workspaceId,
  generatedAt: nowIso(),
  roles: sessions.map((s) => ({
    role: s.role, name: s.name, title: s.title, sessionId: s.sessionId,
    reused: s.reused, model: s.model ? `${s.model.provider}/${s.model.model}` : '',
  })),
};
// B-20261118-163847-5e11：团队会话.json 与 session.mjs / roster-writer 是同一份状态（rotate 的恢复判定读它），
// 必须同口径原子写（json-atomic：tmp→fsync→bak→rename + 锁 + 审计），不得裸 fs.writeFileSync。
writeJsonAtomic(path.join(workspace, '团队会话.json'), sessionManifest, { case: 'launch-manifest', allowedRoots: [workspace] });
const sessionMd = [
  '# 团队会话（程序生成）',
  '',
  '> 由 `launch.mjs` 在每次建团队/换会话时写入；**不要手改**。每个工作区独立，sessionId 不复用其他项目。',
  '',
  `- 项目：${project}`,
  `- 团队模式：${teamMode}（${TEAM_MODE_LABELS[teamMode]}）`,
  `- 工作区：${workspace}`,
  `- workspaceId：${dshWorkspace.workspaceId}`,
  `- 生成时间：${sessionManifest.generatedAt}`,
  '',
  '| 角色 | 会话标题 | sessionId | 新建/复用 | 模型 |',
  '|---|---|---|---|---|',
  ...sessions.map((s) => `| ${s.name} | ${s.title} | \`${s.sessionId}\` | ${s.reused ? '复用' : '新建'} | ${s.model ? s.model.provider + '/' + s.model.model : '—'} |`),
  '',
].join('\n');
// 展示件（.md）：只给人看、不参与任何判定，保留裸写（非状态文件，无需原子写语义）。
fs.writeFileSync(path.join(workspace, '团队会话.md'), sessionMd, 'utf8');
let indexRefreshed = false;
try {
  const ir = spawnSync(process.execPath, [path.join(PATHS.teamRoot, '工具', 'team.mjs'), 'index', '--project', project, '--json'], { encoding: 'utf8', timeout: 60000 });
  indexRefreshed = ir.status === 0;
  if (!indexRefreshed) errors.push({ role: 'system', stage: 'index', message: (ir.stderr || ir.stdout || 'index 失败').slice(-400) });
} catch (e) {
  errors.push({ role: 'system', stage: 'index', message: String(e.message || e).slice(-400) });
}

// 轮换记账失败的 role 一律**不写名册**：宁可不换人，也不允许「名册指向新会话但没有轮换记录」。
const rotationFailedRoles = new Set(rotations.map((r) => r.role).filter((role) => !rotationResults.some((x) => x.role === role)));
if (rotationFailedRoles.size) {
  for (const role of rotationFailedRoles) {
    const s = sessions.find((x) => x.role === role);
    if (s) s.rosterSkipped = 'ROTATION_RECORD_FAILED';
  }
}

// 回填已有成员的 sessionId；可选把新角色加进 roster（唯一赋值/入册入口在 lib/roster-writer.mjs，AC-W1）
mutateTeam((t) => {
  for (const s of sessions) {
    if (rotationFailedRoles.has(s.role)) continue;
    const member = setMemberSession(t, s.role, s.sessionId);
    if (!member && addMembers) {
      pushRosterMember(t, { role: s.role, name: ROLE_NAMES[s.role] || s.role, status: 'active', joinedAt: nowIso(), sessionId: s.sessionId });
    }
  }
  return t;
});

// 明确选择的工作区：切换 activeProject + 当前工作区，避免“建团队默认当前”
setActiveProject(project);
let wsMeta = {};
try { wsMeta = JSON.parse(fs.readFileSync(path.join(workspace, 'workspace.json'), 'utf8').replace(/^\uFEFF/, '')); } catch { /* legacy workspace */ }
const currentWorkspace = {
  ...wsMeta,
  version: wsMeta.version || 1,
  name: project,
  path: workspace,
  dshWorkspaceId: dshWorkspace.workspaceId,
  engineUrl: engineUrl || wsMeta.engineUrl || null,
  dshCreated: Boolean(workspaceResult.created),
  reused: !workspaceResult.created,
  updatedAt: nowIso(),
};
writeJsonAtomic(path.join(PATHS.state, '当前工作区.json'), currentWorkspace);

const record = { generatedAt: nowIso(), workspace, workspaceId: dshWorkspace.workspaceId, dshWorkspaceCreated: workspaceResult.created, project, teamMode, restoreMode, seedVisible, seedResults, noPrompt, promptRoles, addMembers, sessions, errors, cleanup, indexRefreshed, sessionManifest, currentWorkspace, rotations: rotationResults };
const file = path.join(PATHS.state, '会话.json');
writeJsonAtomic(file, record);
appendEvent({
  role: 'owner', sessionId: 'launch', action: 'launch_sessions', project,
  target: roles.join(','), note: `mode=${teamMode} created=${sessions.length} errors=${errors.length} prompt=${!noPrompt} addMembers=${addMembers}`,
  data: { sessions, errors, file, teamMode },
});

if (args.json) jsonOut({ ok: errors.length === 0, ...record, file });
else {
  textOut(`已创建/恢复 ${sessions.length}/${plan.length} 个会话（${TEAM_MODE_LABELS[teamMode]}；${noPrompt ? '空会话，未发启动卡' : '仅唤醒：' + promptRoles.join(',')}）`);
  if (seedResults.length) textOut(`已让 ${seedResults.filter((x) => x.ok).length}/${seedResults.length} 个空白成员显示（发了一句“已就位”）`);
  if (cleanup.length) textOut(`清理占位会话 ${cleanup.filter((x) => x.action === 'archived_blank').length} 个`);
  for (const s of sessions) textOut(`- ${s.title}  ${s.sessionId}${s.prompted ? '  [已启动]' : ''}`);
  if (errors.length) {
    textOut('\n失败：');
    for (const e of errors) textOut(`- ${e.role} ${e.stage}: ${e.message}`);
  }
  textOut(`\n记录：${file}`);
  if (!noPrompt) textOut('提示：默认只唤醒 PM；仅在全队空转演练时才加 --prompt-all。');
}

function out(obj) {
  if (args.json) jsonOut(obj);
  else {
    textOut(`DRY RUN · ${obj.plan.length} 个会话 · ${obj.project} · ${obj.teamMode} · ${obj.workspace}`);
    for (const p of obj.plan) textOut(`- ${p.title}（${p.role}）${p.inRoster ? ' [已在 roster]' : ' [未入 roster]'}`);
    textOut(`engine: ${obj.engineUrl}`);
  }
}
