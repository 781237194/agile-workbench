# DSH 壳模型审计

> 审计对象：旧壳 `D:\deepseek\luanyujia-workbench\12-源码照搬\外壳\`（任务描述中的 `shell\renderer`，实际目录名是 `外壳\renderer`）与 `D:\deepseek\工作台\团队\`；新壳 `D:\deepseek\agile-workbench\`。
>
> 审计方式：只读源码、状态文件与协议/角色文档；未启动程序、未执行构建、未修改 `src/`、`package.json` 或旧仓库。本文是唯一写入文件。
>
> 快照：2026-11-05 04:2x。旧壳 `main.js` 67,864 B、`renderer/app.js` 90,670 B、`renderer/index.html` 7,532 B；新壳 `src/main.js` 135,431 B、`src/renderer/app.js` 95,659 B、`src/renderer/index.html` 21,239 B。新仓库在审计期间仍在被并行重写，行号以本快照为准，定稿前请按函数名复核。
>
> 结论一句话：**旧版是“DSH 工作区做底座、项目 = 工作区、一个角色 = 一个会话、消息走文件邮箱 + 回执、看板/流程浮在 DSH 上”的壳；新壳把本地项目库、任务、提案、流程做成了主界面和事实来源，DSH 降级成一个可切换的外部视图。这就是“独立项目管理系统”偏离的来源。**

---

## 0. 两套模型总览

| 维度 | 旧版（壳模型） | 新壳（当前实现） | 判定 |
|---|---|---|---|
| 启动底座 | `#engine-webview` 首屏加载 DSH；场景/项目是覆盖页签 | `#app` 本地项目页是根；DSH 是 `#dsh-shell` 的另一个场景 | **偏离** |
| 项目身份 | 一个目录 = 一个 DSH workspace；`workspace.json` 的 `dshWorkspaceId` 是硬绑定 | `workbench.json` 的 `P-xxxx` 是主键；`dshWorkspaceId` 可空，等建团队时才补 | **偏离** |
| 六角色 | 六个 DSH 会话，标题 `团队·<角色>`，按 workspace 的 `sessionIds` 复用 | 仍是六个会话，但角色页读本地 `project.sessions`；还有绕过 `launch.mjs` 的直连路径 | **部分保留 / 有分叉** |
| 项目切换 | 走「建团队/恢复」→ `launch.mjs` 写 `当前工作区.json` + `setActiveProject` | 左侧项目列表 → `project:select` 只改本地 `activeProjectId` | **断裂** |
| 消息 | `send → 邮箱/<role>/new → inbox/read/ack → 回执.jsonl`，全部要 `--boot` | `team:send` 写 `workbench.json.messages` + 直接 prompt；回执由人点按钮代记 | **自造，不再是旧协议** |
| 派单锁 | `团队/状态/项目/<name>/派单锁.json`，ack 才清 | 本地 `project.pendingAck`，10 分钟 TTL 自动释放 | **协议漂移** |
| 看板 | `team.mjs board` 生成 `看板.html`，独立置顶半透明窗口悬浮在 DSH 上 | `shell.openPath` 丢给系统浏览器；本地还有一个四列任务看板页 | **偏离** |
| 流程 | 读 `工作流.json/任务/提交/需求`，`fs.watch` 推送，浮窗 + Owner 决定自动发 PM 收件箱 | 读本地 `tasks`，8 阶段，整页 `#view-flow`；Owner 决定只写本地库，`notified:null` | **偏离** |
| 状态真相 | 团队/状态 + workspace 目录 + DSH registry 三源合并 | `workbench.json` 是业务真相；团队状态只被 `ensure/launch/board` 局部调用 | **双真相** |

---

## 1. 启动：先 DSH 还是先项目页

**结论：旧版先 DSH，新版先项目页。** 旧版首屏就是 `#engine-webview`，项目页只是点开的一个场景页签；新版首屏是 `#app` 本地项目页，DSH 在线时才在 boot 末尾切过去。

### 1.1 旧版：DSH 是首屏，项目页只是场景页签

证据链：

1. `外壳/main.js:952` `createWindow()` 创建主窗口，唯一加载的是 `renderer/index.html`（`:971`），`webviewTag: true`（`:965`）。
2. `外壳/renderer/index.html:66` 首屏就是引擎视图：
   ```html
   <section id="engine-view" class="view active">
     <webview id="engine-webview" src="about:blank" partition="persist:harness" allowpopups></webview>
   ```
   `:68` 是离线提示 `#engine-off`，`:73` 是 `#engine-retry`。
3. `外壳/renderer/app.js:17` 初始 `state = { ..., view: 'engine' }`；`loadScenarios()`（`:1801`）最后调用 `showView()`（`:498`）；`showView()` 在 `state.view === 'engine'` 时执行 `loadEngine()`（`:504`）。
4. `loadEngine()`（`app.js:1400-1424`）：
   - `API.app.config()` 取地址；
   - `wv.src = url`；
   - 只有 `did-fail-load` 才显示 `#engine-off`。
5. `app:config`（`main.js:163-174`）先读 `config.json` / `config.local.json`，但最后用 `ensureEngine()` 的结果覆盖 `engineUrl`：
   - `resolveEngine()`（`:139-157`）扫描 `DeepSeek Harness.exe` 的监听端口；
   - 从 `~/.dsh/.credentials.yaml` 读 `browser-session` secret；
   - `mintEngineCookie()`（`:108-116`）生成 cookie；
   - 验证首页长度和 `<base href="./">`；
   - 把 cookie 写进 `persist:harness` 分区（`:150-151`）。
6. 场景/项目页签是叠加层，不是底座：`renderTabs()`（`app.js:468-488`）第一个 tab 是「DeepSeek Harness」，之后才是 `scenarios/*`；`showView()`（`:498-506`）在 `#engine-view` 和 `#scenario-view` 之间互斥切换。所谓「项目总览」就是 `scenarios/projects.json` 里的一个场景，由 `renderProjectCards()`（`app.js:768-809`）在场景网格里画卡片，点卡片只是打开 `项目索引.md`，不改变工作区。

**旧版启动顺序：建窗 → 加载 `index.html`（首屏 webview）→ 探测并载入 DSH → 用户点场景 tab 才看到项目页。**

### 1.2 新壳：先渲染本地项目页，DSH 只是可切换场景

证据链：

1. `src/main.js:1847` `createWindow()` 加载 `src/renderer/index.html`（`:1857`），主窗口本身没有指定初始 URL 的 webview。
2. `src/renderer/index.html:109` 的 `#app` 是常规根布局；`:84` 的 `#dsh-shell` 带 `hidden`；`:93` 的 `#dsh-view` 只是 `#dsh-shell` 内部的 webview：
   ```html
   <div id="dsh-shell" hidden>
     ...
     <webview id="dsh-view" src="http://127.0.0.1:52711" allowpopups></webview>
   ```
3. `src/renderer/app.js:2082` 的 `boot()`：
   ```js
   bind();
   await refresh();        // 先读本地 workbench.json，渲染项目页
   warnStore();
   await initDsh();        // 之后才探测 DSH
   ...
   let mode = 'dsh';
   try { mode = localStorage.getItem('awb.mode') || 'dsh'; } catch { }
   if (mode === 'dsh' && state?.dsh?.online) showDshView(true, { probe: false });
   else showDshView(false);
   ```
   `refresh()`（`:313-324`）调用 `window.workbench.state()`，即 `app:state`（`main.js:601-615`），返回的是 `workbench.json` 的 `projects`，不是 DSH 工作区。
4. `showDshView()`（`app.js:1519-1540`）只是把 `#app.hidden` 和 `#dsh-shell.hidden` 对调：
   ```js
   app.hidden = Boolean(on);
   shell.hidden = !on;
   ```
5. 新壳没有旧版的端口扫描/cookie 自动注入。`src/main.js:75` 直接把 `dsh` 初始化为 `process.env.DSH_WEB_URL || 'http://127.0.0.1:52711'`；`installDshCookie()`（`:2619-2629`）只对当前 `baseUrl` 生成一次 cookie。DSH 换端口后 webview 不会自动重连，需要 `dsh:configure` 手工改地址（`app.js:1542`）。
6. `app:state` 的字段顺序也说明重心：`projects`、`activeProjectId`、`defaultRoot`、`dsh`、`team`（`main.js:601-615`）——本地项目库是第一等公民，DSH 只是状态字段。

**新壳实际启动顺序：建窗 → 渲染本地项目页（`#app`）→ 探测 DSH → 在线才切到 `#dsh-shell`；DSH 离线则停在项目页。项目页不是覆盖层，是底座。**

### 1.3 偏离判定与修正要求

- **偏离**：旧版 DSH 离线时仍停在 DSH 视图，用 `#engine-off` 提示重试；新壳 DSH 离线时直接展示完整项目管理系统，用户自然把工作台当独立项目工具。
- **修正**：`#dsh-view` 必须是主窗口的常驻底层，启动即 `loadURL`；`#app` 改成覆盖在 webview 之上的顶栏/抽屉/浮层。项目页不能和 DSH 互斥切换，只能“叠加/收起”。
- 旧版的 `resolveEngine()` / `mintEngineCookie()` / `persist:harness` 必须恢复；DSH 端口不能写死 `52711`。

---

## 2. 一个项目如何映射一个 workspace

### 2.1 旧版：目录 → DSH workspace → 项目登记，三处同一身份

旧版是“先有目录，再用 DSH 注册，再把 workspaceId 写回项目元数据”，链条如下：

1. **建目录 + 注册 DSH workspace**：`团队/工具/workspace.mjs:270` `main()` 的 `create` 分支：
   - `:279` `target = path.join(root, project)`；
   - `:308` 注释写明「一个工作台 = 一个项目 = 一个目录」；
   - `:309-314` 同名目录或同名登记一律 `WORKSPACE_EXISTS`，只能走「建团队/恢复」；
   - `:347-352` `new DshClient(...).workspaceCreate({ path: target })` 拿到 `workspaceId`；
   - 注册失败时回滚空目录并 `DSH_WORKSPACE_CREATE_FAILED`（`:353-358`）。
2. **写项目元数据**：`workspace.mjs:208-247` `scaffold()` 建六角色目录、`协作准则.md`、`项目信息.md`、`项目索引.md`、`项目铁律.md`、`需求/`、`site/`、`_tmp/`，并写 `workspace.json`：
   ```json
   { "name": ..., "path": ..., "dshWorkspaceId": ..., "engineUrl": ..., "roles": [...], "limits": {...} }
   ```
   （`:234-245`）
3. **写团队登记**：`workspace.mjs:249-266` `registerTeamProject()` 写 `团队/状态/项目/<项目名>/项目.json`，字段含 `name/path/dshWorkspaceId/entry/index/status`，并 `setActiveProject(project)`。
4. **写当前工作区**：`workspace.mjs:360-364` 写 `团队/状态/当前工作区.json`，内容就是 `workspace.json` 的元数据 + `dshCreated/reused`。
5. **建团队时再确认一次**：`launch.mjs:88-99` 对 `--workspace` 调用 `workspaceCreate({ path: workspace })`，把返回的 `workspace.sessionIds` 当作“这个工作区允许复用的会话白名单”，并把真实 `workspaceId` 回写 `workspace.json`。
6. **项目清单按路径去重**：`main.js:525-572` `team:workspaces` 从三个来源合并：
   - `团队/状态/项目/*/项目.json`；
   - `工作台/项目/*` 目录（有 `workspace.json` 用它的 name/path/dshWorkspaceId）；
   - `~/.dsh/storages/workspace.json` 里的所有 DSH 工作区（`:556-563`）。
   用 `path.resolve(p).toLowerCase()` 去重（`:529-534`），`current` 只认 `当前工作区.json` 的 path（`:564-570`）。

**结论：旧版的一个“项目”不是一条数据库记录，而是“磁盘目录 + DSH workspaceId + 团队项目登记”三者同路径、同名字、同 id。** 这也是为什么 `workspace.mjs` 拒绝同名不同目录（`:308-314`），`team:openProject` 也要查 `项目.json` 的 path 冲突（`main.js:669-677`）。

### 2.2 新壳：先建本地项目记录，DSH workspace 可以不存在

证据链：

1. `src/main.js:634-672` `createProject()`：
   - `:641-646` 只查本地 `store.projects` 的 path/name 冲突；
   - `:653-657` 自己 `mkdir` 六角色目录、`src/`、`_tmp/`、`需求/`；
   - `:658-661` 自己写一个简化版 `项目信息.md`（只有目标/交付/边界）和 `README.md`；
   - `:662-670` 往 `workbench.json` 的 `projects[]` push 一条 `{ id: 'P-xxxx', name, path, tasks, messages, proposals, ... }`，并设 `activeProjectId`。
   这条路径**完全不调用** `DshClient.workspaceCreate`。另外，旧 `workspace.mjs` 的代码目录是 `site/`（`workspace.mjs:224`），新 `createProject` 建的是 `src/`（`main.js:655`），`ROLES` 的 scope 也写 `src/ + 程序员A/`（`main.js:57-58`），与旧角色卡/流程的 `site/**` 不一致。
2. `src/main.js:910-922` `project:create` 在 `createProject()` 之后才 `syncTeamProject(p)`；`syncTeamProject`（`:28-35`）调用 `teamTools.ensureProject`，最终跑 `workspace.mjs ensure`（`team-tools.js:449-509`）。
3. `workspace.mjs:292-305` 的 `ensure` 分支只做三件事：读旧 `dshWorkspaceId` → `scaffold(..., { overwrite: false })` → `registerTeamProject` + `generateIndex`。**它从不调用 `workspaceCreate`**。所以新建项目后 `workspace.json.dshWorkspaceId` 是 `null`，`项目.json.dshWorkspaceId` 也是 `null`，直到某次 `launch.mjs` 才补上。
4. `team:workspace:create`（`main.js:1262-1337`）也没有走旧 `workspace.mjs create`；它先 `createProject()`，再 `syncTeamProject()`。旧壳“没有引擎就不给建工作区”的硬闸门（旧 `main.js:756-758`）在新壳不存在。
5. `project:adopt`（`main.js:962-999`）对任意带 `项目信息.md` 的目录建本地记录，同样不注册 DSH workspace；`team:open-project`（`:1213-1260`）接受任意目录，但**不写本地 store**，所以打开后项目页仍然看不到这个项目。
6. 新壳的 `workflowSnapshot()`（`main.js:792-813`）把 `workspace` 直接写成 `path.resolve(project.path)`，不读 `workspace.json`，也不校验 `dshWorkspaceId`。

**结论：旧版的 1:1 是强制的；新壳变成“一个本地项目记录可以没有 DSH workspace”，甚至在 `launch` 之前是 1:0。** 这会让“项目”先在本地成立，DSH 只是后来被拉来实现会话，模型反了。

### 2.3 修正要求

- 新建项目必须走 `workspace.mjs create`（或至少先 `workspaceCreate` 再落库）；拿不到 `dshWorkspaceId` 就不允许写 `projects[]`。
- `workspace.json`、`团队/状态/项目/<name>/项目.json`、`当前工作区.json` 是项目身份的三处落点；`workbench.json` 只能做 UI 投影/窗口状态，不能做项目主键。
- `project:adopt`/`project:discover` 要么删除，要么改成 `team:openProject` / `team:restore` 的薄包装；不能自己造 `P-xxxx`。
- 恢复项目清单必须重新接入 DSH registry（`~/.dsh/storages/workspace.json`），否则旧项目/外部 workspace 不可见。

---

## 3. 六个会话如何创建、复用、显示

### 3.1 旧版：`launch.mjs` 是唯一创建者

`团队/工具/launch.mjs` 的完整生命周期：

| 阶段 | 代码 | 行为 |
|---|---|---|
| 角色计划 | `:53-66` | 六个 role 固定；标题 `团队·${ROLE_NAMES[role]}`；模型 `deepseek-account/deepseek-flash`，`reasoningEffort: max` |
| 工作区 | `:88-99` | `workspaceCreate({ path: workspace })`；`activeSessionIds = dshWorkspace.sessionIds`；真实 `workspaceId` 回写 `workspace.json` |
| 复用判定 | `:100-107` | 只复用同时满足三个条件的会话：① id 在 `dshWorkspace.sessionIds`；② `cwd` 等于 workspace；③ 有 `projections.values.title`。archived 历史会话不算成员 |
| 创建 | `:110-124` | 没有可复用才 `client.create({ workspaceId })`；然后 `rename(title)`；`selectModel(...)` |
| 可见化 | `:148-168` | `--seed-visible` 时逐个给空白会话发“已就位”，每发一个 `await 1200ms`，避免六个人同时启动 |
| 清理占位 | `:170-190` | 只归档 `blank=true` 且无标题的会话，不碰有标题/在跑的成员 |
| 清单 | `:192-219` | 写 `<workspace>/团队会话.json` 和 `团队会话.md`，含 `workspaceId` 与每个角色的 `sessionId/reused/model` |
| 团队记账 | `:229-254` | 回填 `团队.json` 的 `members[].sessionId`；`setActiveProject`；写 `当前工作区.json` |

显示侧：`main.js:477-489` `team:members` 只读 `<当前工作区 path>/团队会话.json`，返回 `roles[]`；旧渲染层 `mountMembers()`（`app.js:1640-1665`）把它渲染成 `member-row`，并说明“DSH 左侧默认不显示空白会话，需要逐个发‘已就位’”。

协议侧：`团队/协议/01-会话与必读.md` 明确：
- 「一个角色 = 一个会话」；
- 「每个工作区独立建六角色会话，sessionId 是动态值，不能写死」；
- 「同一工作区重复点建团队会按标题复用；不同工作区不会复用其他工作区 ID」；
- `团队.json.members[].sessionId` 只表示当前工作区。

### 3.2 新壳：创建逻辑部分保留，但显示/持久化另起一套

1. `src/main.js:173-246` `provisionTeamSessions()`：
   - 先读本地 `project.sessions`；
   - 用 `dsh.listSessions()` 核对，幽灵会话从本地删掉（`:178-194`）；
   - 只把 `missing` 角色传给 `teamTools.launchSessions`（`:205-218`）；`launchSessions` 最终仍跑 `launch.mjs`（`team-tools.js:770-884`），所以标题、模型、复用、seed 这些核心行为还在。
   - `:219` 成功后 `persistTeamLaunch(projectId, result)` 把 `sessionId` 写回 `workbench.json`。
2. `persistTeamLaunch()`（`main.js:38-52`）写的是 `current.sessions[role]`、`teamWorkspace`、`dshWorkspaceId`，不是 `团队会话.json`。
3. `team:members`（`main.js:1065-1101`）仍读 manifest，但渲染层 `renderRoles()`（`app.js:698-735`）用的是 `p.sessions`：
   ```js
   const sessions = p.sessions || {};
   const ready = state.roles.filter((r) => sessions[r.id]).length;
   ...
   <div class="role-session">${sessions[r.id] ? 'DSH · ' + ... : 'DSH 会话未创建'}</div>
   ```
   也就是说「角色页」显示的是本地缓存，不是 `团队会话.json`。
4. `provisionDirect()`（`main.js:91-166`）是绕过 `launch.mjs` 的兜底：
   - 标题是 `${project.name} · ${role.name}`（`:118`），不是旧版的 `团队·<角色>`；
   - 不调用 `selectModel`；
   - 不写 `团队会话.json`；
   - 不 `setActiveProject` / 不写 `当前工作区.json`；
   - 不做 `seedVisible`。
   只要 `teamTools.toolInfo().available === false` 就会走这条路（`:175-176`），模型、标题、清单、当前工作区全部漂移。
5. 新壳 UI 的「建团队」并没有调用兼容旧形状的 `team:launch`：`#btn-team-start` 绑定的是 `startTeam()`（`app.js:1815`、`:2030-2043`），后者直接 `dshProvision({ projectId })`。`teamLaunch` 在 renderer 中没有任何调用点。
6. `team:restore` 的持久化也有缺口：`main.js:1193` 只在 `stored` 存在时 `persistTeamLaunch(stored.id, result)`。按名字恢复一个**不在本地 store** 的项目时，`launch.mjs` 已经建好六个会话，但 `workbench.json` 没有记录；随后 `refresh()` 的角色页仍然显示“DSH 会话未创建”，再点「启动团队」会重复走一遍。

### 3.3 偏离判定与修正要求

- **保留**：`launch.mjs` 的 `workspaceCreate → 按 title/cwd/sessionIds 复用 → rename → selectModel → seedVisible → 团队会话.json` 这条链是正确的，必须继续做唯一创建者。
- **删除/禁用**：`provisionDirect()` 与 `dsh:provision` 的直连兜底；`createSessionOnce()` 只应在 `launch.mjs` 不可用时明确报错，而不是静默降级。
- **统一显示**：角色页、成员弹窗、`team:members` 全部读 `<workspace>/团队会话.json`；`workbench.json.sessions` 只能是缓存，且必须在 manifest 缺失时回退读取。
- **恢复即记账**：`team:restore`/`team:open-project` 即使项目不在本地 store，也要把 manifest 投影到当前 UI，或强制先 `adopt` 再恢复，不能留下“会话已建、页面说没有”的中间态。

---

## 4. 会话之间的消息、派单、回执、inbox/read/ack

### 4.1 旧版：文件邮箱 + 启动令牌 + 回执链

旧版不是“UI 里记一条消息”，而是完整的多会话文件协议：

1. **命令入口**：`团队/工具/team.mjs:19-23` 暴露 `send/inbox/read/ack`；`ops.mjs:36-40` `bootFor()` 要求 `--boot` 令牌，且令牌的角色/项目必须匹配。
2. **令牌**：`store.mjs:307-326` `createBootToken()` 把 `role/project/sessionId/rulesHash/docHashes/projectIndexHash` 写进 `团队/状态/启动/<token>.json`（`PATHS.boots`，`core.mjs:27`），默认 30 分钟；`store.mjs:328-345` `requireBoot()` 校验存在、过期、角色、项目、`rulesHash`（宪法/铁律/角色卡/成员表一变就 `RULES_CHANGED`）。
3. **发消息**：`ops.mjs:339-412` `cmdSend()`：
   - `--to` 可以是任意 active 成员；
   - `--ack` 标记要回执；
   - PM 带 `--ack` 派单时写 `派单锁.json`（`dispatchLockPath` `:320-321`，检查 `:347-353`，写锁 `:373`）；上一条未回执直接 `PM_DISPATCH_PENDING`；
   - `--task` 时顺手把 task.owner 定成目标角色（`:354-368`）；
   - `--ack`/`--wake` 会通过 `DshClient.prompt` 唤醒目标会话（`:374-409`），唤醒文本明确要求：
     ```
     1) boot --role <to> --project ...
     2) inbox --all，再 read --id M-...
     3) ack --id M-... --note "已收到 ... + 边界"
     4) task claim ...
     ```
4. **落盘**：`store.mjs:347-380` `sendMessage()` 写
   `团队/状态/邮箱/<to>/new/<ts>-M-xxxx.json`，字段 `id/from/to/subject/body/project/task/ackRequired/type/replyTo/ts`；正文上限 600 字（`team.config.messageMaxChars`）。
5. **收件箱**：`store.mjs:382-397` `listInbox()` 默认只读 `new/`，`--all` 才带 `cur/`；`ops.mjs:414-421` `cmdInbox()` 输出表格。
6. **已读**：`store.mjs:417-429` `readMessage()` 把文件从 `new/` 移到 `cur/`，返回 `alreadyRead`；`ops.mjs:423-429` `cmdRead()` 写 `mail_read` 事件。
7. **回执**：`store.mjs:435-475` `ackMessage()`：
   - 校验回执 ≤300 字；
   - 查重（同一 `msgId + from` 只记一次）；
   - 写 `团队/状态/回执.jsonl`（`A-xxxx`，含 `msgId/from/to/project/note/log/ts`）；
   - 给原发件人发一条 `type:'receipt'` 的消息，且 `ackRequired:false`，避免“回执→回执”递归（`:457-469`）。
8. **解除派单锁**：`ops.mjs:431-441` `cmdAck()` 调 `clearDispatchLock(r.msg.project, id)`，只有回执才清锁。
9. **协议文本**：`团队/协议/02-消息任务回执.md:14-16` 明确「重要消息带 `--ack`；收到先 `read`，办完 `ack`；ack 自动给发件人回一条回执消息并写 `回执.jsonl`；没有回执 = 没发生」。`团队/流程.md:27-43` 给出完整回执链（Owner→PM→需求→产品→Owner→开发→测试→收口）。

**旧版的核心：消息不是 UI 状态，而是收件人邮箱里的一个文件；回执不是操作员代填，而是收件会话用 `--boot` 令牌执行 `ack` 后自动回信并落账。**

### 4.2 新壳：本地消息数组 + 直接 prompt + 人工代记回执

1. `src/main.js:1677-1729` `team:send`：
   - 从 `readStore()` 取项目；
   - `role` 来自 `p.role || p.to`，且 `ROLE` 里不能是 `pm`（`:1683`）——**发送者被硬编码为 `from:'pm'`**（`:1694`）；
   - 生成 `message = { id: 'M-...', from:'pm', to:role, ..., ack:false }`，push 进 `project.messages`（`:1693-1700`）；
   - `pendingAck` 是本地字段（`:1704-1706`），不是 `派单锁.json`；
   - 唤醒用 `dsh.prompt(sessionId, "【团队派单 ...】...")`（`:1714-1718`），文本只有一句“完成后回执”，**没有 `boot`、`inbox`、`read`、`ack --id` 的指令，也没有把消息写进目标邮箱**。
2. `src/main.js:1739-1761` `team:ack`：
   - 由 UI 弹窗（`app.js:766-787` `openAckModal`）让操作员输入回执；
   - 直接把 `message.ack = true` 写回 `workbench.json`；
   - 不校验是谁回的、不回发给发件人、不写 `回执.jsonl`。
3. `src/renderer/app.js:737-764` `renderDispatch()` 只渲染本地 `project.messages`；`#dispatch-role` 过滤掉 `pm`（`:741`），所以**角色之间（A↔B 互审、测试→PM、需求→产品）无法通过 UI 发消息**。
4. `openWakeModal()`（`app.js:789-814`）走 `dshPrompt` 发任意文本，不产生 message、不加锁、不要求 ack；它和旧版 `send --ack` 不是同一件事。
5. 消息上限也变了：新 `team:send` 正文 `slice(0,1000)`（`main.js:1696`），旧协议是 600 字（`store.mjs:358`、`协议/02:51`）。
6. 没有 inbox/read UI，也没有任何 `团队/状态/邮箱` 的读写。`rg "inbox|邮箱|回执\\.jsonl|--boot|派单锁" src/` 只在注释和自测里出现，业务路径为 0。

**直接后果**：如果目标角色按旧协议执行 `team.mjs ack --id M-...`，会得到 `MESSAGE_NOT_FOUND`——因为这条 `M-...` 只存在于 `workbench.json`，不在它的 `邮箱/<role>/new/` 里（`store.mjs:441`）。新壳的“回执”只是操作员在 UI 上点了一下，不是收件会话的协议回执。

### 4.3 偏离判定与修正要求

- **删除**：`project.messages`、`project.pendingAck`、`team:send/cancel/ack` 的本地实现，以及 `#dispatch-*` 那套“人选角色 + 手填回执”的 UI。
- **恢复**：`team:send` 必须 spawn `team.mjs send --boot ... --to ... --ack`（或提供一个等价的、带 boot 令牌的桥）；消息必须落到 `团队/状态/邮箱/<role>/new/`；回执必须由收件会话 `ack` 产生 `回执.jsonl` 并回信；`派单锁.json` 由工具维护。
- **UI**：新增「收件箱」视图，按角色显示 `inbox`、`read`、`ack`；发送端允许任意角色（不只是 PM），支持 `--task`、`--subject`、`--body`、`--ack`。
- **兼容**：`team:send` 的返回要包含 `message.id` 和 `wake`，前端不应自己拼 `M-...`。

---

## 5. 团队看板/流程如何“浮在 DSH 上”

### 5.1 旧版：独立置顶窗口 + 可拖拽浮窗

1. **看板是独立 BrowserWindow，不是页面**：`main.js:247-271` `openTeamBoard()`：
   - 复用 `teamBoardWin`，存在则 `loadFile` + `show` + `focus`（`:249-254`）；
   - 新建时：`width:1120, height:780`、`frame:false`、`transparent:true`、`alwaysOnTop:true`、`backgroundColor:'#00000000'`、`opacity:0.94`（`:255-266`）；
   - `setAlwaysOnTop(true, 'floating')`（`:267`）；
   - `loadFile(团队/看板.html)`（`:268`）。
2. **看板生成**：`main.js:574-583` `team:board` 跑 `team.mjs board --json`，然后 `openTeamBoard()`；`team:board-project`（`:585-597`）切换项目后重新 `loadFile` 并 `focus`，且看板头部明确写「切换项目不会改变工作台当前项目」。
3. **窗口控制**：`main.js:624-651` `team:board-control` 支持 `collapse`（收成 320×64）、`expand`、`maximize`、`minimize`、`close`、`zoom-in/out`；`board-preload.js:4-8` 暴露 `boardWin.control/selectProject/openFile`；看板 HTML 自带 `.board-chrome` 和 `[data-win="collapse"]` 等按钮（`团队/工具/lib/board.mjs:158`）。
4. **看板内容来自团队状态**：`board.mjs` 渲染需求/进行中任务/提案（含评审、签字、提交）/回执/项目文件/成员/质量/日志（`看板.md` 的八节）；`team:board-file`（`main.js:599-622`）只允许预览工作台内 ≤4MB 的文件，并区分文本/图片/外链。
5. **流程是主窗口里的浮窗**：`renderer/index.html:83-116` `#flow-launcher` + `#flow-panel`；`app.js:1669-1798` `mountFlow()` 负责拖拽（`:1782-1795`）、关闭、Owner 评审弹窗、阶段高亮。
6. **流程数据不是本地任务**：`main.js:451` `workflow:get` → `computeWorkflow()`（`:377-430`）读：
   - `团队/状态/项目/<name>/工作流.json`；
   - `任务/*.json`；
   - `<project>/需求/R-*.md`；
   - `提交/*.json`。
   然后算出 `stage/ownerReview/counts/roundKey`。`startFlowWatch()`（`:432-450`）用 `fs.watch(..., { recursive:true })` 监听状态目录，220ms 去抖后向所有窗口发 `workflow:changed`；渲染层 `API.team.onWorkflow()`（`app.js:1773`）收到后刷新。
7. **Owner 决定会进 PM 收件箱**：`main.js:452-475` `workflow:owner` 写 `工作流.json`，然后 `runNode(OWNER_NOTE, ...)`；`owner-note.mjs:14-19` 用 `sendMessage({ from:'system', to:'pm', type:'owner-review', ackRequired:true })` 把决定写进 PM 邮箱。

**旧版是“DSH 主窗口 + 一个置顶看板窗口 + 一个主窗口内浮动的流程面板”，三层叠在一起；看板和流程都不占用主界面页签。**

### 5.2 新壳：看板丢给系统浏览器，流程变成整页

1. `src/main.js:1339-1358` `team:board` 生成后：
   ```js
   opened = await shell.openPath(result.boardPath);
   ```
   ——直接交给系统默认浏览器/编辑器，不是 Electron 窗口，没有 `alwaysOnTop`、没有透明度、没有折叠/缩放控制。`team:board-project`（`:1360-1371`）也只生成，不再 `loadFile/focus` 已有窗口。`#btn-team-board-old`/`team:board-old`（`main.js:1398-1405`）同样走 `shell.openPath`，只是“能打开旧看板”，不是“旧看板悬浮”。
2. 新壳 `preload.js` 完全没有 `team:board-control` / `team:board-file`；`src/main.js` 里也没有 `alwaysOnTop` / `board-preload`，更没有用于看板的 `BrowserWindow`。
3. 新壳却有本地看板页：`index.html:214-223` `#view-board`，`.board` 四列；`app.js:532-586` `renderBoard()` 读 `project.tasks` 的 `todo/doing/review/done`。这和旧 `team.mjs board` 的八节看板不是同一份数据。
4. 流程变成整页：`index.html:225-244` `#view-flow`，`app.js:587-686` `flowMarkup()` 用本地 `project.tasks` 和 8 个阶段画图；`deriveStage()`（`main.js:556-568`）只认 `intake/requirement/review/owner/dispatch/dev/test/close`，**没有旧版的 `devreview`（互审/对账）和 `iterate`（迭代）**。
5. 浮窗 `#flow-panel`（`index.html:311-320`）还在，但 `renderFlow()` 渲染的是同一份本地状态（`app.js:657-686`），不是 `computeWorkflow()` 的团队状态。
6. Owner 决定只写本地库：`main.js:1762-1771` `owner:decide` → `ownerDecide()`（`:778-783`）写 `project.ownerReview`；`workflow:owner`（`:1382-1397`）返回 `notified: null`，**不写 `工作流.json`、不跑 `owner-note.mjs`、不发 PM 收件箱**。
7. 没有 `fs.watch`，没有 `workflow:changed` 推送；`workflow:get` 每次从 `workbench.json` 现算（`main.js:1372-1380`）。

### 5.3 偏离判定与修正要求

- **删除**：`#view-board`、`#view-flow` 作为一级页签；本地 `project.tasks` 驱动的看板/流程。
- **恢复**：`openTeamBoard()` 的独立 BrowserWindow（`frame:false/transparent/alwaysOnTop/opacity`），`team:board-control` 与 `team:board-file`，`board-preload.js`，看板窗口项目切换；流程用 `#flow-panel` 浮在主窗口 webview 上，数据回到 `computeWorkflow()` + `fs.watch` + `workflow:changed`。
- **Owner 决定**必须写 `团队/状态/项目/<name>/工作流.json` 并调用 `owner-note.mjs`；前端不能只写本地 `ownerReview`。

---

## 6. 项目切换 / 恢复 / 外部目录

### 6.1 旧版

1. **项目清单**：`main.js:525-572` `team:workspaces` 三源合并（团队登记、`工作台/项目` 目录、DSH registry），按真实 path 去重，`current` 来自 `当前工作区.json`。用户在选择器里选一个 workspace，看到的和 DSH 左侧是同一批目录。
2. **打开外部目录**：`main.js:653-690` `team:openProject`：
   - 没有传 path 时弹目录选择，默认 `D:\deepseek`（`:657-663`）；
   - `project = basename(dir)`，同名不同目录报 `PROJECT_NAME_CONFLICT`（`:669-677`）；
   - 调 `launch.mjs --project <name> --workspace <dir> --roles ... --no-prompt --add-members --json`（`:682`）；
   - `launch.mjs` 内部的 `workspace.mjs ensure` 会补齐六角色目录和索引（`launch.mjs:73-85`），不复制、不移动原目录。
3. **按名字恢复**：`main.js:692-736` `team:restore`：
   - 只收项目名，不允许路径（`:695-696`）；
   - 先找 `工作台/项目/<name>`，再按大小写不敏感找目录（`:697-705`）；
   - 再查 `团队/状态/项目/*/项目.json`，允许“已登记但项目根目录名不同”的旧项目（`:707-720`）；
   - 调 `launch.mjs --restore --add-members`（`:727`）。
4. **新建工作区**：`main.js:738-775`：
   - 同名目录/同名登记直接拒绝（`:744-745`）；
   - 外部 root 时加 `--allow-external`（`:760-763`）；
   - 没有 engine 时拒绝（`:756-758`）；
   - 返回 `reload: true`，前端 `refreshWorkspaceSoon()` 重载 webview（`app.js:143-147`）。
5. **切换即绑定**：从壳内执行“建团队/恢复/打开项目”时，最终都走 `launch.mjs`，由它 `setActiveProject(project)` + 写 `当前工作区.json`（`launch.mjs:239-254`），因此壳内项目切换和 DSH 工作区切换是同一件事（DSH 左侧自己切换工作区不属于壳内动作）。

### 6.2 新壳

1. `src/main.js:923-928` `project:select`：
   ```js
   const store = readStore();
   if (!store.projects.some((p) => p.id === projectId)) throw new Error('项目不存在');
   store.activeProjectId = projectId;
   writeStore(store);
   ```
   **只改 `workbench.json`，不调 `setActiveProject`，不写 `当前工作区.json`，不切换 DSH workspace。**
2. `src/renderer/app.js:1942-1955` 左侧项目列表点击 → `project:select` + `showDshView(false)`；用户以为切换了项目，实际团队工具仍停在旧 `activeProject`，DSH 左侧也没变。
3. `project:discover`（`main.js:936-961`）只扫 `ROOT/projects` + `团队/状态/项目` 登记，并且要求目录里有 `项目信息.md`；**不读 `~/.dsh/storages/workspace.json`**，所以旧版能看到的 DSH 工作区在新壳清单里消失。
4. `project:adopt`（`main.js:962-999`）同样要求 `项目信息.md`，并在本地建 `P-xxxx` 记录；旧版 `team:openProject` 接受任意目录并由 `workspace.mjs ensure` 补齐，不要求先有 `项目信息.md`。
5. `team:restore`（`main.js:1163-1210`）用 `findProjectByName()`（`:719-734`）：本地 store → 团队登记 → `ROOT/projects`；**不搜旧 `工作台/项目`**。旧项目若没有团队登记，按名字恢复会直接 `PROJECT_FOLDER_NOT_FOUND`。
6. `team:open-project`（`main.js:1213-1260`）接受任意目录，但**不写本地 store**，所以 `#project-list` 不会出现该项目；同时它只 `launchSessions`，不负责把项目登记到 `workbench.json`。
7. `team:workspace:create`（`main.js:1262-1337`）先 `createProject` 再 `ensure`，不是旧 `workspace.mjs create`；没有“没有引擎就拒绝”的检查。
8. 新壳默认根目录是 `path.join(ROOT, 'projects')`（`main.js:610`），旧版是 `D:\deepseek\工作台\项目`；外部目录/旧项目需要手工选择，不能靠名字恢复。
9. 更关键的是账本根也换了：`team-tools.js:260-267` 默认 `TEAM_ROOT = <repo>/团队`，`core.mjs:11-13` 同样以 `WORKSPACE = <repo>` 计算 `状态/`、`邮箱/`、`回执.jsonl`、`启动/`。旧账本在 `D:\deepseek\工作台\团队\状态`；新壳不显式设 `TEAM_ROOT` 时，旧项目登记、旧邮箱、旧回执、旧令牌全部不可见——这也是新仓 `团队/状态/项目`、`团队/状态/邮箱` 为空的原因之一。

### 6.3 修正要求

- `project:select` 必须变成 `team:use`：写 `当前工作区.json` + `团队.json.activeProject`，并让 DSH 切到对应 workspace；不能只改本地 `activeProjectId`。
- `team:workspaces` 恢复 DSH registry 读取；`team:restore` 恢复旧 `工作台/项目` 搜索。
- `team:open-project` 打开后必须把 manifest/项目投影到 UI（或强制 `adopt`），不能出现“会话建了、页面没有”。
- 新建工作区必须走 `workspace.mjs create`，拿不到 `dshWorkspaceId` 就失败。

---

## 7. 哪些新功能是自造、应移除

下面这些不是旧壳的“等价重写”，而是新壳自己长出来的第二套系统。它们与 `团队/工具/*` 的协议、状态、看板、回执都不互通，应优先移除或改为薄包装。

| # | 自造功能 | 现落点 | 为什么不兼容旧版 | 处置 |
|---|---|---|---|---|
| 7.1 | 本地项目库 | `main.js:248-420` `storeFile/readStore/writeStore`；`projects[]`；`project:create/select/adopt/delete-record`；`index.html:130-151 #sidebar/#project-list` | 旧版项目身份是 `workspace.json + 项目.json + dshWorkspaceId`；本地 `P-xxxx` 可与 DSH 无关，造成 1:0 | **删除业务字段**；`workbench.json` 只留窗口/主题/最近打开 |
| 7.2 | 本地任务库/四列看板 | `task:create/update/delete`（`main.js:1415-1451`）；`#view-board`（`index.html:214-223`）；`renderBoard()`（`app.js:532-586`） | 旧版任务是 `团队/状态/项目/<name>/任务/*.json`，由 `team.mjs task create/claim/done` 管理，owner/证据/需求关联都在工具里 | **删除**；看板回到 `team.mjs board` 的八节 HTML |
| 7.3 | 本地提案/评审/签字/apply/rollback | `proposal:*`（`main.js:1453-1675`）；`#view-proposals`（`index.html:246-255`） | 旧版是 `propose → show → review → sign → apply`，多文件、`proposalHash+baseHash`、按风险分级签字（normal=PM，sensitive/critical=全员+owner 终端批准）、`团队/状态/项目/<name>/提案 / 提交 / 备份`；新实现只支持单文件（`:1465`）、只有 PM 能签（`:1548-1549`）、没有 `show` 读回执、备份写 `_backup/commits`（`:1596`） | **删除**；改为 `team.mjs` 的提案/签字/apply |
| 7.4 | 本地派单/回执 | `team:send/ack/cancel`（`main.js:1677-1761`）；`#dispatch-*`（`index.html:292-301`）；`renderDispatch/openAckModal`（`app.js:737-787`） | 旧版走邮箱 + `--boot` + `回执.jsonl` + `派单锁.json`；新实现只写 `workbench.json`，发送者固定 PM，回执人工代填 | **删除**；恢复 `team.mjs send/inbox/read/ack` |
| 7.5 | 本地流程/Owner | `deriveStage`（`main.js:556-568`）；`workflow:get/owner`（`:1372-1397`）；`owner:decide`（`:1762-1771`）；`#view-flow`（`index.html:225-244`） | 旧版读 `工作流.json/任务/提交/需求`，10 阶段含 `devreview/iterate`，`fs.watch` 推送，Owner 决定给 PM 发系统消息；新实现 8 阶段、读本地 `tasks`、`notified:null` | **删除**；回到 `computeWorkflow()` + `owner-note.mjs` |
| 7.6 | DSH 作为可切换场景 | `#btn-dsh-mode`（`index.html:54`）；`#dsh-shell`（`:84`）；`showDshView()`（`app.js:1519-1540`） | 旧版 DSH 是底座，切换的是场景页签，不是“项目页 ↔ DSH”；新壳把 DSH 变成同级页面 | **改成常驻底层**，删除模式切换 |
| 7.7 | 直连建会话兜底 | `provisionDirect()`（`main.js:91-166`）；`dsh:provision`（`:1794-1817`）；`createSessionOnce()`（`:79-85`） | 绕过 `launch.mjs` 会丢 `团队·` 标题、模型选择、`团队会话.json`、`当前工作区.json`、seed 可见化 | **删除兜底**；工具缺失时报 `TOOL_MISSING` |
| 7.8 | 本地恢复/扫描 | `project:discover`（`:936-961`）；`project:adopt`（`:962-999`）；`team:open-project`（`:1213-1260`） | 旧版 `team:openProject` 接受任意目录并 scaffold；`team:restore` 按名字搜旧根/登记；新实现要求 `项目信息.md`、不写 store 或写 `P-xxxx` | **改成旧 `team:openProject/team:restore` 的包装** |
| 7.9 | 手工 DSH 配置/固定端口 | `main.js:75` 默认 `http://127.0.0.1:52711`；`dsh:configure`（`:1834-1838`）；`openDshConfig()`（`app.js:1542-1566`） | 旧版 `resolveEngine()` 扫描进程端口 + 凭据 cookie；端口变化自动发现 | **恢复自动探测**；手工配置只做覆盖 |
| 7.10 | 删除项目记录 | `project:delete-record`（`:1406-1414`） | 只删 `workbench.json`，不清理团队登记/DSH workspace/看板，留下孤儿 | **删除**；删除必须走团队工具并清理三处身份 |

---

## 8. 应保留 / 应删除清单

### 8.1 UI（选择器级）

#### 保留（或保留外形，改接旧逻辑）

| 选择器 | 旧用途 | 新壳现状 | 处置 |
|---|---|---|---|
| `#engine-webview` / `#dsh-view` | DSH 主视图，cookie 分区 `persist:harness` | `#dsh-view` 在 `#dsh-shell` 里，默认 hidden | 改成主窗口常驻底层；恢复 `partition="persist:harness"` |
| `#engine-off` / `#dsh-off` | DSH 离线提示 | 新壳有，但项目页仍可用 | 保留，但显示在 DSH 底层上，不是独立场景 |
| `#engine-retry` / `#dsh-retry` | 重试连接 | 有 | 保留，接 `resolveEngine()` |
| `#scenario-tabs` / `#tabs` | 旧场景页签（DSH/项目总览等） | 新壳是项目页签（overview/board/flow/proposals/files/roles） | **不要保留成项目页签**；只保留 DSH 场景条（可选） |
| `#flow-launcher` | 流程浮窗入口 | 有 | 保留 |
| `#flow-panel` / `#flow-drag` / `#flow-close` | 浮动流程面板 | 有，但读本地状态 | 保留外形，数据改回 `workflow:get` |
| `#btn-team-board` / `#btn-board` | 悬浮团队看板 | 新 `#btn-board` 打开本地看板页 | 恢复 `team:board` → 独立置顶窗口 |
| `#btn-team-members` / `#btn-members` | 六角色成员清单 | 有，读 manifest | 保留 |
| `#btn-workspace-create` / `#btn-workspace` | 新建工作区（建目录 + DSH 注册） | 新按钮打开本地「新建项目」 | 恢复旧对话框：名称/根目录/导入六角色 |
| `#btn-team-launch` / `#btn-team-start` | 选择 workspace 建六个空会话 | 新按钮直接 `dshProvision` 当前本地项目 | 恢复选择器 + `launch.mjs` |
| `#btn-team-restore` / `#btn-restore` | 按项目名恢复 | 新壳按名字恢复 + 本地 adopt | 保留入口，逻辑回团队工具 |
| `#btn-refresh-workspace` / `#btn-refresh` | 在线刷新 DSH 工作区/成员 | 有 | 保留，接 `team:workspaces` + DSH reload |
| `#btn-folder` / `#btn-folder-top` | 打开项目文件夹 | 有 | 保留 |
| `#btn-more` / `#tb-more-panel` | 更多菜单 | 有 | 保留，但删掉 `team/dsh` 场景切换项 |
| `#modal-root` / `#toast` / `#onboard` | 弹窗/提示/引导 | 有 | 保留 |

#### 删除（或降级为浮层/抽屉）

| 选择器 | 说明 |
|---|---|
| `#app` 作为根容器 | 应改成覆盖层容器（`position:absolute/inset:0` 的浮层），不能和 `#dsh-shell` 互斥 |
| `#sidebar`、`#project-list`、`.project-item`、`#project-count`、`#sidebar-stats` | 本地项目库列表；应改为“DSH/团队工作区切换器”，数据来自 `team:workspaces` |
| `#tabs`、`data-tab="overview / board / flow / proposals / files / roles"` | 项目页签体系；删除或只保留“文件/角色”作为抽屉 |
| `#view-overview`、`#stats`、`#stage-summary`、`#owner-summary`、`#overview-tasks` | 本地项目总览；删除 |
| `#view-board`、`#board` | 本地四列任务看板；删除，改用旧看板窗口 |
| `#view-flow`、`#flow-board`、`#flow-meta` | 整页流程；删除，改用 `#flow-panel` 浮窗 |
| `#view-proposals`、`#proposals-list`、`#btn-proposal-add` | 本地提案页；删除，改用 `team.mjs propose` 流程 |
| `#view-roles`、`#roles-grid`、`#dispatch-role`、`#dispatch-subject`、`#dispatch-body`、`#dispatch-send`、`#dispatch-pending`、`#dispatch-ack`、`#dispatch-cancel` | 本地角色页 + 本地派单；角色清单可保留为弹窗，派单删除 |
| `#btn-dsh-mode` | “项目页 ↔ DSH”模式切换；删除，DSH 常驻 |
| `#dsh-shell` 作为独立场景 | 保留 webview 本体，去掉外层“场景”语义 |
| `#project-actions` 中的 `#btn-provision` / `#btn-owner` | 可以保留为浮层入口，但不能绑定本地 `owner:decide` |
| `#empty-view` | 可保留为空态覆盖层，但只在 DSH 上盖一层，不占整页 |

### 8.2 IPC（`ipcMain.handle`）

#### 保留/补回

| IPC | 旧行为 | 新壳现状 |
|---|---|---|
| `app:config` | 读 config + `ensureEngine()` 自动探测 | **缺失**；补回 |
| `app:dirs` | DSH 根/工作区/场景目录 | 可补 |
| `app:version` / `system:metrics` / `window:control` | 基础 | 有 |
| `files:list` / `files:open` | 项目内只读浏览 | 有（旧 `fs:list/fs:read` 等价） |
| `team:status` | 团队/会话/看板/当前工作区 | 有 |
| `team:members` | 读 `团队会话.json` | 有 |
| `team:workspaces` | 三源合并 + DSH registry | 有，但缺 DSH registry，需补 |
| `team:workspace:create` | `workspace.mjs create` | 有，但实现改成 `createProject`，需改回 |
| `team:launch` | `launch.mjs` 建/复用六角色 | 有，但 UI 不用 |
| `team:restore` | 按名恢复 + `--restore` | 有，但搜索范围缺旧根 |
| `team:open-project` | 任意目录 + `--add-members` | 有，但不落 UI 记录 |
| `team:board` | 生成 + 打开置顶看板窗口 | 有，但改成 `shell.openPath` |
| `team:board-project` | 切换看板项目并 focus | 有，但不 focus |
| `team:board-file` | 只读预览看板文件 | **缺失**；补回 |
| `team:board-control` | 折叠/缩放/最大化/关闭 | **缺失**；补回 |
| `workflow:get` | 读团队状态算 stage | 有，但读本地 tasks |
| `workflow:owner` | 写 `工作流.json` + `owner-note` | 有，但不写文件/不通知 |
| `dsh:status` / `dsh:team-status` | 只读探测/会话状态 | 有，可保留 |
| `workflow:changed` event | `fs.watch` 推送 | **缺失**；补回 |

> 注意：`teamLaunch`、`teamWorkspaceCreate`、`teamWorkspaces`、`teamStatus`、`teamOpenProject` 在 `src/renderer/app.js` 中都没有调用点（`rg` 只命中 `preload.js` 的定义）。真正走的是 `project:create`、`dsh:provision`、`project:adopt`、`project:select`。所以“旧 IPC 还在”只是壳，UI 已经换了模型。

#### 删除/改造

| IPC | 问题 | 处置 |
|---|---|---|
| `project:create` | 建本地 `P-xxxx`，不注册 DSH workspace | 删除；改为 `team:workspace:create` |
| `project:select` | 只改本地 `activeProjectId` | 删除；改为 `team:use`（写 `当前工作区.json` + `setActiveProject`） |
| `project:discover` | 只扫本地根/登记，要求 `项目信息.md`，不读 DSH registry | 删除；恢复 `team:workspaces` 三源 |
| `project:adopt` | 建本地记录，不注册 DSH | 删除；改为 `team:openProject` |
| `project:delete-record` | 只删本地记录 | 删除 |
| `project:open` | 打开目录 | 可并入 `app:openPath` |
| `task:create/update/delete` | 本地任务库 | 删除；用 `team.mjs task` |
| `proposal:create/review/sign/apply/rollback` | 本地单文件提案系统 | 删除；用 `team.mjs propose/show/review/sign/apply` |
| `team:send` | 本地 message + 直接 prompt | 重写为 `team.mjs send --boot` 包装 |
| `team:ack` | 人工代记回执 | 删除；回执由收件会话执行 |
| `team:cancel` | 本地撤销 | 删除；旧协议用 `派单锁.json`，不提供随便撤销 |
| `owner:decide` | 只写本地 `ownerReview` | 删除；用 `workflow:owner` |
| `dsh:prompt` | 任意文本唤醒，不记账 | 删除；唤醒只由 `team:send --ack` 触发 |
| `dsh:provision` | 可走 `provisionDirect` 兜底 | 保留入口但删除兜底；只调 `launchSessions` |
| `dsh:configure` | 手工地址 | 保留为覆盖，但启动必须先自动探测 |

### 8.3 数据与模块

| 保留为唯一真相 | 说明 |
|---|---|
| `<workspace>/workspace.json` | `dshWorkspaceId`、`name`、`path`、`engineUrl`、`roles`、`limits` |
| `<workspace>/团队会话.json` / `.md` | 六个 sessionId、title、reused、model、workspaceId |
| `团队/状态/项目/<name>/项目.json` | 项目登记（path/dshWorkspaceId） |
| `团队/状态/项目/<name>/工作流.json` | `ownerReview`、轮次 |
| `团队/状态/项目/<name>/任务/*.json`、`提案/`、`提交/`、`备份/` | 任务/提案/提交/回滚 |
| `团队/状态/邮箱/<role>/new / cur` | 消息 |
| `团队/状态/回执.jsonl` | 回执 |
| `团队/状态/项目/<name>/派单锁.json` | PM 单派单锁 |
| `团队/看板.html` / `看板.md` / `状态/看板.json` | 看板生成物 |
| `团队/状态/当前工作区.json` | 当前项目/工作区 |

| 删除/降级 | 说明 |
|---|---|
| `workbench.json.projects[].tasks/messages/proposals/commits/ownerReview/pendingAck` | 本地业务真相；与团队状态双写 |
| `workbench.json.projects[].id` 作为项目主键 | 改为 `path`/`workspaceId` 投影 |
| `<project>/_backup/commits/<C-id>` | 新壳本地 apply 备份；旧版在 `团队/状态/项目/<name>/备份/` |
| `renderer` 的 `project.messages` 渲染/回执弹窗 | 改为团队邮箱 |

---

## 9. 正确的目标形态（建议落地顺序）

1. **倒转启动**：`app.whenReady` 里先 `resolveEngine()`（端口扫描 + 凭据 cookie + `persist:harness`），再建窗；`index.html` 首屏就是 `#engine-view`/webview；`#app` 改为覆盖层。
2. **砍本地项目库**：删除 `project:create/select/adopt/delete-record`；新建项目 = `team:workspace:create`（内部 `workspace.mjs create`）；打开外部目录 = `team:openProject`；恢复 = `team:restore`。
3. **统一六角色**：只允许 `launch.mjs` 建/复用；删 `provisionDirect`；角色页/成员弹窗统一读 `团队会话.json`；`team:restore/open-project` 必须把 manifest 投影到 UI。
4. **恢复消息协议**：`team:send` 改成 `team.mjs send --boot` 包装；新增收件箱 UI（inbox/read/ack）；回执由收件会话产生；派单锁由 `派单锁.json` 管理。
5. **恢复看板/流程悬浮**：`team:board` 走 `openTeamBoard()` 独立窗口 + `team:board-control/file`；流程用 `#flow-panel` + `computeWorkflow()` + `fs.watch` + `workflow:changed`；Owner 决定写 `工作流.json` + `owner-note.mjs`。
6. **切换即绑定**：`project:select` 改为 `team:use`：写 `当前工作区.json` + `团队.json.activeProject`，并让 DSH 切到对应 workspace；`team:workspaces` 恢复 DSH registry。
7. **最后清 UI**：删除 `#tabs` 项目页签、`#view-*`、`#sidebar` 本地项目列表；保留顶栏按钮、浮窗、弹窗。

---

## 10. 验收断言（改完后按这些复核）

### 10.1 静态断言

```powershell
# 1) 不应再有本地业务真相
rg -n "project\.(tasks|messages|proposals|commits|ownerReview)" src/main.js
# 期望：只出现在只读投影/迁移代码，或 0 处

# 2) 不应再有本地任务/提案 IPC
rg -n "ipcMain\.handle\('(task|proposal|project):" src/main.js
# 期望：0 处（project:open 可并入 app:openPath）

# 3) team:send 必须走团队工具
rg -n "team:send" -A 8 src/main.js
# 期望：spawn/runNode 调 team.mjs send，参数含 --boot/--to/--ack

# 4) 看板必须是独立置顶窗口
rg -n "alwaysOnTop|team:board-control|board-preload|team:board-file" src/main.js src/preload.js
# 期望：均非 0

# 5) 流程必须来自团队状态
rg -n "fs\.watch|workflow:changed|owner-note|工作流\.json" src/main.js
# 期望：均非 0

# 6) DSH 必须自动探测
rg -n "resolveEngine|findEnginePorts|persist:harness|mintEngineCookie" src/main.js
# 期望：均非 0
```

### 10.2 运行时断言

| 断言 | 做法 | 期望 |
|---|---|---|
| 启动首屏是 DSH | 启动后看 `#dsh-view` 的 `src` 和可见性 | `src` 非 `about:blank`；`#dsh-shell` 可见；`#app` 是覆盖层 |
| 一个项目一个 workspace | 新建项目后读 `<path>/workspace.json` 与 `团队/状态/项目/<name>/项目.json` | 两者 `dshWorkspaceId` 非空且相同；DSH registry 能查到该 path |
| 六角色齐 | 建团队后读 `团队会话.json` | `roles.length === 6`；每个 `sessionId` 都在该 `workspaceId.sessionIds` 里；标题都是 `团队·*` |
| 消息落邮箱 | UI 发一条 `--ack` 派单 | 出现 `团队/状态/邮箱/<role>/new/*.json`；目标会话 `inbox` 能读到同 `id` |
| 回执闭环 | 目标会话 `ack` | `回执.jsonl` 新增 `A-*`；`派单锁.json` 消失；发件人收到 `type:'receipt'` 消息 |
| 看板悬浮 | 打开看板 | `BrowserWindow` 存在，`isAlwaysOnTop() === true`，可折叠到 320×64 |
| 流程推送 | 改 `工作流.json` 或任务 | 主窗口收到 `workflow:changed`，`#flow-panel` 阶段更新 |
| Owner 决定进 PM 邮箱 | 在流程浮窗点「通过/打回」 | `工作流.json.ownerReview` 更新；`邮箱/pm/new` 出现 `Owner评审：*` |
| 切换项目同步 | 左侧切换项目 | `当前工作区.json.path` 等于所选路径；`团队.json.activeProject` 等于项目名 |

---

## 11. 证据索引

### 旧壳

- `D:\deepseek\luanyujia-workbench\12-源码照搬\外壳\main.js`：`resolveEngine` 139、`ensureEngine` 158、`app:config` 163、`openTeamBoard` 247、`computeWorkflow` 377、`startFlowWatch` 432、`workflow:get` 451、`workflow:owner` 452、`team:members` 477、`team:launch` 491、`team:workspaces` 525、`team:board` 574、`team:board-project` 585、`team:board-file` 599、`team:board-control` 624、`team:openProject` 653、`team:restore` 692、`team:workspace:create` 738、`createWindow` 952。
- `...\外壳\renderer\index.html`：`#engine-view` 66、`#engine-webview` 67、`#flow-launcher` 83、`#flow-panel` 84、`#btn-team-board` 19、`#btn-team-members` 20、`#btn-workspace-create` 21、`#btn-team-launch` 22、`#btn-team-restore` 23。
- `...\外壳\renderer\app.js`：`renderTabs` 468、`showView` 498、`renderProjectCards` 768、`loadEngine` 1400、`mountMembers` 1640、`mountFlow` 1669、`openWorkspaceDialog` 166、`openLaunchDialog` 273。
- `...\外壳\board-preload.js`：`boardWin.control/selectProject/openFile`。
- `D:\deepseek\工作台\团队\工具\launch.mjs`：角色计划 53、复用 100、创建 110、seed 148、清理 170、manifest 192、团队记账 229、当前工作区 240。
- `...\团队\工具\workspace.mjs`：`scaffold` 208、`registerTeamProject` 249、`create` 270、`ensure` 292、`workspaceCreate` 347、`当前工作区` 360。
- `...\团队\工具\lib\store.mjs`：`createBootToken` 307、`requireBoot` 328、`sendMessage` 353、`listInbox` 382、`readMessage` 417、`ackMessage` 435。
- `...\团队\工具\lib\ops.mjs`：`bootFor` 36、`notify` 176、`dispatchLockPath` 320、`cmdSend` 339、`cmdInbox` 414、`cmdRead` 423、`cmdAck` 431。
- `...\团队\工具\owner-note.mjs`：`sendMessage({from:'system',to:'pm',type:'owner-review'})`。
- `...\团队\流程.md`：阶段表 13-25、回执链 27-43。
- `...\团队\团队宪法.md`：消息/回执 30-35。
- `...\团队\协议\01-会话与必读.md`：一个角色=一个会话 3、会话绑定 42-48。
- `...\团队\协议\02-消息任务回执.md`：send/inbox/read/ack 5-16、大小限制 47-55。

### 新壳

- `D:\deepseek\agile-workbench\src\main.js`：`provisionDirect` 91、`provisionTeamSessions` 173、`createProject` 634、`project:create` 910、`project:select` 923、`project:discover` 936、`project:adopt` 962、`team:workspaces` 1000、`team:members` 1065、`team:launch` 1133、`team:restore` 1163、`team:open-project` 1213、`team:workspace:create` 1262、`team:board` 1339、`team:board-project` 1360、`workflow:get` 1372、`workflow:owner` 1382、`team:send` 1677、`team:ack` 1739、`owner:decide` 1762、`dsh:provision` 1794、`createWindow` 1847、`installDshCookie` 2619。
- `...\src\renderer\index.html`：`#dsh-shell` 84、`#dsh-view` 93、`#app` 109、`#tabs` 115、`#sidebar` 130、`#view-overview` 174、`#view-board` 214、`#view-flow` 225、`#view-proposals` 246、`#view-files` 257、`#view-roles` 279、`#flow-panel` 311。
- `...\src\renderer\app.js`：`showTab` 335、`render` 353、`renderSidebar` 390、`renderBoard` 532、`flowMarkup` 600、`renderRoles` 698、`renderDispatch` 737、`openAckModal` 766、`openWakeModal` 789、`openNewProject` 1187、`openRestoreModal` 1217、`showDshView` 1519、`startTeam` 2030、`boot` 2082。
- `...\src\preload.js`：`window.workbench.*` 暴露清单 5-49（无 `team:board-control`/`team:board-file`）。
- `...\src\team-tools.js`：`launchSessions` 760、`listWorkspaces` 511、`ensureProject` 449、`teamStatus` 625、`readSessionManifest` 644、`generateBoard` 682。
- `...\src\dsh-adapter.js`：`DshAdapter` 45、`check` 149、`createWorkspace` 183、`createSession` 187、`prompt` 201、`archiveSession` 216。

### 状态/运行物

- `D:\deepseek\工作台\团队\状态\项目\<name>\项目.json`、`工作流.json`、`任务/`、`提案/`、`提交/`、`备份/`。
- `D:\deepseek\工作台\团队\状态\邮箱\<role>\new / cur`、`回执.jsonl`、`派单锁.json`、`启动/*.json`。
- `D:\deepseek\agile-workbench\团队\状态\团队.json`、`看板.json`、`看板.md`；`状态/启动`、`状态/授权`、`状态/邮箱`、`状态/锁`、`状态/项目` 目录存在但文件数为 0，且没有 `当前工作区.json`。这本身就是“新壳尚未接入旧账本”的证据。

---

## 12. 最终判定

| 问题 | 判定 |
|---|---|
| 旧版是不是“套在 DSH 上的壳”？ | **是**。首屏 webview、自动发现 DSH、场景页签覆盖、看板/流程悬浮、项目=workspace。 |
| 新版是不是“独立项目管理系统”？ | **是**。`#app` 项目页是根，`workbench.json` 存项目/任务/提案/流程，DSH 是同级可切换场景。 |
| 1 项目 = 1 DSH 工作区？ | 旧版强制；新壳只在 `launch.mjs` 执行后才成立，创建/恢复/切换都可能 1:0。 |
| 1 会话 = 1 角色？ | 旧版强制（标题/角色卡/manifest）；新壳 `launch.mjs` 路径仍成立，但 `provisionDirect` 会破坏标题/模型/清单。 |
| 六会话能互相发消息/回执？ | 旧版能（任意 active 成员、邮箱、boot、ack、回执）；新壳 UI 只能 PM→角色，且消息不进邮箱、回执人工代记。 |
| 流程严格照旧版？ | 旧版 10 阶段、团队状态驱动、Owner 决定进 PM 邮箱；新壳 8 阶段、本地任务驱动、Owner 决定不出本地库。 |
| 新 UI 的“项目页面”是否偏离？ | **是**。应改成覆盖在 DSH webview 上的顶栏/浮层/抽屉，不能作为与 DSH 互斥的整页。 |

**修复优先级：P0 启动倒转 + 消息协议回邮箱；P1 项目=workspace 强绑定 + 六角色只走 launch.mjs；P2 看板/流程悬浮 + 项目切换同步。**
