# MVP 阻断清单：建项目 → 六会话 → 需求 → 评审 → 派单 → 开发互审 → 测试 → Owner 验收

> 只读审计。范围：`D:\deepseek\agile-workbench`（当前代码）与 `D:\deepseek\工作台`（旧仓库/旧团队工具）。
> **结论只对文末快照负责**；审计期间源码在持续变化（16:37 起 `团队\工具` 新增了 `req review` / `owner` / `workflow`，16:40 后 `src\main.js`、`src\team-tools.js`、`src\renderer\app.js` 仍在改）。若文件哈希已变，先按 §7 复验，不要直接复用本文结论。

---

## 0. 一句话结论

**主链已经不再是“缺三条旧命令所以第 2 步必断”的状态**：当前快照的 `团队\工具` 已实现 `req review` / `owner` / `workflow`，能力探测 `missing: []`；普通风险下，建项目 → 六会话 → 需求 → 产品评审 → Owner 决定 → 派单 → 开发提案/互审/PM 签字 apply → 开发 done → 派测试 → 测试 done → Owner 验收，在代码路径上已经具备走通条件。

**但还不能按“可验收的六角色闭环”发布**，原因不是某一步一定抛错，而是：

1. **Owner 决定/验收没有身份**：`owner` 命令只记录 `by: "Owner"`，没有 nonce、没有 TTY、没有凭据；`owner:accept` / `requirement:owner` 默认就是 `role: "owner"`。任何能调 preload/CLI 的调用方都能替 Owner 通过/验收。这是当前唯一的 **P0**（若产品明确定位为“单人编排台”，可降为 P1，但必须改文案和字段）。
2. **派单仍不唤醒、不写回执锁**：工作流派单用 `send --no-wake` 且不带 `--ack`，PM 可以连续派多单；`流程.md` 的“一次一个、未回执不派下一个”在 workflow 路径上没有执行。
3. **必读闸门先补模板再放行**：`bootRole` 先 `ensureProjectStructure` 再读文档，缺 `项目信息.md` 会生成“（待填写）”模板后 `complete: true`；占位符能通过评审/派单。
4. **旧项目 4 位需求号读不到**：新壳正则只认 `R-YYYYMMDD-6位序号`；旧仓库的 `R-20261103-0001-*.md` 在 `readRequirementDocs()` 里计数为 0，恢复旧项目后评审会 `MISSING_DOC`。
5. **需求创建不要求角色 boot**、**互审/签字可无会话代跑**、**sensitive/critical 提案必卡在 apply**、**收口没有 verify/pilot 闸门**、**两套 Owner 状态并存**。这些是 P1，详见 §4。

---

## 1. 快照与复验基线

### 1.1 当前快照（2026-11-05 16:47 +08:00；审计期间 16:43→16:47 又有一轮源码变更）

| 文件 | 字节 | SHA-256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 475,115 | `ED812497D4F7A94C` | 16:47:00 |
| `src/team-tools.js` | 250,696 | `A268800BAF24FF55` | 16:47:00 |
| `src/preload.js` | 7,433 | `43D94AF143AB9823` | 13:47:04 |
| `src/renderer/app.js` | 460,168 | `3D510C8EEACD9FC1` | 16:47:25 |
| `src/renderer/index.html` | 47,200 | `2271AF226C49064E` | 16:40:00 |
| `团队/工具/team.mjs` | 6,198 | `B08FC4B5E5B22D5C` | 16:37:41 |
| `团队/工具/lib/ops.mjs` | 120,020 | `1A00B6A082AAC5D3` | 16:37:29 |
| `团队/工具/lib/workflow.mjs` | 40,660 | `496F13DDDFB7FC8D` | 16:41:11 |
| `团队/工具/launch.mjs` | 14,127 | `714AE47B66042DA7` | 11-03 07:47 |
| `团队/工具/workspace.mjs` | 26,440 | `E5757F2482EBAEE8` | 11-03 09:14 |

> 16:47 的变更没有改掉本文列出的关键 P1：`sendWorkflowNotice` 仍是 `--no-wake`、`devSubmit/devReview/devApply` 仍是 `allowMissingSession:true`、`REQ_FILE_RE` 仍是 6 位、`provisionTeamSessions` 仍会返回 `SESSION_BLANK`、selftest 主链仍注入 `createWorkflowProtocolMock`。行号以函数名复验为准。

### 1.2 两棵“团队工具”树，不要混用

| 树 | `team.mjs` | `req review` / `owner` / `workflow` | 谁在用 |
|---|---|---|---|
| `D:\deepseek\agile-workbench\团队\工具` | 6,198 B / 16:37 | **有** | 当前工作台实际调用（`layout.toolRoot` 默认指向这里） |
| `D:\deepseek\工作台\团队\工具` | 6,986 B / 15:36 | **没有**（`cmdReq` 对 review 返回 `NOT_IMPLEMENTED`） | 旧仓库/旧文档基线；**不是**当前 app 的运行树 |

> 这解释了一个常见误判：拿旧仓库的 `team.mjs` 审当前 app，会得出“三条命令缺失、主链在需求评审断开”的结论。该结论对**旧仓库**成立，对**当前 app 的 `团队\工具`** 不成立（见 §5.1）。
> 反过来，旧仓库的 `团队/流程.md` 仍是当前流程的规格来源，但它没有写这三条新命令的参数表；两棵树需要收敛成一份。

### 1.3 只读边界

- 未修改 `src/**`、`package.json`、`package-lock.json`、`团队/**`、`项目/**`、旧仓库任何文件。
- 未启动 Electron、未启动/驱动真实 DSH 会话、未跑 `npm run selftest`（它会写 `.selftest-data\`）。
- 做过的只读检查：`npm run check`（exit 0，5 个入口语法通过）、`teamTools.legacyCapabilities()` 能力探测、`teamTools.readRequirementDocs()` 旧需求探测、文件哈希/时间戳。
- 结论里的“可走通”是**代码路径 + 能力探测**结论；真实 DSH 六会话与真实六角色执行仍未被本轮证明（见 §8）。

---

## 2. 链路判定表

| 阶段 | 当前入口 | 真相/落点 | 判定 | 主要依据 |
|---|---|---|---|---|
| 建项目 | `project:create` → `createProject()` | 项目目录 + `团队/状态/项目/<slug>/项目.json` + `workspace.json` | **有条件**：DSH 在线可建；DSH 不可达会整单回滚 | `main.js` `createProject`；P1-1 |
| 六会话 | `dsh:provision` → `provisionTeamSessions()` | `团队会话.json` + DSH workspace | **有条件**：能建/复用；空白会话会返回 `SESSION_BLANK` 让用户再点一次 | `launch.mjs`；P1-2 |
| 需求 | `requirement:create` → `createRequirement()` | 旧 `req create` + `需求/R-*.md` + `工作流.json` | **可用**，但创建前不要求角色 boot | P1-4 |
| 产品评审 | `requirement:review` → `reviewRequirement()` | 新 `req review` → `工作流.json` + 需求文档/总览 | **可用**：普通 6 位新需求可走；旧 4 位需求号不可走 | P1-3、P1-5 |
| Owner 评审 | `requirement:owner` → `ownerRequirementDecision()` | 新 `owner` → 需求级 `ownerReview` | **可走但不可信**：没有身份证明 | P0-1 |
| 派单 | `requirement:dispatch` → `dispatchRequirement()` | `task create` + `send --no-wake` | **可派但不唤醒/不加锁**：不满足“一次一个、等回执” | P1-6 |
| 开发提交/互审/签字 | `dev:submit` / `dev:review` / `dev:apply` | 旧 `propose/show/review/sign/apply` | **normal 可走**；互审/签字可无会话代跑；sensitive/critical 必卡 | P1-7、P1-8 |
| 测试 | `test:dispatch` → `dispatchTest()` | `task create` + `send --no-wake`；测试 claim/done | **可走**，但同样不唤醒/不加锁 | P1-6 |
| Owner 验收 | `owner:accept` → `ownerAccept()` | 新 `owner --action accept` + 收口需求任务/文档 | **可走但不可信**：没有身份证明 | P0-1 |
| 迭代/终止 | `workflow:iterate` / `workflow:terminate` | 新 `workflow iterate` / `workflow terminate` | **可用**：PM boot 后能走；会收口旧任务/文档 | §5.1 |
| 收口健康 | `team:reconcile` | 本机通信对账 | **缺 verify/pilot 闸门**：账本问题不曝光 | P1-9 |

---

## 3. P0

### P0-1 Owner 决定/验收是“自称”，不是身份，Owner 闸门可被任意调用方完成

**结论**

当前 `Owner 验收` 阶段可以走通命令，但“是 Owner 本人做的”没有任何证明。`owner` 命令把 `by: "Owner"` 写死/按入参写，`owner:accept` 和 `requirement:owner` 在 IPC 层默认 `role: "owner"`；渲染层、preload、甚至一个本地脚本都能完成“Owner 通过/验收”。对一个把 Owner 闸门写进主链的产品，这使该阶段不可验收。

**证据**

1. `团队/工具/lib/ops.mjs` `cmdOwner`（约 1892 行起）：只校验 `--project` / `--requirement` / `--decision` / `--opinion`，没有 `--boot`、没有 nonce、没有凭据；`channel` 只区分 `tty` / `stdio`：

   ```js
   const channel = process.stdin.isTTY && process.stdout.isTTY ? 'tty' : 'stdio';
   const r = ownerDecision({ project, projectName, requirementId, action: actionRaw, decision,
     opinion: String(opinionRaw).trim(), channel });
   ```

2. `团队/工具/lib/workflow.mjs` `ownerDecision`（约 629 行起）在验收/评审分支写：

   ```js
   acceptance = { status: normalized, by: 'Owner', at, opinion: opinionText, channel, ... };
   row.ownerReview = { status: normalized, by: 'Owner', at, opinion: opinionText, channel, ... };
   ```

   `by` 不是从签名/会话解析出来的。

3. `src/team-tools.js` `ownerRequirementDecision()`（约 3817 行起）只做字符串判断：

   ```js
   const role = String(input.role || '').trim();
   if (role !== 'owner') return failure('ROLE_NOT_ALLOWED', ...);
   ```

   `ownerAccept()`（约 4812 行起）默认 `role = String(input.role || 'owner')`；`main.js` 的 `requirement:owner` / `owner:accept` 也默认 `role: 'owner'`（约 3873 / 3945 行）。

4. `src/preload.js` 暴露 `ownerAccept`、`ownerDecide`；渲染层可以不经 Owner 本人直接调用。

5. 对照：旧工具唯一有身份的是**提案级** `owner-approve`（`cmdOwnerApprove`）——它要求真实 TTY、输入「批准 P-…」、用 `signatureDigest` 绑定 `proposalHash/baseHash/newHash/ts/nonce`。当前 workflow 的 `owner` 命令没有走这套。

**影响**

- `Owner 验收` 可以在没有 Owner 会话、没有 Owner 终端、没有 Owner 确认的情况下完成；审计账本上的 `by: "Owner"` 不能证明 Owner 做过决定。
- 如果 MVP 的卖点是“六角色 + Owner 闸门”，这是发版前必须解决或明确降级的产品语义问题。

**最小修法（二选一，必须写进发布说明）**

- **方案 A（保留 Owner 闸门）**：给 `owner` / `owner:accept` 加一次性 nonce 或本机凭据；nonce 由主进程生成、只写当前用户可读文件；命令校验 nonce 后才写 `by: "Owner"`，记录 `nonceHash`、`expiry`、`channel`；无有效 nonce 返回 `OWNER_IDENTITY_REQUIRED`。
- **方案 B（承认单人编排）**：把字段改成 `recordedBy: "operator"` / `actor: "workbench-shell"`，UI 把“Owner 已通过/已验收”改成“已记录 Owner 意见（未做身份认证）”；在 README 和关于页写明“本工作台不提供 Owner 身份隔离”。

**验收**

- 无 nonce 调 `requirement:owner` / `owner:accept` → `OWNER_IDENTITY_REQUIRED`；
- 有 nonce → 记录含 `nonceHash` + `expiry`，且 UI 不再显示成“Owner 本人”；
- 或方案 B 下，所有记录明确 `actor=workbench-shell`，没有 `by:"Owner"`。

---

## 4. P1

> P1 的判定标准：主链在“正常路径 + 人工补一步”下可能走通，但会在真实使用中卡住、误导、丢闸门或让发布证据不成立。按链路顺序排列。

### P1-1 建项目硬依赖 DSH；DSH 不可达会整单回滚

**证据**

- `src/main.js` `createProject()`：先写本地 `workbench.json` 记录，再 `activateWorkspace()`；`activateWorkspace` 返回 `ok: binding.ok`；`createProject` 在 `!activation.ok` 时直接 `throw` 并 `rollbackCreatedProject()`。
- `bindProjectWorkspace()` 在 DSH 失败时其实已经把 `workspace.pending=true` 写进本地记录，但 `createProject` 不采用这个 pending 状态，仍按失败回滚。

**影响**

- DSH 未启动、重启中、地址配错时，用户连“建一个本地项目”都做不到；第一步就失败。
- 对首次使用者，最容易先看到的是 `[DSH_OFFLINE]` / `DSH_WORKSPACE_CREATE_FAILED`，而不是“项目已建、待绑定 DSH”。

**最小修法**

- `createProject` 允许 `workspace` 为 pending：本地项目/六角色目录/索引先落，返回 `ok:true, workspace.pending:true`；只在“建团队”时要求 DSH 在线。
- 或 UI 在 DSH 离线时明确禁用“新建项目”，并给出“先启动 DSH”的单一入口；不要先让用户填完再回滚。

**验收**

- 停掉 DSH，`project:create` 返回 `ok:true` + `workspace.pending:true`，项目出现在列表；
- 启动 DSH 后 `team:ensure-project` 把 `workspaceId` 绑上，`workspace.pending=false`。

### P1-2 六会话能建，但空白会话会返回 `SESSION_BLANK`，首次“建团队”容易显示失败

**证据**

- `provisionTeamSessions()`（`src/main.js` 约 1241 行起）在 `launch.mjs` 之后立刻 `inspectProjectSessions()`；若 `after.blank` 非空，返回 `ok:false, code:'SESSION_BLANK'`，并提示“再点一次建团队补发就位”。
- `launch.mjs` 的 `--seed-visible` 会给每个空白会话发一条“已就位”prompt；prompt 是 queue 模式，刚发完立刻查 `session/list` 时 `blank` 可能仍为 true，于是第一次建团队很容易落到 `SESSION_BLANK`。
- `dsh:provision` handler 传 `seedVisible: payload && payload.seedVisible`；`provisionTeamSessions` 里是 `seedVisible: options.seedVisible !== false`，即**默认 seed**。这与“只建空会话，不发全队启动卡”的旧纪律不完全一致（虽然不是启动卡，仍是六次 prompt）。

**影响**

- 六个会话其实已经建好，但 UI 报“启动团队失败/有角色还是空白会话”，用户会重复点，可能重复 seed。
- 没有真实 DSH 的正向证据：selftest 的 DSH 是 mock，`selftestRound10RealCommands` 只覆盖旧命令，不覆盖六会话。

**最小修法**

- 建团队后轮询 `session/list` / `projections`（带超时），区分“刚建、尚未产生 turn”和“真失败”；不要用一次瞬时 `blank` 判定失败。
- 返回 `ok:true` + `pendingSeed:[...]` + “补发就位”按钮；或把 `seedVisible` 默认关掉，明确由用户点“补发就位”。
- 增加一次真实 DSH 的六会话 smoke（手动或 CI 受控）：建工作区 → 六个 `团队·角色` → 每个 `sessionId` 能在 `workspace/create` 的 `sessionIds` 里查到。

**验收**

- 首次建团队返回 `ok:true`（即使有 `pendingSeed`），六个 `sessionId` 落库；
- 第二次调用不新建、只复用；
- 真实 DSH 下六会话 `sessionId` 与 `团队会话.json` 一致。

### P1-3 必读闸门“先补模板再放行”，占位符可以通过评审/派单

**证据**

- `src/team-tools.js` `bootRole()`（约 3096 行起）在 `readBootDocs()` **之前**调用 `ensureProjectStructure()`。
- `ensureProjectStructure()` 会补齐 `项目信息.md`（正文是“（待项目经理填写）/（待填写）”）、`需求/00-需求总览.md`（空表头）、六角色目录/角色卡/索引、`src/`、`_tmp/`、`需求/`；缺 `项目铁律.md` 时从团队根复制。
- `readBootDocs()` 随后读到刚生成的文件，`complete:true`；`requireWorkflowBoot()` 信任这份记录。
- `hashCheck` 对旧令牌里没有的 `projectInfo` / `requirementOverview` 返回 true；`roleCard` 也直接 true（因为它和旧令牌的全局角色卡不是同一份）。

**影响**

- “项目信息没写清前不叫角色”被自动模板绕过；产品评审/ Owner 闸门可以建立在一份占位符上。
- 审计上无法区分“角色真的读了项目信息”和“壳刚生成了一份模板”。

**最小修法**

- `bootRole` 先 `readBootDocs`；缺必读就 `MISSING_DOC` 停，只有 `project:create` / 显式 `project ensure` 才允许补模板。
- 在 `requireWorkflowBoot` 的产品评审/Owner 动作前检测占位符（`（待…填写）`、空表头、只有标题的 `R-*.md`），命中返回 `PLACEHOLDER_DOC`。
- UI 把“模板占位”从绿色“可推进”降为 warn，并禁用评审/Owner 按钮。

**验收**

- 删除 `项目信息.md` 后 boot 返回 `MISSING_DOC`，不是自动补模板后 complete；
- `项目信息.md` 仍是“（待填写）”时，产品评审返回 `PLACEHOLDER_DOC`；
- 补完正文后重新 boot 才可评审。

### P1-4 需求创建不要求角色 boot，壳自己 mint 令牌

**证据**

- `createRequirement()`（`src/team-tools.js` 约 3600 行起）只校验 role ∈ `product/analyst`（Owner 新需求走 pm），没有 `requireWorkflowBoot()`。
- 它走 `runLegacyCommand() → withBootToken() → bootToken()`；`bootToken` 会在需要时自己跑一次 `team.mjs boot` 拿令牌。
- 旧流程默认“角色已经先 boot”；新壳把前置变成了“壳替你 boot”。

**影响**

- 需求是流程的第一个写动作，却可以在没有角色阅读证据的情况下创建；再叠加 P1-3，空项目可以先生成一条需求。
- 与 `流程.md` 的“每轮先 boot”不一致；审计上无法证明创建者读过项目信息/需求总览。

**最小修法**

- `createRequirement` 先 `requireWorkflowBoot(role)`；没 boot 返回 `BOOT_REQUIRED`，UI 引导先读。
- Owner 新需求（`createOwnerRequirement`）用 PM 的 boot；如果坚持“PM 代建”，记录 `actor: 'workbench-shell'`，不要显示成产品/需求本人已读。

**验收**

- 全新项目、零角色 boot，`requirement:create` 返回 `BOOT_REQUIRED`；
- 角色 boot 后创建成功，`工作流.json` 记录 `createdBy` + `sessionId`。

### P1-5 旧项目 4 位需求号读不到，恢复后评审/派单会 `MISSING_DOC`

**证据**

- `src/team-tools.js` `REQ_FILE_RE = /^R-\d{8}-\d{6}(?:-[0-9a-f]{2,8})?/i`（约 3047 行）；只认 6 位序号。
- 旧仓库/旧项目里的需求文件名是 4 位：`需求/R-20261103-0001-首页作品流.md`、`R-20261103-0002-作品详情.md`（`项目\微光作品集`）。
- 只读探测：

  ```text
  teamTools.readRequirementDocs('D:/deepseek/agile-workbench/项目/微光作品集')
  → { list: [], count: 0 }
  ```

- `requireWorkflowBoot(name, path, role, { requirementId })` 会拿 `readBootDocs()` 的 `live.requirements.list` 找该需求；找不到就返回 `MISSING_DOC`（“需求 R-… 没有可读正文”）。

**影响**

- 恢复旧项目后，需求卡可能仍从旧 `任务/*.json` 显示，产品评审按钮也可能因角色 boot 完整而可点；一点就 `MISSING_DOC`。
- 旧项目无法在新壳里完成评审/派单，等于“恢复项目”只恢复了壳，恢复了业务却走不动。

**最小修法**

- `REQ_FILE_RE` 改为 `^R-\d{8}-\d{4,6}(?:-[0-9a-f]{2,8})?`（与旧 `scaffold.mjs` 的 4–6 位一致）；补一个旧项目 fixture 测试。
- 或者 `readRequirementDocs` 在 0 条时用旧任务 `type=requirement` 反查文档，按 `id-` 前缀匹配。

**验收**

- 对 `项目/微光作品集` 探测返回 count 2；
- 恢复该项目后，产品评审 `R-20261103-0001` 能通过 `req review`，不再 `MISSING_DOC`。

### P1-6 工作流派单不唤醒、不写回执锁，PM 可以连续派多单

**证据**

- `sendWorkflowNotice()`（`src/team-tools.js` 约 4153 行）固定拼：

  ```js
  'send', '--boot', token, '--to', to, '--subject', subject, '--body', body, '--no-wake',
  ```

  没有 `--ack`。
- 旧 `cmdSend` 只在 `--ack` 时写 `派单锁.json`（`ops.mjs`：`pmDispatch = role==='pm' && args.ack && to!=='pm'`）；工作流派单不写锁，因此 `PM_DISPATCH_PENDING` 不会触发。
- `dispatchRequirement()` / `dispatchTest()` 都复用 `sendWorkflowNotice()`；它们只把 notice 的 messageId 写进 `工作流.json`，没有 wake/ack 状态。
- 补充：`task create` 本身会给 owner 发一条 `ackRequired:true` 的旧协议 note（旧 `cmdTask create` 的 `notify`），所以目标**会收到一条要回执的 note**；但它不是 `send --ack` 的派单锁来源，`ack` 这条 note 也不会清 `派单锁.json`（因为没有写锁）。因此“有回执要求”和“PM 一次只派一个”是两件事，后者仍不成立。

**影响**

- 空闲角色不会被 DSH prompt 唤醒；PM 连派多人不会触发“一次一个”的闸门。
- 与 `团队\流程.md` 的 PM 硬闸门 #6“一次只发一个 send --ack；派单锁未清，不派下一个”直接冲突。
- UI 显示“已派发”，实际可能没人处理；测试派单同样。

**最小修法**

- 复用 `sendDispatch()`（默认 `--ack` + wake 文本），由主进程 `dsh.prompt` 唤醒目标会话；把 `wake/ack/lock` 结果写回 `工作流.json` 的 `dispatch` 字段。
- 如果产品坚持“工作流派单只通知、不唤醒”，UI 必须明确标“仅通知（未唤醒/未加锁）”，不能显示成旧派单成功。

**验收**

- 派单后 `派单锁.json` 存在；未回执时第二次派单返回 `PM_DISPATCH_PENDING`；
- 目标角色收到 wake 文本；`ack` 同 id 后锁清；
- UI 能显示 delivered / wake / read / ack 四段状态。

### P1-7 互审/签字/apply 由壳一口气代跑，没有角色会话或人的证明

**证据**

- `devSubmit()` 调 `legacyProposalAction({ ..., allowMissingSession: true })`（约 4545 行）。
- `devReview()` 连续调 `show` + `review`，两次都 `allowMissingSession: true`（约 4626 / 4630 行）。
- `devApply()` 一次调用里连续 `show → review → sign → apply`，全部 `role: 'pm'`，全部 `allowMissingSession: true`（约 4684–4698 行）。
- `legacyRoleContext()` 注释明确：“工作流编排（需求/任务/提案）只要求团队名册与 boot 令牌，不要求 DSH 会话在线；只有调用方显式允许时才放宽。”

**影响**

- “互审是另一名程序员”“PM 看过才签字”在审计上等于“点击者替这两个角色做了”；六角色可以全不在线，一个人点完整条链。
- 这与 `团队\流程.md` 的 A/B 互审、PM 签字是语义冲突；如果产品定位是“单人编排台”，必须把它写成产品事实，而不是显示成角色本人。

**最小修法**

- `devReview` / `devApply` 绑定对应角色的真实会话（复用 `verifyProjectRoleSession`），或携带一次性角色 nonce；壳只转发，不代跑。
- 至少把 `actor: 'workbench-shell'` / `executor` 写进评审、签字、apply 记录和 UI，让审计能区分“角色本人”和“壳代跑”。
- `devApply` 拆成 `show/review/sign/apply` 四步确认，或在一次点击前展示 `proposalHash`、必需签字人、当前签字状态。

**验收**

- 无对应角色会话时 `devReview` / `devApply` 返回 `SESSION_ID_REQUIRED`；
- 或有会话时记录含真实 `sessionId`；壳代跑时记录含 `actor=workbench-shell`。

### P1-8 sensitive/critical 提案没有 Owner TTY 签字通道，选高 risk 会卡死在 apply

**证据**

- UI 的 `dev-submit` 表单仍提供 `normal / sensitive / critical` 三档（`src/renderer/app.js` 约 4759 行）。
- `devSubmit()` 把 UI 的 `risk` 原样传给旧 `propose`（约 4543 行）。
- `devApply()` 只以 PM 身份 `show + review + sign + apply`（约 4684–4698 行），没有收集其他角色签字，也没有 `owner-approve` 桥；`src/team-tools.js` 里没有 `owner-approve` 的调用。
- 旧 `requiredSets()`：`sensitive/critical` 的签字人 = 所有角色 + `owner`；`checkApprovals()` 对 owner 签字额外要求 `channel === 'tty'`，否则 `OWNER_CHANNEL`。

**影响**

- 选 `sensitive`/`critical` 的提案在 `apply` 时会被判 `APPROVALS_INCOMPLETE` / `MISSING_SIGNATURE owner`；新壳没有 UI 路径补齐。
- “越按安全流程选高风险，越走不完”；用户会认为工作台坏了。

**最小修法**

- MVP 只允许 `normal`：UI 把 `sensitive/critical` 禁用并写明“需旧终端 owner-approve，当前未接入”。
- 或增加 `owner-approve` 桥：给出手工终端命令 + 回填签名文件的流程；同时补齐其他角色签字 UI。

**验收**

- 选 `sensitive` 时要么按钮禁用并解释，要么能完成：所有角色 review/sign + owner TTY 签名后 `apply` 成功；
- `proposal` 详情展示 `requiredSigners` 与每个角色的 review/sign 状态。

### P1-9 收口没有 verify/pilot 健康闸门，账本问题不曝光

**证据**

- `main.js` 的 `team:*` IPC 没有 `team:verify` / `team:pilot`；`team:reconcile` 只调用本机 `reconcileProjectCommStates()`（消息/唤醒/已读/回执），不是旧 `team.mjs reconcile`。
- 旧 `cmdVerify()` / `cmdPilot()` 仍存在，但新壳没有入口把它展示出来。
- 当前仓库团队状态仍有两个指向缺失目录的登记（`个人博客项目`、`个人简历展示项目`），旧 `team.mjs verify` 在历史 QA 中报 9 个问题；本快照未重跑（它读真实账本，属只读但会产生日志/输出，见 §7）。
- `流程.md` 的收口顺序是 `reconcile → verify → pilot → board`；新壳没有后两步。

**影响**

- 用户可以在 `verify` 仍 FAIL、`pilot` 未过的情况下点“Owner 验收/下一轮”；收口没有健康证据。
- 幽灵登记/产物漂移/stale lock/超时提案不会在界面出现；真实账本问题无法作为发布门槛。

**最小修法**

- 加只读 `team:verify` / `team:pilot` IPC 和“健康检查”卡：展示问题数/明细/路径；不自动修。
- 收口/下一轮按钮在 `verify` 非绿时给明确警告（不一定要硬阻断，避免又造一个死按钮）。

**验收**

- 界面能看到 `verify` 的问题明细和 `pilot` 五项；
- 幽灵登记能在“项目健康”里被列出，而不是只在 CLI 里。

### P1-10 两套 Owner 状态并存：项目级 `owner:decide` 与需求级 `requirement:owner` 互不相通

**证据**

- `main.js` 仍暴露 `owner:decide`（约 5418 行）：调用 `ownerDecide()` 写本地 `project.ownerReview`，再 `recordOwnerDecision()` 写 `工作流.json` 的**顶层** `ownerReview`；不写任何需求的 `requirements[id].ownerReview`。
- 需求级入口是 `requirement:owner`（约 3873 行）→ `ownerRequirementDecision()` → 新 `owner` 命令，写需求级字段。
- 派单检查的是需求级字段：`dispatchRequirement()` 里 `if (!meta.ownerReview || !['approved','skipped'].includes(...)) return OWNER_REVIEW_REQUIRED`。
- UI 已经把“旧版项目级评审”单独标注为“不参与 PM 派单”，这是正向的；但 `preload.js` 仍暴露 `ownerDecide`，`#btn-owner-legacy` 仍可打开旧弹窗。

**影响**

- 用户点旧版项目级“Owner 通过”，界面可能显示“Owner 已通过”，但派单仍 `OWNER_REVIEW_REQUIRED`；两套状态、两套后果。
- 审计上会出现“顶层 Owner 通过、需求级 Owner 未决定”的分叉。

**最小修法**

- 只保留一个 Owner 闸门：`owner:decide` 必须带 `requirementId` 并写需求级；或删除该 IPC / 隐藏入口，只留需求级。
- 如果保留项目级状态，明确标注“项目级备注，不参与派单”，且不要把“通过”渲染成需求已放行。

**验收**

- 任意 Owner 入口写完后，`需求 R-…` 与 `工作流.json.ownerReview` 的需求级状态一致；
- 派单只读需求级；顶层状态不再能单独放行。

### P1-11 发布证据不完整：真实 DSH 六会话未覆盖，完整开发链仍跑 mock

**证据**

- `npm run selftest` 的主链（ROUND10）仍通过 `createWorkflowProtocolMock()` 注入旧命令桩（`main.js` 约 7728 行）；`selftestRound10RealCommands()` 只覆盖真实 `req review` / `owner` / `owner --action accept`，**没有覆盖完整开发链**（propose→review→sign→apply→test）。
- selftest 的 DSH 是 mock；没有真实六角色 DSH 会话执行。
- 当前 app 的 `团队\工具` 与旧仓库 `团队\工具` 是两棵树（§1.2），命令集不同；修复/审计容易打错树。

**影响**

- `selftest` 绿不能证明“真实 DSH 上六个角色能跑完”；发布/验收证据不足。
- 两棵树会让后续修 P0/P1 时只修一边，另一边继续报旧结论。

**最小修法**

- 加一条受控的真实 DSH smoke（不要求全自动）：建工作区 → 六会话 → 产品评审 → Owner skip → 派单 → 一个最小提案 apply → 测试 done → Owner accept；把命令/会话 id/哈希留证。
- 收敛工具树：以 app 的 `团队\工具` 为准，旧仓库副本同步或删除；`团队/流程.md` 补新命令参数表。
- selftest 增加“真实命令完整开发链”用例，或明确标注“mock 主链 + 真实命令子集”的边界。

**验收**

- 真实 DSH smoke 报告含六个 `sessionId`、一次 apply commit、一次 test done、一次 owner accept；
- 两棵树的 `legacyCapabilities().missing` 一致；
- `npm run selftest` 的报告明确区分 mock/real，不再把 mock 绿当真实绿。

---

## 5. 已修复 / 不要再重复的结论

> 这一节是给后续审计/评审用的“防重复”清单。旧报告（`PARITY-ROUND12.md`、`QA-ROUND12-CORE.md`、`QA-ROUND12-UI.md`）写于 16:19–16:29，早于 16:37 的工具升级；它们的 P0-1 与部分 UI P1 已被当前快照修掉。

### 5.1 P0-1「发行物缺 req review / owner / workflow」——**当前 app 的团队工具已修**

- `团队\工具\team.mjs` 已有：

  ```js
  case 'owner': cmdOwner(args); break;
  case 'workflow': cmdWorkflow(args); break;
  ```

- `ops.mjs` 已有 `cmdReqReview` / `cmdOwner` / `cmdWorkflow`；`lib/workflow.mjs` 新增（40 KB），落 `工作流.json` + 需求文档/总览 + 评审/验收记录。
- 只读能力探测（当前 app 的树）：

  ```json
  {
    "available": true,
    "missing": [],
    "optionalMissing": [],
    "commands": { "workflow": true, "owner": true, "reqReview": true }
  }
  ```

- `src/main.js` 已新增 `selftestRound10RealCommands()`，对真实 `req review` / `owner` / `owner --action accept` 做正向断言；缺命令负例改用最小桩工具（不再拿真实工具断言“必缺”）。

**因此：不要再把“缺三条命令、需求评审必断”写成当前 P0。** 对旧仓库 `D:\deepseek\工作台\团队\工具` 仍然成立；对当前 app 的运行树不成立。

### 5.2 UI「缺命令仍可点」——**已修**

- `src/renderer/app.js` 的 `legacyReqButton()` 现在调用 `legacyActionCommandGate(action)`；`LEGACY_ACTION_COMMANDS` 把 `requirement-review`→`req review`、`owner-review`→`owner`、`owner-accept`→`owner,workflow` 等映射到能力表；缺命令时按钮 `disabled` 并给出 `commandGate.reason`。
- `legacyBootControl()` 也按 `legacyActionCommandGate('boot')` 禁用。

### 5.3 UI「boot 过期仍显示已读全、无法重新 boot」——**已修**

- `legacyBootFor()` 计算 `expiresAt` / `expired` / `remainingMs`，`ready` 包含 `!expired`、`!stale`、`!roundMismatch`。
- `legacyBootControl()` 在过期/文档变更/跨轮时显示“重新 boot”，不再按 `complete` 一律禁用。
- `scheduleBootExpiryTick()` 到点自动重绘，避免页面停在绿色“可推进”。

### 5.4 能力缓存不失效——**已修**

- `legacyCapabilities()` 现在用 `legacyCapabilityFingerprint()`（`team.mjs` + `lib/ops.mjs` + `lib/workflow.mjs` 的 size/mtime）做缓存键；工具升级后不必重启工作台即可重新探测。

### 5.5 UI 模板占位仍然可推进——**只修了文案，没修闸门**

- 当前 `legacyGateResultMarkup` 会把“有模板占位”显示成 `可推进（有模板占位）`，不再是纯绿色“已读全”；但评审/Owner 按钮仍未因占位符禁用。
- 对应后端问题仍是 **P1-3**（boot 先补模板），不要因为文案变了就当成已修。

### 5.6 其他旧报告的 P1/P2，仍然存在的

- `PARITY-ROUND12` P1-1（派单不唤醒/不加锁）→ 本文 **P1-6**，仍存在。
- `PARITY-ROUND12` P1-2（互审/签字壳代跑）→ 本文 **P1-7**，仍存在。
- `PARITY-ROUND12` P1-3（boot 先补模板）→ 本文 **P1-3**，仍存在。
- `PARITY-ROUND12` P1-4（两套 Owner 闸门）→ 本文 **P1-10**，仍存在（UI 已标注旧版不参与派单，但 IPC 仍在）。
- `PARITY-ROUND12` P1-5（sensitive/critical 无 Owner TTY 通道）→ 本文 **P1-8**，仍存在。
- `PARITY-ROUND12` P1-6（需求创建不要求 boot）→ 本文 **P1-4**，仍存在。
- `PARITY-ROUND12` P1-7（无 verify/pilot 健康闸门）→ 本文 **P1-9**，仍存在。
- `PARITY-ROUND12` P1-8（propose 授权自动补发）→ 仍在 `ensureProposeGrant()`；不属于主链阻断，未单列 P1，建议在 P1-7 的“壳代跑”修复里一起处理（不要自动批准，改为缺授权时提示 PM 一键 grant）。

---

## 6. 发布前最小验收清单

> 按“能证明”的标准，不按“点过了”的标准。每项都要有命令/路径/哈希/截图之一。

### 6.1 必须绿（P0/P1）

- [ ] `npm run check` exit 0。
- [ ] `legacyCapabilities().missing.length === 0`；且 `missing` 不含 `req review` / `owner` / `workflow` / `req create` / `task claim` / `task done`。
- [ ] P0-1：无有效 Owner nonce 的 `requirement:owner` / `owner:accept` 被拒绝；或有方案 B 的 `actor=workbench-shell` 记录与文案。
- [ ] P1-1：DSH 停止时建项目返回 `ok:true + workspace.pending`（或 UI 明确禁用并说明，不允许“填完再回滚”）。
- [ ] P1-2：真实 DSH 六会话 smoke：六个 `团队·角色`、六个 `sessionId`、`workspace/create` 的 `sessionIds` 能对上；第二次建团队不新建。
- [ ] P1-3：删除 `项目信息.md` → boot `MISSING_DOC`；占位符 → 评审 `PLACEHOLDER_DOC`。
- [ ] P1-4：零 boot 建需求 → `BOOT_REQUIRED`；boot 后创建成功。
- [ ] P1-5：`readRequirementDocs('项目/微光作品集').count === 2`；旧 `R-20261103-0001` 能 `req review`。
- [ ] P1-6：派单写 `派单锁.json`；第二单 `PM_DISPATCH_PENDING`；目标收到 wake；`ack` 清锁。
- [ ] P1-7：无会话 `devReview` / `devApply` → `SESSION_ID_REQUIRED`；或有 `actor=workbench-shell` 记录。
- [ ] P1-8：`sensitive`/`critical` 要么禁用并解释，要么完成全员签字 + owner TTY 后 apply 成功。
- [ ] P1-9：界面能显示 `verify` 问题数与 `pilot` 五项；幽灵登记可见。
- [ ] P1-10：项目级 `owner:decide` 不再能单独放行派单；需求级 `ownerReview` 是唯一真相。
- [ ] P1-11：真实 DSH smoke 证据 + 两棵树 `legacyCapabilities` 一致 + selftest 报告区分 mock/real。

### 6.2 主链实跑（普通风险）

按顺序，每一步都留 `sessionId` / `taskId` / `proposalId` / `commitId` / `工作流.json` 路径：

1. 新建项目（DSH 在线）→ 六角色目录/索引/项目信息模板；
2. 建团队 → 六会话；
3. 六角色 boot（产品/需求/PM 至少）；创建需求（带验收标准）；
4. 产品 `req review --verdict approve`；
5. Owner `owner --decision skipped`（或 approved）；
6. PM 派开发 → 目标 wake + ack + claim；
7. 程序员 `propose` → 另一名程序员 `show/review` → PM `show/review/sign/apply`；
8. 开发任务 `done`（带 commitId）；
9. PM 派测试 → 测试 `claim/done`（带证据）；
10. Owner `owner --action accept --decision accepted`；
11. `iterate` 或 `terminate`；
12. 每步后看 `工作流.json`、需求文档状态行、旧任务状态、看板/事件链。

### 6.3 负例（缺一不可）

- [ ] 未 boot 调评审/派单 → `BOOT_REQUIRED`；
- [ ] 角色不符 → `ROLE_NOT_ALLOWED`；
- [ ] 缺命令（桩工具）→ `LEGACY_PROTOCOL_REQUIRED`，且不写状态；
- [ ] 终态后派单/建需求 → `WORKFLOW_TERMINATED`；
- [ ] 提案 CAS 失败 → `STALE_BASE`；
- [ ] Owner 验收前测试未 done → `TEST_NOT_DONE`；
- [ ] 旧 4 位需求 + 新壳 → 修复后能通过，修复前明确 `MISSING_DOC`（不要静默）。

---

## 7. 复验命令（只读/低副作用）

```powershell
# 1) 语法（只读）
npm run check

# 2) 能力探测（只读；会读 team.mjs/ops.mjs/workflow.mjs）
node -e "const t=require('D:/deepseek/agile-workbench/src/team-tools.js'); console.log(JSON.stringify(t.legacyCapabilities(),null,2))"

# 3) 旧项目 4 位需求号探测（只读）
node -e "const t=require('D:/deepseek/agile-workbench/src/team-tools.js'); console.log(JSON.stringify(t.readRequirementDocs('D:/deepseek/agile-workbench/项目/微光作品集'),null,2))"

# 4) 新命令是否存在（只读）
node 团队\工具\team.mjs help | Select-String "req review|owner |workflow "

# 5) 文件快照（与 §1.1 对比；变了就重审）
Get-FileHash src\main.js,src\team-tools.js,src\renderer\app.js,团队\工具\team.mjs,团队\工具\lib\ops.mjs,团队\工具\lib\workflow.mjs -Algorithm SHA256

# 6) 真实账本健康（只读，但会读团队状态；不要改状态）
node 团队\工具\team.mjs verify
node 团队\工具\team.mjs pilot
```

> `npm run selftest` 会写 `.selftest-data\`（隔离开关），本轮未跑；需要发布证据时在干净环境跑，并把“真实命令/真实 DSH”与“mock”分开记录。

---

## 8. 边界与未证明

- **本轮没有真实 DSH 六会话执行**：`legacyCapabilities` 与 `readRequirementDocs` 是真实调用；六会话、六角色 agent 执行、真实终端 TTY 均未在本轮驱动。
- **没有跑 `npm run selftest`**：它写 `.selftest-data\`；本文只能引用代码里的 selftest 设计（`selftestRound10RealCommands()` 覆盖三条命令的正向，主链仍 mock）。
- **没有逐个点 UI**：UI 结论来自 `src/renderer/app.js` 的当前代码路径；旧 `QA-ROUND12-UI.md` 的截图/行号早于 16:40，不能直接复用。
- **代码在动**：16:37–16:47 期间 `team.mjs`、`ops.mjs`、`workflow.mjs`、`main.js`、`team-tools.js`、`app.js` 都发生了变化；本文行号是 16:47 快照的近似值，复验请按函数名/命令名，不要按行号。
- **旧仓库不是当前运行树**：`D:\deepseek\工作台\团队\工具` 仍缺三条命令；拿它审当前 app 会得到过期结论（§1.2、§5.1）。

---

## 9. 一句话给 PM

**先把 P0-1（Owner 身份或明确降级）和 P1-6（派单唤醒/回执锁）修掉，再用真实 DSH 跑一遍 §6.2；P1-3/P1-5 决定“新项目能不能算真的读了/旧项目能不能恢复”，P1-8/P1-9 决定“高风险提案和收口能不能验收”。其余 UI 死按钮/过期绿标已在当前快照修掉，不要再按旧报告重复派单。**
