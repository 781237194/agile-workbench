# MVP Round 3 阻断清单：新建项目 → 建团队 → 需求 → 评审 → 派单 → 开发互审 → 测试 → 验收

> 只读审计，未修改 `src/**`、`团队/**`、`项目/**`。
> 审计对象：当前代码 `D:\deepseek\agile-workbench`；旧仓库 `D:\deepseek\工作台` 只作为旧团队协议基线，不作为当前 app 的运行树。
> 快照：2026-11-05 18:25 +08:00。
> 本文只列**会阻断主链**或**让主链必经闸门失效**的问题；已修项、P2、纯 UI 观感不列。

**定位前提**：本文按“六角色真实协作”审计——需求、评审、开发互审、测试、Owner 验收都应能对应到真实角色会话/证据。如果产品明确改成“单编排台”，P0-2、P1-1、P1-2 应降级，并且必须把“角色已做”改成“工作台代记”，不能既叫六角色又不要求会话证据。

---

## 0. 一句话结论

主链的按钮、文件、工作流状态已经能点通，但当前仍不能作为“可验收的六角色闭环”发布：

1. **需求创建的回退路径会写第二份正文**，标题特殊时同 ID 两份，需求真相分叉；
2. **Owner 决定/验收没有身份**，最终闸门可以由任意调用方完成；
3. **派单不唤醒、不加派单锁**，真实角色不会开始，PM 也可以连派；
4. **互审、PM 签字、apply 允许壳代跑**，另一个程序员不是必要条件；
5. **验收没有独立测试证据和 verify/pilot 闸门**，测试说“ok”就能过。

---

## 1. 判定口径

- **P0**：主链直接产生两个真相、或必经闸门失效，导致“走完也不可信/不可复现”。
- **P1**：主链在“正常路径 + 人工补一步”下可能走通，但真实使用会卡住、误导、丢闸门或让发布证据不成立。

---

## 2. P0

### P0-1 需求创建的回退路径会写第二份同 ID 正文（特殊标题必现）

**现象**

创建一条需求后，`需求/` 下可能出现两个同 ID 的 `R-*.md`；标题含全角冒号等“旧工具与壳命名规则不同”的字符时必现。本轮临时项目 `_tmp/round14-ui/projects/QA14-新项目/需求/` 实测：

```text
R-20261105-0001-首条需求_文档就绪验证.md      （旧工具生成，501 B）
R-20261105-0001-首条需求：文档就绪验证.md     （壳 fallback 生成，333 B）
```

`readRequirementDocs()` 对该目录返回 `count: 2`；`00-需求总览.md` 只指向其中一个。

**证据**

- `src/team-tools.js:3931-3938`：

  ```js
  const legacyRel = run.value && run.value.doc ? String(run.value.doc).replace(/\\/g, '/') : '';
  if (legacyRel) { ... return abs; }
  return writeRequirementDoc(ctx.projectPath, task, meta);
  ```

  这里把 `run.value.doc` 当字符串处理。

- `团队/工具/lib/ops.mjs:573,591`：`const doc = ensureRequirementDoc(...)`，JSON 返回的是 `{ ok:true, requirement, doc, overview, index, warnings }`；`doc` 是对象，不是路径字符串。

- `团队/工具/lib/workflow.mjs:305-307`：`ensureRequirementDoc()` 明确返回 `{ file, created }`。

- 因此 `String(run.value.doc)` 得到 `"[object Object]"`，`fs.existsSync(abs)` 为 false，桥接层必然走 `writeRequirementDoc()` 再写一份；旧工具已经写的那份不会删除。

**为什么是 P0**

- 这条 fallback 是**无条件触发**的：`String({ file, created })` 永远不等于真实路径，所以壳总会再写一份。标题特殊时文件名不同 → 两份同 ID 正文；标题普通时 fallback 可能同名覆盖旧工具骨架，仍会绕开旧工具的 `doc.created`/总览行。
- 违背“一个需求一个 `R-*.md`”的硬规则，`需求/` 里出现两个同 ID 正文。
- `readRequirementDocs()`、`boot` 的 `requirements.list`、`00-需求总览`、项目索引、评审/验收更新可能各指一份；用户改到 orphan 那份时，工作流读不到。
- 后续 `req review`、`owner`、`owner accept` 都按需求 ID 找文件；同 ID 两份会让“评审的是哪份、验收的是哪份”不可复核。这是需求阶段直接产生的真相分叉，不是显示问题。

**最小修法（二选一）**

- 桥接层兼容两种返回：`doc` 是字符串时直接用；是对象时用 `doc.file`；只有确实找不到 `doc.file` 时才 fallback。
- 或者旧 `req create` 的 JSON 同时返回 `docFile: doc.file`，桥接层只认 `docFile`。

**验收**

- 全新项目建一条标题含全角冒号的需求，`需求/` 下同 ID 文件只能有 1 个。
- `readRequirementDocs(projectPath).count === 1`，且 `00-需求总览` 的文件链接与实际文件一致。
- 重跑一次 `req create` 同一标题不应再新增第二份。

---

### P0-2 Owner 决定/验收没有身份，Owner 闸门可被任意调用方完成

**现象**

`requirement:owner`、`owner:accept` 都从调用参数取 `role`，缺省就是 `"owner"`；后端只判断 `role === 'owner'`，没有 nonce、没有 TTY、没有本机凭据。写出的记录是 `by: "Owner"`，但无法证明是 Owner 本人做的决定。

**证据**

- `src/team-tools.js:4091-4168` `ownerRequirementDecision()`：

  ```js
  const role = String(input.role || '').trim();
  if (role !== 'owner') return failure('ROLE_NOT_ALLOWED', ...);
  ...
  row.ownerReview = { status: decision, by: 'Owner', at, opinion, source: 'team.mjs owner', ... };
  ```

  只校验字符串 `owner`，没有身份材料。

- `src/team-tools.js:5187-5292` `ownerAccept()`：

  ```js
  const role = String(input.role || 'owner').trim();
  ...
  row.acceptance = { status: decision, by: role, at, opinion };
  state.ownerReview = { required: true, status: 'approved', kind: 'acceptance', by: role, at, opinion };
  ```

  `role` 缺省即 `owner`，验收记录同样只靠调用方自报。

- `src/main.js:3900-3907`：`requirement:owner` 默认 `role: String(p.role || 'owner')`。
- `src/main.js:3972-3979`：`owner:accept` 默认 `role: String(p.role || 'owner')`。
- 对照旧工具里唯一有身份语义的 `owner-approve`：`团队/工具/lib/ops.mjs:1881-1917` 要求真实 TTY、输入 `批准 P-...`、写 `nonce` 和 `signatureDigest`。当前工作流的 `owner`/`owner:accept` 没有走这条路径。

**为什么是 P0**

- “验收”是主链最后一道闸门。任何能调 IPC/CLI 的调用方都能把需求标成 `accepted`，审计账本上的 `by: "Owner"` 不能证明 Owner 做过决定。
- 与 `MVP-BLOCKERS.md` 的 P0-1 同源；本轮 18:25 快照仍未修。
- 如果产品定位是单编排台，必须把字段改成 `recordedBy: "operator"` / `actor: "workbench-shell"`，并改文案；不能继续写 `by: "Owner"`。

**最小修法（二选一）**

- 保留 Owner 闸门：加一次性 nonce（主进程生成、只写当前用户可读文件），或要求真实 TTY 的 `owner-approve`，校验后写 `nonceHash`/`channel`；无有效凭据返回 `OWNER_IDENTITY_REQUIRED`。
- 承认单编排台：字段改 `recordedBy`/`actor`，UI 显示“已记录 Owner 意见（未做身份认证）”，不再显示“Owner 本人已通过/已验收”。

**验收**

- 无 nonce/TTY 调 `requirement:owner`、`owner:accept` → `OWNER_IDENTITY_REQUIRED`。
- 有 nonce/TTY 的记录带 `nonceHash`、`channel`、`expiry`，且 UI 不再伪造 `by=Owner`。

---

## 3. P1

### P1-1 派单/测试派单只记账不唤醒，也不加派单锁

**现象**

PM 点“派单”后，开发任务和 `工作流.json` 状态已经变成 `dev`，但目标程序员的 DSH 会话没有被唤醒；PM 也可以连续派多条，因为这条路径没有写旧协议的派单锁。

**证据**

- `src/team-tools.js:4527-4547` `sendWorkflowNotice()` 固定使用：

  ```js
  'send', '--boot', token, ... '--no-wake'
  ```

- `dispatchRequirement()` 在 `src/team-tools.js:4652` 调 `sendWorkflowNotice()`，随后 `4665` 直接把 `row.status = 'dev'`。
- `dispatchTest()` 在 `src/team-tools.js:5151` 调同一个 `sendWorkflowNotice()`，随后 `5164` 直接把 `row.status = 'test'`。
- `src/team-tools.js:4667`、`:5166` 只记 `messageId`，没有 `wakeText`、没有 DSH prompt、没有 dispatch lock。
- 对照旧 `sendDispatch()`：`src/team-tools.js:1813-1838` 会生成四步唤醒文案，交给主进程 DSH 适配层发送；工作流派单没有复用这条路径。
- UI 的 `requirement:dispatch` 映射在 `src/renderer/app.js:5082`，动作完成后只记结果，没有额外的 `dsh.prompt`。

**影响**

- 真实六会话模式下，PM 派单后程序员不会启动，主链停在“开发认领”；只能靠人手动打开角色会话或再点一次“全队 boot”。
- 没有 `--ack`/dispatch lock，PM 可以同时派多个开发/测试任务；“一次只派一个、等回执”的规则在工作流路径上没有执行。
- 旧 `MVP-BLOCKERS.md` P1-6 已报；当前快照仍在。

**最小修法**

- 派单成功后，由主进程用目标角色的当前项目 `sessionId` 发一次 `wakeMessageFor()` 四步文案（boot → inbox → read → ack），唤醒失败要返回 `WAKE_FAILED`，不能只写 `warnings`。
- 要么让 `sendWorkflowNotice` 带 `--ack` 并复用 PM 派单锁；要么在 `工作流.json` 里记录 pending 派单，未 ack 前禁止下一条。

**验收**

- 派单后目标会话出现一条真实 prompt，角色执行 `ack` 后 PM 才能派下一条。
- 目标会话无 `sessionId` 时派单明确失败，不是“消息已写、状态已 dev”。

---

### P1-2 开发互审、PM 签字、apply 允许壳代跑，互审不是可验证闸门

**现象**

“开发互审”按钮由当前操作者点击，后端以另一个程序员的 role 执行 `show + review`；这个程序员不要求有真实 DSH 会话。PM 的 `show + review + sign + apply` 也在一次 `devApply` 里连续完成。

**证据**

- `src/team-tools.js:5000-5006`：

  ```js
  const shown = await legacyProposalAction({ ..., action: 'show', allowMissingSession: true });
  const reviewed = await legacyProposalAction({ ..., action: 'review', allowMissingSession: true });
  ```

- `src/team-tools.js:5059-5073`：PM 的 `show`、`review`、`sign`、`apply` 全部 `allowMissingSession: true`。
- `src/team-tools.js:2061-2083` `legacyRoleContext()`：

  ```js
  if (!session && contextOptions.allowMissingSession !== true) {
    return failure('SESSION_ID_REQUIRED', ...);
  }
  ```

  显式允许“没有当前项目会话”执行旧评审协议。

- `bootRole()`（`src/team-tools.js:3305-3433`）也不要求真实 DSH 会话即可写 boot 记录；UI 的互审按钮在 `src/renderer/app.js:5369-5385` 只是按 role 调用。

**影响**

- 一个操作者可以在一台工作台上点完“程序员 A 提交 → 程序员 B 互审 → PM 签字/apply”，而 B 的会话从未参与。
- 如果 MVP 的卖点是“六角色 + 开发互审”，这条闸门目前不是可验证的；只能算“工作台代记”。
- 与旧 `MVP-BLOCKERS.md` P1-7 同源；本轮仍在。

**最小修法**

- 开发互审必须带 `reviewer` 当前项目的真实 `sessionId`，用 `main.js` 已有的 `verifyProjectRoleSession()` 核验会话归属后再执行；没有会话就拒绝，并提示“先在 B 会话里执行 review”。
- 如果保留壳代跑，记录 `actor: "workbench-shell"`，UI 显示“代记互审”，不要把 `peerReview.by` 写成真实程序员。

**验收**

- 删除 B 的会话/`sessionId` 后，互审按钮返回 `SESSION_ID_REQUIRED`，不能写 `peerReview.approved`。
- 真实 B 会话执行 review 后，记录里带可核验的 `sessionId`。

---

### P1-3 验收没有独立测试证据和 verify/pilot 闸门

**现象**

测试任务 `done` 只要求一个字符串 `evidence`；Owner 验收只要求 `meta.status === 'test_done'` 和 tester 已 boot。没有要求测试报告文件、没有跑 `team.mjs verify`、没有 `pilot`，验收就能通过。

**证据**

- `src/team-tools.js:4769-4771`：`const evidence = ...; if (!evidence) return failure('EVIDENCE_REQUIRED', ...)`。只校验非空字符串。
- `src/team-tools.js:4806-4816`：测试 done 只写 `row.test = { taskId, doneAt, evidence }`、`row.status = 'test_done'`；没有测试报告/`verify` 结果。
- `src/team-tools.js:5212-5214`：`ownerAccept()` 只要求 `meta.status === 'test_done'`；`5220` 只校验 tester 的 boot，不校验测试产物。
- `src/team-tools.js` 中没有调用 `team.mjs verify` 或 `team.mjs pilot`（grep 无命中）；`src/main.js` 也没有 `verify`/`pilot` 工作流入口；UI 只有 `teamReconcile`（通信链对账），没有质量闸门。
- 对照旧团队工具：`verify` 会检查产物漂移、提案哈希、审批；`pilot` 会检查回执/提案/陈旧拒绝/锁争用。新工作流没有把这些接到 `ownerAccept`。

**影响**

- 测试人员输入“ok”即可 `task done`，Owner 点通过即 `accepted`；产物漂移、提案/签字不完整、回执缺失都不会阻断验收。
- “测试 → 验收”可以走完，但没有可复现的质量证据；发布证据不成立。
- 与旧 `MVP-BLOCKERS.md` P1-9 同源；本轮仍在。

**最小修法**

- 测试 done 必须要求测试报告文件（`测试人员/验收报告.md` 或等价产物）并记录哈希；Owner 验收前跑 `team.mjs verify --project <项目>`，失败直接拒绝。
- 如果保留 `pilot` 作为扩编门槛，至少在 `ownerAccept`/收口时跑一次；不要只写“已验收”。

**验收**

- 删除测试报告/制造产物漂移后，`owner:accept` 必须失败并返回 `VERIFY_FAILED` 或 `TEST_EVIDENCE_MISSING`。
- 干净项目 `verify` 通过才允许 `accepted`。

---

### P1-4 新建项目硬依赖 DSH，DSH 不可达会整单回滚

**证据**

- `src/main.js:2399-2509` `createProject()`：先 `ensureProjectReady()`，再写本地库，再 `activateWorkspace()`（`2465`）；`activation.ok` 为 false 时抛错并 `rollbackCreatedProject()`（`2492-2509`）。
- DSH 未启动、地址错、重启中时，第一步 `project:create` 直接失败，本地项目也被回滚。

**影响**

- 用户连“先建一个本地项目、稍后绑 DSH”都做不到；首屏最容易看到的是 `DSH_OFFLINE`/`DSH_WORKSPACE_CREATE_FAILED`，不是可继续的 pending 状态。
- 与旧 `MVP-BLOCKERS.md` P1-1 同源；本轮仍在。

**最小修法**

- 允许 `workspace.pending=true`：本地项目/六角色目录/索引先落，返回 `ok:true` + pending；只在“建团队”时要求 DSH 在线。
- 或 UI 在 DSH 离线时明确禁用“新建项目”并给出单一恢复入口，不要先填表再回滚。

**验收**

- 停掉 DSH，`project:create` 返回 `ok:true` + `workspace.pending:true`；启动 DSH 后 `team:ensure-project` 能补绑。

---

### P1-5 建团队首次经常返回 `SESSION_BLANK`，界面显示失败但会话已建

**证据**

- `src/main.js:1382-1403`：`provisionTeamSessions()` 在 `launch` 后立即 `inspectProjectSessions()`；`blankAfter.length` 非空时返回 `ok:false, code:'SESSION_BLANK'`，即使 `result.sessions` 已创建。
- `seedVisible` 的“已就位”是 queue prompt；刚发完立刻查 `session/list` 时 `blank` 可能仍为 true，于是第一次建团队很容易落到 `SESSION_BLANK`。
- 旧 `MVP-BLOCKERS.md` P1-2 已报；当前代码仍返回 `ok:false`。

**影响**

- 六个会话其实已经建好，UI 却提示“启动团队失败/还有角色是空白会话”，用户重复点，重复 seed。
- 与“建团队”这一步的“成功/失败”语义冲突；用户无法判断是否可以继续。

**最小修法**

- 轮询 `session/list`/projections 一小段时间，区分“刚建、尚未产生 turn”和“真失败”；返回 `ok:true` + `pendingSeed` + “补发就位”按钮，不要用一次瞬时 `blank` 判失败。
- 或把 `seedVisible` 默认关掉，由用户显式补发。

**验收**

- 首次建团队返回 `ok:true`（可有 `pendingSeed`），六个 `sessionId` 落库；第二次调用只复用，不新建。

---

### P1-6 sensitive/critical 提案没有 Owner TTY 签字通道

**证据**

- `src/team-tools.js:5038-5110` `devApply()` 只以 PM 身份跑 `show + review + sign + apply`；没有 owner 签字。
- 旧 `团队/工具/lib/ops.mjs:140` 在 `checkApprovals()` 中要求：`role === 'owner'` 的签字必须 `channel === 'tty'`（selftest 例外）。
- 唯一能产生这种签字的 `owner-approve` 在 `团队/工具/lib/ops.mjs:1881-1917`，要求真实 TTY 和 `批准 P-...` 输入；当前 app 没有对应 IPC/UI，工作流 `devApply` 也没有调用它。
- 因此开发提案一旦标成 `sensitive`/`critical`，`apply` 会因缺 owner 签字卡住。

**影响**

- 普通 `normal` 提案可走通；高风险变更在 UI 里没有完成路径，只能切回 CLI 终端手工 `owner-approve`。
- 如果 MVP 允许用户选 risk，这是高风险路径的直接阻断。

**最小修法**

- 在桥接层提供 `owner-approve` 的受控入口（TTY 或 nonce），并在 `devApply` 前检查 owner 签字；或 UI 不提供 sensitive/critical 选项，明确只支持 normal。

**验收**

- `sensitive` 提案无 owner TTY → `OWNER_TTY_REQUIRED` / `MISSING_SIGNATURE`，不是静默卡住。
- 有 owner 签字后 `apply` 通过。

---

### P1-7 开发提交的 `expect` 默认当前哈希，CAS 前置失效

**证据**

- `src/team-tools.js:4885-4895`：

  ```js
  const current = fs.existsSync(abs) ? sha256(...) : 'absent';
  const expect = row.expect || current;
  if (expect !== current) return failure('STALE_BASE', ...);
  ```

  `row.expect` 为空时直接取**提交时**的当前哈希，等于没有声明“我读到的是哪个版本”。

- 旧 `team.mjs propose` 要求显式 `--expect 目标=当前哈希`；新工作流 `devSubmit` 的 UI 不强制填 `expect`，所以默认路径没有读后校验。

**影响**

- 程序员基于旧版本内容提交时，桥接层用提交时的当前哈希做 base，apply 的 CAS 不会发现“提交内容基于旧读”。
- 版本栅栏只在 propose 之后、apply 之前有效；读 → 写之间的窗口没有保护。

**最小修法**

- `devSubmit` 必须要求 `expect`，或从该角色最近一次 `find/show/read` 的记录里取 hash；没有读证据就返回 `EXPECT_BASE_REQUIRED`。
- UI 提交表单显示目标当前哈希并要求确认。

**验收**

- 不传 `expect` → `EXPECT_BASE_REQUIRED`；传旧 hash → `STALE_BASE`。
- 两人同 base 提交，后提交者在 apply 时仍被 CAS 拒绝。

---

### P1-8 需求创建自动 boot，绕过“角色先 boot”闸门

**证据**

- `src/team-tools.js:3892-3899` `createRequirement()` 直接 `runLegacyCommand(ctx.name, role, 'req create', ...)`；`runLegacyCommand` → `withBootToken`（`src/team-tools.js:1444-1460`）会在需要时自己 `team.mjs boot` 拿令牌。
- `createRequirement()` 没有先调用 `requireWorkflowBoot(role)`；UI 也在 `src/renderer/app.js:5349` 明确写“首次自动 boot”。
- 结果是：需求可以在“该角色从未读项目信息/需求总览”的情况下创建，只要壳替它 boot 一次。

**影响**

- “每轮先 boot、先读后写”的闸门在需求创建这一步被绕过；审计无法证明创建者读过项目信息。
- 与 P0-1 叠加时，空项目可以先产生一条需求，再产生两份正文，评审前就已经分叉。
- 与旧 `MVP-BLOCKERS.md` P1-4 同源；本轮仍在。

**最小修法**

- `createRequirement` 先 `requireWorkflowBoot(role)`；没有 boot 返回 `BOOT_REQUIRED`，由 UI 引导先 boot。
- Owner 新需求仍可由 PM 代办，但记录 `createdBy: "pm (owner-origin)"`，不要写成产品/需求本人已读。

**验收**

- 全新项目、零角色 boot，`requirement:create` 返回 `BOOT_REQUIRED`。
- 角色 boot 后创建成功，`工作流.json` 记录真实 `createdBy` 和 `sessionId`。

---

## 4. 链路判定表

| 阶段 | 当前判定 | 主要阻断 |
|---|---|---|
| 新建项目 | 有 DSH 才可建；离线整单回滚 | P1-4 |
| 建团队 | 能建六会话；首次易 `SESSION_BLANK` | P1-5 |
| 需求 | 能建；特殊标题落两份同 ID 正文；创建绕过 boot | **P0-1**、P1-8 |
| 评审 | 产品评审有 boot 闸门；可点通 | —（依赖 P0-1 的正文唯一性） |
| 派单 | 状态能写；真实角色不唤醒、不加锁 | P1-1 |
| 开发互审 | 能点；壳可代跑，B 会话非必需 | P1-2 |
| 测试 | 能派/能 done；只收字符串证据 | P1-3 |
| 验收 | 能 `accepted`；Owner 无身份、无 verify 闸门 | **P0-2**、P1-3 |
| 高风险变更 | normal 可走；sensitive/critical 卡 owner 签字 | P1-6 |

---

## 5. 复验命令与证据

只读或临时目录复验，不写真实项目：

```powershell
# 1) 语法/能力
cd D:\deepseek\agile-workbench
npm run check
node -e "const t=require('./src/team-tools.js'); console.log(t.legacyCapabilities())"

# 2) 复现 P0-1（临时项目；不要用真实项目）
#    通过 UI/桥接建一条标题含“：”的需求后：
Get-ChildItem <临时项目>\需求\R-*.md | Group-Object { ($_.Name -split '-')[2] } |
  Where-Object Count -gt 1

# 3) 复验 Owner 无身份（代码路径）
#    src/team-tools.js:4091-4168 / 5187-5292；main.js:3900-3907 / 3972-3979
#    两处都没有 nonce/TTY 校验。

# 4) 复验派单不唤醒
#    src/team-tools.js:4542 固定 --no-wake；4652/5151 调 sendWorkflowNotice；
#    4665/5164 直接写 dev/test，没有 wakeText/DSH prompt。

# 5) 复验验收无 verify
#    src/team-tools.js 中 grep -n "verify\|pilot" 无命中；
#    ownerAccept 仅校验 meta.status === 'test_done'（5212-5214）。
```

本轮直接证据：

- `src/team-tools.js` 269,628 B，SHA-256 前 16：`9DB40C03607EEB20`，2026-11-05 18:23:49。
- `_tmp/round14-ui/projects/QA14-新项目/需求/` 下两个同 ID 文件；`readRequirementDocs()` 返回 `count: 2`。
- `_tmp/round14-ui/team/状态/项目/QA14-新项目/工作流.json` 的 `phase=requirement_review`，`requirements` 只有一条 `R-20261105-0001`，与两份正文不一致。

---

## 6. 边界

- 未启动真实 DSH 六会话；本文的“真实角色”判断基于代码路径与现有会话/状态文件，不把 mock 自测当真实六会话证明。
- 未修改任何源码、团队状态或真实项目；`_tmp` 只作本轮临时证据。
- 源码在本轮审计后仍可能变化；若 `src/team-tools.js`、`团队/工具/lib/ops.mjs`、`团队/工具/lib/workflow.mjs` 的哈希变了，先按第 5 节复跑，不要直接复用本文结论。
- 旧仓库 `D:\deepseek\工作台` 的 `团队\工具` 不作为当前 app 的运行树；它的 `req review`/`owner`/`workflow` 能力与当前树不同，混用会得到假结论。
