# 旧代码逻辑审计：旧工作台（v1.1.0 外壳）→ 新工作台（v0.1.0）

> 只读审计报告。**未修改任何代码、package、旧仓库**；本文是唯一写入的文件。
> 审计时间：2026-11-05 03:2x–03:4x。审计方式：函数级逐段对照 + IPC/选择器清单比对 + 数据文件落点比对，未启动程序、未执行自检。
> **重要**：审计与写作期间新仓库正被并行重写（渲染层 42 KB→91 KB、主进程 71 KB→102 KB 等），本文按“审计快照”记录差异，并在 §0.2 标出哪些条目的根因在写作时已出现修复迹象。落修复前请以最新代码复核。
> 结论口径：只写“旧的有、新的没有/不一样”，并给出可落点。不评判产品取舍，不做代码复制建议。

---

## 0. 审计对象

| 侧 | 位置 | 规模 |
|---|---|---|
| 旧壳主进程 | `D:\deepseek\luanyujia-workbench\12-源码照搬\外壳\main.js` | 1091 行 |
| 旧壳渲染层 | `...\外壳\renderer\app.js` / `index.html` / `style.css` | 1828 / 138 行 |
| 旧壳场景与配置 | `...\外壳\scenarios\*.json`、`update.json`、`config.json`、`记忆模板\` | 5 场景 |
| 旧链路（共用工具） | `D:\deepseek\agile-workbench\团队\工具\`（`team.mjs`、`launch.mjs`、`workspace.mjs`、`owner-note.mjs`、`lib\ops.mjs` 1896 行、`lib\store.mjs`） | 被旧壳直接 spawn |
| 新壳主进程 | `D:\deepseek\agile-workbench\src\main.js` | 1459 行 |
| 新壳渲染层 | `src\renderer\app.js` / `index.html` | 838 / **348** 行 |
| 新壳适配层 | `src\dsh-adapter.js`、`src\team-tools.js`、`src\preload.js` | 223 / 786 / 41 行 |

### 0.1 快照与漂移（重要，先读）

审计期间 **`src/renderer/` 被并行重写**，同一天内至少三次变化：

| 时刻 | 事件 |
|---|---|
| 03:25:41 | `src/renderer/app.js` 42,072 B / 838 行（审计开始时的版本） |
| 03:27–03:33 | `index.html` 13,284 B → **21,238 B**（新增 `#btn-members`、`#dsh-off`、`#flow-launcher`、`#onboard`、文件工具条等） |
| 03:33 快照 | `app.js` 尚未同步：仍查已删除的 `#flow-lane`，`render()` 会在 `renderFlow()` 抛 `TypeError`；多数新控件无绑定（**当时确实会打断主界面**） |
| 03:36–03:41 | `app.js` 被整体替换并继续增长（42,072 → 90,061 B，约 2,000 行），`style.css` 37,577 → 56,694 B；离线卡片/重试/引导/文件工具条/菜单动作陆续接线；随后 `main.js`/`preload.js`/`team-tools.js` 也开始被重写（见 §0.2） |

因此本文的处理方式是：

- **主进程 / 适配层 / preload / 团队工具 / 旧仓库**：按“文件:行”引用，行号对应 **03:27 前后**的版本（`src/main.js` 71,209 B、`src/team-tools.js` 27,849 B、`src/dsh-adapter.js` 03:02:57、`src/preload.js` 2,646 B）。这些文件在写作后期也被改动，**行号会漂移**，请以函数名/结构为准（见 §0.2）。
- **`src/renderer/*`**：渲染层被整体重写，**行号只能在写作时刻成立**；凡涉及渲染层的结论，一律以函数名/选择器/行为表述。**定稿前请重跑附录 D 的 DOM↔JS 差集命令复核一遍。**

**行号约定**：旧壳一律写 `外壳/...` 或 `团队/...`；新壳写 `src/...`。旧壳渲染层写作 `外壳/renderer/index.html`、`外壳/renderer/app.js`，新壳写作 `src/renderer/index.html`、`src/renderer/app.js`。

这份漂移本身就是一个审计发现（见 **P0-0**）：旧壳用自检断言锁住“选择器 + API 都在”，新壳没有等价断言，所以 HTML 先改、JS 后改的中间态可以毫无阻拦地留在工作树里——审计期间就真的断过一次。

### 0.2 复核状态（本报告写作期间，主进程也被并行重写了）

写作过程中 `src/main.js`（71,209 → 101,980 B）、`src/preload.js`（2,646 → 3,283 B）、`src/team-tools.js`（27,849 → 33,641 B）也发生了变化。**本报告全部条目仍按“审计快照时读到的代码”描述**，但下列条目的根因在写作时已出现被修掉的迹象，请以最新代码复核后再排期：

| 条目 | 快照时的问题 | 写作时观察到的变化 | 建议 |
|---|---|---|---|
| P0-0 | 渲染层 HTML/JS 脱节 | `app.js` 已重写并对齐（`#flow-lane` 消失、新控件接线） | 只剩“自检未覆盖 UI 契约”仍是缺口 |
| P0-2 | 建团队绕过 `launch.mjs` | `main.js` 已出现 `launchSessions`/`seedVisible`/`团队会话` 引用 | 疑似已修；仍无 `selectModel`，需确认模型是否落到 `deepseek-flash` |
| P0-4 | 派单锁只在本地 | `main.js` 已出现 `派单锁` 引用（5 处） | 疑似部分修复；仍需确认 boot 令牌/事件/ACL 是否回写团队库 |
| P1-2 | 无 `roundKey`、不写 `工作流.json` | `main.js` 已出现 `roundKey`（2 处）；`工作流.json`/`owner-note` 仍为 0 | `roundKey` 疑似已补；团队状态回写仍需复核 |
| P1-3 | 无 `team:restore` | `main.js`/`preload.js` 已出现 `team:restore` | 疑似已补；`项目信息.md` 门槛与大小写匹配仍需复核 |
| P1-5 | 文件树不可展开、无预览 | 渲染层已实现折叠树/工具条 | 预览（`files:read`）仍未实现 |
| P1-7 / P2-7 | 入口缺失/未接线 | 渲染层菜单与引导已接线 | 余额/扩展/体检/检查更新/主题 `auto` 仍缺 |

仍然维持原判、未见修复迹象的：**P0-1**（渲染层仍无 `teamWorkspaces` 调用）、**P0-3**（`show`/评审集合/签名绑定仍无）、**P0-5**（仍无 `fs.watch`）、**P1-9**（仍无单实例锁）、**P2-1**（仍无协作台）、**P2-3**（仍只认 `DSH_HOME`）。

**一个必须先说清的事实**：`团队\工具\*` 同时被旧壳和新壳的 `src\team-tools.js` 引用。旧壳把它当**唯一真相源**（读 `团队\状态\*.json`、调 `launch.mjs` / `team.mjs` / `owner-note.mjs`）；新壳只在 `team:ensure-project` / `team:board` / `team:launch` 三个包装里用它，而**界面主要走的是自建的 `workbench.json` 模型**。下面多条问题都源于这一条分叉。

### 覆盖矩阵（对应任务要求的 10 项）

| # | 要求覆盖 | 主要条目 |
|---|---|---|
| 1 | 工作区/场景/项目清单加载与切换 | P0-1、P2-1、P3-4 |
| 2 | 新建/恢复/删除项目 | P1-3、P1-4、P1-9、P2-2 |
| 3 | 六角色会话启动/恢复/重名/空会话 | **P0-2**、P1-9、P2-5 |
| 4 | 派单→回执→唤醒失败/没有会话 | **P0-4**、P3-1、P3-3 |
| 5 | 提案 propose→show→review→sign→apply→rollback | **P0-3** |
| 6 | 看板/流程/Owner 阶段推进 | P0-5、P1-2、P1-6、P3-2 |
| 7 | 文件树/项目目录/环境扫描 | P1-5、P2-8、P3-4 |
| 8 | 顶栏按钮/菜单/主题/引导/更新检查 | **P0-0**（UI 契约自检）、P1-7、P2-7、P3-5、P3-6 |
| 9 | DSH 离线/重连/cookie/错误码 | P1-1、P2-3、P2-4 |
| 10 | 数据持久化/路径/团队状态 | P0-5、P1-9、P2-1、P2-6 |

**计数**：P0 ×6（含 P0-0 机制类）、P1 ×9、P2 ×8、P3 ×6（共 29 条）。

---

## P0 · 会断核心流程或造成状态错乱

### P0-0（机制类）UI 契约没有自检锁：审计期间确实断过一次主界面，随后被并行改造修掉

> 本条不是产品逻辑差异，而是把“为什么这种差异能长期藏着”说清楚；只关心功能的话可跳到 P0-1。**产品逻辑的 P0 是 P0-1~P0-5。**

- **旧行为**：旧壳把“界面控件存在 + preload API 存在”写成自检断言：`SELFTEST_UI` 逐项检查 `window.kun.team`、`#btn-team-board`、`#btn-workspace-create`、`#btn-team-launch`、`[data-act="newproj"]` 是否存在（`外壳/main.js:978`），另有 `SELFTEST_MODAL`/`SELFTEST_MENU`/`SELFTEST_FLOW` 等逐块断言（`989-1028`）；`npm run check` 还做 `node --check`（`外壳/package.json:27`）。选择器改名而忘了改 JS，会在自检里立刻失败。
- **新行为（快照序列）**：03:33 快照时，`src/renderer/index.html` 已把流程区改成 `#flow-board` / `#flow-mini`，而 `src/renderer/app.js` 仍在查 `#flow-lane` 并直接 `lane.innerHTML = ...`——该 id 已不存在，`render()` 每次都会在 `renderFlow()` 抛 `TypeError`，被 `refresh()` 的 `catch` 吞成一条 toast「读取失败：…」，主界面不渲染；同期新增的 `#btn-members`、`#dsh-off`/`#dsh-retry`/`#dsh-config-2`、`#flow-launcher`、`#onboard`、`[data-file-tool]`、菜单里的 `theme/refresh/index/team-board/restore/guide/version` 在 `app.js` 里**没有任何绑定**。03:36 起 `app.js` 被整体重写（42,072 → 90,061 B，随后超过 2,000 行）：`renderFlow()` 改用 `#flow-board`，离线卡片/重试/引导/文件工具条/菜单动作陆续接上——**上述中断在写作时已不存在**。但新壳自检仍只 `click('[data-tab="flow"]')` 并读 `display`（`src/main.js:1395-1397`），不校验选择器与 JS/preload 的对应关系；`#btn-side-restore` 这类控件仍然只在 HTML 里存在。
- **差异**：旧壳“UI 契约有断言，漂移在自检里爆”，新壳“UI 契约靠人肉同步，漂移在主界面白屏时爆”；而且新壳的渲染层是一次性大改（838 → 2,015 行）且没有对应的自检扩展。
- **影响**：任何一次“先改 HTML 再改 JS”的并行施工，都可能让主界面整体不可渲染且没有告警——审计期间已经发生过一次；死按钮比没有按钮更糟，用户会以为程序坏了。这类问题会掩盖本文其它条目的实际验证。
- **建议落点**：把旧壳式断言搬进 `src/main.js` 的 `selftest()`（`1198-1425`）：对每个 `[data-more]`、每个顶栏按钮、每个新增面板断言“选择器存在 且 `window.workbench` 上对应 API 存在”，并断言 `#flow-board`/`#dsh-off`/`#onboard` 的关键子节点齐全；渲染层每次大改后跑一遍。补齐 `#btn-side-restore` 等未绑定控件或从 HTML 删除。

### P0-1 场景体系与“工作区清单”整体消失，只剩本地项目库

- **旧行为**：主进程 `readScenarios()` 读 `scenarios/*.json`，坏 JSON 写 `main.log` 的 `BAD_SCENARIO` 而不是静默丢弃（`外壳/main.js:29-43`），并按固定顺序 `['self-review','pc-cleanup','api-gateway','projects','demo-workbench']` 排序（`44-49`）；渲染层 `renderTabs()` / `selectScenario()` / `showView()` 做「引擎视图 ⇄ 场景网格」互斥切换（`外壳/renderer/app.js:468-506`），`renderGrid()` / `buildPanel()` 按 `col/row/w/h` 铺面板并支持 `harness`、`embed`(webview)、`collab`、`pc-*` 等类型（`509-631`）；`loadScenarios()` 可被菜单项 `data-act="reload-scenes"` 热刷新（`外壳/renderer/app.js:1372-1374`、`1801-1809`）。项目清单来自 `team:workspaces` 的**三路合并**：团队登记 `状态/项目/*/项目.json`、`工作台\项目\*`（含 legacy `workspace.json`）、DSH `storages/workspace.json`（`外壳/main.js:525-572`），并带 `current` 标记与排序（`564-571`）；「项目总览」面板用卡片渲染并可点开 `项目索引.md`（`外壳/renderer/app.js:768-809`）。
- **新行为**：没有任何场景配置加载/页签/网格/面板系统。`src/renderer/index.html` 的 `#tabs` 是写死的 6 个固定页签（项目总览/看板/流程/提案/文件/角色）；`renderSidebar()` 只渲染 `state.projects`（`workbench.json`）。`team:workspaces` 仍存在（`src/main.js:493-507` → `src/team-tools.js:469-533`），但**渲染层从不调用**（`preload.js:22` 暴露后无人使用；全仓 grep 无 `teamWorkspaces(` 调用）。切换项目只写本地 `activeProjectId`（`src/main.js:440-446`）。
- **差异**：旧壳有“场景/面板/项目清单/DSH 工作区”这一整层导航与合并去重（含 `qq-bridge`、`default-workspace`、工作台根目录过滤，`外壳/main.js:528-535`）；新壳是单层本地项目库，团队工作区与 DSH 左侧工作区在 UI 上不可见、不可切换。
- **影响**：旧项目/团队工作区在界面里“消失”，用户无法从新壳切到已有团队项目；`工作台\项目` 下的老目录、DSH 已有工作区都进不了新壳，只能靠“恢复”扫 `repo/projects`（见 P1-3）。`docs/FEATURE-MATRIX.md:25` 自己标注“场景页签 未完成”，但 P0-1 的清单/切换能力也被一起带走了。
- **建议落点**：`src/main.js` 的 `statePayload()` 增加 `workspaces`（合并 `team:workspaces` 结果与 store 项目，按 path 去重、标 current）；`src/renderer/app.js` 的 `renderSidebar()` 增加“团队/DSH 工作区”分组；`project:select` 同步写 `团队/状态/当前工作区.json`（旧 `currentFlowProject()` 的单一真相，`外壳/main.js:370-375`）。若要恢复场景体系，落点是独立的 `scenarios` 加载器 + `buildPanel` 等价物，而不是塞进固定页签。

### P0-2 六角色会话启动绕过 `launch.mjs`：丢模型、丢复用、丢空会话可见化、不写团队记账

- **旧行为**：`team:launch` 由主进程 spawn `launch.mjs`，参数含 `--roles`（默认六角色）、`--no-prompt`、`--add-members`、可选 `--seed-visible` / `--restore` / `--dry-run` / `--engine-url`（`外壳/main.js:491-523`，参数拼装在 `513-519`），并把 `launch.mjs` 的 JSON 原样回传（`520-522`）。`launch.mjs` 内部：按角色固定模型 `deepseek-account/deepseek-flash` + `reasoningEffort:max`（`团队/工具/launch.mjs:58-66`）、逐角色 `selectModel`（`125-132`）、标题统一为 `团队·<角色名>`（`62`）、**按标题+同 cwd 且属于该 workspace 的 sessionIds 复用**（`100-123`），归档会话先 `workspaceUnarchiveSession` 再复用（`118-119`）、`--seed-visible` 时逐个给空白成员发“已就位”且间隔 1.2s（`148-168`）、清理工作区自带空白占位会话（`170-179`）、最后写 `团队会话.json` / `团队会话.md`（`203-219`）、`状态/会话.json`（`257-258`）、`当前工作区.json`（`245`）、`workspace.json` 的 `dshWorkspaceId`（`93-99`）和 `事件.jsonl`（`260-263`）。
- **新行为**：界面“建团队”/“启动团队”按钮都走 `dshProvision`（渲染层 `startTeam()` 与 `#btn-provision` 分支）→ `dsh:provision`（`src/main.js:931-993`）：`createWorkspace(project.path)` 后逐角色 `session/create({cwd})`（`953`），标题为 `${project.name} · ${role.name}`（`953` 传入 `title`，`src/dsh-adapter.js:195-197` 再 rename），**不选模型**（`src/dsh-adapter.js` 根本没有 `selectModel`）、**不复用**（只在 `current.sessions[role.id]` 有值时 `continue`，`952`，从不向 DSH 核实该会话是否还存在/是否属于本工作区）、**不发 seed**、**不写 `团队会话.json`/`状态/会话.json`/`当前工作区.json`/`事件.jsonl`**，只在 `workbench.json` 记 `sessions`（`960-991`）。`src/team-tools.js:682-689` 也不传 `--seed-visible`（`launch.mjs:50` 明确支持该参数）。
- **差异**：① 会话模型没有落到 `deepseek-account/deepseek-flash`，六角色可能起不来或跑在默认模型；② 标题规范不同（`<项目> · 项目经理` vs `团队·项目经理`），导致 `launch.mjs` 的 `existingByTitle` 复用**永远匹配不到**新壳建的会话，之后任何人走 `team:launch`/`--restore` 都会重复建六份；③ 空白会话在 DSH 左侧不显示（旧 README 第 95 行、`外壳/renderer/app.js:1650` 的说明），新壳没有 seed 入口，用户会看到“有工作区、成员为空”；④ 团队侧会话清单、当前工作区、事件流全部不更新。
- **影响**：这是“建团队”主流程的静默降级——最多能建出六个会话 id，但不可见、不可复用、不可恢复、模型不确定，且与旧工具链的数据不兼容。已采纳（adopt）的旧项目再点“建团队”会凭空多出六份重复会话。
- **建议落点**：`src/main.js` 的 `dsh:provision` 改为（或并列提供）调用 `teamTools.launchSessions(project, {dryRun:false, roles, addMembers:true, seedVisible:true, restore:false, engineUrl})`；`src/team-tools.js:682-689` 补 `--seed-visible`；`src/dsh-adapter.js` 补 `selectModel`/`workspaceUnarchiveSession`；标题常量集中一处（建议沿用 `团队·<角色名>` 以保持复用）。若坚持直连 RPC，至少写 `团队会话.json` + `当前工作区.json` + 事件，并实现“按标题+cwd 复用”。

### P0-3 提案链路是第二套实现：缺 show、缺评审集合、签名不绑哈希、无锁无索引

- **旧行为**：唯一路径 `propose → show → review → sign → apply`（`团队/协议/03-变更评审签字.md`），由 `lib/ops.mjs` 强制执行：`propose` 要求 boot 令牌、任务归属、优先级、`--expect 目标=当前哈希`（`ops.mjs:580-619`）、风险只能升不能降（`608-611`）、`grant` 授权（`620-622`）、暂存快照哈希复核（`623-627`）、重复提案去重（`630-631`），并按风险算出 `minReviews`/`requiredSigners`（`646-650`）；`show` 校验提案哈希、支持 `--diff`，并**写 read receipt**（`668-704`，receipt 在 `702`）；`review` 强制“先 show 同哈希”（`707-722`）、作者不能自审（`713`）、必须在评审人集合内（`717`）、打回≥10 字（`726`）、状态机 `reviewed/reviewing/rejected`（`739-742`）；`sign` 仅签字人、非作者签字前必须有同哈希 approve（`755-778`）、签名摘要绑定 `proposalHash+baseHash+newHash+ts+nonce`（`779-789`）；`apply` 仅 PM、加锁（`815-816`）、重算哈希（`820-821`）、`checkApprovals` 逐项校验（`87-120`，含 `STALE_SIGNATURE`/`BAD_SIGNATURE`/`OWNER_CHANNEL`）、逐文件 CAS（`824-840`，不满足则整单 `STALE_BASE`）、备份并核对 baseHash（`841-853`）、临时文件+rename 写入并核对 newHash（`856-867`）、失败自动回滚，回滚不完整则 `ROLLBACK_FAILED` 停手（`872-893`）、写 artifacts 版本（`895-905`）、写 commit（`906-912`）、重建索引（`922`）。
- **新行为**：`proposal:create` 只收 `title/author/fileRel/content`，单文件、无任务绑定、无 `--expect`、无风险分级、无 grant、无 read receipt（`src/main.js:651-685`）；`proposal:review` 只要求“角色合法 + 非作者 + 必须写理由”，**没有评审人集合、没有 show 前置、没有打回字数**（`686-705`）；`proposal:sign` 由固定 `by:'pm'` 单次签字，签名只是 `{by:'pm', decision, note}`，**不绑定任何哈希**（`706-722`，`716`）；`proposal:apply` 检查 `status==='approved' && signature`（`728`），做单文件 `baseHash` CAS（`735-740`）与“同文件已有未回滚提案”拦截（`741-746`），备份到 `<项目>/_backup/commits/<C>`（`748-756`），原子写入（`757-759`），写本地 commits（`760-769`）；回滚校验 afterHash 与备份哈希（`773-815`）。**没有锁、没有 artifacts、没有索引重建、不改团队状态、不写事件。**
- **差异**：缺 3 个协议环节（show/read receipt、评审集合、风险与授权）；签名从“绑定哈希的摘要”退化为“一个人点了一下”；apply 从“多文件整单 CAS + 回滚 + 索引”退化为“单文件”；提案/评审/签字/提交都不进 `团队/状态`，`team.mjs board` 与 `verify` 看不到任何记录。
- **影响**：`docs/FEATURE-MATRIX.md:13-17` 标注“已完成”，但审计/追责属性（谁在什么哈希上批的、改没改过、是否走过 show）全部丢失；同时新旧两套提案状态互不可见，PM 在 UI 里 apply 后，团队看板/索引/事件仍是旧数据。
- **建议落点**：短期把 `src/main.js` 的 `proposal:*` 改成 `team.mjs` 的薄包装（`propose/show/review/sign/apply`，用 `runNode` 解析 JSON，沿用 `src/team-tools.js:250-345` 的错误归一），UI 只补 show/diff 与 read receipt 展示；若保留本地模型，则必须补：`requiredReviewers/requiredSigners`、`show` 记录、签名 `sig` 绑定哈希、apply 前 `checkApprovals` 等价物、索引/事件回写。

### P0-4 派单→回执链路断开：角色无法按协议回执，锁只存在本地

- **旧行为**：派单与回执由 `团队/工具` 承担。`cmdSend` 要求 boot 令牌（`ops.mjs:340`），PM 带 `--ack` 派单时读 `派单锁.json`，有未闭环就 `PM_DISPATCH_PENDING` 拒绝（`320-353`）；派单顺手把任务 owner 定为目标角色，已属他人则 `TASK_OWNED`（`354-368`）；写消息 + `事件.jsonl`（`176-183`、`369-372`）；唤醒时若目标无会话→`wake={ok:false, why:'目标角色还没有 DSH 会话'}`，无 engineUrl→对应原因（`376-389`）；唤醒文案强制要求 `boot → inbox → read → ack → task claim`（`392-399`），失败原因随结果返回（`404-411`）。`cmdAck` 由角色自己执行，写 receipt、清派单锁、写事件、通知发件人（`431-441`）。
- **新行为**：`team:send` 只写 `workbench.json` 的 `messages`（`src/main.js:830-849`），锁是 `pendingAck/pendingAckAt`（`836-843`，TTL 10 分钟，`54`）；唤醒文案是四行短句，**不含 boot/inbox/read/ack/task claim 指令**（`853`）；唤醒失败时释放锁并写一条本地事件（`856-863`）；`team:ack` 供**人**在 UI 里代填回执（渲染层 `openAckModal()`；`src/main.js:876-895`），不通知任何角色、不写 `事件.jsonl`、不产生 receipt、不校验角色身份。
- **差异**：旧链路的“回执”是角色带令牌的主动行为并留下证据链；新链路是操作者手填一条备注。派单消息不进团队消息库，`team.mjs inbox` 永远看不到；`派单锁.json` 与本地 `pendingAck` 是两把互不相识的锁（PM 用 CLI 派单后，UI 仍显示“没有待回执”，反之亦然）。
- **影响**：六角色协作的核心闭环失效——角色收到唤醒也不知道该 boot/ack；PM 看到的“已回执”无法证明是角色回的；跨端（CLI/旧壳/新壳）派单会互相绕过锁。
- **建议落点**：`src/main.js:816-895` 改为包装 `team.mjs send/ack`（保留 UI 的“记录回执”按钮，但改为“人确认角色回执”的只读同步）；唤醒文案复用 `ops.mjs:392-399` 的模板；`pendingAck` 只作为 UI 投影，真相以 `派单锁.json` 为准。若暂不接 CLI，至少写 `事件.jsonl` 与 `派单锁.json`。

### P0-5 任务/看板/阶段三套数据互不相通，团队状态与实时推送消失

- **旧行为**：阶段由 `computeWorkflow()` 从**团队状态文件**推导：读 `状态/项目/<name>/工作流.json`、`任务/*.json`、`需求/R-*.md`、`提交/*.json`（`外壳/main.js:377-431`），阶段含 `intake/requirement/review/bossreview/dispatch/dev/test/close` 与 `iterate`，`ownerReview.rejected→requirement`、`approved|skipped→dispatch`（`423-424`），并返回 `counts`/`roundKey`（`427-428`）。`startFlowWatch()` 用 `fs.watch(..., {recursive:true})` + 220ms 去抖向所有窗口 `workflow:changed`（`432-450`），渲染层 `API.team.onWorkflow` 收到即刷新（`外壳/renderer/app.js:1773-1778`）。看板由 `team.mjs board` 从同一份团队状态生成（`团队/工具/lib/ops.mjs:1347-1425` 的 `boardData` 读 `listTasks/listProposals/listCommits/loadReceipts/loadReviews`）。
- **新行为**：任务存在 `workbench.json`（`src/main.js:613-650`），阶段由 `deriveStage()` 只看本地 `project.tasks` 与 `project.ownerReview`（`246-258`），**完全不读需求/提交/团队状态**；没有任何文件监听或推送（全仓无 `fs.watch`；渲染层只在用户操作后 `refresh()`）。`team:board` / `team:board-old` 生成的是团队状态里的看板（`src/main.js:575-603`），因此**新壳里建的任务永远不会出现在“旧版看板”上**。`statePayload().team` 只塞了 `quickInfo()`（`284-286`），渲染层仅在“版本信息”弹窗里读过一次 `state.team?.toolExists`。
- **差异**：旧壳是“团队状态单一真相 + 文件变化推送”；新壳是“本地库单一真相 + 团队状态只读残留”，两边任务/阶段/提案/回执各算各的；实时性从 push 退化为手动刷新。
- **影响**：用户点“旧版看板”看到的是空板或上一轮旧数据（`docs/FEATURE-MATRIX.md:11` 的“看板 已完成”不成立）；PM 在 CLI 里改任务，新壳界面不会变；阶段推进与团队 `phase/activeProject` 脱钩。
- **建议落点**：二选一并写清楚：① `workbench.json` 只做 UI 缓存，任务/阶段全部从 `团队/状态` 派生（推荐，回到旧 `computeWorkflow` 的语义并补 `review`/`iterate`）；② 保留本地任务，但 `task:*` 同步写 `状态/项目/<name>/任务/*.json`、`owner:decide` 同步写 `工作流.json`，并在 `src/main.js` 加 `fs.watch` → `workflow:changed` 等价推送。

---

## P1 · 关键功能缺失或语义反转

### P1-1 DSH 地址发现与配置持久化丢失；cookie 只在启动铸一次

- **旧行为**：端口每次重启随机，所以启动时**主动发现**：`tasklist` 找 `DeepSeek Harness.exe` 的 PID + `netstat -ano` 找 LISTENING 端口（`外壳/main.js:124-138`），逐端口用自签 cookie 探测，校验 `status 200` 且 body 含 `<base href="./">` 且长度 >20000（`139-157`），成功后把 cookie 写进 `persist:harness` 分区（`150-151`，`httpOnly/strict/30 天`）；`app:config` 合并 `config.json` + `config.local.json`，自动探测结果覆盖 `engineUrl` 并清空 `engineToken`（`163-174`）；渲染层 `loadEngine()` 有 `engine-off` 遮罩、URL 打码、忽略 `ERR_ABORTED(-3)`、6 秒看门狗、`engine-retry` 重试（`外壳/renderer/app.js:1401-1424`，遮罩 DOM 在 `外壳/renderer/index.html:68-75`）。
- **新行为**：地址只来自 `process.env.DSH_WEB_URL` 或硬编码 `http://127.0.0.1:52711`（`src/main.js:58`）；`dsh:configure` 只替换内存里的适配器并装一次 cookie（`src/main.js:1010-1014`），**不落盘**；cookie 由 `installDshCookie()` 在 `whenReady` 装一次（`src/main.js:1427-1437`、`1442`），失败静默返回 false（`1436`）且调用方不检查；401/403 被适配层归成 `DSH_OFFLINE`（`src/dsh-adapter.js:124-127`），但**没有“重新铸 cookie 再试”的路径**。渲染层在 03:36 重写后已接上离线卡片/重试/地址应用（函数 `renderDsh` 的 `#dsh-off` 分支、`retryDsh()`、`applyDshViewSrc()`、`openDshConfig()` 保存后重新探测并改 `#dsh-view` 的 src），这部分已不是缺口；缺口在**主进程没有端口发现、没有配置持久化、没有 cookie 重铸**。
- **差异**：旧“随机端口 + 配置合并 + 失败遮罩 + 重试”里，“发现端口/记住地址/处理鉴权过期”三件事都在主进程；新壳只把“遮罩与重试”补在渲染层，主进程仍是“固定 52711 + 环境变量 + 启动时铸一次 cookie”。
- **影响**：本机 DSH 不是 52711（旧壳默认甚至是 3080）时，首屏离线卡片会提示，但用户只有在环境变量或每次手填地址之间二选一；改完地址重启即回默认；DSH 换 secret/端口后只能重启应用。
- **建议落点**：`src/main.js:1439-1454` 检查 `installDshCookie()` 返回值；新增 `resolveEngine()` 等价物（端口探测 + body 校验）与 `data/dsh.json` 持久配置（`dsh:configure` 写盘）；`dsh-adapter.js` 的 `rpc()` 在 401/403 时重读 `.credentials.yaml` 重铸一次再重试。

### P1-2 Owner 闸门位置错了，且决定不落团队状态、不去重、可被关掉

- **旧行为**：Owner 评审只在 `stage==='bossreview'` 时弹（`外壳/renderer/app.js:1723-1730`），即“需求→产品评审→（无开发/测试任务且评审都完成）”之后；弹窗 `closable:false`，只有“跳过评审/开始评审”两条路（`外壳/renderer/app.js:1688`），通过时必须写意见（`1718`），弹窗内可“打开项目文件夹”（`1714`）；同一轮用 `roundKey`（项目名+需求数+任务数+进行数，`外壳/main.js:427`）去重，新一轮会再问（`外壳/renderer/app.js:1726-1729`）；决定写 `工作流.json` 的 `ownerReview{required,status,by,at,roundKey,opinion}`（`452-467`）并调 `owner-note.mjs` 给 PM 发一条系统消息（`469-472`、`团队/工具/owner-note.mjs`），再广播 `workflow:changed`（`473`）。
- **新行为**：`deriveStage()` 一旦有任务且 `owner.status` 不在 `approved/skipped` 就返回 `'owner'`（`src/main.js:252-254`），而渲染层 `render()` 在 `stage==='owner'` 且未提示过时**自动弹窗**（`ownerPrompted` 集合 + `openOwnerModal()`）；弹窗默认**可关闭**（`openModal` 的 `closable` 默认 true，`openOwnerModal()` 未传 `closable:false`），关掉后 `ownerPrompted` 已记录该 id，**不会再弹**（只有 stage 离开 owner 时才删除记录）；`owner:decide` 只写 `workbench.json` 的 `ownerReview`（`src/main.js:896-908`），不写 `工作流.json`、不通知 PM、无 `roundKey`。
- **差异**：① 闸门时机从“评审后”提前到“建第一个任务后”，`review` 阶段永远不可达（`deriveStage` 只可能返回 `intake/requirement/close/owner/test/dev/dispatch`，从不返回 `review`）；② 旧弹窗不可关闭、必选一条，新弹窗可 Esc/点 × 关掉 -> 阶段永久停在 `owner`（后续 `test/dev` 判定都被挡在前面）；③ 旧按轮次重复询问，新只问一次；④ 旧落盘并通知 PM，新只落本地。
- **影响**：“流程”页签的阶段高亮会长期停在 Owner；Owner 通过后团队看板/PM 收件箱没有任何记录；用户误关弹窗后不知道还能从哪补（`btn-owner` 可重开，但界面没有任何提示）。
- **建议落点**：`src/main.js:246-258` 的 `deriveStage` 恢复旧语义（先 requirement/review，再 owner，再 dispatch/dev/test），并把 `review` 判据接上（产品/需求角色任务）；`openOwnerModal()` 传 `closable:false`；`owner:decide` 同步写 `状态/项目/<name>/工作流.json` + 调 `owner-note.mjs`（旧 `外壳/main.js:460-472` 可照语义重写）；用“项目+需求数+任务数+进行数”做 `roundKey` 去重。

### P1-3 “恢复项目”退化为“扫 repo/projects 且必须有 项目信息.md”，外部目录打开能力消失

- **旧行为**：`team:restore` 按项目名恢复：先找 `工作台\项目\<名>`，找不到做**大小写不敏感**匹配（`外壳/main.js:700-705`），再回退到 `状态/项目/*/项目.json` 里登记过的 `cfg.path`（`706-720`），校验磁盘存在后调 `launch.mjs --restore` 复用会话并补齐工作区（`727-735`）；`team:openProject` 支持“📂 打开已有项目文件夹（不复制、不移动）”，默认定位 `D:\deepseek`（`657-661`），并做**同名不同目录**冲突保护（`669-677`，`PROJECT_NAME_CONFLICT`）；`openWorkspaceDialog` 把该入口放在新建弹窗第一位（`外壳/renderer/app.js:174-177`），恢复弹窗还有“按名字恢复”输入框 + “让成员显示”勾选（`296-341`）。
- **新行为**：`openRestoreModal()` 只调 `discoverProjects()`，而 `project:discover` 只扫 `<repo>/projects`（`src/main.js:456`）且只收含 `项目信息.md` 的目录（`463-464`）；`project:adopt` 同样强制要求 `项目信息.md`（`474-476`），名字取 `path.basename`（`477`），无大小写匹配、无同名冲突检查、不写团队 `--restore`、不建会话。`team:restore` 没有任何 UI 入口（`src/main.js` 根本没有 `team:restore` IPC）。
- **差异**：旧有三条恢复路径（按名、按目录、按团队登记）+ 冲突保护 + `--restore` 复用；新只有一条“扫描默认目录 + 必须有固定文件名”，且“打开已有项目文件夹”这个旧壳首页级入口消失（`外壳/renderer/app.js:149-164`）。
- **影响**：真实项目目录（多数没有 `项目信息.md`）无法登记；`工作台\项目` 之外的老项目必须手动选目录且大概率被拒；两个同名目录会产生两个同名项目（团队名会被 `src/team-tools.js:371-378` 加 sha1 后缀，界面名与团队名从此不一致）。
- **建议落点**：`src/main.js:453-492` 增加“无 `项目信息.md` 也可登记（生成模板）”分支与同名冲突检测（返回 `PROJECT_NAME_CONFLICT` 等价结构）；补 `team:restore` IPC（调 `teamTools.launchSessions(project,{restore:true,seedVisible:true})`）；`openRestoreModal()` 增加“选择其他目录”+ 大小写不敏感匹配；恢复弹窗补“让成员显示”勾选。

### P1-4 新建项目不再登记 DSH 工作区，也没有“必须有引擎”的硬门槛

- **旧行为**：`team:workspace:create` 先拒绝已存在目录/已登记项目（`外壳/main.js:744-745`，`WORKSPACE_EXISTS`，文案直接引导去“建团队/恢复”），没有探测到引擎时**直接拒绝**（`756-758`：“没有探测到 DSH 引擎地址，无法登记到左侧工作区列表”），再调 `workspace.mjs create`（`760-775`），后者建六角色目录、写 `workspace.json`、`当前工作区.json`、并 `setActiveProject`（`团队/工具/workspace.mjs:238-264`、`336`、`364`）。渲染层创建成功后再自动 `launch(prompt:false, seedVisible:true, addMembers:true)` 导入六角色（`外壳/renderer/app.js:240-256`），失败会明确提示“工作区已创建，但六角色导入失败”（`259-260`）。
- **新行为**：`createProject` 建目录与六角色空目录（`src/main.js:306-310`），随后 `syncTeamProject()` 调 `teamTools.ensureProject`（`435-439`、`28-35`），但**不登记 DSH 工作区**（只有 `dsh:provision` 才 `createWorkspace`）；失败只作为返回值里的 `team` 字段，渲染层 `openNewProject()` 忽略它并 toast“项目已创建”；无“引擎未就绪”门槛、无 `WORKSPACE_EXISTS` 等价引导（错误是 `这个目录已经是工作台项目` / `目标目录不是空目录，避免覆盖已有文件`，`src/main.js:300-305`）。
- **差异**：旧“新建工作区 = 目录 + DSH 登记 + 六角色空会话 + 协作准则/索引”；新“新建项目 = 目录 + 团队登记（尽力而为）”，DSH 里要再点一次“建团队”才出现，且失败无提示。
- **影响**：新建后 DSH 左侧没有工作区，用户会以为没建成功；团队登记失败（工具缺失/权限）时项目看似正常但看板/索引全缺。
- **建议落点**：`src/main.js:435-439` 在 `team.ok===false` 时把 `team.code/message` 回传给渲染层，`openNewProject()` 据此提示；`createProject` 成功后可选调用 `dsh.createWorkspace` 并写回 `workspace.json`/store。

### P1-5 文件面板：树补回来了，但“面板内预览”没有——点文件仍是交给系统程序

- **旧行为**：`fs:list` / `fs:read`（`外壳/main.js:872-901`）支撑一个真正的树：工具条含“全部收起/刷新目录”（`外壳/renderer/app.js:820-837`）、目录懒加载并记录 `loaded`、`dirRows`（`839-840`、`871-909`）、图标与类型标签（`842-852`）、展开状态 `aria-expanded`（`899`）、文件夹空态（`908`）；文件点击在**面板内预览**：markdown 渲染（`681-752`）、图片 `dataUrl`、视频/PDF `file://`、文本 `pre`，并按 20MB 上限拒绝（`884-900`、`754-766`）；还记住最近 12 个文件（`673-679`）并在“📁 文件夹”菜单里列出（`1277-1297`）。项目总览里的“项目目录/环境扫描”各自是独立面板（`scenarios/projects.json:18-40`）。
- **新行为**：主进程 `files:list` 一次性递归扫描（深度 ≤4、最多 600 条、跳过 `node_modules/.git/userdata/_tmp`，`src/main.js:378-384`），`files:open` 只做路径越界校验后 `shell.openPath`（`src/main.js:399-407`）。渲染层在 03:36 重写后已实现可折叠树与工具条（`renderFileTree()`/`toggleFileDir()`/`[data-file-tool]` 的 expand/collapse/refresh 分支），并在 UI 上写明“点文件用系统程序打开”；**仍然没有 `files:read` 与面板内预览**，文件行点击走 `filesOpen`（`src/renderer/app.js` 的 `#files-list` 点击分支）。
- **差异**：展开/收起/刷新已对齐；缺的是“看内容”这一步（旧 md/图片/PDF/视频都在面板内渲染，新一律外部程序），以及最近文件、大小/类型上限、目录排序（旧目录优先 + `zh-CN`，`外壳/renderer/app.js:877`）；超过 4 层或 600 条仍**静默截断**（`src/main.js:379`）。
- **影响**：看 md 文档要跳外部编辑器（旧是内嵌渲染）；大项目“少文件”无提示；`_tmp` 被隐藏（这点是改进，但需在 UI 说明）。
- **建议落点**：`src/main.js:371-407` 增加 `files:read`（类型/大小/文本或 dataUrl，沿用旧 `fs:read` 语义）与 `files:list` 的 `truncated` 标记；`src/renderer/app.js` 的文件区增加预览容器（复用旧 `markdownToHtml` 的语义重写）与“最近打开”；排序在 `files:list` 里做。

### P1-6 团队看板浮窗整套消失，只剩“用系统浏览器打开一个 HTML”

- **旧行为**：`openTeamBoard()` 创建独立 `BrowserWindow`：无边框、透明、`alwaysOnTop('floating')`、`opacity 0.94`、1120×780（`外壳/main.js:247-271`）；`team:board-control` 支持 `collapse/expand/maximize/minimize/close/zoom-in/zoom-out` 并恢复边界（`624-651`），窗口折叠到 320×64（`629`）；`team:board-project` 可在看板内切项目（`585-597`）；`team:board-file` 允许预览工作台内文件（文本/图片，4MB 上限、路径白名单，`599-622`）；配套 `board-preload.js`；折叠/展开用 `boardRestoreBounds` 记住原边界（`629`、`633`）。
- **新行为**：`team:board` 生成后 `shell.openPath(result.boardPath)`（`src/main.js:583-587`），`team:board-old` 同样（`596-603`）；渲染层已接上项目头部的“旧版看板”按钮与菜单 `data-more="team-board"`，但**主进程没有对应的窗口控制/项目切换/文件预览 IPC，也没有 `board-preload.js`**——所以无论从哪点，结果都是“系统浏览器打开一个 HTML”。
- **差异**：置顶浮窗/折叠/缩放/项目切换/文件抽屉/窗口状态恢复全部丢失，退化为默认浏览器标签页（且会被浏览器拦截本地文件打开）。
- **影响**：旧壳最常用的“边看板边干活”工作流消失；`docs/FEATURE-MATRIX.md:24` 的“旧界面逐像素 进行中”实际上把浮窗整块丢了。
- **建议落点**：恢复 `openTeamBoard()` 等价物（`BrowserWindow` + `board-preload` + `team:board-control`/`team:board-file` IPC），或至少在新壳内嵌 iframe/webview 显示 `看板.html` 并保留项目切换。

### P1-7 顶栏/菜单补齐了大部分入口，旧壳的“运维层”仍缺一半（余额/扩展/体检/更新/序号/最近/网页 AI/盘容量/状态点）

- **旧行为**：顶栏 12 个入口：看板、成员、＋工作区、🚀建团队、♻恢复、⟳刷新、📁文件夹（菜单含工作区/DSH 根/场景目录 + 最近打开）、扩展组（插件/技能/MCP/工具，`外壳/renderer/app.js:1426-1449`）、⋯、窗口三键（`外壳/renderer/index.html:17-36`）；“⋯”菜单 12 项（`外壳/renderer/index.html:38-49`）并由 `mountTopbar` 分发（`外壳/renderer/app.js:1332-1397`）：主题、在线刷新工作区/成员、刷新场景页签、打开已有项目、按名恢复、打开看板、新手引导、窗口序号、版本信息、检查更新、工作台体检、初始化记忆模板。另有余额胶囊（5 分钟轮询，`外壳/renderer/app.js:427-442`）、状态点/文本（`444-449`）、场景条（`外壳/renderer/index.html:55-63`）、网页 AI 五站点按钮（`外壳/renderer/app.js:402-425`）、盘容量面板（`953-984`）、体检报告写入 `工作台\体检\报告-*.md`（`外壳/main.js:304-342`）。
- **新行为**：03:36 重写后，顶栏 7 键（看板/成员/工作区/建团队/恢复/刷新/文件夹）+ DSH 工作区/主题/⋯ + 窗口三键；⋯ 菜单 10 项**全部已接线**（`runMoreAction` 处理 `team/dsh/theme/refresh/index/folder/team-board/restore/guide/version`，引导与版本弹窗都已实现）。但“成员”只是切到角色页（`$(`#btn-members`)` → `showTab('roles')`），不是旧壳那种列六个 session id + “逐个显示成员”的弹窗；仍然没有：余额胶囊、状态点/文本、扩展组（插件/技能/MCP/工具）、工作台体检、检查更新（无 `updateCheck` 调用、无 `update.json` 读取）、窗口序号、最近打开、网页 AI 五站点、盘容量、场景条。
- **差异**：从“画了没接线”变成“接线了但功能面只有旧壳的一半”：菜单里的“版本信息”只读本地版本与团队工具是否存在，不能检查更新；“成员”入口的语义与旧壳不同。
- **影响**：用户无法自查插件目录、无法体检（旧会写出报告并打开）、无法看余额、无法检查更新；`docs/FEATURE-MATRIX.md:26` 的“安装包/更新 未完成”在界面层也没有手动兜底。
- **建议落点**：补 `app:updateCheck`/`workbench:health`/`app:balance`/`mem:inject`（旧实现见 `外壳/main.js:813-856`、`304-342`、`787-810`、`903-923`，建议重写而非复制）与对应菜单项；扩展组按旧 `openDir()` 语义补（`外壳/renderer/app.js:1426-1449`）；“成员”改为旧式弹窗或明确改名为“角色”。

### P1-8 “刷新”不再刷新嵌入的 DSH 页面

- **旧行为**：`reloadEngine()` + `refreshWorkspaceSoon()` 在 700ms、1800ms **两次** `webview.reload()`，专门解决“会话投影比页面晚到”（`外壳/renderer/app.js:138-147`）；建工作区、打开项目、恢复、成员唤醒、⟳刷新、菜单项都会调用（`163/266/340/395/1257/1370/1661`）。
- **新行为**：`#btn-refresh` 只做 `refresh()` + `initDsh()`；`initDsh()` 走 `applyDshViewSrc()`，而后者**只在 src 为空/为 about:blank/与 baseUrl 不一致时才改 src**（`src/renderer/app.js` 的 `applyDshViewSrc()`），**不会 reload 已有 webview**；只有离线卡片的 `retryDsh()` 会 `view?.reload()`。建团队/建项目/恢复后都没有刷新嵌入页。
- **差异**：旧“在线刷新左侧工作区/成员”是双次 `reload()`；新只有“地址变了才换 src”，同地址下 DSH 页面不重新加载。
- **影响**：建完六角色后用户在 DSH 面板里看不到成员（叠加 P0-2 的空白会话问题，几乎必然发生）；会误判为“建团队失败”（离线重试按钮也救不了——在线时它不出现）。
- **建议落点**：`refresh()` 成功后（或 `dshProvision`/`adoptProject`/`createProject` 成功后）调用 `#dsh-view` 的 `reload()`，沿用旧的双次延时补偿；`retryDsh()` 里的 reload 可以抽成公共函数。

### P1-9 删除项目只删记录、无 UI；单实例锁缺失

- **旧行为**：没有“删除项目”这个动作（`外壳/main.js` 无删除 IPC，避免误删目录）；同一时刻只允许一个实例，重复双击只把已有窗口前置（`18-26`），避免两个实例抢同一份用户数据与团队状态。
- **新行为**：`project:delete-record` 只从 `workbench.json` 摘掉记录、切 `activeProjectId`（`src/main.js:604-612`），**不动目录、不清理团队登记、不清理 `_backup`**，而且渲染层没有任何入口（`preload.js:17` 暴露，`src/renderer/app.js` 无调用）。主进程没有 `requestSingleInstanceLock`（grep 无命中），`app.on('second-instance')` 也没有。
- **差异**：多出一个“半删除”后端（可被 preload 直接调用，删完本地记录仍在磁盘与团队状态里），同时失去旧壳的进程级互斥。
- **影响**：两个实例同时跑会各自写 `workbench.json`（虽然有 `.bak`），并发建 DSH 会话、并发改团队状态；一旦有人调用 `deleteProjectRecord`，项目会变成“磁盘有、壳里没有、团队里还在”的三态。
- **建议落点**：`src/main.js` 恢复 `requestSingleInstanceLock`/`second-instance`；`delete-record` 要么补 UI + 二次确认 + 明确“只移除登记、不删文件”的文案，要么暂时不暴露到 preload。

---

## P2 · 明显退化，但有绕行路径

### P2-1 团队状态与协作台在界面上完全不可见

- **旧行为**：`team:status` 聚合 `团队.json`、`会话.json`、`看板.json`、`当前工作区.json` 与四个工具是否存在（`外壳/main.js:354-364`），建团队弹窗用它取 `currentWorkspace`（`外壳/renderer/app.js:281-285`）；协作台面板每 5 秒自动读 `协作/state.json`（仅在面板可见且页面未隐藏时），展示 5 张统计卡、智能体表、派单明细（含状态筛选“全部/进行中/已完成/异常”）与最近 10 条回执流水（`外壳/renderer/app.js:986-1213`；数据源 `外壳/main.js:343-352`）。
- **新行为**：`statePayload().team = teamTools.quickInfo()`（`src/main.js:285`），只有 `initialized/toolExists/teamRoot/projectCount/activeProject/phase/boardExists/boardGeneratedAt`（`src/team-tools.js:535-565`）；渲染层只在“版本信息”弹窗里读过一次 `state.team?.toolExists`，团队 phase/成员/当前工作区/看板时间都没有进界面，也没有协作台。`teamWorkspaces()` 在渲染层零调用。
- **差异**：团队 phase/成员数/当前项目/看板生成时间这些旧壳随处可查的信息，新壳完全黑盒；协作台的“5 秒自动对账 + 状态筛选 + 回执流水”整块消失。
- **影响**：用户无法判断团队工具是否初始化、看板是不是最新、当前工作区是不是自己要的那个；出问题时只能去翻文件。
- **建议落点**：`src/renderer/app.js` 侧栏 `dsh-box`下方补团队卡片（读 `state.team` + 按需 `teamWorkspaces()`）；若要协作台，新增只读面板与 5 秒可见性轮询（旧 `collabActive()` 语义）。

### P2-2 错误码与引导文案退化

- **旧行为**：面向用户的错误有明确 `code` 与针对性文案：`PROJECT_NAME_CONFLICT`（附“请先改目录名，或从左侧原有项目恢复”，`外壳/main.js:669-677`）、`WORKSPACE_EXISTS`（“一个工作台=一个项目…不要重复新建”，`744-745`，渲染层再改写一次，`外壳/renderer/app.js:233-235`）、`NAME_REQUIRED`/`BAD_NAME`（`695-697`）、`PROJECT_FOLDER_NOT_FOUND`（`666`、`721`）、`CANCELED`（`662`）、`OPEN_FAILED`/`RESTORE_FAILED`（`688`、`733`）。
- **新行为**：IPC 直接 `throw new Error('这个目录已经是工作台项目')` 等中文串（`src/main.js:300-305`、`474-476`），渲染层的 `catch (e) { error(e.message) }`（`openNewProject()` / `openRestoreModal()` 的提交分支）；`team-tools.js` 内部有规范化 `code`（`PROJECT_DIR_MISSING/TOOL_MISSING/DSH_OFFLINE/TIMEOUT` 等，`195-205`、`287-328`、`628-638`），但多数没被渲染层区分展示。
- **差异**：从“错误码 + 操作建议”变成“一句话”，用户不知道该改目录名还是去恢复；`CANCELED` 不再被特殊处理（旧会静默忽略取消）。
- **影响**：常见错误（同名、已存在、没引擎）都要靠猜；无法做自动化判断。
- **建议落点**：`src/main.js` 统一抛 `{ok:false, code, message}` 结构（或在 preload 层包一层）；`src/renderer/app.js` 的 catch 按 code 给旧文案。

### P2-3 环境变量与配置文件兼容性

- **旧行为**：`dshHome()` = `DSH_HOME || DSH_ROOT || ~/.dsh`（`外壳/main.js:100`，`175-176`、`187` 同）；引擎地址来自 `config.json` + `config.local.json` 合并（`163-174`），支持 `DSH_WEB_URL` 兜底（`509-512`）；`app:dirs` 支持 `DSH_WORKSPACE` 与“工作台”目录猜测（`175-186`）；团队根支持 `WB_WORKBENCH_DIR`（`190-194`）。
- **新行为**：`dshHome()` 只认 `DSH_HOME`（`src/dsh-adapter.js:18-20`）；没有配置文件读写；`TEAM_ROOT`/`AWB_DATA_DIR`/`AWB_STORE`/`AWB_NODE` 是新的变量名（`src/team-tools.js:224`、`src/main.js:11`、`20-21`、`team-tools.js:226`）。
- **差异**：只设了 `DSH_ROOT` 的老用户/老脚本，新壳找不到 `.credentials.yaml`（报 `DSH_AUTH_MISSING`），且没有任何配置迁移提示；`DSH_WEB_URL` 仍认，但端口变化时无法持久化。
- **影响**：从旧壳迁移过来的机器大概率首次启动即离线，且错误信息在侧栏小字里。
- **建议落点**：`src/dsh-adapter.js:18-20` 恢复 `DSH_ROOT` 兜底；`src/main.js` 增加 `config.json`/`config.local.json` 读取（与旧 `app:config` 同语义）并作为 `dsh.baseUrl` 默认值。

### P2-4 顶栏负载指标口径变了

- **旧行为**：CPU 用 `os.cpus()` 两次采样算**整机**占用（`外壳/main.js:53-68`），GPU 读 `nvidia-smi` 的 `utilization.gpu,memory.used,memory.total`（`70-85`），内存用 `os.totalmem/freemem`（`87-91`）；渲染层按 90/70 阈值加 `warn/bad` 类，标题里带 GPU 显存（`外壳/renderer/app.js:451-465`）。
- **新行为**：CPU 用 `app.getAppMetrics()` 各进程 `percentCPUUsage` 求和并 clamp 到 100（`src/main.js:408-427`），GPU 取 `util`（`417-423`）；渲染层在重写后已加 85/65 阈值配色，并在 title 里显示 GPU 显存（`tickMetrics()`）。仍不同的是**口径**：同一个“CPU”从整机占用变成应用自身占用，UI 仍标“本机负载”。
- **差异**：配色与显存已对齐；数字含义没对齐（旧 20% ↔ 新 3% 都可能）。
- **影响**：用户会误判机器负载（尤其卡顿时 CPU 只显示个位数）。
- **建议落点**：`src/main.js:408-430` 用 `os.cpus()` 采样恢复整机口径，或把 UI 标签改成“应用 CPU/内存”并保留整机内存。

### P2-5 `team:launch` 默认语义反转，且这层包装实际没人用

- **旧行为**：`team.launch(payload)` 默认**真建会话**，只有显式 `dryRun:true` 才 `--dry-run`（`外壳/main.js:517`）。
- **新行为**：`team:launch` 默认 `dryRun:true`（`src/main.js:540-541`，注释也写了“必须显式 dryRun:false”），`src/team-tools.js:643`/`657` 两处再次确认“非 false 即 dry”；而渲染层**从不调用** `teamLaunch`（只有 selftest 调，`src/main.js:1254-1255`），preload 里 `teamLaunch`/`teamWorkspaces`/`teamEnsureProject`/`teamBoard`/`deleteProjectRecord` 全是死接口（`src/preload.js:17`、`22-25`）。
- **差异**：同名 IPC 的默认行为相反；包装层（含 `--seed-visible` 缺失、`latest` 复用语义）没有任何 UI 路径能走到，属于“写了但没接”。
- **影响**：后续有人照旧习惯调用会得到“静默不建会话”；同时团队工具的 dry-run/离线错误码（`DSH_OFFLINE`）在真实 UI 路径上永远触发不到，测试覆盖的是死代码。
- **建议落点**：`src/main.js:535-574` 明确 `dryRun` 默认值并与 UI 对齐；要么把“建团队”接到 `teamLaunch`（推荐，见 P0-2），要么删除这批死接口，避免误用。

### P2-6 数据落点与运维能力

- **旧行为**：团队状态在工作台目录（`WORKBENCH_DIR/团队`，`外壳/main.js:190-201`），项目在 `工作台\项目`；`main.log` 记录 `createWindow/did-finish-load/did-fail-load/engine resolved/建工作区/恢复`（`27`、`968-970`、`152`、`685`、`730`、`759`、`773`）；`process.on('uncaughtException')` 也写日志（`1091`）；单实例保护（`18-26`）。
- **新行为**：数据在仓库内 `data/`（`userData`/`sessionData`/`temp` 全被重定向，`src/main.js:11-17`），团队根默认 `<repo>/团队`（`src/team-tools.js:224`），团队状态因此写在**应用目录**里；`data/` 未进 `.gitignore`（现 `.gitignore` 只有 `node_modules/`、`userdata*/`、`.selftest-data/`、`projects/`、`selftest*.png`、`*.log` 和 `团队/状态` 等）；没有任何日志文件，没有 `uncaughtException` 处理。
- **差异**：旧“状态在用户工作区、日志在应用旁、单实例”；新“状态在安装目录、无日志、可多实例”。打包后 `团队/状态` 若在 asar 内将不可写（`team-tools.js:230` 只设 `ELECTRON_RUN_AS_NODE`，未处理只读目录）。
- **影响**：升级/重装可能丢团队状态；误配置时无日志可查；`data/userdata`（Chromium profile、cookie）有被提交进 git 的风险。
- **建议落点**：`.gitignore` 加 `data/`；`src/main.js:11-17` 允许 `AWB_DATA_DIR` 指向用户目录并在 about/体检里显示；团队根默认改为数据目录下的 `团队`（`src/team-tools.js:224`）；补一个 `data/logs/main.log` 与 `process.on('uncaughtException')`。

### P2-7 引导补回来了，但“插件清单 + 更新检查 + 系统主题”仍缺

- **旧行为**：`applyTheme(mode)` 支持 `auto`（跟随系统 `prefers-color-scheme`）、持久化 `wb.theme`、启动 `restoreTheme()`、菜单项文案随主题切换（`外壳/renderer/app.js:1451-1472`、`1366-1368`、`外壳/renderer/index.html:38`）；新手引导 5 步聚光（`ob-ring`/`ob-arrow`/`ob-blocker`、步骤点、上一步/下一步/跳过、`wb.onboarded.v2`、第 4 步读 `update.json` 的 `requiredPlugins` 与版本）（`外壳/renderer/app.js:1474-1616`、`外壳/renderer/index.html:118-135`）；更新检查支持 `repo`/`feedUrl`/`downloadUrl`、版本比较、`source:'local'` 兜底、发现新版本给 `brand-ver` 加 `has-update` 并 toast（`外壳/main.js:813-856`、`外壳/renderer/app.js:1339-1361`、`1617-1629`）。
- **新行为**：主题有 `applyTheme/currentTheme/syncThemeUi/toggleTheme`，菜单文案与按钮图标会同步，持久化 `awb.theme`——但只接受 `light|dark`，不认 `auto`/系统偏好（`applyTheme(mode)` 里 `mode === 'light' ? 'light' : 'dark'`）。引导在 03:36 重写后已实现（`GUIDE_STEPS`、步骤点、上一步/下一步/完成、`awb.onboarded`、`positionGuide()` 的圆环/箭头定位），但**没有插件清单**（渲染层 grep 无 plugins）、**没有更新检查**（无 `updateCheck` 调用，`update.json` 在 `src/` 下无任何读取），版本弹窗只读本地版本与 `state.team?.toolExists`。
- **差异**：引导的“形式”已对齐，“内容”少了旧壳第 4 步的必需插件清单与版本检查；更新检查整块仍缺；主题少了 auto。
- **影响**：新用户看不到“六角色要 deepseek-account 插件”的提示；版本落后无提示；“跟随系统”用户每次要手动切。
- **建议落点**：`GUIDE_STEPS` 补插件清单（读 `update.json` 的 `requiredPlugins`，与旧 `外壳/main.js:813-821` 同源）；`applyTheme` 支持 `auto` 并在启动时按 `prefers-color-scheme` 解析；新增 `app:updateCheck`（语义参考旧 `外壳/main.js:813-856`）并接到 `data-more="version"` 或独立菜单项。

### P2-8 环境扫描/盘容量/PC 面板与 `fs:read` 预览接口消失

- **旧行为**：`disk:list` 读 C/D/E/F 的 `statfs`（`外壳/main.js:858-871`），`renderPcPanel()` 画总容量头 + 每盘环形图（`外壳/renderer/app.js:953-984`）；`projects.json` 的“环境扫描”面板指向 `工作台\项目索引`（`scenarios/projects.json:30-38`）；`fs:read` 支持 md/图片/视频/PDF（`884-900`）。
- **新行为**：无盘容量、无扫描面板、无 `fs:read`；`system:metrics` 只返回 CPU/MEM/GPU（`src/main.js:408-430`）。
- **差异**：整块系统面板消失。
- **影响**：旧壳的“本地电脑”场景（清理/盘点）在新壳没有对应物；`scenarios` 目录也没有加载器（P0-1）。
- **建议落点**：如仍要“本地电脑”场景，需先恢复场景/面板系统（P0-1），再补 `disk:list` 与 `fs:read`（注意路径白名单）。

---

## P3 · 细节不一致（不阻断，但会造成“看起来一样、其实不一样”）

### P3-1 `pendingAck` 过期只在展示层生效

- **旧行为**：派单锁 `派单锁.json` 没有 TTL，必须 `ack` 或 `--force`，存在性以文件为准（`ops.mjs:320-337`、`347-353`）。
- **新行为**：`publicProject()` 在读取时把过期 `pendingAck` 置空但**不落盘**（`src/main.js:266-270`），下一次 `team:send`/`team:ack` 才真正清理（`823-829`、`879-881`）。
- **差异**：UI 显示“无待回执”，磁盘仍是旧状态；两个读取路径（`statePayload` 与 `team:send` 的 `readStore`）短暂不一致。
- **影响**：只影响诊断与并发窗口，风险低。
- **建议落点**：`publicProject` 只做投影、不改对象；或在 `statePayload` 里显式标注 `pendingAckExpired:true` 交给 UI 决定。

### P3-2 任务默认归属与阶段判定

- **旧行为**：任务 `owner` 为空时由 PM 派单时补写，阶段用 `owner` 判定（`ops.mjs:354-368`、`外壳/main.js:401-421`）。
- **新行为**：`task:create` 的 `role` 默认 `'pm'`（`src/main.js:619`），`deriveStage` 只按 `tester/programmer` 判定（`255-256`），pm 任务永远不会推进到 `dev/test`，只会停在 `dispatch`。
- **差异**：默认值让“新建任务”变成“派给 PM 的障碍物”。
- **影响**：用户建一个任务后阶段卡在派发。
- **建议落点**：`src/main.js:619` 默认 `role` 改为空/首个非 pm 角色并允许 UI 必选；`deriveStage` 对无角色任务给出明确阶段（如 `dispatch` 前先 `requirement`）。

### P3-3 回执/派单/Owner 的约束变化

- **旧行为**：`ack` 的 note 可省略（默认“已收到”，`ops.mjs:434`）；PM 可以给 `pm` 自己发消息（只有派单锁逻辑排除 `to==='pm'`，`347`）；`workflow:owner` 只接受 `approved/skipped/rejected`（`外壳/main.js:455`）。
- **新行为**：`team:ack` 强制非空（`src/main.js:887`）；`team:send` 直接禁止 `role==='pm'`（`820`）；`owner:decide` 接受 `optional` 并把状态复位（`900`）。
- **差异**：三处都是“更严/更松”的静默改变。
- **影响**：旧脚本/习惯操作会得到新错误；`optional` 复位没有 UI 入口，属于隐藏能力。
- **建议落点**：对齐契约或在 UI 文案中说明；`owner:decide` 若保留 `optional`，补“重置本轮”按钮与二次确认。

### P3-4 文件列表排序、截断与错误返回形态

- **旧行为**：`fs:list` 明确 `dirs first + localeCompare('zh-CN')`（`外壳/main.js:877-879`），失败返回 `{ok:false, why}`（`881`）。
- **新行为**：`files:list` 用 `readdir` 原生顺序（`src/main.js:378-396`），超过 `depth>4` 或 `out.length>600` 静默 `return`（`379`），失败 `throw`（`374-376`）。
- **差异**：顺序不稳定；截断无提示；异常风格从返回值变异常。
- **影响**：同目录在不同机器上顺序不同；大项目“少文件”无感知。
- **建议落点**：`src/main.js:371-398` 排序 + `truncated` 字段；文件列表标题处显示“已截断”。

### P3-5 窗口细节

- **旧行为**：`app.setAppUserModelId('com.xuyefeng.agile-workbench')`（`外壳/main.js:11`）；标题栏拖拽区双击最大化（`外壳/renderer/app.js:1220-1221`）；窗口 `minWidth 1000/minHeight 660`（`外壳/main.js:956-957`）。
- **新行为**：无 `setAppUserModelId`；标题栏双击最大化在 03:36 重写后已补（`#titlebar` 的 `dblclick` 绑定）；`minWidth 980/minHeight 640`（`src/main.js:1025`），`show:false` + `ready-to-show`（`1026`、`1034`）。
- **差异**：任务栏归组/图标行为与最小尺寸变了；双击已对齐。
- **影响**：低；主要是 Windows 任务栏与旧版不一致。
- **建议落点**：`src/main.js:1439-1441` 补 `setAppUserModelId`。

### P3-6 旧交互文案与“一个工作台=一个项目”的硬约束

- **旧行为**：新建/恢复/成员/引导里充满操作指引：“一个工作台=一个项目，请直接选「建团队/恢复」”（`外壳/renderer/app.js:234`）、“建完你先找 PM 说需求，其他角色等派单”（`207`、`262`）、“DSH 左侧不显示空白会话…点下面的按钮逐个发一句已就位”（`1650`）、“只能点这里的下一步/上一步/跳过”（`外壳/renderer/index.html:133`）；“成员”弹窗会列出六个角色与 session 短 id，并提供“逐个显示成员”（`外壳/renderer/app.js:1640-1666`）。
- **新行为**：新建/恢复弹窗只有字段与 hint；角色页显示“DSH 会话未创建/已就绪/空会话”（`loadDshTeamStatus()`），没有“为什么看不到成员”的解释，也没有批量 seed 入口；顶栏“成员”按钮在 03:36 重写后只是 `showTab('roles')`，不是旧式成员弹窗。
- **差异**：旧壳把“空白会话不可见”这个坑写在 UI 里并给了按钮；新壳只显示事实，不给解法。
- **影响**：用户反复“建团队”以为失败，实际是空白会话不显示（与 P0-2 叠加）。
- **建议落点**：角色页补说明 + “让成员显示（逐个发已就位）”按钮，调用 `launchSessions({seedVisible:true})` 或等价循环（主进程见 P0-2）。

---

## 附录 A · 新壳做得更好、不要回退的部分

审计不是为了回到旧实现。以下新壳能力旧壳没有，建议保留并作为重写底座：

1. **状态库原子写 + 上一版备份 + 损坏隔离**（`src/main.js:87-240`，含 `.bak`、`.corrupt-<stamp>`、`.tmp`、`STORE_RESTORED/STORE_CORRUPT` 提示），并有 20+ 条隔离自检（`1040-1132`）。旧壳完全没有本地库。
2. **提案的哈希绑定与冲突保护**（`baseHash/afterHash`、`STALE/CONFLICT`、回滚备份哈希校验，`src/main.js:723-815`）比旧协议更细，只是缺了协议层（P0-3）。
3. **路径越界防护**：`files:open`、`proposal:*` 都做 `startsWith(root + sep)`（`src/main.js:405`、`662`、`733`、`782`）。
4. **团队工具调用的错误归一**：超时/工具缺失/坏 JSON/DSH 离线全部结构化（`src/team-tools.js:250-345`、`628-638`），比旧壳“截 stderr 1200 字”强。
5. **单文件提案的 256KB 上限与“已有未回滚同文件提案”拦截**（`src/main.js:666`、`741-746`）。

## 附录 B · 与 `docs/FEATURE-MATRIX.md` 的出入

| 矩阵行 | 声称 | 审计结论 |
|---|---|---|
| `:5` DSH 工作区入口 | 已完成 | 入口与离线卡片都在，但地址写死、配置不持久、cookie 不重铸（P1-1） |
| `:6` 六角色 DSH 会话 | 已完成 | 仅创建会话，缺模型/复用/空会话可见/记账（P0-2） |
| `:11` 看板 | 已完成 | 仅本地四列任务；旧版看板读团队状态，二者不通（P0-5、P1-6） |
| `:12` 文件索引 | 已完成 | 树与工具条有了，但没有面板内预览/最近打开（P1-5） |
| `:13-19` 提案/评审/签字/apply/rollback/派单/回执 | 已完成 | 缺 show、评审集合、签名绑定、boot 令牌、事件（P0-3、P0-4） |
| `:21` 流程图 | 已完成 | 8 阶段线性图，`review` 不可达、无 push（P1-2、P0-5） |
| `:25` 场景页签 | 未完成 | 实际连“工作区清单/切换”也缺（P0-1） |
| `:26` 安装包/更新 | 未完成 | 版本弹窗有了，但“检查更新”仍无实现（P1-7、P2-7） |

## 附录 C · 未验证 / 需运行确认

以下结论基于静态阅读，未启动程序；若要落修复，建议先在沙盘验证：

1. DSH 实际端口是否默认 52711（`src/main.js:58`）；旧壳默认 3080（`config.json:2`）。这决定 P1-1 的实际影响面。
2. **渲染层仍在被并行重写**（`app.js` 838 → 2,015 行，`index.html` 245 → 348 行，`style.css` 37,577 → 56,694 B）。本文对渲染层的结论已改为函数/选择器级；定稿前请重跑附录 D 的 id 差集与 `data-more` 覆盖检查。
3. `dsh:provision` 建的会话在 DSH 左侧是否真的不可见（依据是旧注释 `launch.mjs:48-50` 与 README:95，未在新版本复测）。
4. `verify`/`board` 对“新壳提案/任务”的实际表现（预期为空，因为二者不在 `团队/状态`）。
5. `team-tools.js` 的 `TEAM_ROOT` 默认 `<repo>/团队` 在打包（asar）后是否可写。
6. “成员”按钮改成切角色页后，旧式“逐个发已就位”的批量 seed 是否还有其它入口（当前 grep 无）。

## 附录 D · 复核命令（只读，供后续验证用）

```powershell
# 新壳渲染层实际调用过哪些 IPC（确认死接口）
Select-String -Path src\renderer\app.js -Pattern 'workbench.([A-Za-z]+)' -AllMatches |
  ForEach-Object { $_.Matches } | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique

# 新壳是否存在单实例锁 / 日志 / 异常兜底（预期：无输出）
Select-String -Path src\main.js -Pattern 'requestSingleInstanceLock|appendFile|uncaughtException'

# 新壳是否用过 seed-visible / selectModel（预期：无）
Select-String -Path src\*.js -Pattern 'seed-visible|selectModel'

# 旧壳菜单项清单（12 项）
Select-String -Path 'D:\deepseek\luanyujia-workbench\12-源码照搬\外壳\renderer\index.html' -Pattern 'data-act='

# 团队工具里派单锁/回执的真实实现
Select-String -Path 团队\工具\lib\ops.mjs -Pattern 'dispatchLock|PM_DISPATCH_PENDING|cmdAck|checkApprovals'

# DOM 控件 vs 渲染层绑定：html 有、app.js 没引用的 id（P0-0 的复核方式）
$app = 'src\renderer\app.js'; $html = 'src\renderer\index.html'
$bound = Select-String -Path $app -Pattern '#([A-Za-z][A-Za-z0-9_-]+)' -AllMatches |
  ForEach-Object { $_.Matches } | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique
Select-String -Path $html -Pattern 'id="([A-Za-z][A-Za-z0-9_-]+)"' -AllMatches |
  ForEach-Object { $_.Matches } | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique |
  Where-Object { $bound -notcontains $_ }
```

---

**审计结论一句话**：新壳把“数据可靠性”做扎实了，但把旧壳的**导航层（场景/工作区清单）、会话层（launch.mjs 的模型/复用/seed/记账）、协作层（团队工具协议：boot/show/签名/锁/索引/事件）**换成了本地简化模型，三者与 `团队/状态` 不再互通——这是 P0-1~P0-5 的共同根因；P0-0 则是“UI 契约缺自检”导致的即时可见后果。修复顺序建议：先补 P0-0 的 UI 契约自检（对齐已大体完成）→ P0-2（会话）→ P0-4/P0-3（协议接线）→ P0-5/P0-1（单一真相与导航）→ 其余 P1。

> 本报告是**审计快照 + 待复核清单**，不是对最新工作树的判决。写作期间主进程/渲染层都在被并行重写（§0.1、§0.2）；请先按 §0.2 的“疑似已修”列复核一遍，再决定修哪几条——避免把已经修好的条目再排一遍，也避免把“已修一半”的条目当成完成。
