# 第十二轮 · 旧工作台完整流程 / 新壳 S12 对照审计（只读）

> 范围：以旧工作台的完整流程（接单 → 需求 → 产品评审 → Owner 评审 → 派单 → 开发/互审 → 测试 → 收口 → 迭代）为基准，逐段对照新壳当前实现，列出仍然缺/不一致的 P0/P1/P2，并给出可复核的文件/函数。
>
> 只读边界：本轮**只新增本文件** `docs/PARITY-ROUND12.md`。未修改 `src/**`、`package.json`、`团队/**`、`项目/**`、`userdata-*`、旧仓库 `D:\deepseek\工作台` 与 `D:\deepseek\luanyujia-workbench`。未启动 Electron / DSH 会话，未跑 `npm run selftest`，只跑了 `team.mjs verify / doctor / pilot` 三条只读命令和一个只读的能力探测。
>
> 写法约定：审计期间**新旧两边的源码都在被并行修改**（见 §1.3）。正文一律以“函数名 / IPC 名 / 常量名”为主，行号只作 S12 快照的定位提示；如果源码已再变，按 §9 的命令重验，不要用旧行号下结论。

---

## 0. 结论速览

### 0.1 一句话

**S12 的完整流程在最关键的一步被自己锁死了：新壳把 `req review`、`owner`、`workflow` 三条旧工具并不存在的命令设成硬前置，`legacyCapabilities()` 当前明确返回缺这三条；因此“需求评审 → Owner 闸门 → 迭代/终止”全部返回 `LEGACY_PROTOCOL_REQUIRED`，后面的派单/开发/测试/验收代码虽然存在，却走不到。**

这不是“少一个按钮”，而是整条主链在当前快照上不可完成。其余问题（Owner 身份、派单不唤醒不加锁、互审/签字由壳代跑、boot 先补模板再放行、两套 Owner 闸门）是在这条主链修通之后会立刻遇到的下一个闸门。

### 0.2 阶段判定

| 旧流程阶段 | 旧版执行者/入口 | 新壳 S12 对应 | 判定 |
|---|---|---|---|
| 0 接单 | PM 写 `项目信息.md`、`req create` | 建项目时自动生成模板；需求创建可走 `requirement:create` | **部分**：模板可全是占位符，PM 不能建需求（只允许产品/需求） |
| 1 需求 | 产品/需求/PM `req create` + 分析师写 `R-*.md` | `createRequirement()` → 旧 `req create` + 写 `需求/R-*.md` | **可用**：但创建前不要求角色 boot，壳自己 mint 令牌 |
| 2 产品评审 | 产品在需求/提案上 `review approve`（旧版没有 `req review` 命令） | `reviewRequirement()` → 硬要求 `req review` | **P0 阻断**：旧工具没有该命令，直接 `LEGACY_PROTOCOL_REQUIRED` |
| 2.5 Owner 评审 | PM 弹流程框，Owner 选跳过/通过；提案敏感级另有 `owner-approve` TTY | `ownerRequirementDecision()` → 硬要求 `owner` 命令 | **P0 阻断**：旧工具没有 `owner` 命令；且身份只是字符串 |
| 3 派单 | PM `send --ack`，写派单锁，DSH prompt 唤醒 | `dispatchRequirement()` → `task create` + `sendWorkflowNotice()` | **P1**：`--no-wake`、无 `--ack`、无锁；即使前两步修通，也不会真正唤醒/限流 |
| 4 开发/互审/签字 | 程序员 claim→propose；另一名互审；PM show→review→sign→apply | `devSubmit/devReview/devApply` | **P1**：互审和签字的 `legacyProposalAction` 允许无会话；PM 的 show/review/sign/apply 一次点完 |
| 5 测试 | PM 建测试任务并 `send`；测试 claim/done 带证据 | `dispatchTest()` → `task create` + 无 ack 通知 | **P1**：同派单问题；测试任务不会被唤醒 |
| 6 收口 | `reconcile → verify → pilot → board`，PM 更新索引/看板 | `team:reconcile` 只做本机通信对账；无 `verify/pilot` 入口 | **P1**：没有旧版的收口健康闸门；当前真实 `verify` 仍 9 个问题、`pilot` FAIL |
| 7 迭代/终止 | 新需求新文件；终止由 Owner/PM 决定 | `iterateWorkflow/terminateWorkflow` → 硬要求 `workflow` 命令 | **P0 阻断**：旧工具没有 `workflow` 命令；终止后的旧任务收口代码已经写了，但执行不到 |

### 0.3 三条硬结论

1. **旧工具本来就没有 `req review` / `owner` / `workflow`。** 旧 `team.mjs` 的 `NOT_IMPLEMENTED_COMMANDS` 明确把 `workflow`、`owner` 列成“未实现”；`cmdReq` 对 `review` 返回 `NOT_IMPLEMENTED`。新壳却把这三条设成必需前置，等于把“旧协议没有的能力”变成“新壳也不许走”。
2. **Owner 闸门在 S12 仍然只是字符串。** `requirement:owner` 主进程默认 `role: 'owner'`，`owner:accept` 默认 `role: 'owner'`；没有 nonce、没有 TTY、没有本地凭据、没有服务端解析。任何能调用 preload 的渲染层代码都能以 Owner 名义通过/验收。
3. **派单/互审/签字仍然可以由一个操作者代跑。** 工作流派单不带 `--ack`/`--no-wake`，互审/签字显式 `allowMissingSession: true`；旧版“一次只派一个、等回执”“互审是另一名程序员”“PM 看过才签字”的语义没有被新壳真正执行。

---

## 1. 快照与基线

### 1.1 新仓 S12 快照

审计快照：**2026-11-05 15:43:47（Asia/Shanghai）**，仓库 `D:\deepseek\agile-workbench`。

| 文件 | 字节 | SHA-256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 461,250 | `D856020C5BE1BC9E` | 15:39:07 |
| `src/team-tools.js` | 243,399 | `80DE5387966EBE41` | 15:39:19 |
| `src/preload.js` | 7,433 | `43D94AF143AB9823` | 13:47:04 |
| `src/renderer/app.js` | 440,734 | `30B931D144460EDB` | 15:43:47 |
| `src/renderer/index.html` | 44,584 | `810F5234D1082A99` | 14:49:02 |

新仓的 `团队/工具/**` 仍是旧工具的**副本**（`team.mjs` 5,354 B / `ops.mjs` 111,912 B，与旧仓 15:36 之前的版本字节相同），所以新壳调用的仍是旧引擎，而不是重写后的引擎。

### 1.2 旧版基线

旧协议语义以三份稳定材料为准：

- `D:\deepseek\工作台\团队\流程.md`（5,477 B，2026-11-03）：阶段表、回执链、PM 硬闸门。
- `D:\deepseek\工作台\团队\工具\team.mjs`：命令表 + `NOT_IMPLEMENTED_COMMANDS`。
- `D:\deepseek\工作台\团队\工具\lib\ops.mjs` / `store.mjs`：`cmdBoot/cmdSend/cmdReq/cmdPropose/cmdReview/cmdSign/cmdApply/cmdOwnerApprove/cmdReconcile/cmdVerify` 等实现。
- 旧壳 UI 以 `D:\deepseek\luanyujia-workbench\shell` 为准（`main.js` 67,864 B / `E54991F0A2EDA795`，2026-11-03 09:14；`renderer/app.js` 90,670 B）。

旧版流程原文（`团队/流程.md` 阶段表）是：**PM 接单 → 需求分析师写需求 → 产品/架构评审（Owner 可参与/跳过）→ PM 派开发（一次一个，等回执）→ A/B 开发互审、PM 签字 apply → 测试 → PM 收口（reconcile/verify/pilot/board）→ 迭代**。

### 1.3 审计期间源码在动（必须先说明）

- 新仓 `src/team-tools.js` 从 15:28 的 234,019 B 涨到 15:39 的 243,399 B；`src/main.js` 从 453,707 B 涨到 461,250 B；`src/renderer/app.js` 从 416,119 B 涨到 440,734 B。
- **旧仓也被改了**：`工作台/团队/工具/lib/ops.mjs` 15:36:41 变为 118,907 B（`A7BBC9A4…`），`team.mjs` 15:36:53 变为 6,986 B（`86A46682…`），`workspace.mjs` 15:39:27 也有改动。旧仓不再是完全静止的基线。
- 因此本报告把“旧协议语义”锚在 `团队/流程.md` 和旧壳（未变）上；旧 `team.mjs` / `ops.mjs` 只按函数名引用，不依赖行号。新仓按 S12 函数名引用。
- 结论只对 S12 快照负责。**若源码在报告之后又变，先跑 §9 的 1–3 条再决定哪些 P0/P1 已被修掉。**

---

## 2. 旧版完整流程（按阶段拆）

### 2.1 旧版阶段与硬闸门

| 阶段 | 旧版动作 | 旧版闸门/证据 |
|---|---|---|
| 0 接单 | PM 写 `项目信息.md`；`req create`；`task create` | 没有项目信息不叫角色；`req create` 允许 `pm/product/analyst`（`ops.mjs` `cmdReq`） |
| 1 需求 | 分析师写 `需求/R-YYYYMMDD-xxxx-标题.md` + `需求/00-需求总览.md` | 需求正文 + 验收标准；`boot` 令牌 |
| 2 产品评审 | 产品在需求/提案上 `review approve` 并回执 PM | `show` 是 `review` 前置；旧版**没有** `req review` 命令（`cmdReq` 明确 `NOT_IMPLEMENTED`） |
| 2.5 Owner 评审 | PM 弹流程框，Owner 选择跳过/开始评审；PM 记录 | Owner 必须明确选择；旧 `workflow:owner` 只写 `工作流.json.ownerReview`，是过程记录，不是强身份 |
| 3 派单 | PM `send --ack`，写 `派单锁.json`，DSH prompt 唤醒 | 一次一个；未回执不派下一个；`ack` 同 id 才清锁（`ops.mjs` `cmdSend`） |
| 4 开发 | 程序员 `grant → claim → propose`；另一名程序员 `show/review`；PM `show/review/sign/apply` | `apply` 必须 PM、CAS、备份、回滚、索引；敏感/关键提案需全员签字 + `owner-approve` TTY（`requiredSets` / `checkApprovals`） |
| 5 测试 | PM 建测试任务并 `send`；测试 `claim/done --evidence` | 测试报告 + 回执；PM 不替测试 done |
| 6 收口 | `reconcile → verify → pilot → board`；PM 更新索引/看板 | `verify` 全绿、`pilot` 五项 PASS 才扩编/下一轮（`团队/运行手册.md` 第四节） |
| 7 迭代 | 新需求新建文件；澄清更新原需求 | 不把新需求塞旧文件；重新走阶段 1 |

### 2.2 旧版“Owner 评审”到底是什么

- 需求级 Owner 评审：旧壳 `workflow:owner`（`shell/main.js`）只写 `工作流.json` 的顶层 `ownerReview`；没有身份校验，是 PM/Owner 在流程浮窗里的**过程记录**。
- 提案级 Owner 批准：`team.mjs owner-approve`（`ops.mjs` `cmdOwnerApprove`）才要求真实 TTY，输入「批准 P-…」，并用 `signatureDigest` 绑定 `proposalHash/baseHash/newHash/ts/nonce`。
- **这两件事不是一回事。** 新壳把“需求级 Owner 评审”升级成派单硬闸门（比旧版强），却又没有给这个新硬闸门任何身份证明；这是 §4 P0-2 的核心。

### 2.3 旧版派单/回执/锁的真实行为

- `send --ack`：`cmdSend` 写 `派单锁.json`，并 `DshClient.prompt(sessionId, ...)` 唤醒收件角色（除非 `--no-wake`）。
- 收件角色自己 `boot → inbox → read → ack`；`ack` 清同 id 锁，并给发件人发 `receipt` 回执。
- 未回执时下一次 PM 派单返回 `PM_DISPATCH_PENDING`；旧版没有 10 分钟 TTL（TTL 是新壳加的本地语义）。
- 旧 UI 没有“收件箱”面板；未读只在终端简报里，回执只在看板第 4 节。

---

## 3. 新壳当前流程映射（谁执行）

| 阶段 | 新壳 IPC / 函数 | 底层调用 | 实际执行者 |
|---|---|---|---|
| 建项目 | `project:create` → `createProject` | `teamTools.ensureProjectReady` → 旧 `workspace ensure` + 结构/索引 | 壳 |
| 建团队 | `dsh:provision` → `provisionTeamSessions` | 旧 `launch.mjs`（按标题复用/补建） | 壳 + DSH |
| 需求 | `requirement:create` → `createRequirement()` | 旧 `req create` | 壳持产品/需求角色令牌 |
| 评审 | `requirement:review` → `reviewRequirement()` | 旧 `req review`（**不存在**） | 壳 |
| Owner 评审 | `requirement:owner` → `ownerRequirementDecision()` | 旧 `owner`（**不存在**） | 壳 |
| 派单 | `requirement:dispatch` → `dispatchRequirement()` | 旧 `task create` + 旧 `send --no-wake` | 壳 |
| 开发提交 | `dev:submit` → `devSubmit()` | 旧 `propose`（`allowMissingSession:true`） | 壳 |
| 互审 | `dev:review` → `devReview()` | 旧 `show` + `review`（`allowMissingSession:true`） | 壳 |
| PM 签字/apply | `dev:apply` → `devApply()` | 旧 `show+review+sign+apply`（全 PM，`allowMissingSession:true`） | 壳 |
| 测试 | `test:dispatch` → `dispatchTest()` | 旧 `task create` + `send --no-wake` | 壳 |
| Owner 验收 | `owner:accept` → `ownerAccept()` | 本地 `工作流.json` + 旧 `task done`（PM）+ `owner-note.mjs` | 壳 |
| 迭代/终止 | `workflow:iterate` / `workflow:terminate` | 旧 `workflow`（**不存在**） | 壳 |
| 通信 | `team:send/inbox/read/ack` | 旧 `send/inbox/read/ack` | 壳持角色会话身份，`actor=workbench-shell` |
| 看板 | `team:board` / `team:board-old` | 旧 `board` | 壳 |
| 收口 | `team:reconcile` | 本机 `reconcileProjectCommStates`，**不是**旧 `team.mjs reconcile` | 壳 |

**关键事实**：除 `team:send/inbox/read/ack` 会核验角色会话外，工作流侧的需求/评审/派单/开发/互审/签字/测试/验收都不要求角色会话在线。`legacyRoleContext` 的注释写明“工作流编排只要求名册与 boot 令牌，不要求 DSH 会话在线”；调用方用 `allowMissingSession: true` 显式放宽。也就是说：**六角色可以全不在线，工作台一个人点完整个流程。**

---

## 4. P0（当前快照上直接阻断主链 / 直接击穿闸门）

### P0-1（阻断主链）把旧工具不存在的三条命令设成硬前置，需求评审/Owner/迭代终止全部锁死

**证据**

- 旧 `team.mjs` 的 `NOT_IMPLEMENTED_COMMANDS` 明确列出：
  - `workflow`：项目工作流（工作流.json 阶段机 / ownerReview 记录）
  - `owner`：Owner 审批通道命令（终端批准请用 `owner-approve`）
  - 并在 help 里写“`workflow · owner · req review` 当前版本没有实现，调用会返回 `NOT_IMPLEMENTED`”。
- 旧 `ops.mjs` `cmdReq` 对 `sub === 'review'` 直接 `fail('NOT_IMPLEMENTED', …)`，只支持 `req create/list/show`。
- 新 `src/team-tools.js` 的 `legacyCapabilities()` 只从 `team.mjs` 的 `case` 和 `ops.mjs` 的子命令探测能力。S12 实测（只读）：

```json
{
  "available": true,
  "commands": { "workflow": false, "owner": false, "reqReview": false },
  "missing": ["workflow", "owner", "req review"]
}
```

- 新壳在写入任何状态之前就 `requireLegacyCommand(...)`：
  - `reviewRequirement()`：`const commandGuard = requireLegacyCommand('req review'); if (commandGuard) return ...`
  - `ownerRequirementDecision()`：`requireLegacyCommand('owner')`
  - `iterateWorkflow()` / `terminateWorkflow()`：`requireLegacyCommand('workflow')`
- `runLegacyWorkflowProtocol()` 对 `owner` 直接拼 `team.mjs owner …`，对 `req review` 拼 `team.mjs req review …`；即使能力探测被绕过，实际 CLI 也会返回 `NOT_IMPLEMENTED`。

**后果**

`createRequirement()` 可以成功，但紧接着的产品评审必定返回 `LEGACY_PROTOCOL_REQUIRED`；Owner 闸门不可达；派单不可达；迭代/终止不可达。新壳的 UI 能力卡会显示“缺 3 条旧命令”，但按钮仍然可点，点完只得到错误码。**旧版完整流程在新壳上到第 2 步就断了。**

**这不是“旧版有、新壳没补”，而是方向错了：** 旧版本来就没有这三条 CLI 命令；旧版的产品评审走提案 `review`，Owner 走 `workflow:owner` 文件记录，迭代/终止是旧壳阶段机的新概念。新壳要求旧 CLI 提供它们，等于要求旧引擎为壳补功能。

**建议（按负担从低到高）**

1. **首选**：把这三步明确实现为“工作流文件契约”，而不是旧命令：
   - `protocol: 'workflow-file'` + `contractVersion` + `actor` + 输入哈希；
   - 评审/ Owner 决定/迭代/终止写 `工作流.json`，并在返回值/UI 明确标“文件契约，不是旧命令”；
   - 仍然做状态机校验（前置阶段、产品评审、Owner 决定、任务收口），只是不伪造 `team.mjs` 成功。
2. 或者在**新仓自己的** `团队/工具` 里真正实现 `req review` / `owner` / `workflow` 子命令（新代码、新测试、更新能力探测）；这会增加引擎负担，且与“旧工具只读”边界冲突，需单独评估。
3. 无论选哪条，先加发布断言：`legacyCapabilities().missing` 不能包含主流程必需命令；如果包含，UI 必须禁用对应按钮并说明“当前快照不可完成”，不能只让用户点出错误。

### P0-2（闸门失真）Owner 评审/验收没有身份，`by:'Owner'` 是调用方自称

**证据**

- `team-tools.js` `ownerRequirementDecision()` 只做字符串判断：`const role = String(input.role || '').trim(); if (role !== 'owner') return failure('ROLE_NOT_ALLOWED', ...)`。没有 session、nonce、签名、TTY。
- `main.js` `requirement:owner` 直接 `role: String(p.role || 'owner')`，即**不传也是 Owner**。
- `ownerAccept()` 同样只判断字符串：`role = input.role || 'owner'`；`main.js` `owner:accept` 也 `role: String(p.role || 'owner')`。
- `ownerRequirementDecision()` 落盘写死 `row.ownerReview = { status, by: 'Owner', ... }`；`ownerAccept()` 写 `by: role`（`iterate/terminate` 时可能是 pm）。
- 旧版唯一有身份的是**提案级** `owner-approve`：`cmdOwnerApprove` 要求 `process.stdin.isTTY && process.stdout.isTTY`，输入「批准 P-…」，并用 `signatureDigest` 绑定提案哈希；新壳没有等价入口（`team-tools.js` 中 `owner-approve` 0 次，能力里也没有）。
- 旧版需求级 Owner 评审也只是 PM 记录，没有强身份；但新壳把它升级成**派单硬闸门**并写 `by:'Owner'`，就必须给出与“硬闸门”匹配的证明，否则这个闸门只是 UI 文案。

**后果**

任何能执行渲染层代码/调用 preload 的人，都能把需求标成 Owner 通过、把测试标成 Owner 验收；审计账本上的 `by:'Owner'` 不能证明 Owner 本人做过决定。对一个把“Owner 闸门”写进流程的工作台，这是 P0。

**建议**

- 增加 `OWNER_IDENTITY_REQUIRED`：`requirement:owner` / `owner:accept` 必须携带一次性 nonce、Owner 本地凭据或终端确认结果；`by` 只能由主进程解析，不能由调用方传。
- 桌面壳里可用的最低成本方案：主进程生成一次性 nonce 写入仅当前用户可读的文件/环境，Owner 在终端或系统凭据框确认；不要把“弹窗点一下”当身份。
- 在身份未落地前，UI 应把这两个入口标成“记录 Owner 意见（非身份认证）”，不要显示“Owner 已通过/已验收”。

---

## 5. P1（主链修通后立刻遇到，或已经造成语义/审计偏差）

### P1-1 工作流派单不唤醒、不写回执锁，PM 可以连派多单

**证据**

- `sendWorkflowNotice()` 固定拼 `send … --no-wake`，且从不传 `--ack`。它被 `dispatchRequirement()` 和 `dispatchTest()` 复用。
- 旧 `cmdSend` 只有在 `--ack` 时才写 `派单锁.json`；旧版靠这把锁实现“一次一个、未回执不派下一个”。
- 手工派单 `sendDispatch()` 反而是对的：默认 `--ack`，返回 `wakeText`；`main.js team:send` 会 `dsh.prompt` 唤醒收件会话，并在失败时释放本地锁和旧锁。
- 结果：团队台“团队派单”走的是有锁有唤醒的路径；旧流程页的“PM 派发开发任务/测试任务”走的是无锁无唤醒的另一条路径。同一产品里两套派单语义。

**后果**

工作流派单只落邮箱；空闲角色不会醒；PM 连续派多人不会触发 `PM_DISPATCH_PENDING`。UI 显示“已派发”，实际没人处理。旧版的“派单锁 + 回执”闸门在 workflow 路径上不存在。

**建议**

工作流派单复用 `sendDispatch()`（`ackRequired:true`），由主进程 `dsh.prompt`；把 `wake`/`ack`/`lock` 结果写回 `工作流.json` 的 `dispatch` 字段和 UI。若产品坚持“工作流派单只通知不唤醒”，必须在界面明确标“未唤醒/未加锁，不参与旧派单闸门”，不能默认显示成旧流程成功。

### P1-2 互审/签字/apply 由壳一口气代跑，没有角色会话或人的证明

**证据**

- `devSubmit()` 调 `legacyProposalAction({ …, allowMissingSession: true })`。
- `devReview()` 连续调 `show` + `review`，两次都 `allowMissingSession: true`。
- `devApply()` 一次调用里连续 `show → review → sign → apply`，全部以 `role: 'pm'`，全部 `allowMissingSession: true`。
- `legacyRoleContext()` 的注释明确：“工作流编排（需求/任务/提案）只要求团队名册与 boot 令牌，不要求 DSH 会话在线；只有调用方显式允许时才放宽。”
- 旧版 `propose/review/sign/apply` 是四个角色动作；`apply` 必须 PM，`show` 是 `review` 前置，`sign` 绑定提案哈希。新壳把“PM 复核”折叠成一个按钮，且不要求 PM 会话。

**后果**

“互审”和“PM 签字”在审计上等于“点击者替这两个角色做了”；角色会话可以完全不在线。旧版的“另一名程序员互审”“PM 看过才签”没有被真正执行。`allowMissingSession: true` 让跨项目/冒写的会话校验也失效（普通 `proposal:legacy` 仍要求真实会话，工作流路径反而更松）。

**建议**

- `devReview`/`devApply` 必须绑定对应角色的真实会话（复用 `proposal:legacy` 的 `verifyProjectRoleSession`），或携带一次性角色签名 nonce；壳只转发，不代跑。
- 至少把 `actor: 'workbench-shell'` 写进评审/签字/apply 记录和 UI，让审计能区分“角色本人”与“壳代跑”。
- 把 `devApply` 拆成 `show/review/sign/apply` 四个确认步骤，或在一次点击前展示 `proposalHash`、必需签字人、当前签字状态。

### P1-3 boot 先补模板再放行：缺文档不再报错，占位符可以通过“每轮必读”

**证据**

- `bootRole()` 在 `readBootDocs()` 之前先 `await ensureProjectStructure(...)`。
- `ensureProjectStructure()` 会创建：
  - `项目信息.md`（`projectInfoTemplate`，正文是“（待项目经理填写）/（待填写）”）；
  - `需求/00-需求总览.md`（空表头）；
  - 六角色目录、`角色卡.md`、`文件索引.md`、`产出/`；
  - `src/`、`_tmp/`、`需求/`；
  - 缺 `项目铁律.md` 时从团队根复制。
- `readBootDocs()` 随后读到这些刚生成的文件，`bootRole()` 记录 `complete:true`；`requireWorkflowBoot()` 后续信任它。
- 旧 `store.readDocSet` 对缺失的必读文件是硬 `MISSING_DOC` 拒绝，不会先补。
- 真实例子：`项目/六人敏捷工作区` 当前缺 `项目信息.md`、`项目铁律.md`、`需求/00-需求总览.md`；`项目/团队工作台改造` 缺 `项目信息.md`、`需求/00-需求总览.md`。在新壳里点一次 boot 就会生成模板并“读全”，而不是报缺文档。

**后果**

“每轮先读铁律 → 项目信息 → 角色卡 → 索引”的闸门，可以被壳自己刚写的占位符满足；新项目/老项目的空模板都能通过 boot 和产品评审。旧版“缺文档不能开工”的硬失败被降级成“自动补模板”。

**建议**

- 把 `ensureProjectStructure`（创建/恢复时补齐）与 `bootRole`（阅读闸门）分开：**boot 不补必读文档**，缺了返回 `MISSING_DOC` + 修复入口。
- 在 boot 简报和 `requireWorkflowBoot` 里检测占位符（`（待…填写）`、空表头、只有标题的 `R-*.md`），关键闸门（产品评审、Owner 放行）拒绝“正文仍是模板”的需求。
- 对真实老项目（`六人敏捷工作区`、`团队工作台改造`）明确标“结构不齐/需补文档”，不要用自动模板伪装成已读。

### P1-4 两套 Owner 闸门互不相通：界面“Owner 通过”推不动派单

**证据**

- 顶层 Owner 弹窗 `openOwnerModal()` 调 `window.workbench.ownerDecide({ projectId, status, opinion })` → `owner:decide` / `workflow:owner` → 本地 `ownerDecide()`，写 `project.ownerReview`；`recordOwnerDecision()` / `writeOwnerWorkflow()` 只改 `工作流.json` 的**顶层** `ownerReview`，不碰任何需求的 `requirements[id].ownerReview`。
- 派单检查的是**需求级**字段：`dispatchRequirement()` 里 `if (!meta.ownerReview || !['approved','skipped'].includes(...)) return failure('OWNER_REVIEW_REQUIRED', ...)`。
- 需求级入口是另一个函数 `ownerRequirementDecision()`，界面在“旧流程”页签的 `owner-review` 动作（`requirement:owner`），不是顶栏那个 Owner 弹窗。
- 顶栏 Owner 弹窗 `closable: true`，注释还明确写“Owner 不自动弹窗”；旧壳是 `closable:false` + 按 `roundKey` 去重的自动弹窗。

**后果**

用户点最显眼的“Owner 评审”通过，界面显示“本轮 Owner 已通过”，但 PM 派单仍然 `OWNER_REVIEW_REQUIRED`；用户会认为按钮坏了。反过来，只走需求级入口时，顶栏 Owner 状态又可能是另一套。两套字段、两套后果。

**建议**

- 只保留一个 Owner 闸门：`owner:decide` 改为必须带 `requirementId` 并写需求级；或删掉顶栏入口，只留“旧流程”页签的需求级 Owner 动作。
- 如果保留项目级 Owner 状态，明确标注“本项目级备注，不参与派单”，并在 UI 上不要把“通过”渲染成需求已放行。
- 旧版的自动弹窗是过程提醒，不是身份；不建议为了“逐像素”恢复自动弹窗，优先把两套状态合并。

### P1-5 敏感/关键提案没有 Owner TTY 签字通道，选高 risk 会卡死在 apply

**证据**

- 旧 `requiredSets()`：
  - `normal`：至少 1 个非作者评审；签字人 = PM（作者是 PM 时取另一人）。
  - `sensitive` / `critical`：评审人 = 所有其他角色；签字人 = 所有角色 + `owner`。
- 旧 `checkApprovals()` 对 `owner` 签字额外要求 `channel === 'tty'`，否则 `OWNER_CHANNEL`。
- 新 `devSubmit()` 把 UI 选择的 `risk` 原样传给旧 `propose`；UI 的 dev-submit 表单提供 `normal/sensitive/critical` 三档。
- 新 `devApply()` 只以 PM 身份 `review + sign`，没有 `owner-approve` 桥，也没有其他角色签字收集；`team-tools.js` 中 `owner-approve` 0 次。
- 结果：normal 提案可以走通；sensitive/critical 提案在 `apply` 时会被旧 `checkApprovals` 判 `APPROVALS_INCOMPLETE` / `MISSING_SIGNATURE owner`，而新壳没有 UI 路径补齐。

**后果**

高风险提案无法闭环。用户越按旧流程选“敏感/关键”，越走不完；这是“安全流程”反而被安全流程卡死。

**建议**

- 在完整多签实现前，UI 只允许 `normal`，并明确说明“sensitive/critical 需旧终端 owner-approve，当前未接入”。
- 或增加 `owner-approve` 桥：Electron 无法提供 TTY 时，至少给出手工终端命令 + 回填签名文件的流程；同时补齐其他角色签字。
- 提案详情展示 `requiredSigners` 和每个角色的 review/sign 状态，避免用户点到最后才发现缺谁。

### P1-6 需求创建不要求角色 boot，壳自己 mint 令牌

**证据**

- `createRequirement()` 只检查 `role` 是否在 `['product','analyst']`（Owner 新需求走 pm），没有 `requireWorkflowBoot(...)`。
- 它调用 `runLegacyCommand(projectName, role, 'req create', …)`；`runLegacyCommand → withBootToken → bootToken` 会在需要时**自己跑一次 `team.mjs boot`**拿令牌。
- 旧 `req create` 要求 `--boot`，但旧流程默认角色已经先 boot；新壳把这个前置变成了“壳替你 boot”。

**后果**

需求是流程的第一个写动作，却可以在没有任何角色阅读证据的情况下创建；再叠加 P1-3 的自动模板，第一条需求可以在空项目上直接产生。`boot` 闸门对“创建需求”不生效。

**建议**

- `createRequirement` 先 `requireWorkflowBoot(role)`；如果产品/需求还没 boot，返回 `BOOT_REQUIRED`，由 UI 引导先读。
- 如果产品坚持“PM 可以代建需求”，至少把 `actor` 写成 `workbench-shell`，不要把它显示成角色已读。

### P1-7 收口没有旧版 `reconcile/verify/pilot` 健康闸门，真实现状未被界面暴露

**证据**

- 旧 `cmdReconcile()` 会写 `对账.json/对账.md`，清理 stale lock，检查事件链、任务逾期、提案超时、产物漂移、回执、授权过期、`verify` 总体。
- 旧 `cmdVerify()` 只读检查 proposal hash/commit/approvals/artifact drift；`cmdPilot()` 五项：回执、提案闭环、STALE_BASE、LOCK_BUSY、verify 全绿。
- 旧 `团队/运行手册.md` 收尾顺序是 `reconcile → verify → pilot → board`。
- 新壳 `team:reconcile` 只调用 `reconcileProjectCommStates()`（本机消息/唤醒/已读/回执状态），**没有调用旧 `team.mjs reconcile`**；没有 `verify`/`pilot` 的 IPC/按钮。
- S12 只读实测：`team.mjs verify` = ❌ FAIL，6 个项目 / 1215 事件 / **9 个问题 / 0 警告**；9 条全部是幽灵项目 `个人简历展示项目` 的缺失产物。`team.mjs doctor` = ✅；`team.mjs pilot` = FAIL（verify 9 个问题）。`团队/状态/团队.json.activeProject = 微光作品集`，已不是 QA11 时的幽灵项目。

**后果**

“收口”没有旧版的健康证据；stale lock、超时提案、产物漂移、事件链问题都不会在界面出现。用户可以在 `verify` 仍是 FAIL 的情况下点“验收通过/下一轮”。旧版的“verify 全绿才收口”没有被新壳继承。

**建议**

- 在“旧流程”页签加一个只读“健康检查”卡：调 `team.mjs verify` 和 `pilot`（只读），展示问题数/明细；不要自动修。
- `reconcile` 若要保留旧语义，显式调用旧 `team.mjs reconcile`（它会写对账文件），并显示写入路径；不要用本机通信对账冒充旧对账。
- 收口/下一轮按钮在 `verify` 非绿时给出明确警告，但不一定要硬阻断（避免又造一个“按钮坏了”）。

### P1-8 propose 授权被自动补发，PM 的 grant 闸门被绕过

**证据**

- 旧 `cmdPropose` 对每个目标文件检查 `hasGrant(role,'propose',project,rel)`，没有就 `NO_GRANT`，要求 PM `grant` 具体 scope。
- 新 `devSubmit()` 在 propose 前调用 `ensureProposeGrant()`：如果缺授权，直接用 PM 身份跑 `team.mjs grant --actions propose --scope <目标目录>/** --expires 7d`，reason 写“工作流开发提交自动授权（PM 代办）”。
- 新壳没有 `grant list/revoke` 的 UI/IPC；`grant` 只在这个自动路径里出现。

**后果**

“PM 只给需要的目录授权”的旧治理被改成“程序员一提案，壳就替他向 PM 申请并批准”。虽然 scope 是按目标目录算的、也写了授权文件，但 PM 没有实际决策；授权过期/撤销也没有界面。

**建议**

- 保留 `ensureProposeGrant` 作为“缺授权时返回 `NO_GRANT` + 一键申请”的辅助，不要自动批准；或在 UI 明确显示“壳已代 PM 授权”并给出 scope/期限。
- 增加只读的授权列表（至少 `grant list` 的展示），让 PM 能看到谁在什么范围、何时过期；revoke 可后置。

---

## 6. P2（不阻断主链，但会造成第二真相、误导或维护负担）

### P2-1 团队项目的“任务”页仍是本地装饰，`MIRROR_ONLY` 不在界面解释

- `syncWorkbenchBoard()` 现在固定返回 `{ ok:true, code:'MIRROR_ONLY', skipped:true, direction:'none', truthSource:'legacy-workflow' }`；真正的旧写实现 `syncWorkbenchBoardLegacyWrite()` 没有调用点，是死代码。
- 但 `task:create/update/delete` 仍然只写 `workbench.json`，然后 `mirrorToTeamBoard()`，照常返回 `{ok:true}`；`publicProject` 把本地 `tasks` 原样给界面。
- `app.js` 中没有 `MIRROR_ONLY` 的提示；用户新建/改状态/删除任务一路成功，旧看板、旧 `任务/`、任何角色都看不到。

**建议**：团队项目登记后把任务页改成只读旧任务，或所有任务统一走 `task create/claim/done`；至少对 `MIRROR_ONLY` 显示“只写本机，角色看不到”，并删掉死函数。

### P2-2 没有 `workflow:changed` 文件监听，旧版流程浮窗的实时高亮没了

- 旧壳 `startFlowWatch()` 用 `fs.watch` + 220ms 去抖，`工作流.json` 变化时推送 `workflow:changed`，旧 preload 有 `onWorkflow`。
- 新仓 `main.js` / `preload.js` / `app.js` 中 `workflow:changed`、`onWorkflow`、`fs.watch` 均为 0 命中；只有手动刷新和 30 秒缓存。
- 角色在 DSH 里自己推进后，工作台界面不会自动更新，除非用户点刷新/重新打开。

**建议**：加一个只读的 `fs.watch`（或 2–3 秒轮询）推送 `workflow:changed`；如果不想做，至少在流程页标“手动刷新”。

### P2-3 旧流程 10 节点被压成 7 节点，Owner/接单节点没有独立位置

- 旧壳 `index.html` 是 10 个节点：PM 接单、需求分析师、产品设计师、Owner 评审、PM 派发、开发 A/B、互审/对账、测试、PM 收口、迭代。
- 新 `app.js` `LEGACY_FLOW_STEPS` 只有 7 个：需求、产品评审、PM 派单、开发互审、测试、Owner 验收、迭代/终止；`LEGACY_PHASE_INDEX` 把 `owner_review` 映射到“产品评审”节点，只在 small 文案里写“Owner 待选择”。
- 这不是必须逐像素恢复；但当前“Owner 评审”在图上没有一个独立节点，和 P1-4 的两套闸门叠加时更难理解。

**建议**：不恢复 10 个节点也可以；至少给“产品评审”节点加 `owner_review` 子状态徽标，或在图例中单独标 Owner 阶段。不要为了像素对齐再加一套重复入口。

### P2-4 死接口与零引用桥

- `team:proposal-legacy` 有 handler（`main.js` `legacyProposalHandler` 注册两次），但 preload 只转发 `proposal:legacy`，没有任何桥能到达 `team:proposal-legacy`。
- `app.js` 零引用的 preload 方法（S12 检索）：`teamLaunch`、`teamOpenProject`、`teamWorkspaceCreate`、`teamBoardProject`、`teamComm`、`workflowOwner`。
- 其中 `teamComm` 的数据已由 `state` 的 `message.comm` 提供；`workflowOwner` 已被 `owner:decide` / `requirement:owner` 取代。其余是旧入口/未接线的桥。

**建议**：删掉 `team:proposal-legacy` 或统一改名；对零引用桥逐个决定“补界面”还是“删掉”，在 preload 注释写保留原因。

### P2-5 创建项目仍建空的 `src/`，模板却写代码目录是 `site/`

- `ensureProjectStructure()` 创建 `['src','_tmp','需求']`；同一函数写的 `项目信息.md` 模板写 `- 代码目录：site/`，`协作准则.md` / 角色卡也只提角色目录/`site/**`。
- 新项目/老项目 boot 时会多出一个没人用的空 `src/`；程序员按项目信息写 `site/`，索引/授权/验收也按 `site/`。

**建议**：删掉 `src/` 的创建，或把模板改成 `src/`；只保留一个代码目录常量，创建/模板/索引/授权共用。

### P2-6 调试收件箱默认包含 `cur`，与旧 `inbox` 默认口径不同

- 旧 `cmdInbox` 默认只列 `new/`，`--all` 才含 `cur/`。
- 新 `team:inbox` 里 `const all = p.all !== false;`，`inboxFor()` 里 `includeAll = input.all !== false`，即默认 `--all`。
- 收件箱本身是折叠的“旧版没有此面板”调试入口，影响有限；但“未读”数字会被已读邮件抬高。

**建议**：默认 `all:false`，UI 想显示全部时显式传 `all:true`；或在标签上写清“含已读”。

### P2-7 老项目发现/登记仍有幽灵与结构不齐，`项目清单.md` 是旧路径

见 §7；这里只记代码侧：`project:discover` 只收 `项目信息.md` 存在的目录，所以缺 info 的老项目不会出现在“恢复”扫描里；`readTeamRegistrations()` 可以把登记过的项目补进来，但幽灵登记也会被带进来。

**建议**：发现列表同时标 `hasInfo / registered / structureOk`，让用户看到“缺项目信息”的原因；不要自动生成模板后静默当健康项目。

### P2-8 `workflow:boot` 记录 sessionId 但不核验会话

- `workflow:boot` → `teamTools.bootRole(..., { sessionId: meta.sessionId })`；`bootRole` 把 `sessionId` 原样写进 `bootRead`，但没有 `verifyProjectRoleSession()`。
- 与 `team:send/inbox/read/ack` 的严格会话核验相比，boot 记录可以被一个已归档/别的项目的 sessionId 冒充。

**建议**：boot 也复用 `verifyProjectRoleSession`；如果 DSH 离线，至少标 `sessionVerified:false`，不要把 sessionId 当已核验。

---

## 7. 老工作台的项目发现（补充要求）

### 7.1 实际发现

旧仓 `D:\deepseek\工作台\项目` 与新仓 `D:\deepseek\agile-workbench\项目` 都有这 5 个目录，文件数基本一致：

| 项目 | 旧文件数 | 新文件数 | `项目信息.md` | `项目铁律.md` | `需求/00-需求总览.md` | 判定 |
|---|---:|---:|---|---|---|---|
| 微光作品集 | 31 | 33 | ✅ | ✅ | ✅ | 完整，可作为演示样本 |
| 测试工作台项目 | 25 | 25 | ✅ | ✅ | ✅ | 完整 |
| 六人敏捷工作区 | 21 | 21 | ❌ | ❌ | ❌ | 老项目本身结构不齐；新壳 boot 会补模板后放行（见 P1-3） |
| 团队工作台改造 | 10 | 10 | ❌ | ✅ | ❌ | 同上 |
| 小鱼 | 1 | 1 | ❌ | ❌ | ❌ | 只有 `项目索引.md`，不像工作台项目；**不要硬加** |

结论：**老工作台的项目并没有“丢”**；五个目录都在。真正的问题是结构完整性和登记卫生，不是缺功能。

### 7.2 登记卫生（只读实测）

- `团队/状态/团队.json.activeProject = 微光作品集`（目录存在，已不再是 QA11 的幽灵 `个人简历展示项目`）。
- `团队/状态/项目/` 登记 6 个，其中 `个人博客项目`、`个人简历展示项目` 的目录**不存在**；`个人简历展示项目` 还留有任务/提案/提交产物，导致 `verify` 的 9 条 MISSING 全部指向它。
- `项目/项目清单.md` 仍只列 `演示项目`、`示例项目·个人站`，索引路径写的是 `D:\deepseek\工作台\项目\...`，与实际项目不符；这是旧文件复制过来的陈旧索引，不应作为发现来源。
- `project:discover` 只收有 `项目信息.md` 的目录：微光、测试工作台项目会被扫到；六人敏捷工作区、团队工作台改造靠团队登记补；小鱼完全不会出现（这反而是对的，除非确认它是项目）。

### 7.3 建议（不增加功能负担）

1. 清掉两个幽灵登记（或标 `archived`），不要让 `verify/pilot` 永远 FAIL。
2. 对 `六人敏捷工作区`、`团队工作台改造` 做一次显式“补文档/标归档”决定；不要用 boot 自动模板伪装成健康。
3. 把 `项目清单.md` 改成生成物或删掉；发现列表以 `project:discover` 的实际结果为准。
4. `小鱼` 没有 `项目信息.md`，也没有六角色结构；如果它不是工作台项目，不要为了“凑数”硬加。

---

## 8. 旧版有、但不建议硬补的功能

用户已经说明“旧版不一定全对，没有就没有，不要硬加功能”。以下功能在旧壳里存在，但不在团队主流程，或与当前 DSH 主画面重复；建议**不补**或只保留入口说明：

| 旧版功能 | 旧版落点 | 为什么建议不补 |
|---|---|---|
| 场景栏 / 场景页签 / 场景网格 / `scene:context` | 旧 `index.html` `#scenebar`/`#scenario-tabs`/`#scenario-view`；`main.js` `scene:context`；`renderer/app.js` `renderTabs/selectScenario` | 当前 DSH WebView 就是主画面；场景体系是旧壳自己的页面容器，硬搬会多一层导航和第二真相 |
| 协作台面板（`协作/state.json` 的“最近回执流水”） | 旧 `app.js` `renderCollabPanel`；`main.js` `collab:state` | 数据源与团队 `回执.jsonl` 不同；补了会让人分不清哪个回执算数 |
| WebAI 条 / DeepSeek 余额 | 旧 `#webai-strip`、`#balance-chip`；`main.js` `webai:open` / `app:balance` | 外部服务入口，不是团队流程；涉及密钥/计费，不适合塞进开源壳 |
| 检查更新 / 工作台体检 / 初始化记忆模板 / 窗口序号 / 扩展组（插件/技能/MCP/工具） | 旧 `#tb-more-panel`；`main.js` `app:updateCheck` / `workbench:health` / `mem:inject` | 运维/个人偏好，和六角色流程无关；当前 `verify` 卡更值得做 |
| 旧版 10 节点 / 7 条边的逐像素流程 | 旧 `index.html` 91–111；旧 `app.js` `order` | 节点数量不是语义；当前 7 节点已覆盖主阶段，补回 10 节点只会增加维护面。需要的是 Owner 子状态，不是多两个盒子 |
| 旧版收件箱（其实旧 UI 没有） | 旧 UI 0 命中；新壳自己加了 `#inbox-block` | 旧版没有；新壳已折叠成“调试”，保持折叠即可，不要扩成主界面 |
| Owner 自动弹窗 | 旧 `app.js` `maybeOwnerReview` / `closable:false` | 自动弹窗是过程提醒，不是身份；当前更该修“两套 Owner 闸门”，而不是恢复一个会打扰人的弹窗 |

**可以补的小项**（低成本、直接服务旧流程）：
- 只读 `verify/pilot` 健康卡（见 P1-7）。
- 提案 `requiredSigners` / 签字状态展示（见 P1-5）。
- 授权列表只读展示（见 P1-8）。
- 任务页 `MIRROR_ONLY` 提示（见 P2-1）。
- `workflow:changed` 轻量监听（见 P2-2）。

---

## 9. 复核命令与验收断言

### 9.1 先确认快照/能力

```powershell
cd D:\deepseek\agile-workbench
node -e "const t=require('./src/team-tools.js'); console.log(JSON.stringify({missing:t.legacyCapabilities().missing,commands:t.legacyCapabilities().commands},null,2))"
```

**当前期望（S12）**：`missing` 含 `["workflow","owner","req review"]`。  
**主链可用的最低条件**：`missing` 不含这三条，或者这三步有显式的 `workflow-file` 契约实现（不能是假成功）。

```powershell
node 团队\工具\team.mjs verify
node 团队\工具\team.mjs doctor
node 团队\工具\team.mjs pilot
```

S12 实测：`verify` ❌（9 问题，全在幽灵 `个人简历展示项目`）；`doctor` ✅；`pilot` FAIL（verify 9）。

### 9.2 建议进 selftest 的断言

1. **主链贯通**：沙盘项目 `createRequirement → reviewRequirement(approve) → ownerRequirementDecision(approved) → dispatchRequirement → claim → devSubmit → devReview → devApply → dispatchTest → taskDone → ownerAccept(accepted)` 全部 `ok:true`，且没有 `LEGACY_PROTOCOL_REQUIRED`。
2. **Owner 身份负例**：不带 nonce/凭据调用 `requirement:owner` / `owner:accept` 必须 `OWNER_IDENTITY_REQUIRED`；只有带合法证明才成功，`by` 由主进程解析。
3. **派单锁/唤醒**：工作流派单必须生成 `派单锁.json`，调用一次 `dsh.prompt`；第二次派单必须 `PM_DISPATCH_PENDING`。
4. **互审会话**：`devReview` / `devApply` 在角色无会话时必须 `SESSION_ID_REQUIRED`；不允许 `allowMissingSession:true`。
5. **boot 缺文档**：删掉 `项目信息.md` 后 boot 必须 `MISSING_DOC`，不能自动生成后 `complete:true`。
6. **boot 隔离**：新增一条不相关需求后，已 boot 的角色对在途需求的 `requireWorkflowBoot` 仍然通过；不能全员 `RULES_CHANGED`。
7. **高风险提案**：`sensitive/critical` 的 apply 要么被 UI 阻止并说明，要么能收集全签字 + Owner TTY 证明；不能只报 `APPROVALS_INCOMPLETE`。
8. **收口健康**：`verify` 非绿时，收口/下一轮按钮显示明确警告；`pilot` FAIL 不能被显示成成功。
9. **任务镜像**：团队项目本地任务 CRUD 若仍是 `MIRROR_ONLY`，界面必须显示“角色看不到”；否则应改走旧 `task` 命令。
10. **接口卫生**：preload 暴露的方法在 `app.js` 至少有一个调用点；`team:proposal-legacy` 要么可到达，要么删除。

### 9.3 复验时不要做的事

- 不要跑 `npm run selftest` 来做“只读”审计：它会启动 Electron、写沙盘/截图/状态；本轮没有跑。
- 不要为了让流程通过而在 `团队/状态` 里手写 `工作流.json` 或伪造 `owner` 决定；这会把“P0 阻断”变成“假成功”，下一轮更难查。
- 不要用旧行号直接下结论；源码在动时按函数名/IPC 名重验。

---

## 10. 只读边界与副作用

- **新增文件**：仅 `docs/PARITY-ROUND12.md`。
- **只读命令**：`team.mjs verify`、`team.mjs doctor`、`team.mjs pilot`、`legacyCapabilities()` 能力探测；均为只读，不写团队状态、不启动 DSH。
- **未执行**：Electron、`npm run check`/`selftest`、任何真实 DSH `session/prompt`、任何会写团队状态的 `boot/send/ack/task/propose/apply`。
- **未修改**：`src/**`、`package.json`、`团队/**`、`项目/**`、`userdata-*`、`D:\deepseek\工作台\**`、`D:\deepseek\luanyujia-workbench\**`。
- **副作用说明**：审计期间旧仓 `团队/工具/lib/ops.mjs`（15:36:41）、`team.mjs`（15:36:53）、`workspace.mjs`（15:39:27）和新仓 `src/**`（15:39–15:43）被**其他进程**修改；本报告没有参与这些修改。若报告中的行号/行为与当前源码不符，以 §9 的函数/能力探测为准。
- **未验证/边界**：没有真实六角色 DSH 会话，所以“角色没有执行”是从 `allowMissingSession:true`、`--no-wake`、无 `dsh.prompt` 等代码路径推断的，不是运行时抓包；Owner 身份问题也没有实际利用，只做了源码路径判断。

---

## 11. 一句话总结

**S12 把“建项目、结构校验、boot 读文档、Owner 验收失败可见、终止收口任务”这些上一轮的问题修好了一部分，但把 `req review/owner/workflow` 三条旧工具从未实现的命令设成硬前置，导致完整流程在第 2 步就断；即使修通，Owner 身份、派单唤醒/锁、互审代跑、boot 模板放行、两套 Owner 闸门仍会让这条流程“看起来走了、实际没走”。**
