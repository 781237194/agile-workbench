# 第五轮 · 旧版功能/入口/状态流对齐审计（只读）

> 目标：以「旧项目最后一次跑通」为唯一基准，回答三件事——旧版当时到底有哪些功能/入口/状态流；新壳当前还缺什么；按 P0/P1/P2 排序，每条给出旧落点（文件/函数/选择器/IPC）与当前落点。
>
> 只读边界：未修改 `src/`、`package.json`、`团队/`、旧仓库；唯一写入是本文件。

---

## 0. 基准、快照与两个必须说明的事实

### 0.1 旧版基准

`D:\deepseek\luanyujia-workbench\12-源码照搬\外壳\`，`package.json` v1.1.0、Electron ^33；`main.js` 1,091 行 / 67,864 B，`renderer/app.js` 1,828 行 / 90,670 B，`renderer/index.html` 138 行。

“最后一次跑通”的运行证据（不是推测）：

| 证据 | 内容 |
|---|---|
| `外壳/main.log` 尾 | `2026-11-03T01:14:41 engine resolved http://127.0.0.1:52711/`、`2026-11-03T01:29:46 window-all-closed`；761 行日志中 `createWindow` 144 次、`engine resolved` 137 次、`restore done … sessions=6` 多次 |
| 自检产物 | `selftest*.png` 10 张，mtime `2026-11-03 08:15`，对应日志 `00:11–00:15Z` 那一轮 |
| 旧当前指针 | `工作台\团队\状态\当前工作区.json` → `个人简历展示项目`（该目录 09:11 后被移走），`dshWorkspaceId=a61f67bc…`、`engineUrl=http://127.0.0.1:52711` |
| 旧项目实物 | `工作台\项目\微光作品集`：`workspace.json`、`团队会话.json`（6 角色、标题 `团队·<角色>`、`model=deepseek-account/deepseek-flash`）、`协作准则.md`、`项目索引.md/.json`、`项目铁律.md`、六个角色目录 |
| 旧团队账本 | `工作台\团队\状态`：6 个项目登记、392 个邮箱文件、`回执.jsonl` 86 KB、`事件.jsonl` 779 KB、`阅读.jsonl` 42 KB |

**事实 1（口径更正）**：旧自检把 `SELFTEST_UI / SELFTEST_MENU / SELFTEST_SCENARIOS …` 打到 stdout，但**只打印、不中止**（`main.js:972-1085` 全在 `try` 里，断言为 false 仍会到 `SELFTEST_OK`）。且这份副本里已有过期断言：`design-misc` 场景、`api-preview` 面板、`data-act="newproj"`、`#btn-open-project`、`#btn-refresh`、`#rb-chip` 都不存在（`main.js:978-999` 仍去查）。所以：**基准就是这份 1.1.0 精简壳，不要拿“完整版想象”当对齐目标；它自身也有占位**（`pc-toplarge/pc-junk/pc-ledger` 是 `app.js:978-983` 的占位文案；`#flow-owner-state` 在 DOM 里不存在）。

**事实 2（源码在动）**：审计期间新仓库被并行重写。本文钉两个快照：

| 快照 | 时间 | `src/main.js` | `src/renderer/app.js` | `index.html` | `team-tools.js` |
|---|---|---|---|---|---|
| **S1**（前四轮文档基准） | 05:17 / 04:55 | 193,645 B · `2DD6C442…` | 120,780 B · `609E48F6…` | 26,360 B · `5268831D…` | 51,570 B · `B3599688…` |
| 中间态（写作中被并行重写） | 06:24–06:26 | — | 126,162→134,122 B | 30,061 B | 52,890→67,908 B |
| **S2**（本文定稿基准） | 06:28–06:36 | 209,816 B → 仍在长 | 163,176 B → 仍在长 | 30,061 B | 67,908 B |

**§3 的状态列以 S2 为准；凡 S1→S2 已修的，明确标“本轮已修”，避免重复排期。行号只在各自快照成立，复核以函数/选择器/IPC 名为准。**

---

## 1. 旧版最后跑通时的功能面（按层清点）

> `旧文件:行` 为旧副本行号；`选择器` 指 DOM id / data-*。

### A. 主画面与启动

| # | 功能/入口 | 旧落点 | 行为要点 |
|---|---|---|---|
| A1 | 首屏就是 DSH | `renderer/index.html:66` `#engine-view > #engine-webview`（`partition="persist:harness"`）；`app.js:17`、`:498 showView`、`:1402 loadEngine` | 项目只是场景页签，不是根页面 |
| A2 | 引擎自动发现 | `main.js:124 findEnginePorts`、`:139 resolveEngine`、`:158 ensureEngine`、`:163 app:config` | `tasklist` 找 PID + `netstat` 找端口；逐端口验 200 / `<base href="./">` / 长度 >20k；铸 cookie 写 `persist:harness` |
| A3 | 离线遮罩 + 重试 | `index.html:68 #engine-off`、`:73 #engine-retry`；`app.js:1402-1424` | 忽略 `ERR_ABORTED(-3)`；6 秒看门狗；URL 打码 token |
| A4 | 双次 reload | `app.js:138 reloadEngine`、`:143 refreshWorkspaceSoon`（700/1800ms） | 建工作区/打开/恢复/唤醒/刷新都调，解决“会话投影比页面晚到” |
| A5 | 窗口 | `main.js:952 createWindow`（1380×900、min 1000×660、`frame:false`、`webviewTag`）；`index.html:12` 双击最大化 | — |

### B. 顶栏 / 菜单 / 运维层

| # | 功能 | 旧落点 | 备注 |
|---|---|---|---|
| B1 | 12 个顶栏入口 | `index.html:17-36` | 看板/成员/＋工作区/建团队/恢复/刷新/文件夹/扩展组 4 键/⋯/窗口三键 |
| B2 | 负载胶囊 | `index.html:18 #tbs-load`；`app.js:451 tickLoad`（4s）；`main.js:53/70/87` | CPU 为**整机**采样；≥70 黄、≥90 红；title 带 GPU 显存 |
| B3 | 5 个网页 AI | `index.html:15 #webai-strip`；`app.js:403 SITES`、`:410 mountWebAi`；`main.js:934 openWebAi` | 每站点独立 `BrowserWindow` + 独立分区；再点是“收起”不是销毁；DeepSeek 与场景面板共用 `persist:embed-sr-site-bl` |
| B4 | 余额 + 状态点 | `index.html:59-61`；`app.js:428 tickBalance`（5min）、`:444 setStatus`；`main.js:787 app:balance` | 先本地网关 `:18990`，再回退直连 |
| B5 | ⋯ 菜单 12 项 | `index.html:37-50`；`app.js:1332-1397` | 主题/在线刷新/刷新场景页签/打开已有项目/按名恢复/看板/引导/窗口序号/版本/检查更新/体检/记忆模板 |
| B6 | 文件夹 chip | `app.js:1262-1317` | 工作区/DSH 根/场景目录 + 最近打开 8 个（`wb.recent`） |
| B7 | 工作台体检 | `main.js:304 workbench:health`；`app.js:1390` | 5 项检查 + 写 `工作台\体检\报告-*.md` 并打开 |
| B8 | 检查更新 | `main.js:830 app:updateCheck`；`app.js:1339`、`:1617` | 读 `update.json`（repo/feedUrl/requiredPlugins），版本比较，`source:'local'` 兜底 |
| B9 | 记忆模板注入 | `main.js:904 mem:inject`；`app.js:1362` | 点菜单才把 `记忆模板\*.md` 复制到 `<DSH根>\场景项目信息\<场景>\` |
| B10 | 主题 | `app.js:1459 applyTheme`、`:1468 restoreTheme` | 支持 `auto`（`prefers-color-scheme`），持久化 `wb.theme` |
| B11 | 窗口序号 | `app.js:1631 applyPanelNums` | 面板序号可开关 |

### C. 场景与面板体系（整层）

| # | 功能 | 旧落点 | 行为 |
|---|---|---|---|
| C1 | 动态场景页签 | `main.js:25 readScenarios`（坏 JSON 记 `BAD_SCENARIO` + 固定排序）、`:777 app:scenarios`；`app.js:468 renderTabs`、`:1801 loadScenarios` | 第 1 个 tab 恒为 “DeepSeek Harness”，之后是 5 个场景：`self-review / pc-cleanup / api-gateway / projects / demo-workbench` |
| C2 | 网格与展开 | `app.js:509 renderGrid`、`:520 buildPanel` | 按 `col/row/w/h` 铺；`harness/embed` 可“展开到最高”（占位符 + fixed + Esc 收起） |
| C3 | 面板类型 | `app.js:520-631` | `review-doc`、`review-files/file`、`collab`、`harness`、`embed`、`pc-drives`、`reserved`、占位 |
| C4 | 场景身份卡 | `main.js:285 scene:context`；`app.js:634 renderHarnessPanel` | 读场景身份卡 + `<DSH根>\场景项目信息\<场景>\项目信息.md`，展示 §〇 交接，按钮：打开身份卡 / 打开记忆 / 复制会话 ID |

### D. 项目 / 工作区

| # | 功能 | 旧落点 | 行为 |
|---|---|---|---|
| D1 | 工作区清单（三源） | `main.js:525 team:workspaces` | 团队登记 + `工作台\项目\*`（含 legacy `workspace.json`）+ DSH `storages/workspace.json`；`path.resolve().toLowerCase()` 去重；排除工作台根 / `qq-bridge` / `default-workspace`；`current` 只认 `当前工作区.json`；current 优先 + `zh-CN` |
| D2 | 项目总览卡片 | `app.js:768 renderProjectCards`（面板 `pj-list`） | 统计“N 个工作区 · M 个当前”；点卡片在左栏预览 `<项目>\项目索引.md` |
| D3 | 新建工作区 | `main.js:738 team:workspace:create`；`app.js:166 openWorkspaceDialog` | 字段：名称（1–40）、根目录（默认 `D:\deepseek\工作台\项目`）、勾“创建后导入六角色空会话”；`WORKSPACE_EXISTS`；**没有引擎直接拒绝**（`:756-758`）；成功后自动 `launch(seedVisible:true)`，失败明确提示 |
| D4 | 打开已有项目 | `main.js:653 team:openProject`；`app.js:149` | 默认定位 `D:\deepseek`；同名不同目录报 `PROJECT_NAME_CONFLICT`；不复制不移动；`launch.mjs --no-prompt --add-members` |
| D5 | 按名字恢复 | `main.js:692 team:restore`；`app.js:319-341` | 只收项目名；先 `工作台\项目\<名>`，再大小写不敏感，再回退 `状态/项目/*/项目.json` 的 path；`launch.mjs --restore --add-members` |
| D6 | 一键建团队 | `main.js:491 team:launch`；`app.js:273 openLaunchDialog` | 弹窗 = 恢复输入 + seed 勾选 + **工作区下拉（不自动用当前）** + “建六个空会话” |
| D7 | 文件树 + 内嵌预览 | `main.js:872 fs:list`、`:884 fs:read`；`app.js:811 renderFilePanel`、`:754 showPreview`、`:690 markdownToHtml` | 目录懒加载、`aria-expanded`、全部收起/刷新、目录优先 + `zh-CN`；**面板内**渲染 md/图片/视频/PDF/文本；20MB 上限；`wb.recent` 记 12 条 |
| D8 | 协作台 | `main.js:343 collab:state`；`app.js:1020 renderCollabPanel` | 读 `工作台\协作\state.json` + `对账.md`：5 张统计卡、智能体表、派单明细（4 种筛选）、回执流水；仅面板可见时 5 秒轮询 |

### E. 六角色会话

| # | 功能 | 旧落点 | 行为 |
|---|---|---|---|
| E1 | 唯一创建者 | `main.js:491 team:launch` → `团队/工具/launch.mjs` | 标题 `团队·<角色>`；模型 `deepseek-account/deepseek-flash` + `reasoningEffort:max`；按 title + 同 cwd + 属于该 workspace 的 `sessionIds` 复用；`--seed-visible` 逐个发“已就位”（1.2s 间隔）；清理无标题空占位；写 `团队会话.json/.md`、`会话.json`、`当前工作区.json`、`workspace.json.dshWorkspaceId`、`事件.jsonl` |
| E2 | 成员清单 | `main.js:477 team:members`（读 `<当前工作区>/团队会话.json`）；`app.js:1640 mountMembers` | 6 行（名字/标题/session 短 id）+ 说明“空白会话在 DSH 左侧不显示” + **“逐个显示成员”按钮**（confirm 后 `launch({seedVisible:true})`） |

### F. 消息 / 回执协议（旧流程核心）

| # | 功能 | 旧落点 | 行为 |
|---|---|---|---|
| F1 | 启动令牌 | `工具/lib/ops.mjs:36 bootFor`；`store.mjs createBootToken/requireBoot`；`状态/启动/<token>.json` | `send/inbox/read/ack` 全要 `--boot`；校验角色/项目/过期/`rulesHash`（`RULES_CHANGED`） |
| F2 | 派单 | `ops.mjs:339 cmdSend` | `--to` 任意 active 角色（含 pm）；PM 带 `--ack` 时读/写 `派单锁.json`，未闭环 `PM_DISPATCH_PENDING`；`--task` 定 owner；消息落 `邮箱/<to>/new/<ts>-M-xxxx.json`（≤600 字）；唤醒发**四步指令**：`boot` → `inbox --all` + `read --id` → `ack --id` → `task claim`，并要求先读 `项目铁律.md`（`:392-399`） |
| F3 | 收件箱 / 已读 | `ops.mjs:414 cmdInbox`、`:423 cmdRead`；`store.mjs:382/417` | `inbox` 默认只 `new/`，`--all` 带 `cur/`；`read` 把文件 `new→cur` 并写 `mail_read` |
| F4 | 回执 | `ops.mjs:431 cmdAck`；`store.mjs:435 ackMessage` | **由收件角色**带 boot 令牌执行；note ≤300 字；`msgId+from` 去重；写 `回执.jsonl`（`A-xxxx`）；给发件人回 `type:'receipt'`（`ackRequired:false`，防递归）；清 `派单锁.json` |
| F5 | 身份链 | `ops.mjs:27 sessionOf` | 事件里的 `sessionId` 是执行者会话，不是壳进程 |

### G. 看板 / 流程 / Owner

| # | 功能 | 旧落点 | 行为 |
|---|---|---|---|
| G1 | 看板浮窗 | `main.js:247 openTeamBoard`、`:574 team:board`、`:585 team:board-project`、`:599 team:board-file`、`:624 team:board-control`；`board-preload.js:4-8` | 1120×780、`frame:false`、`transparent`、`alwaysOnTop('floating')`、`opacity .94`；折叠 320×64 可还原；缩放/最大化/最小化/关闭；看板内切项目；文件抽屉只读预览（4MB、路径白名单） |
| G2 | 流程推导 | `main.js:377 computeWorkflow`、`:370 currentFlowProject` | 读 `当前工作区.json` → `工作流.json`、`任务/*.json`、`需求/R-*.md`、`提交/*.json`；阶段 `intake/requirement/review/bossreview/dispatch/dev/test/close` + `iterate` + `unknown`；返回 `counts` 与 `roundKey=项目|需求数|任务数|进行数` |
| G3 | 实时推送 | `main.js:432 startFlowWatch`、`:451 workflow:get` | `fs.watch(…,{recursive:true})` + 220ms 去抖 → 广播 `workflow:changed`；渲染层 `API.team.onWorkflow` 收到即刷新（`app.js:1773`），不轮询 |
| G4 | 流程浮窗 | `index.html:83-116`；`app.js:1669 mountFlow` | 10 节点（含 `devreview 互审/对账`、`iterate 迭代`）、7 条边、可拖拽、`#flow-meta` 显示需求/任务/进行/提交计数 |
| G5 | Owner 闸门 | `app.js:1723 maybeOwnerReview`、`:1687 openOwnerReview` | 只在 `bossreview` 弹；`closable:false`；只在“跳过/开始”二选一；通过必须写意见；按钮“通过并通知 PM”；按 `roundKey` 每轮一次 |
| G6 | Owner 落账 + 通知 | `main.js:452 workflow:owner`、`:469 owner-note.mjs`；`owner-note.mjs:14-19` | 写 `工作流.json.ownerReview{required,status,by,at,roundKey,opinion}`；`owner-note.mjs` → `sendMessage({from:'system',to:'pm',type:'owner-review',ackRequired:true})`；广播刷新 |

### H. 工程与自检

| # | 项 | 旧落点 |
|---|---|---|
| H1 | 单实例 | `main.js:14-22` `requestSingleInstanceLock` + `second-instance` 前置窗口 |
| H2 | 日志/异常 | `main.js:23 LOG()` 写 `main.log`；`:1091 process.on('uncaughtException')` |
| H3 | 自检 | `main.js:972-1085`：UI/preload 契约、弹窗字段、真实输入、菜单项数、引导、主题、成员、流程、看板折叠/缩放/文件抽屉、文件树、场景切换、重名拦截、按名恢复 |
| H4 | 包检查 | `package.json:27 check = node --check main.js && preload.js && app.js` |

---

## 2. 旧版状态流（五个闭环）

**S1 建/登记工作区**
`对话框 → team:workspace:create → workspace.mjs create（拒同名目录/同名登记；无引擎硬失败）→ DSH workspaceCreate → 写 workspace.json + 状态/项目/<name>/项目.json + setActiveProject + 当前工作区.json → 自动 launch(seedVisible) → refreshWorkspaceSoon()`

**S2 建团队**
`team:launch → ensureEngine → launch.mjs --project/--workspace/--roles/--add-members/--seed-visible → workspaceCreate（拿 sessionIds 白名单）→ 按 团队·角色 标题复用/补建 → rename + selectModel → seed 逐个“已就位” → 写 团队会话.json/.md、会话.json、事件.jsonl、团队.json.members、当前工作区.json → toast + 双次 reload`

**S3 派单 → 回执（核心）**
`PM 会话 boot → team.mjs send --ack → 邮箱/<to>/new/M-*.json + 派单锁.json + 事件.jsonl → 唤醒目标会话（四步指令）→ 目标会话 boot → inbox --all → read（new→cur）→ ack --note → 回执.jsonl + 回执消息给 PM + 清锁 → PM 收到 type:'receipt'`
失败面：无会话 → `wake={ok:false, why:'目标角色还没有 DSH 会话'}`；无 engineUrl → 对应原因；锁未清 → `PM_DISPATCH_PENDING`。

**S4 流程 → Owner → PM**
`任务/需求/提交 变化 → fs.watch → workflow:changed → workflow:get → computeWorkflow（阶段 + roundKey）→ stage==='bossreview' 且本轮未决 → Owner 弹窗（不可关）→ workflow:owner 写 工作流.json → owner-note.mjs → PM 收件箱（system/owner-review/ackRequired）→ 广播刷新`

**S5 看板**
`team:board → team.mjs board --json（读 任务/提案/提交/回执/需求 + 看板.json）→ 写 看板.html/.md → openTeamBoard 载入浮窗 → 窗口内切项目重跑 board --project 并 reloadFile`

**旧数据落点（唯一真相）**：`<项目>/workspace.json`、`<项目>/团队会话.json`、`团队/状态/项目/<name>/{项目.json,工作流.json,任务/,提案/,提交/,备份/,派单锁.json}`、`团队/状态/邮箱/<role>/{new,cur}`、`团队/状态/回执.jsonl`、`团队/状态/{团队.json,会话.json,看板.json,当前工作区.json,事件.jsonl,启动/}`、`工作台/看板.html`。

---

## 3. 当前落点与缺口（P0 / P1 / P2，状态以 S2 为准）

### P0 · 破坏“必须保持的四条模型/协议”

#### P0-1 团队账本根错位：旧项目、旧邮箱、旧回执在新壳里全部不可见 ❌ 未修

- **旧**：`main.js:190-195` `WORKBENCH_DIR`（或 `WB_WORKBENCH_DIR`）→ `TEAM_DIR=<工作台>/团队`；`team:workspaces`（`:525`）、`team:restore`（`:692`）、`team:members`（`:477`）、`computeWorkflow`（`:377`）都读这一个根。
- **当前**：`team-tools.js:284` `initialRoot = options.teamRoot || process.env.TEAM_ROOT || path.join(repoRoot(),'团队')`；`main.js` 只在 selftest 时改 `TEAM_ROOT`（沙盘），**不认 `WB_WORKBENCH_DIR`，也不默认指向 `D:\deepseek\工作台`**。
- **实测**：`agile-workbench\团队\状态` = 0 个项目 / 0 个邮箱文件；`工作台\团队\状态` = 6 个项目 / 392 个邮箱文件 / 86 KB 回执 / 779 KB 事件。
- **后果**：新壳启动 → 项目列表空；`team:workspaces` 的 `current` 为 null；按名恢复找不到旧项目；`team.mjs send/ack` 写进另一本账。**“1 项目 = 1 workspace / 6 角色 = 6 会话 / 消息回执走旧流程”在旧数据上一条都无法验证。**
- **落点**：`src/team-tools.js` 的 root 解析 + `src/main.js` 顶部常量（旧根探测 / `WB_WORKBENCH_DIR` 兼容 / 一次性迁移指针）。
- **验收**：启动后 `team:workspaces` 至少列出旧 `工作台\项目` 的 5 个目录；`current` 命中 `当前工作区.json`；`team.mjs inbox --all` 与 UI 读同一路径。

#### P0-2 回执仍不是“角色会话”产生的；唤醒不教角色 boot/ack；没有收件箱 🟡 部分已修

- **旧**：`ops.mjs:431 cmdAck` 由收件角色用 `--boot` 执行；`store.mjs:435` 写 `回执.jsonl` + 回信；唤醒强制 `boot → inbox → read → ack → task claim`（`ops.mjs:392-399`）；`cmdRead` 把 `new→cur` 并写 `mail_read`。
- **S2 已修（本轮）**：`team:ack` 现在要求 `mappedSession`（角色必须真有 DSH 会话），否则 `SESSION_IDENTITY_MISSING`；`sessionId` 不匹配报 `SESSION_IDENTITY_MISMATCH`；新增 `manual:true` 人工确认通道——只记 `manualAck/manualAckAt`、`ackSource='manual'`，**不冒充 ack、不清旧协议锁**；回执事件里带真实会话 id；回执后 `mirrorToTeamBoard` 同步旧看板。
- **仍缺**：① 唤醒文案仍是一句（`main.js:2803`：`【团队派单 …】… 请先确认角色、任务和边界，完成后回执；不要巡检全队`），**没有 boot/inbox/read/ack/task claim**，角色收到唤醒仍不知道要回执；② 渲染层没有收件箱/已读（`teamTools.inboxFor` 已存在但无调用者，`preload.js` 也没暴露）；③ boot 令牌仍由壳进程代取，角色会话本身从未执行 `boot`。
- **后果**：回执的“身份”对了，但“流程”还是壳在跑；角色被唤醒后不会自己 ack；“没有回执=没发生”仍无法从会话侧闭环。
- **落点**：`main.js` 唤醒文案换成 `ops.mjs:392-399` 四步模板；新增 `team:inbox`/`team:read` 包装 + 团队台“收件箱”页；`team:ack` 的 `manual` 通道在 UI 上必须显式区分（现在 HTML/JS 已有 `ackSource` 徽标基础）。
- **验收**：在角色会话里手跑 `team.mjs ack --id M-…` 成功；UI 点“记录回执”产生 `manual` 而非 `ack`，且 `回执.jsonl` 不变；团队台能看到该角色的 `new/` 邮件。

#### P0-3 六角色互发：IPC 已支持，UI 尚未把 `from` 传下去 🟡 只剩一行

- **旧**：`ops.mjs:339 cmdSend` 的 `from` = 执行者角色；`--to` 任意 active（含 pm）；只有 `from==='pm' && ack` 才套 PM 单派锁。
- **S2 已修（本轮）**：`team:send` 接受 `from`（默认 pm），允许 `to==='pm'` 与角色互发，`pmDispatch` 只对 `pm→非pm+ack` 生效；`sendDispatch` 透传 `from` 与 `senderSession`；渲染层 `#dispatch-from` 下拉已渲染。
- **仍缺**：`app.js:1622` 的 `teamSend({ projectId, role, subject, body, taskId })` **没有传 `from`**（`fromId` 已从 `#dispatch-from` 读到，却没进 payload），所以界面仍只能 PM→5。
- **落点**：`teamSend` 载荷加 `from: fromId`（并让 `#dispatch-role` 不再过滤 pm，若仍过滤则一并放开）。
- **验收**：`product→pm`、`tester→programmer1` 各一条成功；PM 锁只在 `from==='pm' && ack` 时出现。

#### P0-4 项目可以不绑定 DSH 工作区，UI 仍报“项目已创建” ❌ 未修

- **旧**：`main.js:756-758` 没探测到引擎就**拒绝**建工作区；建完必带 `workspace.json.dshWorkspaceId`。
- **当前**：`createProject`（`main.js`）只建目录 + 简化 `项目信息.md`/`README.md` + 本地 `P-xxxx`；`project:create` 随后 `bindProjectWorkspace`，失败只写 `workspace.pending=true` 并把错误塞进 `warnings`；`openNewProject`（`app.js:2193`）只判断 `r.team.ok`，**不看 `warnings`，也不看 `project.workspace.pending`**，toast 仍是“项目已创建”。
- **后果**：离线/端口错时得到“有项目、没 workspace”的 1:0；用户以为成功，点“建团队”才报错。
- **落点**：`openNewProject` 读 `r.warnings` + `workspace.pending` 并写 `#workspace-warn`（HTML 已加）；`createProject` 拿不到 `dshWorkspaceId` 时拒绝入库或显式 pending 且禁用“建团队”。
- **验收**：DSH 离线新建 → 红色“未绑定工作区”；`state.projects[].workspace.pending === true` 在界面可见。

#### P0-5（原）双真相 → 降为 P1-0（本轮已加双向中的“写”向）

见 P1-0。

### P1 · 关键功能缺失或语义反转

#### P1-0 工作台数据与团队状态：写向已补，读向仍缺

- **旧**：任务/提案/提交/回执全在 `团队/状态/项目/<name>/`；看板与流程都读它。
- **S2 已修（本轮）**：`team-tools.js:782 syncWorkbenchBoard` 在生成看板前把 `project.tasks/proposals/commits` 写成旧协议 JSON（带 `source:'workbench'`，只清理自己写的文件）；`main.js:1544 mirrorToTeamBoard` 在 **9 个写入点**（task/proposal/ack/owner 等）实时镜像；`team:ack` 返回值带 `board` 摘要。
- **仍缺**：① 反向读取（CLI `team.mjs task create` 后 UI 不可见）；② `需求/R-*.md` 没有写入方；③ `工作流.json` 没有写入方（见 P1-1）；④ `回执` 已进镜像，但 `ownerReview` 尚未写 `工作流.json`。
- **落点**：`workflowSnapshot`/`statePayload` 读一次 `状态/项目/<name>/任务|需求|工作流` 做合并（或改成“团队状态为真相、本地只做 UI 缓存”）。
- **验收**：CLI 建任务后 UI 刷新可见；UI 建任务后 `团队.mjs board` 的 `summary.tasks` 加 1（`team:board` 已能，但要求不依赖“生成看板”这一动作）。

#### P1-1 Owner 闸门与旧流程不一致；通过后 PM 收不到任何消息 ❌ 未修

- **旧**：只在 `bossreview` 弹、`closable:false`、按 `roundKey` 每轮一次、`workflow:owner` 写 `工作流.json` 并调 `owner-note.mjs` → PM 收件箱（`app.js:1687-1721`、`main.js:452-475`）。
- **S2 现状**：`openOwnerModal`（`app.js:2368`）仍 `closable:true`（只是加了关闭 toast 与“Owner 待决定”入口）；`render()` 仍用 `ownerPrompted`（`app.js:520-523`）按项目去重，**不是 roundKey**；`owner:decide`/`workflow:owner` 只写本地 `ownerReview`，`notified:null`，没有 `工作流.json`、没有 `owner-note.mjs`。
- **后果**：误关后本轮不再弹；Owner 决定不进团队状态，PM 收件箱永远收不到 `owner-review`。
- **落点**：`closable:false`（或“关闭=稍后”但不清本轮）；用 `workflowSnapshot().roundKey` 替代 `ownerPrompted`；`ownerDecide` 内联 `工作流.json` 写入 + `owner-note.mjs` 调用（`team-tools.runNode` 已具备能力）。

#### P1-2 流程从 10 阶段退成 8 阶段，`review` 不可达，且没有文件推送 ❌ 未修

- **旧**：10 节点（`pm-intake/requirement/review/bossreview/dispatch/dev/devreview/test/close/iterate`）；`computeWorkflow` 会返回 `review`/`iterate`；`fs.watch` 推送。
- **当前**：`STAGES`（`main.js:129`）8 个，缺 `devreview`、`iterate`；`deriveStage` 只可能返回 `intake/requirement/owner/dispatch/dev/test/close`，`review` 永不可达；`FLOW_ROWS`（`app.js:1355`）仍画 `review` 但不亮；无 `fs.watch`、无 `workflow:changed`。
- **落点**：补两阶段；`deriveStage` 增加产品/需求任务判据；主进程 `fs.watch(状态/项目/<name>)` + `workflow:changed` 广播；`workflow:get` 恢复读团队状态。

#### P1-3 看板浮窗只有“置顶”，没有窗口能力：按钮全是死的 ❌ 未修

- **旧**：1120×780、透明、`opacity .94`、`board-preload`、`team:board-control` 九个动作、`team:board-file` 4MB 预览、看板内切项目。
- **当前**：`team:board-old` 建 `BrowserWindow`（440×760、`frame:false`、`alwaysOnTop:true`）但**没有 preload**，也没有 `team:board-control` / `team:board-file` 两个 IPC；旧 `board.mjs` 生成的 HTML 仍带 `[data-win=…]` 与 `#project-select`，脚本 `if (window.boardWin) …` 全部静默跳过（`board.mjs:241-247`）。
- **后果**：能置顶，但折叠/缩放/最大化/切项目/文件抽屉全部无反应；窗口比旧版窄 2.5 倍。
- **落点**：挂 `board-preload.js`（旧文件可复用）+ 补两个 IPC（语义照 `旧main.js:599-651`），尺寸/透明/opacity 对齐；否则隐藏这些按钮，不要留死控件。

#### P1-4 DSH 地址：持久化已补，端口发现/分区/重铸仍缺 🟡 部分已修

- **旧**：`resolveEngine` 端口扫描 + 凭据 cookie + `persist:harness`；`app:config` 合并 `config.json`/`config.local.json`；离线遮罩/重试/6s 看门狗。
- **S2 已修（本轮）**：新增 `DSH_CONFIG_FILE = data/dsh.json`、`readDshConfig/persistDshConfig`、`normalizeDshBaseUrl`；`dsh:configure` 会校验并落盘。
- **仍缺**：`index.html:176` webview 仍写死 `src="http://127.0.0.1:52711"` 且**没有 `partition`**；没有端口发现；没有 401/403 重铸 cookie；`installDshCookie` 失败仍不阻断/不提示。
- **落点**：启动时先读 `dsh.json` → 探测 → 再建窗；webview 加 `partition="persist:harness"`；适配层 401/403 重铸一次。

#### P1-5 文件面板没有“看内容”这一步 ❌ 未修

- **旧**：`fs:read` 渲染 md/图片/视频/PDF/文本，20MB 上限，面板内预览 + 最近 12。
- **当前**：`files:list` 递归（深 4 / 600，静默截断），`files:open` 只 `shell.openPath`；无 `files:read`；UI 明说“点文件用系统程序打开”。
- **落点**：补 `files:read` + 预览容器 + `truncated` + 最近打开。

#### P1-6 刷新/建团队已能 reload；成员弹窗仍无“逐个显示成员” 🟡 只剩一半

- **旧**：`refreshWorkspaceSoon()` 双次 reload；成员弹窗有“逐个显示成员”。
- **S2 已修（本轮）**：`startTeam` 在 `created>0 || seeds>0` 时 `reloadDshFor(next,'provision')`；`#btn-refresh` 与 ⋯ 菜单“刷新”走 `refreshAll()`，其中 `reloadDshFor(p,'refresh')` 会在 DSH 在线时重载（`app.js:3171` 附近），并 `loadWorkspaces/loadTeamStatus/loadDshTeamStatus` 强制刷新。
- **仍缺**：`openMembersModal` 仍只有“去角色页”，**没有批量 seed 按钮**（旧版 `app.js:1651-1664` 有 confirm + `launch({seedVisible:true})`）。
- **落点**：成员弹窗恢复批量 seed（`dshProvision` 或 `launch({seedVisible:true})`）。

#### P1-7 “6/6 就绪”与标题：本轮已修 ✅（保留，别回退）

- **S2**：`sessionReadyCount` 改为 DSH 核验值（未核验返回 null，不拿本地映射冒充）；`roleSessionTitle` 返回 `团队·<角色名>`（优先 manifest 标题）。自检 `SELFTEST_MAPPING` 也断言 `teamTitled:6`、`statusAllExist`。
- **仍建议**：`#tb-sessions` 仍数 `Object.keys(p.sessions).length`（映射数，不是在线数），文案需与 `#tb-team` 区分。

#### P1-8 旧入口语义被替换/仍有 4 个死接口 🟡 部分已修

| 旧入口 | 旧落点 | S2 现状 |
|---|---|---|
| 工作区清单（三源） | `main.js:525` | 🟢 渲染层已调用 `team:workspaces`（`app.js:732` 附近），本地项目只是其中 `source:'store'` 一类 |
| 打开已有项目（不复制、建团队） | `main.js:653 team:openProject` | 🔴 新建弹窗里的“打开已有项目文件夹”改成 `project:adopt`（要求 `项目信息.md`，只登记不建会话）；`team:open-project` 在渲染层零调用 |
| 按清单建团队（下拉） | `app.js:273` | 🔴 `#btn-team-start` 直接 `dshProvision(当前项目)`；`team:launch` 零调用 |
| 新建工作区（名称/根/导入） | `app.js:166` | 🔴 `#btn-workspace` → `project:create`；`team:workspace:create`（语义最接近旧版）零调用 |
| 旧版 IPC 兼容组 | `team:status/members/workspaces/board` 等 | 🟢 仍在，且 `team:workspaces` 增强为“团队登记 + store + DSH”三源 |

- **落点**：把 `team:open-project`/`team:launch`/`team:workspace:create` 接回 UI；或删除并在 README 声明“只保留新路径”，不能留半死接口。

#### P1-9 运维层整块缺失 ❌ 未修

| 旧功能 | 旧落点 | 当前 |
|---|---|---|
| 工作台体检 + 报告 | `main.js:304`、`app.js:1390` | 无 IPC、无菜单 |
| 检查更新 | `main.js:830`、`app.js:1339` | 无 IPC、无菜单 |
| 余额胶囊 | `main.js:787` | 无 |
| 插件/技能/MCP/工具 扩展组 | `index.html:26-31`、`app.js:1427` | 无 |
| 网页 AI 5 站点 | `app.js:410`、`main.js:934` | 无 |
| 盘容量 | `main.js:858`、`app.js:953` | 无（旧版 `pc-toplarge/junk/ledger` 本身是占位） |
| 记忆模板注入 | `main.js:904` | 无 |
| 场景/面板/身份卡 | §1.C | 无 |
| 窗口序号 | `app.js:1631` | 无 |

#### P1-10 `dsh:team-status` 只读已修；额外会话口径待复核 🟡

- **S2**：注释与实现均为“只用 `session/list` + 已记录的 workspaceId/成员快照，绝不调 `workspace/create`”（`main.js:2958` 附近），修掉了 QA4-S16。
- **仍建议**：`extras` 若仍只按 `团队·` 前缀统计，无标题/临时会话不会报；建议改为“当前 workspace 全部会话 − 六个映射”。

### P2 · 细节退化与兼容性

| # | 项 | 旧 | S2 当前 |
|---|---|---|---|
| P2-1 | UI 契约自检 | `main.js:972-1085` 逐项断言 API/选择器/弹窗/菜单/引导/看板 | 只 `click('[data-tab="flow"]')` 读 display；选择器漂移无告警（旧版只打印不阻断，但至少可见） |
| P2-2 | 单实例/日志/异常 | `main.js:14-22`、`:23`、`:1091` | 🟢 单实例已加（`requestSingleInstanceLock` + `second-instance`）；🔴 仍无 `main.log`、无 `uncaughtException` |
| P2-3 | 环境变量兼容 | `DSH_HOME \|\| DSH_ROOT \|\| ~/.dsh`（`:100`）；`DSH_WORKSPACE`、`WB_WORKBENCH_DIR`、`WB_NODE` | `dsh-adapter.js:18-20` 只认 `DSH_HOME`；不读 `config.json/config.local.json`；无 `WB_*`；`AWB_*` 是新名 |
| P2-4 | 负载口径/位置 | 整机 CPU（`os.cpus` 采样）+ 标题栏 `#tbs-load` | `app.getAppMetrics()` 各进程求和 = 应用自身；位置在侧栏 `#metrics`；标签仍写“本机负载” |
| P2-5 | 脚手架 | `workspace.mjs:208-247`：README/协作准则/项目信息/项目索引/项目铁律 + 每角色 角色卡/文件索引 + `site/` + `_tmp/` + `需求/{README,00-需求总览,需求模板,文件索引}` + `workspace.json` | `createProject` 先建空角色目录 + `src/` + `_tmp/` + `需求/` + 简化 `项目信息.md`；完整脚手架靠 `ensureProject → workspace.mjs ensure` 补；**多出 `src/`，旧代码目录是 `site/`**（`ROLES.scope` 也写 `src/`） |
| P2-6 | 提案链 | `ops.mjs:581 propose`（`--expect`/风险分级/`minReviews`/`requiredSigners`/`proposalHash`）、`:669 show`（read receipt）、`:708 review`（先 show）、`:756 sign`（签名绑 hash+ts+nonce） | 单文件（拒绝多文件）；无 show/读回执；签字 `{by,decision,note,at}` 不绑哈希；只有 pm 能签；风险只存不生效 |
| P2-7 | 菜单/引导/主题 | 12 项；引导第 4 步读 `update.json.requiredPlugins`；`auto` 主题 | 10 项；4 步无插件清单；只 `light\|dark` |
| P2-8 | 错误码/文案 | `PROJECT_NAME_CONFLICT / WORKSPACE_EXISTS / PROJECT_FOLDER_NOT_FOUND / CANCELED / OPEN_FAILED / RESTORE_FAILED` + 建议 | 多数为中文一句话；`CANCELED` 未特殊处理；无“最近打开” |
| P2-9 | 删除记录 | 旧版无删除动作 | `project:delete-record` 会 `fs.rmSync` 掉 `团队/状态/项目/<同名或同路径>`（含任务/提案/提交/备份）；`#btn-project-remove` 刚接线，误删成本高，需二次确认 + 只摘登记 |
| P2-10 | 窗口细节 | `setAppUserModelId`（`main.js:8`）、1380×900/min 1000×660 | 无 `setAppUserModelId`；1360×860/min 980×640 |

---

## 4. 本轮并行修复与“别再重复排期”

06:24（HTML）→ 06:25（JS 未接）→ 06:28（JS 接线）之间，作者已补上以下线头；**06:24 快照里它们是死按钮，S2 已不是**：

| 控件/能力 | 意图 | S2 状态 |
|---|---|---|
| `#dispatch-from`（发起） | 六角色互发 | 🟢 下拉已渲染并读到 `fromId`；🔴 `teamSend` 未传 `from`（P0-3 唯一剩余） |
| `#team-board-state` / `#team-board-summary` / `#btn-team-board-refresh` / `#btn-team-board-2` | 团队台内显示旧看板摘要 | 🟢 已接线；🟡 看板窗口本身仍缺 preload/control（P1-3） |
| `#btn-team-sync` | 重登记团队项目并绑 workspace | 🟢 已接线 |
| `#btn-ws-refresh` | 重读团队登记 + DSH 工作区 | 🟢 已接线（`team:workspaces` 三源） |
| `#btn-project-remove` | 移除记录 | 🟢 已接线；🔴 删除会连带 `fs.rmSync` 团队登记（P2-9） |
| `#board-launcher` / `#flow-board-open` | 看板浮窗入口、流程内看板入口 | 🟢 已接线 |
| `#workspace-warn` / `#team-live-note` | 绑定告警、会话真话提示 | 🟢 已渲染；🟡 `openNewProject` 仍不读 warnings（P0-4） |
| `#toggle` 会话真话计数 | 6/6 不再拿本地映射冒充 | 🟢 已改（P1-7） |
| `syncWorkbenchBoard` / `mirrorToTeamBoard` | 工作台 → 团队状态 | 🟢 已加（P1-0 的写向） |
| `data/dsh.json` | DSH 地址持久化 | 🟢 已加（P1-4 的一半） |
| 单实例锁 | 防并发写 | 🟢 已加（P2-2 的一半） |

**结论**：S1→S2 之间，P0-3（IPC 侧）、P1-7、P1-10、P2-2（单实例）已基本闭合；P0-2/P0-5/P1-4/P1-6/P1-8 修了一半。**剩下真正没动的：P0-1（账本根）、P0-4（绑定可缺省）、P1-1（Owner 落账/通知）、P1-2（阶段/推送）、P1-3（看板窗口能力）、P1-5（文件预览）、P1-9（运维层）。**

---

## 5. 已对齐、别回退

1. **DSH 是主画面**：`#dsh-shell > .stage-body > webview#dsh-view` 是唯一主内容，项目/团队是绝对定位抽屉，不再互斥切场景（QA4 第 1 项仍成立）。
2. **六角色由 `launch.mjs` 创建**：`provisionTeamSessions` 先 `bindProjectWorkspace(force)`，再 `inspectProjectSessions` + `rosterStatus`，缺角色交 `launchSessions`（`dryRun:false`、`addMembers:true`、`seedVisible` 默认 true）；自检断言“经 launch.mjs 选了模型”“空白会话已发已就位”。
3. **空白会话可补**：`inspection.blank` 并入缺失集；补完仍 blank 抛 `SESSION_BLANK` 并提示重试（QA4-S1 已修）。
4. **不建额外会话**：映射只保留六角色 key；自检断言 `extras===0`。
5. **切换项目 = 切工作区**：`project:select` → `activateWorkspace` → 绑定/重试 workspace → `activateProject`（旧协议 `project use`）→ 写 `当前工作区.json`。
6. **派单/回执走 `team.mjs`**：`sendDispatch` + `withBootToken`；回执 `ackDispatch` 带真实 sessionId；自检断言 `source==='team'`、锁清空。
7. **回执不再能凭空代写**：`SESSION_IDENTITY_MISSING`/`MISMATCH` + `manual` 通道（S2 新增）。
8. **团队工具是同一份**：`团队/工具/launch.mjs` 与旧仓库哈希完全一致；`team-tools.js` 只是包装，没有复制业务实现。

---

## 6. 环境与数据核查（影响“严格对齐”的现场事实）

1. **旧指针悬空**：`工作台\团队\状态\当前工作区.json` 指向 `个人简历展示项目`，目录已不存在（`工作台\项目` 只剩 5 个；`状态\项目` 有 6 个登记，`个人博客项目`/`个人简历展示项目` 两个登记无目录）。旧壳 `team:workspaces` 会 `existsSync` 过滤，所以旧版打开时 `current` 也是 null——**“最后一次跑通”用的项目现在已不可复现**；复验需新建或恢复 `微光作品集`。
2. **新壳默认根**：`createProject` 默认 `path.join(ROOT,'projects')`，`state.defaultRoot` 同；旧版默认 `工作台\项目`。项目目录不同源。
3. **团队根可写性**：`team-tools` 默认 root 在仓库内；打包 asar 后 `团队/状态` 不可写（只有 selftest 改根）。本轮未打包不触发，开源发布前需处理。
4. **旧 `微光作品集` 没有 `site/`**：可能被手工清理过，也可能是旧版后期不再用 `site/`；因此 P2-5 的 `src/ vs site/` 只能算“与 `workspace.mjs:224` 不一致”，不能断言旧 UI 一定期望 `site/`。

---

## 7. 复核命令（只读；按本文断言逐条验）

```powershell
# 0) 快照（先记下来，防止边改边审）
Get-ChildItem D:\deepseek\agile-workbench\src -Recurse -File -Include *.js,*.html,*.css |
  ForEach-Object { "{0} {1} {2}" -f (Get-FileHash $_.FullName -Algorithm SHA256).Hash.Substring(0,16), $_.Length, $_.Name }

# 1) 账本根（P0-1）
Select-String -Path src\team-tools.js -Pattern "initialRoot|WB_WORKBENCH_DIR|repoRoot"
Get-ChildItem D:\deepseek\agile-workbench\团队\状态\项目,D:\deepseek\工作台\团队\状态\项目 -Directory

# 2) 消息方向（P0-3）
Select-String -Path src\main.js -Pattern "const from = String|pmDispatch" -Context 0,2
Select-String -Path src\renderer\app.js -Pattern "teamSend\(" -Context 0,1

# 3) 回执身份（P0-2）
Select-String -Path src\main.js -Pattern "SESSION_IDENTITY|manual === true|团队派单" -Context 0,3
Select-String -Path src\renderer\app.js -Pattern "ackSource|manualAck"

# 4) 绑定降级（P0-4）
Select-String -Path src\renderer\app.js -Pattern "function openNewProject" -Context 0,18

# 5) 看板能力（P1-3）
Select-String -Path src\main.js -Pattern "team:board-control|team:board-file|board-preload|alwaysOnTop"

# 6) 流程（P1-1/P1-2）
Select-String -Path src\main.js -Pattern "工作流\.json|owner-note|fs\.watch|workflow:changed|notified"
Select-String -Path src\renderer\app.js -Pattern "closable: true|ownerPrompted|FLOW_ROWS"

# 7) 死接口（P1-8）
Select-String -Path src\renderer\app.js -Pattern "teamWorkspaces|teamLaunch|teamWorkspaceCreate|teamOpenProject"

# 8) DSH（P1-4）
Select-String -Path src\main.js,src\renderer\index.html -Pattern "52711|persist:harness|dsh\.json|resolveEngine"

# 9) 文件预览（P1-5）
Select-String -Path src\main.js -Pattern "files:read|fs:read|openPath\(target\)"
```

---

## 8. 一句话结论

旧版最后跑通的是**“DSH 首屏 + 场景页签 + 六角色会话 + 文件邮箱/回执 + 置顶看板 + 浮窗流程 + Owner 通知 PM”**这一整套；S2 的新壳已经把“DSH 主画面、launch.mjs 建六角色、空会话可补、切换项目即切工作区、派单回执走 `team.mjs`、回执身份绑定、会话计数核验、单实例、看板摘要、DSH 地址持久化”做对，**但仍剩 4 个 P0 级断裂：团队账本根错位（旧项目/旧回执不可见）、回执流程仍由壳代跑且没有收件箱、界面没把 `from` 传下去、项目可绕过 workspace**；另有 P1-1（Owner 落账/通知）、P1-2（10→8 阶段与推送）、P1-3（看板窗口能力）、P1-5（文件预览）、P1-9（运维层）等未动。下一轮验收请按 §7 命令逐条复验——**这棵树在 06:24–06:36 之间仍在被并行重写，本文状态列只对 S2 负责。**
