# 第六轮 · 消息/回执/派单锁：旧流程逐步拆解与补齐顺序（只读）

> 范围：只回答“旧版最后跑通的 消息 → 回执 → 锁 流程”到底是什么、当前新壳走到哪一步、下一步按什么顺序补。
> 只读边界：本轮只写本文件；未修改 `src/`、`package.json`、`团队/`、旧仓库与 `D:\deepseek\工作台` 下任何文件。
> 写法约定：旧版行号可复现；新壳行号会漂移（写作期间 `src/main.js` 从 228,475 B 涨到 279,881 B），**一律以函数名、IPC 名、选择器为准**，行号只作定位提示。

---

## 0. 结论摘要（先看这 8 条）

1. **旧版协议不是“UI 记一条消息”**，而是“收件人邮箱里的一个 JSON 文件 + 发件角色用 `--boot` 令牌写 + 收件角色自己 `ack` 并自动回信 + `回执.jsonl` 落账 + `派单锁.json` 由 ack 清”。核心证据：`团队/工具/lib/ops.mjs`、`store.mjs` 的 `send/inbox/read/ack` 四个命令，以及 `事件.jsonl` 中 91 次 `boot`、219 次 `mail_read`、165 次 `ack`、226 次 `message` 的真实记录。
2. **旧 `boot` 是角色会话执行的，不是壳进程**：`launch.mjs:24-34` 的启动卡和 `ops.mjs:392-399` 的唤醒卡都要求角色自己运行 `team.mjs boot --role <role> --project <项目>`；令牌写在 `团队/状态/启动/<token>.json`，30 分钟有效，内含 `role/project/sessionId/rulesHash/docHashes`。没有令牌，`send/inbox/read/ack/task` 全部拒绝。
3. **新壳已经把“写邮箱”做真了，但 `boot` 与 `ack` 仍由主进程 spawn**：`team-tools.js` 的 `bootToken()`/`withBootToken()` 在 `sendDispatch()`、`ackDispatch()` 内部调 `team.mjs boot`，再用该令牌调 `team.mjs send/ack`。`team:send` 用 `--no-wake` 让工具只记账，唤醒改由主进程 `dsh.prompt()` 发一句“完成后回执”。**角色会话本人从未执行过 boot，也没有收到四步指令。**
4. **唤醒文案仍是一句话**（S6 仍为 `【团队派单 <id>】… 请先确认角色、任务和边界，完成后回执；不要巡检全队。`），没有旧版 `boot → inbox --all → read --id → ack --id → task claim`。这是“角色不回执”的第一原因；改这一处不需要动协议。
5. **没有收件箱/已读**：`team-tools.js` 已有 `inboxFor()`，但 `src/main.js` 没有 `team:inbox`/`team:read` IPC，`src/preload.js` 没有暴露，`src/renderer/index.html` 没有收件箱块。旧账本 392 封邮件、PM 的 59 new + 148 cur 在新壳里不可见；UI 的“消息”只读本地 `workbench.json.messages`。
6. **派单锁被新壳“改写”了语义**：旧协议**没有超时**，锁只在收件角色 `ack` 同一条消息时清除；新壳加了 10 分钟 TTL（`ACK_TTL_MS`）、超时自动释放、唤醒失败释放、撤销释放。S6 已修“撤销能释放残留旧锁”，但 TTL 自动释放仍是协议漂移；且降级回执仍会写 `message.ack=true`。
7. **流程仍是本地真相，不是团队状态**：`workflow:get` 读 `workbench.json` 的 `tasks/proposals/ownerReview`，`STAGES` 8 个（缺 `devreview`/`iterate`），没有 `fs.watch`/`workflow:changed`。旧版 `computeWorkflow` 读 `工作流.json + 任务/ + 需求/R-*.md + 提交/`，返回 `unknown/intake/requirement/review/bossreview/dispatch/dev/test/close/iterate` 这些**具名阶段**（注意：旧版**从不返回 `devreview`**，它只是旧 UI 的第 7 个节点），改文件即推送。
8. **Owner 落账在写作期间被并行补上了，但闸门还不对**：S6 的 `team-tools.js` 已出现 `writeOwnerWorkflow()`/`recordOwnerDecision()`（写 `工作流.json` + 调 `owner-note.mjs` 给 PM 写 `owner-review` 系统消息），`workflow:owner` 与 `owner:decide` 都会调；但 UI 的 `openOwnerModal()` 仍 `closable:true`、仍调 `ownerDecide()`，且 07:22 的 `app.js` 明确写了“Owner 不自动弹窗”（旧版在 `bossreview` 自动弹）。

**一句话**：旧版是“角色拿着令牌自己走完邮箱/回执”，新壳目前是“主进程拿着令牌替角色走完邮箱/回执”，只差在“谁执行”与“谁读回”两处；先补唤醒四步和收件箱，再谈锁与流程，顺序反过来会把壳代跑固化。

---

## 1. 快照、现场事实与证据等级

### 1.1 旧版基准（只读）

| 文件 | 大小 | SHA256 前 16 | 说明 |
|---|---:|---|---|
| `12-源码照搬/外壳/main.js` | 67,864 | `E54991F0A2EDA795` | 旧壳主进程：`team:*`、`workflow:*`、`board` |
| `12-源码照搬/外壳/renderer/app.js` | 90,670 | `BAE3B227FD2813C4` | 旧渲染：流程浮窗/Owner/成员 |
| `12-源码照搬/外壳/renderer/index.html` | 7,532 | `72F4F920103A524F` | 旧 DOM：`#flow-panel` 等 |
| `团队/工具/team.mjs` | 5,354 | `E24B0583ABFEE18A` | CLI 入口，`send/inbox/read/ack` |
| `团队/工具/lib/ops.mjs` | 111,912 | `C399439DF429C000` | 命令实现、派单锁、唤醒文案 |
| `团队/工具/lib/store.mjs` | 32,739 | `EA2FC2B17493CFCD` | 令牌、邮箱、回执、任务 |
| `团队/工具/lib/core.mjs` | 14,044 | `A16018442D3B7954` | `PATHS`、通用文件锁 |
| `团队/工具/lib/board.mjs` | 30,547 | `6CA2EAE3209F4FEF` | 看板 v2 HTML/抽屉/切项目 |
| `团队/工具/launch.mjs` | 14,127 | `714AE47B66042DA7` | 六角色会话创建/启动卡 |
| `团队/工具/owner-note.mjs` | 983 | `4192504CBDBD668E` | Owner 决定 → PM 邮箱 |

### 1.2 新壳快照 S6（07:22:12 复核）

| 文件 | 大小 | SHA256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 279,881 | `B6A62CB5F2253D5C` | 07:16:56 |
| `src/team-tools.js` | 77,432 | `025815413EF8CD39` | 07:13:28 |
| `src/preload.js` | 4,297 | `5CB00C6A56051F15` | 07:15:30 |
| `src/renderer/app.js` | 208,940 | `DC5CC71FFCC46AE4` | 07:22:12 |
| `src/renderer/index.html` | 32,975 | `A18A71DCD9C28A54` | 07:15:56 |

**审计期间源码在动（必须写进结论）**：07:09 开始读时 `main.js` 为 228,475 B、`app.js` 为 171,242 B；07:13:28 `team-tools.js` 增加 Owner 落账/身份核验；07:14–07:16 `main.js` 增加 `verifyProjectRoleSession`、看板窗口/控制/文件预览、`team:cancel` 残留锁；07:19–07:22 `app.js` 增至 208,940 B 并加入“Owner 不自动弹窗 / 看板摘要按项目”的改动。**本报告约束到“S6 符号”为止；`openOwnerModal` 仍 `closable:true`、启动时不再自动弹（只手动入口）、`FLOW_ROWS` 仍 8 行（07:22 复核）。若 hash 再变，先按 §7 的 grep 复核，再决定某条是否已经不用做。**

### 1.3 两个现场事实（会改变“旧数据是否可见”的判断）

1. **旧账本被手工拷贝进了新仓库**：`D:\deepseek\agile-workbench\团队\状态` 的 `CreationTime = 2026-11-05 07:05:17`，其中 `回执.jsonl` 与 `D:\deepseek\工作台\团队\状态\回执.jsonl` 字节级相同（86,352 B，SHA256 前 16 均为 `7ad16158474fde5a`），`项目/*/项目.json` 里的 `path` 已被改写成 `D:\deepseek\agile-workbench\项目\...`。这不是代码级迁移，是一次性复制。
2. **拷贝后仍有两处悬空**：`当前工作区.json` 指向 `个人简历展示项目`，但 `D:\deepseek\agile-workbench\项目` 下没有该目录；`个人博客项目` 同样只有登记、没有目录。旧 `team:workspaces` 会用 `existsSync` 过滤，新 `teamTools.listWorkspaces()` 不过滤（`exists:false` 仍返回），所以新壳的“当前项目”可能出现“有 current、无目录”。

> 结论：P0-1（账本根）**不是已修，是“靠一份 07:05 的拷贝暂时能看见”**。代码里仍然没有 `WB_WORKBENCH_DIR`、没有旧根探测、没有迁移提示；一旦旧工具继续写 `工作台\团队\状态`，两边会分叉。

---

## 2. 旧版“消息/回执/锁”逐步拆解

### 2.1 第一步：发件角色如何 boot

**谁执行**：角色自己的 DSH 会话。不是壳进程，也不是 PM 代跑。

**入口文本**：

- `launch.mjs:24-34` `startupText(role, project, workspace)`：新角色第一轮只做两件事——`node 团队\工具\team.mjs boot --role <role> --project "<项目>"`，然后回一行“已就位”。
- `ops.mjs:392-399` 派单唤醒文本第一步同样是 `boot --role <to> --project "<项目>"`。

**命令链**：

```text
team.mjs boot
  → ops.mjs:273 cmdBoot()
    → store.mjs:272 readDocSet(role, project)         // 读并哈希四份必读
    → store.mjs:307 createBootToken({role,project,sessionId,docs})
    → 状态/启动/<token>.json
    → store.mjs:826 addReadReceipt(kind:'index')
    → store.mjs:382 listInbox(role,{project})          // 只数 new/
    → store.mjs:531 listTasks / :658 listProposals / :364 listLocks / :768 activeGrants
    → core.mjs:417 appendEvent({action:'boot', data:{rulesHash, docHashes, token, unread}})
    → 打印启动简报（令牌、规则哈希、未读、待办、待审、锁、授权）
```

**令牌内容**（`store.mjs:307-326`）：

```json
{
  "token": "<24 hex>",
  "role": "programmer1",
  "project": "微光作品集",
  "sessionId": "session-…",
  "rulesHash": "<sha256>",
  "docHashes": { "constitution": "...", "iron": "...", "roleCard": "...", "projectIndex": "...", "teamConfig": "..." },
  "projectIndexHash": "...",
  "createdAt": "…",
  "expiresAt": "…+30min",
  "host": "<COMPUTERNAME>"
}
```

**校验**（`store.mjs:328-345`）：令牌存在、未过期、`role` 一致、`project` 一致、`rulesHash` 与当前四份文档重新哈希一致；任一不符 → `BOOT_INVALID / BOOT_EXPIRED / BOOT_ROLE_MISMATCH / BOOT_PROJECT_MISMATCH / RULES_CHANGED`。

**身份来源**（`ops.mjs:27-29`）：`sessionOf(args) = args.session || DSH_SESSION_ID || 'session-unknown'`。这是旧协议里唯一记录“哪个会话在做”的地方；`回执.jsonl` 本身不写 sessionId，只有 `事件.jsonl` 的 `ack` 行写。

**要点**：

- `boot` 不创建会话、不写邮箱、不派单；它只读文档、发令牌、报未读。
- “没有令牌不执行”是硬闸门：`bootFor()`（`ops.mjs:36-41`）在 `send/inbox/read/ack/task/...` 每个写命令入口都调。
- 令牌 30 分钟，且文档一变就作废（`RULES_CHANGED`），所以旧流程里角色每轮都要重新 boot。

### 2.2 第二步：发件角色如何写邮箱

**命令**：`team.mjs send --boot T --to <角色> --subject S --body B [--ack] [--wake|--no-wake] [--task T-...]`

**实现**：`ops.mjs:339-411 cmdSend()`。

顺序（这个顺序决定了锁与失败面）：

1. `bootFor(args,'send')`：拿令牌，得到 `b.role / b.project / b.sessionId`。
2. 校验 `--to`、正文（`--body` 或 `--body-file`）。
3. **锁检查**：`pmDispatch = b.role==='pm' && args.ack && to!=='pm'`；若非 `--force` 且 `派单锁.json` 有 `messageId` → 直接 `PM_DISPATCH_PENDING`（`ops.mjs:346-353`）。
4. **任务归属**：PM 带 `--task` 时，若任务无 owner 则设成 `to`；若已有别的 owner → `TASK_OWNED`（`ops.mjs:354-368`）。
5. **落邮箱**：`notify()`（`ops.mjs:176-183`）→ `store.mjs:353 sendMessage()`：
   - 发件人必须是团队 active 成员（`system` 例外）；
   - 收件人必须 active；
   - 正文 ≤ `messageMaxChars`（默认 600），主题截 80；
   - 生成 `M-<stamp>-<3hex>`；
   - 写 `团队/状态/邮箱/<to>/new/<ts>-<id>.json`，字段：
     `id, from, to, subject, body, project, task, ackRequired, type, replyTo, ts`。
6. **写锁**：`pmDispatch` 时 `writeDispatchLock(project, msg)`（`ops.mjs:373`）→ `状态/项目/<slug>/派单锁.json`：`{messageId,to,task,subject,ts}`。**注意：先写锁，再尝试唤醒。**
7. **唤醒**：`(ack || wake) && !no-wake` 时，从 `团队.json` 的 `members[].sessionId` 找目标会话；从 `--engine-url` / `DSH_WEB_URL` / `状态/当前工作区.json.engineUrl` 找引擎；`DshClient.prompt({sessionId,text,mode:'queue'})`（`ops.mjs:374-409`、`dsh-session.mjs:106-115`）。
8. 返回 `{ok, message, wake}`；`wake.ok=false` 不会回滚锁（旧版真实行为）。

**旧唤醒文本**（`ops.mjs:392-399`，要原样复用）：

```text
这是派单，不是通知：<M-id>（<subject>）。<任务：T-id>
先读 <项目目录>\项目铁律.md（每轮都读），再读项目信息/项目索引/你的文件索引与角色卡。
现在必须完成，不要只回“收到”：
1) node "<团队工具>\team.mjs" boot --role <to> --project "<项目>"
2) 用 boot 输出的令牌执行 inbox --all，再 read --id <M-id>
3) 本条要回执：ack --id <M-id> --note "已收到 <任务> + 边界"
4) task claim --id <T-id>
最后只回一行：已回执/已认领的角色 + 任务 id；不要输出方案，不要巡检全队。
```

### 2.3 第三步：收件角色如何 inbox / read / ack

**inbox**（`ops.mjs:414-421` + `store.mjs:382-397`）：

- 必须 `--boot`；默认只读 `new/`，`--all` 才带 `cur/`；
- 按 `project` 过滤（消息 `project` 为空则不滤）；
- 按 `ts` 升序；
- 返回 `messages[]`，每项带 `box`。

**read**（`ops.mjs:423-429` + `store.mjs:417-429`）：

- `findMessage(role,id)` 在 `new/`、`cur/` 找；
- 若在 `new/` → `fs.renameSync` 到 `cur/`（同名冲突则删 `new/`）；
- 返回 `alreadyRead`；
- 写 `事件.jsonl` 的 `action:'mail_read'`。

**ack**（`ops.mjs:431-441` + `store.mjs:435-475`）：

1. `bootFor(args,'ack')`：收件角色令牌；`--id`；`--note` 默认“已收到”。
2. `ackMessage(role,id,note)`：
   - note 上限 `ackNoteMaxChars`（默认 300）；
   - `findMessage` 找不到 → `MESSAGE_NOT_FOUND`；
   - **去重**：`回执.jsonl` 里已有 `msgId + from` → 返回 `already:true`，不再写；
   - `readMessage(role,id)`：把 `new→cur`（所以 ack 隐含已读）；
   - 生成 `A-<stamp>-<3hex>`，写 `回执.jsonl`：
     `{id,msgId,from,to,project,note,log,ts}`（**旧 schema 没有 sessionId**）；
   - **回信**：若原消息 `from !== 'system'` 且 `type !== 'receipt'`，`sendMessage({from:role,to:原from,subject:'回执: …',body:'已处理 …',type:'receipt',replyTo:原id,ackRequired:false})`；再向 `回执.jsonl` 追加一行 `{...ack, update:true, receiptMessageId}`（append-only 更新）。
3. `clearDispatchLock(r.msg.project, id)`：只清“这条消息自己的”锁（`messageId` 严格相等才删）。
4. 写 `事件.jsonl` `action:'ack'`，`data:{ackId, receiptMessageId}`。

**回执如何回到发件人**：

- 不是 UI 弹窗，不是壳改本地状态；是一条**新的邮箱消息**：`邮箱/<原发件人>/new/<ts>-M-….json`，`type:'receipt'`、`ackRequired:false`、`replyTo` 原 id。
- 原发件人下一次 `boot` 时未读数 +1，`inbox --all` 能看到“回执: 原主题”；`read` 后进 `cur/`。
- `ackMessage` 对 `type:'receipt'` 不再回执，防递归（`store.mjs:457-469`）。

### 2.4 第四步：派单锁的完整生命周期（旧协议真实语义）

路径：`团队/状态/项目/<slug>/派单锁.json`；实现：`ops.mjs:320-337`。

| 事件 | 触发条件 | 代码 | 结果 |
|---|---|---|---|
| 创建 | `from==='pm'` 且 `--ack` 且 `to!=='pm'` | `ops.mjs:347,373` `writeDispatchLock` | 写 `{messageId,to,task,subject,ts}`；**先于唤醒** |
| 阻塞下一次 | 同上，且锁存在、无 `--force` | `ops.mjs:348-353` | `PM_DISPATCH_PENDING`，`details.pending=锁内容` |
| 强制通过 | 同上 + `--force` | `ops.mjs:348` | 跳过检查；新派单会**覆盖**旧锁（不是释放） |
| 正常释放 | 收件角色 `ack --id` 且 id 与锁相同 | `ops.mjs:435` `clearDispatchLock` | 删 `派单锁.json` |
| 超时 | **无** | — | 旧协议没有 TTL；锁会一直挂到 ack / 手工删 / 下一次 `--force` 覆盖 |
| 撤销 | **无 CLI** | — | 没有 cancel；只能 ack、手工删、`--force` 覆盖 |
| 唤醒失败 | 锁已写、prompt 失败 | `ops.mjs:400-408` | **锁保留**；返回 `wake.ok=false`，不自动清 |
| 非 PM / 非 ack / to=pm | — | `pmDispatch=false` | 不碰 `派单锁.json` |

**不要和通用锁混淆**：`team.mjs lock acquire/release/status` 用的是 `团队/状态/锁/<key>.lock`（`core.mjs:277-376`），60 秒 TTL、heartbeat、stale 判定；那是“防同时写文件”的锁，**不是派单锁**。旧流程的派单锁没有 TTL。

### 2.5 六角色互发、PM 收件、角色→PM

**发送权限**（`store.mjs:353-357`）：`from` 只要是 active 成员（或 `system`），`to` 只要是 active 成员；**没有“只能 PM 发”的限制**。真实 `事件.jsonl` 里既有 `pm→programmer2`，也有 `programmer2→pm`、`programmer2→programmer1`、`tester→pm`、`analyst→tester`，甚至有 `pm→pm`（签字/完成回执）。

**协议消息矩阵**（`ops.mjs` 的 `notify` 调用点）：

| 动作 | from → to | type | ackRequired | 代码 |
|---|---|---|---|---|
| 派单/普通消息 | 任意 → 任意 active | `note`（可 `--type`） | `--ack` 决定 | `:369` |
| 建任务并指派 | 建任务者 → owner | `note` | true | `:457` |
| 认领任务 | 认领者 → pm | `note` | false | `:483` |
| 完成任务 | 完成者 → 建任务者（system 则 pm） | `receipt` | true | `:491` |
| 提交提案 | 作者 → pm | `proposal` | true | `:657` |
| 评审结果 | 评审者 → 提案作者 | `review` | true | `:747` |
| 签字 | 签字者 → pm | `sign` | true | `:801` |
| 授权 | 授权者 → 被授权角色 | `grant` | true | `:985` |
| Owner 评审 | `system` → pm | `owner-review` | true | `owner-note.mjs:14-19` |
| 回执回信 | 收件角色 → 原发件人 | `receipt` | false | `store.mjs:458-469` |

**PM 收件**：PM 的邮箱就是 `邮箱/pm/new|cur`。PM 自己 `boot` 时会看到 `unread` 与最多 8 条主题；`inbox --all` 全量；`read` 逐条已读；`ack` 回执。没有“PM 专用 UI”。

**角色→PM**：与普通消息完全同一条路径（`to:'pm'`）；`sendMessage` 不区分方向。`ack` 回信也回到角色邮箱。

**“没有回执 = 没发生”**：`团队/协议/02-消息任务回执.md:14-16` 的文本规则；技术上由 `回执.jsonl` + 回执消息 + `派单锁` 三件套保证。

### 2.6 看板 / 流程 / Owner 如何读这些状态

**看板**（旧）：

1. 渲染层 `#btn-team-board` → `API.team.board()`（`renderer/app.js:1227-1241`）。
2. 主进程 `team:board`（`main.js:574-583`）→ `runNode([team.mjs,'board','--json'])` → `openTeamBoard()`。
3. `team.mjs board`（`ops.mjs:1578-1591`）→ `boardData()`（`ops.mjs:1347-1422`）读：
   - `listProjects()` / `team.activeProject`；
   - `listTasks(projectName)`；
   - `listProposals(projectName)` + `loadReviews/loadSignatures`；
   - `listCommits(projectName)`；
   - `loadReceipts()`（过滤 `!update`，按 `msgId|from` 去重，按项目过滤）；
   - `项目索引.json` 或 `scanProject()`；
   - `事件.jsonl`（严格链）统计成员贡献；
   - `listLocks()`、`pilotCheckData()`。
4. 写 `团队/看板.md`、`团队/看板.html`、`团队/状态/看板.json`、`团队/状态/看板.md`。
5. `openTeamBoard()`（`main.js:247-271`）：1120×780、`frame:false`、`transparent:true`、`opacity:0.94`、`alwaysOnTop('floating')`、`preload: board-preload.js`。
6. `team:board-project`（`main.js:585-597`）：重新 `board --project`，`loadFile` + `show` + `focus`；看板内 `#project-select`。
7. `team:board-file`（`main.js:599-622`）：只允许 `WORKBENCH_DIR`/`TEAM_DIR` 内、≤4 MB、文本/图片/外链。
8. `team:board-control`（`main.js:624-651`）：`collapse/expand/maximize/minimize/close/zoom-in/zoom-out`；`board-preload.js:4-8` 暴露 `boardWin.control/selectProject/openFile`。

**流程**（旧）：

1. `workflow:get`（`main.js:451`）→ `computeWorkflow()`（`:377-430`）读：
   - `状态/当前工作区.json`（项目名/路径）；
   - `状态/项目/<name>/工作流.json`（`ownerReview`）；
   - `状态/项目/<name>/任务/*.json`；
   - `<project.path>/需求/R-*.md`；
   - `状态/项目/<name>/提交/*.json`。
2. 推导阶段：`computeWorkflow` 返回 `unknown/intake/requirement/review/bossreview/dispatch/dev/test/close/iterate`（**没有 `devreview`**；`devreview` 只是旧 UI 的第 7 个节点，没有判据）；返回 `counts` 与 `roundKey = 项目|需求数|任务数|进行数`。
   - 判据顺序：无任务/需求且有提交 → `close`；有需求无任务 → `requirement`；有测试未完成 → `test`；有开发未完成 → `dev`；评审任务全完且无开发/测试 → `bossreview`；有 owner 任务全完且剩余无 owner → `iterate`；全完 → `close`；有产品/需求任务 → `review`；否则 `dispatch`。
   - `ownerReview.status==='rejected' && stage==='bossreview'` → 强制 `requirement`；`approved/skipped && bossreview` → `dispatch`。
3. `startFlowWatch()`（`:432-450`）：`fs.watch(状态/项目/<key>, {recursive:true})` + 220 ms 去抖 → 所有窗口 `workflow:changed`。
4. 渲染层 `mountFlow()`（`renderer/app.js:1669-1798`）：10 个 `.flow-node[data-stage]`、7 条 `.flow-edge[data-edge]`；`API.team.onWorkflow()` 收到即刷新（`:1773`）。
5. 旧 DOM：`index.html:83-116` `#flow-launcher / #flow-panel / #flow-drag / #flow-close / #flow-project / #flow-meta`，节点 `data-stage="pm-intake|requirement|review|bossreview|dispatch|dev|devreview|test|close|iterate"`。

**Owner**（旧）：

1. `maybeOwnerReview()`（`renderer/app.js:1723-1730`）：只在 `stage==='bossreview'` 弹；`ownerPromptedKey === r.roundKey` 才不重复；`roundKey` 由 `computeWorkflow` 返回。
2. `openOwnerReview()`（`:1687-1721`）：`closable:false`；只有“跳过评审 / 开始评审”；通过必须写意见；按钮文案“通过并通知 PM”。
3. `API.team.workflowOwner({decision,opinion,roundKey})` → `main.js:452-475`：
   - 写 `工作流.json.ownerReview{required,status,by,at,roundKey,opinion}`；
   - `runNode([owner-note.mjs, project, decision, opinion, roundKey])`；
   - 广播 `workflow:changed`；返回 `{...computeWorkflow(), notified}`。
4. `owner-note.mjs:14-19`：`sendMessage({from:'system',to:'pm',subject:'Owner评审：…',type:'owner-review',ackRequired:true})`。
5. PM 下一次 `boot` 的未读里出现该消息；`inbox/read/ack` 与普通消息一致。

---

## 3. 旧版最后一次跑通的“正向证据”

不是推测，是 `D:\deepseek\工作台\团队\状态` 里的真实记录。

### 3.1 事件计数（`事件.jsonl`，1,212 行）

| action | 次数 | 说明 |
|---|---:|---|
| `boot` | 91 | 角色会话启动令牌 |
| `message` | 226 | 写邮箱 |
| `mail_read` | 219 | `new→cur` |
| `ack` | 165 | 回执 |
| `task_claim` | 13 | 认领 |
| `task_done` | 23 | 完成 |
| `launch_sessions` | 54 | 建团队/恢复 |
| `review` | 30 | 评审 |
| `sign` | 16 | 签字 |
| `apply` | 15 | 提交 |

### 3.2 一条完整链（可直接复核）

消息 `M-20261103-084736-b3a4ef`：

```text
00:47:36.591  message    pm         → pm->programmer2  「缺陷修复：技能熟练度条被误删（main.js）」 ackRequired:false
00:47:42.995  boot       programmer2 → programmer2      rules=071ecd0f19d7 index=b8105f016366 unread=4
00:47:53.160  mail_read  programmer2 → M-20261103-084736-b3a4ef
00:48:14.934  ack        programmer2 → M-20261103-084736-b3a4ef  ackId=A-20261103-084814-a5958e receiptMessageId=M-20261103-084814-7afac1
```

`回执.jsonl` 对应行：

```json
{"id":"A-20261103-084814-a5958e","msgId":"M-20261103-084736-b3a4ef","from":"programmer2","to":"pm",
 "project":"个人简历展示项目","note":"已修：hydrate 仅 .skill 作用域处理 level；P-20261103-084808-a6e874 待审",
 "log":"已修：…","ts":"2026-11-03T00:48:14.919Z"}
```

**这条链证明了 5 件事**：角色先 boot；消息在目标邮箱；read 把 `new→cur`；ack 由**同一个 programmer2 会话**执行；回执自动给 PM 回了一条 `M-…`。**它也暴露一个细节**：即使 `ackRequired:false`，旧版也允许 ack（`cmdAck` 不检查该字段）。

### 3.3 锁与令牌的“停下来”状态

- `团队/状态/项目/*/派单锁.json`：**当前 0 个**。
- `团队/状态/启动/*.json`：91 个（全部已过期，旧版没有清理器）。
- `团队/状态/锁/`：0 个（通用文件锁已释放）。
- **但最后留了一条“该回执却没回执”的 PM 派单**：`M-20261103-090106-f39ecf`（pm→tester，`ackRequired:true`，评审通过）在 `回执.jsonl` 与 `事件.jsonl` 里都没有 ack 记录，而 `派单锁.json` 已不在。另一条 `M-20261103-084938-fe13cc`（pm→tester，验收测试）的 `ackRequired:false`，本来就不该加锁，没有回执是正常的。说明最后一次运行后**有人手工清过锁**（或用了 `--force` 覆盖）；不能拿它证明“旧协议会自动超时”（旧协议没有超时）。

### 3.4 看板与 Owner 的证据边界

- `看板.json`：`generatedAt=2026-11-03T01:01:20.588Z`，`selectedProject=个人简历展示项目`，`tasks=7, requirements=1, proposals=6, receipts=13, members=6`。
- 最后跑通的项目 `个人简历展示项目` 的状态目录里**没有 `工作流.json`**：`任务/ 提案/ 提交/ 备份/ 产物.json 对账.json 对账.md 项目.json`。
- 旧账本与仓库副本里唯一的 `工作流.json` 在 `个人博客项目`：`ownerReview.status='skipped'`、`at=2026-11-02T23:52:50Z`、**没有 roundKey**。
- PM 邮箱 `new+cur` 里**没有** `owner-review` / `Owner评审` 消息。

> 所以旧版“Owner → 工作流.json → owner-note → PM 收件箱”这条链，**在最后数据里没有正向证据**；只能证明 `workflow:owner` 曾在另一个项目写过一次 `工作流.json`，不能证明 owner-note 那一步成功。把它列为“旧版设计目标”，不要列成“旧版已验证”。

---

## 4. 新壳逐步对照（S6）

### 4.1 总表

| # | 旧步骤 | 旧落点 | 新壳 S6 落点 | 判定 |
|---:|---|---|---|---|
| 1 | 账本根 | `main.js:190-201 WORKBENCH_DIR/TEAM_DIR` | `team-tools.js:createTeamTools()` 默认 `<repo>/团队`；无 `WB_WORKBENCH_DIR` | ❌ 代码未接（靠 07:05 拷贝） |
| 2 | 角色 boot | `ops.mjs:273 cmdBoot`，角色会话执行 | `team-tools.js:bootToken()/withBootToken()`，主进程 spawn | 🟡 真令牌，**壳代跑** |
| 3 | 写邮箱 | `store.mjs:353 sendMessage` | `team-tools.js:sendDispatch()` → `team.mjs send --no-wake` | ✅ 真写邮箱（+本地镜像） |
| 4 | 唤醒四步 | `ops.mjs:392-399` | `main.js:team:send` 一句 `dsh.prompt` | ❌ 文案缺失 |
| 5 | inbox | `ops.mjs:414 cmdInbox` | `team-tools.js:inboxFor()`，**无 IPC/UI 调用** | ❌ 死代码 |
| 6 | read | `ops.mjs:423 cmdRead` | 无 | ❌ 缺失 |
| 7 | ack | `ops.mjs:431 cmdAck`，收件角色执行 | `main.js:team:ack` → `team-tools.ackDispatch()` 主进程 spawn | 🟡 壳代跑；S6 加会话核验 |
| 8 | 回执回信 | `store.mjs:458-469` | 同左（`team.mjs ack` 内部），UI 不读回 | 🟡 协议真，投影缺 |
| 9 | 锁创建 | `ops.mjs:347,373` | 旧锁照写 + 本地 `project.pendingAck` | 🟡 双锁 |
| 10 | 锁释放 | `ops.mjs:435` 仅 ack | `team:ack` 清本地 + 旧锁；`team:cancel` 可释放残留（S6） | 🟡 语义漂移 |
| 11 | 锁超时 | 无 | `ACK_TTL_MS=10min` + `pendingAckExpired` + `reconcileExpiredLocks` | ❌ 新造 |
| 12 | 锁撤销 | 无 | `team:cancel`（S6 已能按旧锁 messageId 释放） | 🟡 新造但可用 |
| 13 | 六角色互发 | 任意 active ↔ 任意 active | UI `#dispatch-from` 任意角色；`team:send` 校验发件会话；**禁止 from==to** | ✅ 基本对齐（self-send 仍禁） |
| 14 | PM 收件 | `邮箱/pm` + `inbox/read` | 邮箱真写，但无 inbox UI；`project.messages` 只有自己发的 | ❌ 读不回 |
| 15 | 看板 | `team:board` → 独立置顶窗口 + preload | S6 窗口/控制/文件/切项目已接线；`team:board` 仍 `shell.openPath` | 🟡 半接线 |
| 16 | 流程 | `computeWorkflow`（UI 10 节点；返回 8 个具名阶段 + `unknown`，无 `devreview` 判据）+ `fs.watch` | `workflowSnapshot` 读本地，8 阶段，无 watch | ❌ 未接 |
| 17 | Owner | `closable:false` + `roundKey` + 自动弹 + `工作流.json` + `owner-note` | S6 已写 `工作流.json` + `owner-note`；UI 仍 `closable:true`、**不自动弹**、调 `owner:decide` | 🟡 半接线 |

### 4.2 boot：令牌是真的，执行者是壳

- `team-tools.js` `bootToken(projectName, role, {sessionId})`：
  - 先查内存 `bootCache`（key = `project|role|sessionId`）；命中直接复用；
  - 否则 `runNode(layout.teamTool, ['boot','--role',role,'--project',name,'--json','--session',sessionId])`；
  - 从返回里取 `token/rulesHash/sessionId`，缓存到 `expiresAt = now + TTL - 60s`；
  - `withBootToken()` 在遇到 `BOOT_REQUIRED/BOOT_INVALID/BOOT_EXPIRED/RULES_CHANGED` 时重新 boot 一次。
- 调用者：`sendDispatch()`（`team:send`）与 `ackDispatch()`（`team:ack`）。角色会话没有任何代码路径触发 `boot`。
- 后果：`事件.jsonl` 的 `boot` 事件 `role` 是角色名、`sessionId` 是映射会话，但**执行进程是壳**；旧版“角色自己拿令牌”的身份链在事件层面不可区分。S6 新增的 `verifyProjectRoleSession()` 只证明“这个会话存在且属于本 workspace”，不证明“这个会话执行了 boot”。

### 4.3 写邮箱：真协议 + 单向外挂

- `sendDispatch()`：`team.mjs send --boot <token> --to … --subject … --body … [--ack] --no-wake --json`。
- 因此 `邮箱/<to>/new/*.json`、`派单锁.json`、`事件.jsonl` 都是旧工具写的，**这部分是真的**。
- 但 `main.js` 同时 `pushProjectMessage(project, {...})` 写本地 `workbench.json.messages`；`pushProjectMessage` 只有两个调用点（`team:send` 的 team 分支与 local 降级分支），**没有“从邮箱读回来”的路径**。
- `renderTeamLog()` 只读 `p.messages`；`renderDispatch()` 的“待回执”也只从 `p.pendingAck` 找。CLI/角色自己发出的消息、回执消息、旧邮箱历史，UI 都看不到。

### 4.4 唤醒：一句“完成后回执”，没有四步

`main.js team:send`（S6 约 3377 行）：

```js
await dsh.prompt(sessionId, `【团队派单 ${message.id}】${message.subject}\n${message.body}\n请先确认角色、任务和边界，完成后回执；不要巡检全队。`);
```

对比旧版 `ops.mjs:392-399`，缺：`项目铁律.md` 路径、`boot` 命令、`inbox --all`、`read --id`、`ack --id --note`、`task claim`、工具绝对路径、`mode:'queue'` 的“不要只回收到”。

**这是当前最高性价比的一处修复**：不用改协议、不用改锁、不用改 UI，只改这段文本，角色下一轮就会自己去 boot/inbox/read/ack。若不改，后面所有“回执由角色产生”的目标都不会发生。

### 4.5 inbox/read：函数在，入口不在

- `team-tools.js` `inboxFor({projectName, role, all})`：`withBootToken` + `team.mjs inbox --boot … --all --json`，返回 `messages[]`。实现是对的。
- `src/main.js` 没有 `ipcMain.handle('team:inbox')`；`src/preload.js` 没有 `teamInbox`；`src/renderer/app.js` 没有调用；`src/renderer/index.html` 没有收件箱 DOM。
- `readFor` 完全不存在；`team.mjs read` 没有被任何 JS 调用。
- 结果：旧邮箱 392 封（PM 59 new + 148 cur）在新壳里是“只写不读”的账本；`team:send` 的本地镜像反而成了 UI 的“真相”。

### 4.6 ack：身份已核验，执行者仍是壳

S6 的 `team:ack` 流程：

1. 从 `project.messages` 找本地消息（不是从邮箱找）。
2. `manual===true` → 只写 `manualAck`，不动旧锁；这是正确的人工通道。
3. `verifyProjectRoleSession(project, message.to, claimedSession)`：
   - `project.sessions[role]` 必须存在；
   - `claimedSession` 若传，必须等于映射；
   - `dsh.listSessions()` 必须能找到、未归档；
   - `workspaceId/sessionIds/cwd` 三选一必须属于当前项目。
4. `syncRoster(teamName, project.sessions)`：把 `团队.json` 名册同步成当前项目快照（修 H5）。
5. `teamTools.ackDispatch({projectName, role, messageId, note, sessionId: mappedSession, identitySource:'verified-session', workspaceId, checkedAt})`：
   - `withBootToken()` 在壳里 boot；
   - `team.mjs ack --boot … --id … --note … --json`；
   - `annotateReceiptIdentity()` 把 `sessionId/role/identitySource/workspaceId/identityCheckedAt` 补进 `回执.jsonl` 对应行。
6. 本地 `message.ack=true`、`ackSource='team'`、`ackSessionId`、`identitySource`，`mirrorToTeamBoard()`。

**判定**：身份核验（H3）已从“本地字符串”升级为“DSH 会话 + workspace 归属”，这是真进步；但**执行者仍是主进程**。`回执.jsonl` 的 `identitySource:'verified-session'` 只说明“壳核验了这个会话”，不说明“这个会话执行了 ack”。要严格照旧版，必须让角色会话自己执行 `ack`，或至少在回执里写 `actor:'workbench-shell'`，不能写 `identitySource` 冒充角色执行。

### 4.7 锁：旧锁 + 新锁并存，超时是新造的

- 旧锁：`team.mjs send` 写的 `状态/项目/<slug>/派单锁.json`。
- 新锁：`project.pendingAck` / `pendingAckAt`（本地 `workbench.json`），只在 `sessionId && pmDispatch` 时置。
- 新壳在 `team:send` 开头若 `pendingAck` 过期（10 分钟）→ `releaseDispatchLock(旧锁)` + `clearPendingAck`；若未过期 → 抛“还有一条派单未回执”。
- 新壳在 `team:ack` 里若回执的不是当前 `pendingAck` 且已过期 → 释放旧锁 + 清本地。
- 新壳在唤醒失败时释放旧锁 + 清本地（旧版**保留**锁）。
- 新壳在 `team:cancel` 里即使本地 `pendingAck` 为空，也读 `派单锁.json` 并按 `messageId` 释放（S6 已修 H4 的一半）。
- **没有 `--force` 等价入口**：旧版 `--force` 可以强行发下一条（覆盖锁）；新壳只能等超时/撤销。

### 4.8 流程：本地 8 阶段 vs 旧 UI 10 节点

- 旧 `STAGES` 的**事实**：UI 画 10 个 `.flow-node[data-stage]`（`pm-intake/requirement/review/bossreview/dispatch/dev/devreview/test/close/iterate`），但 `computeWorkflow()` 只返回 `intake/requirement/review/bossreview/dispatch/dev/test/close/iterate/unknown`；`devreview` 是“画出来但没有判据”的节点。做对齐时不要为了凑 10 个而编一个 `devreview` 判据；要么照旧保留空节点，要么显式加判据并说明这是新规则。

- `STAGES`（`main.js` 顶部）：`intake/requirement/review/owner/dispatch/dev/test/close`；缺 `devreview`、`iterate`。
- `deriveStage(project)`：`!tasks → intake`；`owner.rejected → requirement`；`owner 未决 → owner`；`proposal.status==='review' → review`；`全部 done → close`；`tester 未完成 → test`；`programmer 未完成 → dev`；否则 `dispatch`。
- `workflowSnapshot(project)`：`ownerReview` 读本地 `project.ownerReview`；`roundKey = project.id|需求数|任务数|进行数`。
- `workflow:get`：`readStore()` + `pickProject()`，不读 `工作流.json`。
- 没有 `fs.watch`，没有 `workflow:changed`；`preload.js` 没有 `onWorkflow`。
- 渲染层 `FLOW_ROWS` 8 节点，没有 `devreview/iterate`；`#flow-panel` 是页内浮窗，但数据来自本地 store。

### 4.9 Owner：落账已补，闸门未补

S6 的 `team-tools.js`：

- `writeOwnerWorkflow(project, input)`：`团队/状态/项目/<slug>/工作流.json` 写 `ownerReview{required:true,status,by,at,roundKey,opinion}`；项目未登记时返回 `NO_TEAM_PROJECT`，不阻断本地。
- `recordOwnerDecision(project, input)`：写文件后 `runNode(owner-note.mjs, [name,status,opinion,roundKey])`，返回 `notified`/`warning`。
- `main.js workflow:owner` 与 `owner:decide` 都调用它。

仍缺：

- `openOwnerModal()` `closable:true`，关闭只 toast；旧版 `closable:false`。
- **没有自动闸门**：`app.js` 启动注释明确“Owner 不自动弹窗”，只剩 `#btn-owner-quick / #btn-owner / #btn-stage-owner / #btn-flow-owner` 手动入口；旧版在 `stage==='bossreview'` 自动弹，并按 `roundKey` 每轮一次。
- UI 调 `window.workbench.ownerDecide(...)`，不是 `workflowOwner`；虽然 S6 两边都落账，但两条路径会漂移。
- 没有 `#flow-owner-state`：旧 `renderer/app.js:1755-1758` 也查这个 id，但旧 `index.html` 里实际不存在（PARITY-ROUND5 §0 已记）；新壳也没有。补它是增强，不是“还原旧 DOM”。Owner 状态目前只在 `#owner-badge`/`#owner-summary`。

### 4.10 看板：窗口能力刚接上，入口还是系统浏览器

S6（07:15）新增：

- `team:board-old`：1120×780、`frame:false`、`alwaysOnTop:true`、`opacity:0.97`、`preload: src/preload.js`、`additionalArguments:['--awb-board']`；复用窗口也 `loadFile`（修 M6）。
- `preload.js` 在 `--awb-board` 下暴露 `window.boardWin.control/refresh/openFile/selectProject`。
- `team:board-control`（collapse/expand/zoom/maximize/refresh/close）、`team:board-refresh`、`team:board-select-project`、`team:board-file`（`readBoardFile` 限制在当前项目目录）。
- `team:board-project` 仍只生成、不 reload 窗口（旧版会 reload+focus）。

仍缺：

- `team:board`（不是 `team:board-old`）仍 `shell.openPath(result.boardPath)`（S6 约 2692 行）→ 从 `#btn-team-board` 旧入口走会打开系统浏览器，不是浮窗。
- 尺寸/透明度与旧版有差：`minWidth 440` vs 旧 300；`opacity 0.97` vs 旧 0.94；`transparent` 没有设置。
- `team:board-project` 未复用 `teamBoardWindow.loadFile`；旧入口会以为“切了项目”，实际窗口没 reload。
- `#team-board-summary`：S6 07:19 已加 `boardUi`/`boardMatchesProject`，当前项目有 `team:board` 结果时用本项目；只有 `team:status` 全局 `看板.json` 时才要求“同名”才显示。剩余：`teamTools.teamStatus()` 本身仍只返回全局 `看板.json`，别让其它调用者直接拿 `status.board` 当“当前项目”。

### 4.11 账本根：代码没接，拷贝是临时的

- `team-tools.js:createTeamTools()`：`const initialRoot = options.teamRoot || process.env.TEAM_ROOT || path.join(repoRoot(),'团队')`；没有 `WB_WORKBENCH_DIR`，没有旧根探测。
- `main.js` 只在 `--selftest` 时把 `TEAM_ROOT` 指到沙盘。
- 07:05 的拷贝让 `team:workspaces` 现在能看到 6 个登记（4 个目录存在：六人敏捷工作区/团队工作台改造/微光作品集/测试工作台项目；2 个不存在：个人博客项目/个人简历展示项目）。
- 旧 `工作台\团队\状态` 仍是 6 个登记、392 封邮件、86 KB 回执；新旧两本账从 07:05 起独立。

---

## 5. “壳进程代跑 / 本地镜像”精确清单

### 5.1 一张图

```text
旧版（角色执行）
  role session ──boot──▶ 启动/<token>.json
       │
       ├──send──▶ 邮箱/<to>/new/M-*.json + 派单锁.json ──prompt(四步)──▶ 目标 role
       │                                                                   │
       │                                                                   ├─boot
       │                                                                   ├─inbox --all
       │                                                                   ├─read（new→cur）
       │                                                                   └─ack
       │                                                                         │
       └──────────── 回执消息 type=receipt + 回执.jsonl + 清派单锁 ◀────────────┘

新壳（主进程执行）
  main ──spawn boot──▶ token cache
    │
    ├──spawn send --no-wake──▶ 邮箱 + 派单锁
    ├──dsh.prompt(一句话)──▶ 目标 role（不知道该 boot/inbox/read/ack）
    └──人点“记录回执”──▶ main ──spawn boot+ack──▶ 回执.jsonl + 回执消息
                              └──本地 message.ack=true（UI 的“回执”真相）
```

### 5.2 逐项证据

**先给结论**：整条链里，只有“第 3 步写邮箱”和“回执回信（`team.mjs ack` 内部的 `sendMessage`）”是旧工具真做的；第 1 步 boot、第 6 步 ack 是壳 spawn；第 4/5 步 inbox/read 根本没有入口；第 8/9 步消息与锁的“真相”在本地 `workbench.json` 又有一份。下表逐项拆。

| # | 壳代跑/镜像点 | 代码 | 它实际做了什么 | 用户可见后果 |
|---:|---|---|---|---|
| M1 | 启动令牌 | `team-tools.js bootToken()/withBootToken()`；`sendDispatch/ackDispatch` | 主进程 spawn `team.mjs boot`，缓存令牌 | 事件里的 `boot` 不是角色会话产生的；角色没拿到令牌 |
| M2 | 派单写邮箱 | `sendDispatch()` + `--no-wake` | 真写邮箱/旧锁；主进程不再让工具唤醒 | 邮箱是真的，但收件角色没收到四步 |
| M3 | 唤醒 | `main.js team:send` `dsh.prompt` 一句话 | 只发主题+正文+“完成后回执” | 角色不会 boot/inbox/read/ack；回执只能人点 |
| M4 | 收件箱 | `inboxFor()` 无 IPC/UI | 函数可读旧邮箱，但没人调 | 旧邮件/PM 邮件在 UI 不可见 |
| M5 | 已读 | 无 `readFor` | `team.mjs read` 从未被调用 | 邮件永远在 `new/`；`阅读.jsonl` 不增 |
| M6 | 回执执行 | `team:ack` + `ackDispatch()` | 主进程 spawn `boot+ack`，用映射 session 写 `回执.jsonl` | “回执”不是角色回的；`identitySource` 可能被误读 |
| M7 | 回执回信 | `team.mjs ack` 内部 `sendMessage(type:'receipt')` | 真写发件人邮箱 | UI 不读回；发件人只有在 DSH 里 boot 才看得到 |
| M8 | 本地消息 | `pushProjectMessage()` 仅 `team:send` 两处 | 只镜像“UI 发出的”消息 | CLI/角色发的、回执消息、旧历史都不可见 |
| M9 | 本地锁 | `project.pendingAck` + `ACK_TTL_MS` | 10 分钟 TTL、自动释放、唤醒失败释放 | 与旧锁并存；旧协议没有 TTL；`--force` 无等价 |
| M10 | 降级回执 | `team:ack` 的 `team-local` 分支 | 旧协议失败时仍 `message.ack=true` + 本地回执 + 尝试释放旧锁 | “本地回执”与“旧协议回执”在 UI 上都叫已回执 |
| M11 | 流程 | `deriveStage/workflowSnapshot` | 读 `workbench.json.tasks` | 团队 `任务/工作流/需求/提交` 改了，UI 不变 |
| M12 | 看板摘要 | `teamTools.teamStatus()` + `renderBoardSummary()` | S6 07:19 已按 `boardUi`/`boardMatchesProject` 兜底；`teamStatus()` 仍返回全局 `看板.json` | 直接用 `team:status.board` 的调用者仍可能看到别的项目；UI 已有“同名才显示”的保护 |
| M13 | Owner | `owner:decide` / `workflow:owner` | S6 都写 `工作流.json` + `owner-note`；但 UI 仍走 `owner:decide`、`closable:true`、不自动弹 | 双入口；`bossreview` 不再自动弹；关闭弹窗后本轮不再提醒 |
| M14 | 看板入口 | `team:board` | `shell.openPath` | 从旧入口点“看板”会打开浏览器，不是浮窗 |

> 说明：M1/M6 的“壳代跑”不是 bug 本身，而是**过渡形态**。真正的问题是它没有在 UI/回执里标明 `actor:'workbench-shell'`，也没有在唤醒里教角色自己走；只要唤醒四步 + 收件箱补上，M1/M6 就可以逐步退化为“兜底”。

---

## 6. 补齐顺序（可执行）

> 依赖顺序：**0 账本根 → 1 唤醒四步 → 2 收件箱/已读 → 3 回执执行者 → 4 锁 → 5 流程 → 6 Owner → 7 看板 → 8 清理/自检**。
> 每一节都给“文件 / 函数 / 选择器 / 验收”。如果 S6 之后已被并行实现，只做该节的“验收”，不要重复造。

| 顺序 | 项 | 依赖 | 完成标志（可验收） |
|---:|---|---|---|
| 0 | P6-01 账本根 | 无 | `team:status.teamRoot` 可见；旧/新根不静默混用；悬空 current 为 null |
| 1 | P6-02 唤醒四步 | 无（可与 0 并行） | prompt 文本含 `boot/inbox/read/ack/task claim`；角色事件出现 boot→read→ack |
| 2 | P6-03 收件箱 IPC | 1 可选 | `team:inbox(pm)` 返回旧邮件；read 后 `new→cur` |
| 3 | P6-04 发件人读回 | 2 | 团队台能看到 mailbox 消息，且不写回 store |
| 4 | P6-05 回执执行者 | 1+2+3 | UI 人工确认不再冒充 ack；`回执.jsonl` 有 `actor` |
| 5 | P6-06 锁 | 4 | 旧锁不被 TTL 静默删；cancel 可释放；`--force` 等价 |
| 6 | P6-07 流程 | 0 | `workflow:get` 读团队状态；10 节点；`workflow:changed` |
| 7 | P6-08 Owner | 6 | 不可关、按 roundKey、只一个写入口、PM 收到 owner-review |
| 8 | P6-09 看板 | 0/6 | `team:board` 开浮窗；折叠/切项目/预览可用；摘要按项目 |
| 9 | P6-10 清理/自检 | 1–8 | 死接口清零；selftest 覆盖 6 条断言 |

**如果只能先做三件事**：P6-02（唤醒四步）→ P6-03（收件箱/已读）→ P6-05a（回执标 `actor`）。这三件不改数据模型，能立刻把“角色不回执、PM 看不到邮件、壳冒充角色”三个现象分开。

### P6-01 账本根：先决定“指向旧根”还是“显式迁移”

**为什么先做**：所有消息/回执/看板/流程都读同一个 `TEAM_ROOT`；根不对，后面全是空账本或两本账。

**文件/函数**：

- `src/team-tools.js` `createTeamTools()` 的 `initialRoot` 解析；
- `buildLayout()` 增加 `rootSource`；
- `src/main.js` `team:status` / `team:workspaces` / `syncTeamProject()`；
- `src/renderer/app.js` `renderTeamWorkspace()`（加一行“账本根”）。

**改法（二选一，推荐 A）**：

A. 指针模式：

```js
const initialRoot =
  options.teamRoot ||
  process.env.WB_WORKBENCH_DIR && path.join(path.resolve(process.env.WB_WORKBENCH_DIR), '团队') ||
  process.env.TEAM_ROOT ||
  detectLegacyTeamRoot() ||                 // 存在 <...>/团队/状态/团队.json 才算
  path.join(repoRoot(), '团队');
// layout.rootSource = 'option' | 'env-wb' | 'env-team' | 'legacy' | 'repo'
```

- 启动时在 `team:status` 返回 `teamRoot/rootSource`；`renderTeamWorkspace()` 显示“账本根：…（旧根/仓库副本）”。
- 如果 `当前工作区.json.path` 不存在：`current` 返回 `null`，并在 UI 显示“指针悬空，请恢复项目”，不要让 `activeProject` 指向空目录。

B. 迁移模式：

- 首次启动检测旧根 + 仓库根都为空/不一致 → 弹“导入旧账本”确认；复制 `状态/{团队.json,项目,邮箱,回执.jsonl,事件.jsonl,阅读.jsonl,启动}` 到仓库根，保留 `migration.json`（来源/时间/文件数/哈希）。
- 不做静默复制；不覆盖已有非空新账本。

**验收**：

```powershell
# 根与来源
Select-String -Path src\team-tools.js -Pattern "WB_WORKBENCH_DIR|rootSource|detectLegacy"
# 旧根/新根计数
(Get-ChildItem D:\deepseek\工作台\团队\状态\邮箱 -Recurse -File).Count   # 392
(Get-ChildItem D:\deepseek\agile-workbench\团队\状态\邮箱 -Recurse -File).Count # 392（若复制）
# 悬空指针
node -e "const j=require('D:/deepseek/agile-workbench/团队/状态/当前工作区.json');console.log(j.path, require('fs').existsSync(j.path))"
```

- `team:workspaces` 至少列出 4 个真实目录；`current` 只在目录存在时为非 null；`team:status.teamRoot` 与 `teamTool` 实际使用的 `TEAM_ROOT` 一致（`_paths()` 对照）。

**回滚**：`teamRoot` 解析加环境变量开关；迁移模式失败时保留 `migration.json` 和原目录，不删任何文件。

### P6-02 唤醒四步：一处文本，先让角色动起来

**文件/函数**：

- `src/main.js` `team:send` 的 `await dsh.prompt(...)`；
- 建议抽 `buildDispatchWakeText({project, teamName, message, to, taskId, teamToolPath})`，放在 `team:send` 上方或 `team-tools.js` 导出。

**改法**：逐字采用旧 `ops.mjs:392-399` 的模板（见 §2.2），只把变量换成本项目的：

```js
const text = [
  `这是派单，不是通知：${message.id}（${message.subject}）。${taskId ? `\n任务：${taskId}` : ''}`,
  `先读 ${path.join(project.path, '项目铁律.md')}（每轮都读），再读项目信息/项目索引/你的文件索引与角色卡。`,
  `现在必须完成，不要只回“收到”：`,
  `1) node "${teamTools.layout.teamTool}" boot --role ${to} --project "${teamName}"`,
  `2) 用 boot 输出的令牌执行 inbox --all，再 read --id ${message.id}`,
  `3) 本条要回执：ack --id ${message.id} --note "已收到 ${taskId || '任务'} + 边界"`,
  `${taskId ? `4) task claim --id ${taskId}\n` : ''}`,
  `最后只回一行：已回执/已认领的角色 + 任务 id；不要输出方案，不要巡检全队。`
].filter(Boolean).join('\n');
```

- 保留 `dsh.prompt` 的 `mode:'queue'`（适配层已是 queue）。
- 记 `wake.textKind='protocol-four-step'`，方便自检断言。

**验收**：

- 静态：`Select-String src\main.js -Pattern "boot --role|inbox --all|ack --id|task claim"` 四处都在同一段文本。
- 运行时（mock DSH 或真实）：派单后抓 `session/prompt` 的 `content[0].text`，必须含四个命令 + 项目铁律路径 + 工具绝对路径。
- 角色侧（真实）：目标会话跑完一轮后，`事件.jsonl` 应新增同一 `sessionId` 的 `boot` → `mail_read` → `ack`，且 `回执.jsonl` 出现 `A-*`、`派单锁.json` 消失。

**回滚**：只改文本，回滚即还原字符串；不影响已写邮箱。

### P6-03 收件箱/已读 IPC：把旧邮箱接回 UI

**文件/函数**：

- `src/team-tools.js`：`inboxFor()` 已有；新增 `readFor({projectName, role, messageId})`，调 `team.mjs read --boot … --id … --json`；两者都走 `withBootToken`。
- `src/main.js`：新增
  - `ipcMain.handle('team:inbox', …)`：`projectId` → `project.teamName` → `inboxFor({role, all})`；
  - `ipcMain.handle('team:read', …)`：`readFor(...)`；
  - 返回 `{ok, source:'team', role, messages, unread}`；失败保留 `code/message`。
- `src/preload.js`：`teamInbox: (p)=>invoke('team:inbox',p)`、`teamRead: (p)=>invoke('team:read',p)`。
- `src/renderer/index.html`：团队台 `#team-log` 之后加一块（选择器固定，便于自检）：

```html
<section class="team-block" id="team-inbox">
  <div class="team-block-head"><h3>收件箱</h3><span id="inbox-unread" class="muted">—</span></div>
  <div class="team-inbox-bar">
    <select id="inbox-role" class="select"></select>
    <label class="check-row"><input type="checkbox" id="inbox-all" checked><span>含已读</span></label>
    <button id="inbox-refresh" class="ghost small" type="button">刷新</button>
  </div>
  <div id="inbox-list" class="inbox-list"></div>
</section>
```

- `src/renderer/app.js`：`renderInbox(p)` / `loadInbox(role)`；`renderTeam()` 调用；`#team-pill` 显示 `pm` 未读数；每行 `[data-inbox-read="<id>"]`、`[data-inbox-ack="<id>"]`；read 后 `loadInbox`；ack 走 `teamAck`（或 P6-05 的角色通道）。

**验收**：

```powershell
# 用旧账本/拷贝账本，PM 应有 new=59, cur=148
node -e "const fs=require('fs');for(const b of ['new','cur'])console.log(b,fs.readdirSync('D:/deepseek/agile-workbench/团队/状态/邮箱/pm/'+b).length)"
```

- 打开团队台 → 收件箱默认 `pm` → 列表 59 条 new + 148 条 cur（勾“含已读”）。
- 点一条 `[data-inbox-read]` → 该文件从 `new/` 进 `cur/`，`事件.jsonl` 新增 `mail_read`，列表少一条。
- `inboxFor` 的调用不再只出现在 `team-tools.js`（grep 到 `main.js`）。

**回滚**：新增块默认 hidden；IPC 失败只显示空态，不影响现有团队台。

### P6-04 发件人读回：把“回执消息/CLI 消息”并进团队台

**问题**：`renderTeamLog()` 只读 `p.messages`，而 `p.messages` 只镜像 UI 发出的消息。PM 邮箱里的 59 条新消息、角色 CLI 发的消息、回执消息都不在。

**改法**：

- 不改 `workbench.json` 存储；把收件箱数据作为**只读投影**：

```js
// app.js
const mailbox = inboxUi.byProject[p.id] || [];
const all = [...(p.messages || []), ...mailbox.map(m => ({...m, source: 'mailbox'}))]
  .filter(dedupe by id)...
```

- `renderTeamLog` 行上标 `mailbox`/`local`/`receipt`；点开显示正文；`ackRequired` 的行给“去收件箱”按钮。
- 不要反向写 `workbench.json`；否则又造第二份真相。

**验收**：用 CLI/旧角色给 PM 发一条 `M-…`，刷新团队台 → 该消息出现在日志（来源 `mailbox`），但 `workbench.json.messages` 不增加。

**回滚**：投影只影响渲染；删掉合并即可。

### P6-05 回执执行者：先标真相，再谈角色侧

**分两步，避免“假角色回执”**：

**5a（立即，低成本）**：

- `team-tools.annotateReceiptIdentity(ackId, identity)` 增加 `actor` 字段：`identity.actor || 'workbench-shell'`；写进 `回执.jsonl` 行。
- `main.js team:ack` 返回 `ackActor`；`app.js openAckModal` 显示“执行者：工作台壳（过渡）”或“角色会话”。
- `team:send`/`team:ack` 的返回都带 `actor`，自检可断言。
- **不要**再把 `identitySource:'verified-session'` 当成“角色执行”；它只代表“会话归属已核验”。

**5b（P6-02 + P6-03 完成后）**：

- UI 的“记录回执”默认只走 `manual:true`（只写 `manualAck`，不动旧锁）。
- 真正的 `ack` 由角色会话执行（它已收到四步）；`team:ack` 只保留兼容入口，且要求同一 `sessionId` 的 `boot` 事件先于 `ack`（旧协议的事件链证据；注意这仍不是密码学证明，壳理论上仍可伪造，所以 UI 文案要写“事件链显示”而不是“已证明”）。
- 若产品决定保留壳代跑，必须在 `回执.jsonl`/UI 双处标 `actor:'workbench-shell'`，并在 `identitySource` 里写 `verified-session-by-shell`，不能写 `role-session`。

**验收**：

- 人点“记录回执” → `回执.jsonl` 不新增（或新增 `local:true` 行），`派单锁.json` 不变，`message.manualAck=true`。
- 角色执行 `ack` → `回执.jsonl` 新增 `A-*`，`actor:'role-session'`，旧锁消失。
- 删除 DSH 会话后再点 ack → `SESSION_IDENTITY_MISSING`；归档 → `SESSION_IDENTITY_ARCHIVED`；换项目会话 → `SESSION_IDENTITY_MISMATCH`（S6 已实现，补断言即可）。

### P6-06 锁：把“超时”从协议里拿掉，把“残留释放”留下

**文件/函数**：

- `src/main.js`：`ACK_TTL_MS`、`pendingAckExpired()`、`reconcileExpiredLocks()`、`team:send` 开头过期分支、`team:ack` 的过期分支、唤醒失败分支；
- `src/team-tools.js`：`readDispatchLockState()`、`releaseDispatchLock()`（S6 已有）；
- `src/renderer/app.js`：`renderDispatch()`、`#dispatch-pending`、`#dispatch-cancel`。

**改法**：

1. **不自动删旧锁**：`pendingAckExpired` 只返回 `stale:true`，不 `releaseDispatchLock`、不 `clearPendingAck`；UI 在 `#dispatch-pending` 显示“旧锁已超 10 分钟（只是展示，不自动释放）”，并给 `#dispatch-force-release`（二次确认）。
2. **显式释放**：`team:cancel` 已有“按旧锁 messageId 释放”的逻辑（S6）；保留它作为唯一释放路径；`#dispatch-cancel` 在没有 `pendingAck` 但 `readDispatchLockState` 有锁时也要显示。
3. **唤醒失败**：旧版保留锁；新壳若要释放，必须在 `team:send` 返回 `lockReleasedBy:'wake-failure'` 并写事件；默认建议**不释放**，让用户看到锁并手动撤销，避免“静默清锁”。
4. **`--force` 等价**：加 `#dispatch-force-send`（确认后带 `force:true` 传给 `sendDispatch` → `team.mjs send --force`），而不是新造一个“跳过本地锁”的私有路径。
5. **本地锁与旧锁对账**：`statePayload()` 每个项目加 `dispatchLock: readDispatchLockState(teamName)`；`renderDispatch` 优先显示旧锁（真相），本地 `pendingAck` 只作投影。

**验收**：

- 模拟目标无会话：发送后 `派单锁.json` 存在；10 分钟后不会被删；`#dispatch-pending` 显示锁 id；点撤销 → 锁消失；再发成功。
- 模拟降级 ack（旧协议 `MESSAGE_NOT_FOUND`）：`回执.jsonl` 不新增 `A-*`；旧锁不被静默删；UI 显示“本地确认，旧锁未释放”。
- `--force`：旧锁被新消息覆盖，且 `事件.jsonl` 有 `force` 标记。

### P6-07 流程：读团队状态，10 节点（devreview 照旧空节点），文件推送

**文件/函数**：

- `src/main.js`：新增 `computeTeamWorkflow(project)`（旧 `computeWorkflow` 的等价物），读
  `teamTools.layout.projectsDir/<slug>/工作流.json`、`任务/*.json`、`project.path/需求/R-*.md`、`提交/*.json`；
  `workflowSnapshot()` 改为优先 `computeTeamWorkflow`，本地 store 只做 fallback；
  `workflow:get` 用它；`workflow:owner` 写完后广播。
- `startFlowWatch()`：`fs.watch(teamStateDir, {recursive:true})` + 220 ms 去抖；切项目时 `close()` + 重建；向主窗口和看板窗口 `webContents.send('workflow:changed')`。
- `src/preload.js`：`onWorkflow(cb)`（旧 `preload.js:39` 的形状）。
- `src/renderer/app.js`：`FLOW_ROWS` 改 10 节点；`#flow-panel` 节点 `data-stage` 用旧 id（`pm-intake/requirement/review/bossreview/dispatch/dev/devreview/test/close/iterate`）；订阅 `onWorkflow`；`renderFlow()` 读 `state.workflow` 或 `workflow()` 返回，不再只用 `p.tasks`。
- `STAGES` 补 `devreview`、`iterate`；`deriveStage` 对齐旧顺序（先 test，再 dev，再 bossreview，再 iterate，再 close，再 review，再 dispatch）。`devreview` 照旧只画节点、不编判据；`iterate` 用旧判据（owner 任务全完且剩余任务无 owner）。
- **一个必须明说的选择**：旧顺序“先 test 再 dev”是 QA5-M3 判过的顺序 bug（开发/测试同时未完成时显示“测试”）。如果目标是“严格照旧”，就保留它并在文档里标注已知 bug；如果目标是“修对”，就改成 dev 先，但不要再宣称逐字对齐。二者只能选一个。

**验收**：

```powershell
Select-String -Path src\main.js -Pattern "fs\.watch|workflow:changed|computeTeamWorkflow"
Select-String -Path src\renderer\app.js -Pattern "devreview|iterate|onWorkflow"
```

- 改 `工作流.json` 的 `ownerReview.status` → 1 秒内 `#flow-panel` 的 `[data-stage="bossreview"]` 高亮变化（不刷新页面）。
- 新建任务/提案 → 阶段变化与旧 `computeWorkflow` 一致；`review` 能通过“提案评审中”到达。
- `#flow-panel .flow-node` 数量 = 10；`#flow-meta` 有需求/任务/进行/提交计数。

### P6-08 Owner：不可关、按轮次、只留一个入口

**文件/函数**：

- `src/renderer/app.js`：`openOwnerModal()`、`render()` 的自动弹条件（当前没有）、`#owner-badge/#owner-summary`；
- `src/main.js`：`owner:decide` / `workflow:owner`（二选一）；
- `src/renderer/index.html`：`#owner-badge`、`#owner-summary`；`#flow-owner-state` 可补，但旧 DOM 里本来就没有这个 id（旧 JS 是空查询），补它属于增强。

**改法**：

1. `closable:false`；`onClose` 不删本轮标记；只允许“跳过/开始/通过/打回”。
2. 恢复 `bossreview` 自动弹：在 `render()`（或 `applyState` 之后）判断 `p.stage==='owner' && !modalOpen`；用 `Map<projectId, roundKey>` 去重（`ownerPrompted.get(p.id) !== roundKey`）；`roundKey` 来自 `workflowSnapshot(p).roundKey`。不要沿用“只在启动时手动点入口”。
3. UI 调 `workflowOwner({projectId, decision, opinion, roundKey})`；删除 `owner:decide`（或让它内部转调 `workflowOwner` 并标 deprecated），只留一条写路径。
4. 结果 toast 显示 `notified.message.id`；失败显示 `warning.code`；`#flow-owner-state` 显示 approved/skipped/rejected/pending/optional。
5. 保留 S6 的 `recordOwnerDecision`（写 `工作流.json` + `owner-note`）；不要在前端写文件。

**验收**：

- 弹窗右上角无关闭；点遮罩不关；Esc 不关。
- 通过后 `工作流.json.ownerReview` 的 `roundKey` 等于 `workflowSnapshot.roundKey`；`邮箱/pm/new` 新增 `type:'owner-review'`、`ackRequired:true`。
- 下一轮任务/需求数变化 → `roundKey` 变 → 再次弹。
- 直接调 `owner:decide` 不再产生第二套记录（或返回 deprecated）。

### P6-09 看板：入口统一到浮窗，摘要按项目

**文件/函数**：

- `src/main.js`：`team:board`、`team:board-project`、`team:board-old`、`openTeamBoard`（可把 `team:board-old` 的建窗逻辑抽成 `openTeamBoard(project)`）；
- `src/team-tools.js`：`teamStatus(projectId?)`、`generateBoard()`；
- `src/renderer/app.js`：`renderBoardSummary()`、`openTeamBoardOld()`、`#team-board-summary`。

**改法**：

1. `team:board` 不再 `shell.openPath`；改为 `generateBoard` + `openTeamBoard`；保留 `payload.open===false` 的纯生成模式。
2. `team:board-project` 在窗口存在时 `loadFile(boardPath)` + `show` + `focus`；不存在时 `openTeamBoard`。
3. `team:board-old` 与 `team:board` 共用建窗函数，尺寸/透明度对齐旧版：1120×780、`frame:false`、`transparent:true`、`opacity:0.94`、`minWidth:300/minHeight:64`、`alwaysOnTop('floating')`。
4. `teamStatus(projectId)` 读该项目自己的 `看板.json`（或调 `generateBoard` 后读 `看板.json` 的 summary）；`renderBoardSummary` 用 `team:status({projectId})`，切项目重新拉。
5. 看板 preload 的契约（S6 已接）保留：`window.boardWin.control/selectProject/openFile`；`team:board-file` 只读、限当前项目目录（S6 实际是文本 512 KB / 图片 8 MB；旧版是统一 4 MB，若要逐字对齐再改常量）。

**验收**：

- 点 `#board-launcher` → Electron `BrowserWindow`（不是系统浏览器）；`isAlwaysOnTop()===true`。
- `[data-win="collapse"]` → 高度 56；`[data-win="expand"]` → 恢复；`[data-win="close"]` → 窗口关闭。
- `#project-select` 切项目 → 看板内容变，但 `当前工作区.json` 不变。
- 点 `.file-link` → 抽屉预览；`.md` 显示文本，图片显示 `<img>`。
- 切到项目 C 后 `#team-board-summary` 的计数来自 C：S6 07:19 的 `boardMatchesProject` 已能在“全局 board 不是当前项目”时显示提示；要彻底按项目，补 `teamStatus(projectId)` 或始终先 `team:board-project` 生成。

### P6-10 清理死接口与自检

**删除/降级**：

| 项 | 位置 | 处置 |
|---|---|---|
| `dsh:prompt` 任意唤醒 | `main.js` `ipcMain.handle('dsh:prompt')`；`preload.dshPrompt`；`app.js openWakeModal` | 删除，或限制为“非协议文本”，且不产生消息/锁 |
| `provisionDirect` 兜底 | `main.js provisionDirect()` / `provisionTeamSessions()` 的 `if (!tool.available) return provisionDirect(...)` | 删除兜底；工具缺失报 `TOOL_MISSING` |
| `owner:decide` | `main.js` / `preload.js` / `app.js` | 并入 `workflow:owner`，只留一个 |
| 本地四列看板/整页流程 | `#view-board` / `#view-flow` | 保留为“投影页”可以，但不能作为一级真相；流程主入口用 `#flow-panel`，看板主入口用浮窗 |
| `renderBoardSummary` 全局 `看板.json` | `team-tools.teamStatus()` | S6 07:19 已按项目兜底；可选给 `teamStatus(projectId)` 收口 |

**自检断言**（加到 `selftest` / `selftestFlow`）：

1. `SELFTEST_FLOW`：派单后 `邮箱/<role>/new` 有 `M-*`；`派单锁.json` 有且仅有一条；`回执.jsonl` 在角色 ack 后新增 `A-*`；旧锁消失；发件人邮箱收到 `type:'receipt'`。
2. `SELFTEST_INBOX`：`team:inbox(pm)` 返回 `new>0`；`team:read` 后 `new` 减 1、`cur` 加 1、`事件` 有 `mail_read`。
3. `SELFTEST_WAKE`：mock DSH 捕获的 prompt 文本含 `boot --role`、`inbox --all`、`read --id`、`ack --id`、`task claim`。
4. `SELFTEST_OWNER`：`workflowOwner` 后 `工作流.json.ownerReview.roundKey` 存在；`邮箱/pm/new` 有 `owner-review`；弹窗不可关（静态断言 `closable:false`）。
5. `SELFTEST_FLOW_WATCH`：改 `工作流.json` → 收到 `workflow:changed`；`#flow-panel .flow-node` = 10。
6. `SELFTEST_BOARD`：`team:board` 产生窗口；`isAlwaysOnTop`；折叠高度 56；`#project-select` 不改变当前项目。

**验收命令**：

```powershell
npm run check
npm run selftest   # 或现有 Electron selftest 入口
```

---

## 7. 复核命令（只读；按符号查，不按行号）

```powershell
# 0) 当前快照（先记录，防止边改边审）
Get-ChildItem D:\deepseek\agile-workbench\src -Recurse -File -Include *.js,*.html |
  ForEach-Object { "{0} {1} {2}" -f (Get-FileHash $_.FullName -Algorithm SHA256).Hash.Substring(0,16), $_.Length, $_.Name }

# 1) boot 是否仍由壳代跑
Select-String -Path src\team-tools.js -Pattern "bootToken|withBootToken|sendDispatch|ackDispatch"
Select-String -Path src\main.js -Pattern "team:send|team:ack|团队派单"

# 2) 唤醒四步是否在
Select-String -Path src\main.js -Pattern "boot --role|inbox --all|ack --id|task claim|项目铁律"

# 3) 收件箱/已读是否接
Select-String -Path src\main.js,src\preload.js,src\renderer\app.js -Pattern "team:inbox|team:read|inboxFor|inbox-role|inbox-list"

# 4) 锁
Select-String -Path src\main.js -Pattern "ACK_TTL_MS|pendingAckExpired|reconcileExpiredLocks|releaseOldDispatchLock|LOCK_MISMATCH"
Select-String -Path src\team-tools.js -Pattern "readDispatchLockState|releaseDispatchLock"

# 5) 流程
Select-String -Path src\main.js -Pattern "工作流\.json|fs\.watch|workflow:changed|STAGES"
Select-String -Path src\renderer\app.js -Pattern "devreview|iterate|closable|workflowOwner|ownerDecide"

# 6) 看板
Select-String -Path src\main.js -Pattern "team:board-control|team:board-file|board-preload|alwaysOnTop|shell\.openPath\(result\.boardPath\)"
Select-String -Path src\preload.js -Pattern "boardWin|awb-board"

# 7) 账本根
Select-String -Path src\team-tools.js -Pattern "initialRoot|WB_WORKBENCH_DIR|rootSource|repoRoot"
Get-ChildItem D:\deepseek\工作台\团队\状态\项目,D:\deepseek\agile-workbench\团队\状态\项目 -Directory

# 8) 旧账本计数（对照用）
node -e "const fs=require('fs');for(const b of ['new','cur'])console.log('pm',b,fs.readdirSync('D:/deepseek/agile-workbench/团队/状态/邮箱/pm/'+b).length)"
node -e "const fs=require('fs');const r=fs.readFileSync('D:/deepseek/agile-workbench/团队/状态/回执.jsonl','utf8').trim().split(/\r?\n/);console.log('receipts',r.length)"
```

---

## 8. 已对齐、别回退 / 不要重复排期

**已经做对、不要回退**：

1. 真写旧邮箱：`team.mjs send` 的 `邮箱/<to>/new/M-*.json` 是旧协议文件，不是本地 JSON。
2. 会话身份核验：S6 的 `verifyProjectRoleSession()` 已查 `session/list` + 归档 + workspaceId/sessionIds/cwd，删掉了“只比本地字符串”。
3. 发件角色可配置：`#dispatch-from` 已渲染并传 `from`，`product→pm`、`tester→programmer1` 可发。
4. `manual` 通道：人工确认不冒充旧协议 ack、不清旧锁（`team:ack` 的 `p.manual===true` 分支）。
5. 撤销残留旧锁：S6 的 `team:cancel` 即使本地 `pendingAck` 为空，也能按 `派单锁.json.messageId` 释放。
6. Owner 落账：S6 的 `writeOwnerWorkflow()` + `recordOwnerDecision()` 已写 `工作流.json` + `owner-note`；不要另写一套。
7. 看板窗口：S6 已有 `preload + additionalArguments + team:board-control/file/select/refresh`；不要退回 `shell.openPath`。
8. `launch.mjs` 是六角色唯一创建者；不要恢复 `provisionDirect` 作为默认路径。

**不要重复排期（S6 已做/半做）**：

- 回执身份 `SESSION_IDENTITY_*`（已做，补断言）。
- 发件人 `from`（已做）。
- 跨项目名册（已加 `syncRoster(teamName, project.sessions)`，补“B 项目无会话必须拒绝”的断言）。
- 看板 preload/control/file（已做；摘要已按项目兜底，`team:board` 入口仍待接）。
- Owner `工作流.json` + `owner-note`（已做，补 `closable/roundKey/单入口`）。

**最容易做错的 4 件事**：

1. 把 `identitySource:'verified-session'` 当成“角色执行了 ack”——它只证明“壳核验了会话”。
2. 为了“不卡死”继续加 TTL 自动清旧锁——旧协议没有 TTL，清锁必须是显式动作（ack/cancel/force）。
3. 把收件箱数据写回 `workbench.json`——会造第三份真相；只做只读投影。
4. 在 `team:send` 里继续用一句 prompt——角色永远不会自己 boot/inbox/read/ack，后面所有“角色回执”都是假的。

---

## 9. 附录：符号索引（旧 → 新）

| 旧符号 | 旧文件 | 新符号（S6） | 新文件 | 状态 |
|---|---|---|---|---|
| `cmdBoot` / `createBootToken` / `requireBoot` | `ops.mjs:273` / `store.mjs:307,328` | `bootToken` / `withBootToken` / `verifyProjectRoleSession` | `team-tools.js` / `main.js` | 🟡 令牌真，执行者壳 |
| `cmdSend` / `sendMessage` | `ops.mjs:339` / `store.mjs:353` | `sendDispatch` + `team.mjs send --no-wake` | `team-tools.js` | ✅ 写邮箱 |
| 唤醒四步 | `ops.mjs:392-399` | `dsh.prompt` 一句话 | `main.js team:send` | ❌ |
| `cmdInbox` / `listInbox` | `ops.mjs:414` / `store.mjs:382` | `inboxFor`（无 IPC） | `team-tools.js` | ❌ 死代码 |
| `cmdRead` / `readMessage` | `ops.mjs:423` / `store.mjs:417` | 无 | — | ❌ |
| `cmdAck` / `ackMessage` | `ops.mjs:431` / `store.mjs:435` | `team:ack` + `ackDispatch` + `annotateReceiptIdentity` | `main.js` / `team-tools.js` | 🟡 壳代跑 |
| `writeDispatchLock` / `clearDispatchLock` | `ops.mjs:326,331` | `readDispatchLockState` / `releaseDispatchLock` + 本地 `pendingAck` | `team-tools.js` / `main.js` | 🟡 双锁 |
| `computeWorkflow` | `main.js:377` | `workflowSnapshot` / `deriveStage` | `main.js` | ❌ 本地 8 阶段 |
| `startFlowWatch` | `main.js:432` | 无 | — | ❌ |
| `workflow:owner` + `owner-note` | `main.js:452` / `owner-note.mjs` | `recordOwnerDecision` + `workflow:owner`/`owner:decide` | `team-tools.js` / `main.js` | 🟡 落账已补，闸门未补 |
| `openTeamBoard` / `team:board-control/file` | `main.js:247,599,624` | `team:board-old` + `team:board-control/file/select/refresh` | `main.js` / `preload.js` | 🟡 窗口已接，`team:board` 未接 |
| `WORKBENCH_DIR`/`TEAM_DIR` | `main.js:190-201` | `createTeamTools().layout`（默认 repo） | `team-tools.js` | ❌ 根未接 |

---

## 10. 最终判定（一句话）

**旧版最后跑通的是“角色自己 boot → 写邮箱 → 唤醒四步 → inbox/read/ack → 回执消息 + 回执.jsonl + 清派单锁”的完整文件协议；新壳已经把“写邮箱/身份核验/Owner 落账/看板窗口/撤销旧锁”补到可用，但“boot/ack 仍由壳进程执行、唤醒仍是一句话、收件箱/已读仍没有、流程仍读本地 8 阶段、账本根仍靠 07:05 的拷贝”这五处没有变。按 §6 的 P6-01→P6-10 顺序做，先换唤醒文本和收件箱，再让角色自己 ack，最后把流程/看板/Owner 接到团队状态；不要先动锁的 TTL，否则会把壳代跑固化。**

---

### 附：本轮只读边界声明

- 只读：`D:\deepseek\luanyujia-workbench\12-源码照搬\外壳\main.js`、`renderer\*`、`D:\deepseek\工作台\团队\工具\*`、`D:\deepseek\agile-workbench\src\*`、`docs\PARITY-ROUND5.md`、`docs\QA-ROUND5.md`、`docs\DSH-MODEL-AUDIT.md`。
- 唯一写入：本文件 `D:\deepseek\agile-workbench\docs\PARITY-ROUND6.md`。
- 未修改 `src/`、`package.json`、`团队/`、旧仓库、`D:\deepseek\工作台` 下任何文件。
- 写作期间 `src/main.js`、`src/team-tools.js`、`src/preload.js` 被并行修改（07:13–07:16）；本报告已把这些变化标成“S6 已出现/半接线”，落地前请按 §7 重新核对符号。
