# 第七轮 · 旧版“角色自己收件 / 已读 / 回执”完整拆解（只读）

> 范围：只回答六个问题——①发件写哪些文件、唤醒原文是什么；②收件角色 `boot/inbox/read/ack` 的参数与顺序；③回执怎么回到发件人；④派单锁怎么清；⑤旧 UI 怎么展示收件箱/未读/回执；⑥当前新壳还缺哪几个 IPC/函数/选择器。
> 只读边界：本轮**只写本文件**。未修改 `src/`、`package.json`、`node_modules`、`团队/`、旧仓库 `D:\deepseek\工作台`、`D:\deepseek\luanyujia-workbench`。
> 写法约定：旧版三份文件（`ops.mjs` / `team.mjs` / 旧壳 `main.js`）字节级稳定，行号可复现；**新壳行号必然漂移**，一律以“符号 + 选择器 + IPC 名”为准，行号只作定位提示。

---

## 0. 结论摘要（先看这 9 条）

1. **旧版“发件”只写 4 个文件**：`邮箱/<to>/new/<ts>-<M-id>.json`、`状态/事件.jsonl`、`状态/项目/<slug>/派单锁.json`（仅 PM 要回执时）、`状态/项目/<slug>/任务/<T-id>.json`（仅 PM 带 `--task` 且任务无 owner 时）。**不写** `回执.jsonl`、**不写** `阅读.jsonl`、**不新建**启动令牌。证据：`ops.mjs:339-411`、`ops.mjs:176-183`、`store.mjs:353-380`、`ops.mjs:326-330`、`ops.mjs:355-368`。
2. **唤醒文案是一条 7–8 行模板，不是“一句话”**：`ops.mjs:392-399`（带 `--task` 时 8 行，不带时 7 行），含 `这是派单，不是通知` → 读 `项目铁律.md` → `boot` → `inbox --all` + `read --id` → `ack --id --note` → `task claim` → `最后只回一行`。其中 `taskHint` 由 `ops.mjs:391` 拼入，`--note` 里的任务名回退为字面量“任务”。
3. **`boot` 是唯一发令牌的命令，30 分钟、文档一改即废**：`ops.mjs:273-316` + `store.mjs:307-326` + `store.mjs:328-345`。`inbox/read/ack/send/task` 全部先 `bootFor()`（`ops.mjs:36-41`），令牌角色/项目不符直接 `BOOT_ROLE_MISMATCH / BOOT_PROJECT_MISMATCH`。
4. **四步的语义顺序是 `boot → inbox → read → ack`，但“read”不是硬前置**：`ackMessage` 内部自己调 `readMessage`（`store.mjs:444`），所以只 `ack` 不 `read` 也能过，邮件会同时被移到 `cur/`。
5. **回执回到发件人靠“再发一封邮箱消息”，不是 UI 状态**：`store.mjs:458-473` 生成 `type:'receipt'`、`replyTo:原 id`、`ackRequired:false` 的消息写进 `邮箱/<原发件人>/new/`，并往 `回执.jsonl` **追加第二行** `{...ack, update:true, receiptMessageId}`。旧看板正是靠过滤 `update` 行去重（`ops.mjs:1361-1362`）。
6. **派单锁只在“收件角色 ack 同一条消息”时清**：`ops.mjs:435` → `clearDispatchLock`（`ops.mjs:331-337`）严格比较 `lock.messageId === 被 ack 的 id`。旧协议**没有 TTL、没有 cancel、唤醒失败也不释放**（`ops.mjs:400-408`）。
7. **旧 UI 根本没有收件箱/未读**（关键发现）：旧壳 `12-源码照搬/外壳/main.js` 的 IPC 表里没有 `team:send / team:ack / team:inbox`，`renderer/app.js` 里也没有任何收件箱 DOM；唯一叫“回执”的面板读的是 `工作台\协作\state.json`（collab.mjs 的另一套账），**不是** `回执.jsonl`。旧版看“邮件回执”的唯一界面是**看板浮窗**里的“四、回执（最近 50 条）”（`board.mjs:176/212`）。
8. **本轮审计期间，新壳被并行补齐了收件箱链路**：`team:inbox` / `team:read` IPC、`#inbox-block` 一整块 DOM、`inboxFor()` / `readFor()` / `wakeMessageFor()` 都已落地（S7 快照见 §1.2）。**仍然缺的是“回执账本读取”这一条链**：没有 `team:receipts` IPC、没有 `listReceiptsFor()`、`layout` 里连 `mailDir` 都没有、团队台没有回执区块。
9. **当前新壳的语义债不在“有没有按钮”，在“谁执行”**：`ack` 仍由主进程 spawn（`main.js team:ack` → `ackDispatch`），只是现在诚实地写了 `actor:'workbench-shell'`（`team-tools.js:1351-1355` 注释 + 8 处标记）；收件箱读一次就会替该角色 `boot` 出一个 30 分钟令牌（`inboxFor` → `withBootToken` → `bootToken`），这是“只读入口”的隐藏写副作用。

**一句话**：旧版是“角色拿令牌自己走邮箱，ack 顺手清锁并回信”；新壳现在是“壳拿令牌替角色读邮箱，收件箱可见了，但回执账本仍只写不读，且每次读都替角色签一次到”。

---

## 1. 快照、证据等级与“源码在动”的处置

### 1.1 旧版基准（只读，字节稳定）

| 文件 | 大小 | SHA256 前 16 | 最后写入 | 用途 |
|---|---:|---|---|---|
| `D:\deepseek\工作台\团队\工具\lib\ops.mjs` | 111,912 | `C399439DF429C000` | 2026-11-03 07:03:22 | `boot/send/inbox/read/ack`、派单锁、唤醒文案 |
| `D:\deepseek\工作台\团队\工具\team.mjs` | 5,354 | `E24B0583ABFEE18A` | 2026-11-03 03:52:38 | CLI 分派、退出码 |
| `D:\deepseek\工作台\团队\工具\lib\store.mjs` | 32,739 | `EA2FC2B17493CFCD` | 2026-11-03 03:52:27 | 邮箱、令牌、回执、`ackMessage` |
| `D:\deepseek\工作台\团队\工具\lib\core.mjs` | 14,044 | `A16018442D3B7954` | 2026-10-29 20:53:24 | `PATHS`、`parseArgs`、通用锁 |
| `D:\deepseek\工作台\团队\工具\lib\board.mjs` | 30,547 | `6CA2EAE3209F4FEF` | 2026-11-03 04:10:25 | 看板里的“回执”区块 |
| `D:\deepseek\工作台\团队\工具\launch.mjs` | 14,127 | `714AE47B66042DA7` | 2026-11-03 07:47:38 | `startupText`（角色第一轮） |
| `D:\deepseek\luanyujia-workbench\12-源码照搬\外壳\main.js` | 67,864 | `E54991F0A2EDA795` | 2026-11-03 09:14:17 | 旧壳 IPC（无 send/ack/inbox） |
| `D:\deepseek\luanyujia-workbench\12-源码照搬\外壳\renderer\app.js` | 90,670 | `BAE3B227FD2813C4` | 2026-11-03 09:14:19 | 旧渲染（只有协作台回执） |
| `D:\deepseek\工作台\团队\看板.html` | 132,432 | `9B893676F0CF1FEF` | 2026-11-03 09:01:20 | 已生成的看板实例（第 43/79/81 行含回执） |

### 1.2 新壳快照 S7（2026-11-05 10:24:56）

| 文件 | 大小 | SHA256 前 16 | 末次写入 |
|---|---:|---|---|
| `src/main.js` | 304,143 → 325,560 | `212D0EEB99728453` → `98747196B4E006B9` | 10:24:54 → 10:26:48 |
| `src/team-tools.js` | 85,601 | `BC5FF41E19580148` | 10:21:42 |
| `src/preload.js` | 4,547 | `B799FB5E26A7DAE2` | 10:21:47 |
| `src/renderer/app.js` | 241,416 | `DF9DE6128EC3E1D0` | 10:24:21 |
| `src/renderer/index.html` | 35,000 | `140B926E48417179` | 10:21:26 |
| `src/renderer/style.css` | 95,860 | `BE1AC2A1531AEDC7` | 10:23:49 |

**审计期间源码在动，必须写进结论。** 本轮 10:16 开始读时 `main.js` 为 283,381 B / 5,373 行；10:21:55 为 285,159 B；10:22:50 为 293,283 B；10:24:54 为 304,143 B / 5,799 行。同一时间窗内 `preload.js` 出现 `teamInbox/teamRead`、`index.html` 出现 `#inbox-block`、`app.js` 长出 `renderInbox`。也就是说：

- 本轮第 6 条“还缺什么”**绑定 S7 快照**，不是绑定 PARITY-ROUND6 的 S6；
- **写本文件期间它又变了一次**：`main.js` 10:26:48 涨到 325,560 B / 6,106 行 / `98747196B4E006B9`。我在该 hash 上重跑了 §7.2 的五个“缺”判据，结论不变（`team:receipts`=0、`listReceiptsFor`=0、`teamReceipts`=0、`#team-receipts`=0、`mailDir`=0）；`team:inbox` 仍为 1 处；
- 若你读到本文件时 hash 已变，请先按 §9 的 6 条 grep 复核，再决定哪一条还需做；
- 不要拿本文件的“已落地”去证明功能正确——它只证明**符号存在**，正确性看 §2–§8 的断言。

### 1.3 旧账本实测（判断“可见/不可见”的唯一依据）

`D:\deepseek\agile-workbench\团队\状态`（07:05 从旧仓库整目录拷贝，两份 `回执.jsonl` 字节相同）：

| 指标 | 数值 | 说明 |
|---|---:|---|
| 邮箱 `.json` 总数 | 392 | 六角色全部 |
| 其中 `new/`（未读） | 128 | `pm` 59 / `analyst` 18 / `tester` 17 / `programmer2` 13 / `programmer1` 12 / `product` 9 |
| 其中 `cur/`（已读） | 264 | `pm` 148 为最多 |
| 消息类型分布 | `receipt` 186、`note` 116、`review` 30、`grant` 18、`proposal` 19、`sign` 16、`welcome` 4、`reconcile` 3 | **近一半邮件是回执回信** |
| `ackRequired=true` | 203 | 其余 189 不需要回执 |
| `回执.jsonl` | 328 行 / 86,352 B | 其中 `update:true` 163 行 → 真实回执 **165** 条 |
| `回执.jsonl` 带 `identitySource` | **0 行** | 说明新壳尚未在这本账上成功代跑过 ack |
| `事件.jsonl` | 1,212 行 | `boot` 91 / `message` 226 / `mail_read` 219 / `ack` 165 |
| `启动/<token>.json` | 91 个 | 旧版无清理器，全部已过期 |
| `项目/*/派单锁.json` | **0 个** | 最后一次有人手工清过锁（见 §5.3） |

> 这组数字的用处：任何“新壳能读旧账”的断言，都可以用 `392 / 128 / 328 / 165` 这四个数直接判真假，不需要看截图。

---

## 2. 第 1 条：发件写入哪些文件、唤醒文案原文

### 2.1 调用链（自上而下）

```text
team.mjs send --boot T --to <role> --subject S --body B [--ack] [--wake] [--no-wake] [--task T-id]
  team.mjs:68  case 'send': await cmdSend(args)
  ops.mjs:339  cmdSend
    :340  bootFor(args,'send')                 // 令牌必须已存在且 role/project 相符
    :341-345  --to 必填、--body/--body-file 必填、正文不能空
    :347  pmDispatch = b.role==='pm' && Boolean(args.ack) && to!=='pm'
    :348-353  非 --force 且 派单锁.json 有 messageId → PM_DISPATCH_PENDING
    :355-368  PM + --task：任务无 owner 则设 to；已有别人的 owner → TASK_OWNED
    :369-372  notify({from:b.role,to,subject,body,project,task,ackRequired:Boolean(args.ack),type,sessionId})
    :373  writeDispatchLock(b.project, msg)    // 先写锁
    :374-409  唤醒（wantWake=(--ack||--wake) && !--no-wake；TEAM_SELFTEST 下跳过）
    :410-411  输出 "已发送 M-… → role（要回执）；已唤醒/唤醒失败：…"
```

### 2.2 逐文件写点

| # | 文件 | 何时写 | 字段/内容 | 证据 |
|---:|---|---|---|---|
| 1 | `团队/状态/邮箱/<to>/new/<ISO时间，把 : 和 . 换成 ->-<M-id>.json` | 每次 send | `{id, from, to, subject(截 80), body(≤messageMaxChars，默认 600), project, task, ackRequired, type, replyTo:'', ts}` | `store.mjs:353-380`（字段 363-375，路径 376-378） |
| 2 | `团队/状态/事件.jsonl`（追加） | 每次 send | `{role:from, sessionId, action:'message', project, target:'from->to', note:subject 截 120, data:{messageId, ackRequired}}` | `ops.mjs:176-183` |
| 3 | `团队/状态/项目/<slug(项目名,60)>/派单锁.json` | **仅** `pmDispatch`（PM→非 PM 且 `--ack`） | `{messageId, to, task, subject, ts}` | `ops.mjs:326-330`、写点 `:373`、目录名 `store.mjs:177-179` |
| 4 | `团队/状态/项目/<slug>/任务/<T-id>.json` | **仅** `b.role==='pm' && --task && 任务无 owner` | 只补 `owner=to`、`status=status||'open'` | `ops.mjs:355-368` |
| — | `团队/状态/回执.jsonl` | **不写** | — | `cmdSend` 全文无 receipts 写入 |
| — | `团队/状态/阅读.jsonl` | **不写** | 只有 `boot` 会 `addReadReceipt(kind:'index')` | `ops.mjs:284`、`store.mjs:826` |
| — | `团队/状态/启动/<token>.json` | **不写**（send 用已有令牌） | — | `store.mjs:328-345` 只读 |
| — | DSH 会话（非文件） | `wantWake` 时 | `DshClient.prompt({sessionId, text, mode:'queue'})` | `ops.mjs:400-403` |

**发送权限**：`sendMessage` 只要求 `from` 是团队成员（`system` 例外）、`to` 已 active（`store.mjs:355-357`）。**没有“只能 PM 发”的限制**，所以 `programmer2→pm`、`programmer2→programmer1` 都是旧版真实用法（账本里有）。
**正文上限**：超 `messageMaxChars` 是**报错**（`MESSAGE_TOO_LONG`，`store.mjs:361`），不是截断；截断只发生在新壳的 `sendDispatch`（`team-tools.js` 里 `rawBody.slice(0, maxChars)` 并返回 `truncated`）。

### 2.3 唤醒文案（`ops.mjs:392-399`，原文照抄）

模板（`${}` 为旧版真实插值）：

```text
这是派单，不是通知：${msg.id}（${msg.subject}）。${taskHint}
先读 ${path.join(projectPath,'项目铁律.md')}（每轮都读），再读项目信息/项目索引/你的文件索引与角色卡。
现在必须完成，不要只回“收到”：
1) node "${teamTool}" boot --role ${to} --project "${b.project}"
2) 用 boot 输出的令牌执行 inbox --all，再 read --id ${msg.id}
3) 本条要回执：ack --id ${msg.id} --note "已收到 ${msg.task || '任务'} + 边界"
${msg.task ? `4) task claim --id ${msg.task}\n` : ''}最后只回一行：已回执/已认领的角色 + 任务 id；不要输出方案，不要巡检全队。
```

其中：

- `taskHint = msg.task ? '\n任务：' + msg.task : ''`（`ops.mjs:391`）；
- `teamTool = <TEAM_ROOT>/工具/team.mjs` 绝对路径（`ops.mjs:390`）；
- `projectPath` 取 `loadProject(b.project).path`，取不到就用项目名（`:389`）；
- 第 4 行只有带 `--task` 时才存在；不带任务时第 3 行下面直接是“最后只回一行”。

**两个容易被忽略的细节**（照做时必须保留）：

1. 文案里**没有**给令牌本身，只写“用 boot 输出的令牌执行”——这是旧版故意让角色自己 boot 的写法；如果新壳要发一条可直接执行的消息，必须自己补 `--boot <token>`，否则模型会卡在“令牌从哪来”。
2. `--note "已收到 ${msg.task || '任务'} + 边界"`：没有任务时 note 字面量是 `已收到 任务 + 边界`（不是消息 id）。

### 2.4 新落点（S7）

| 旧写点 | 新落点 | 状态 |
|---|---|---|
| `邮箱/.../new/*.json` | `team-tools.js sendDispatch()` → `team.mjs send … --no-wake`（`--boot` 由 `withBootToken` 提供） | ✅ 真协议写入 |
| `事件.jsonl` | 同上（工具内部写） | ✅ |
| `派单锁.json` | 同上（工具内部写）；新壳另有本地 `project.pendingAck` | 🟡 双锁 |
| `任务/<T>.json` owner | `sendDispatch` 透传 `--task` | ✅ |
| 唤醒 | `main.js team:send` → `teamTools.wakeMessageFor(...)` → `dsh.prompt(sessionId, wakeText)` | 🟡 文案 7 处差异（3 处整行缺失），见 §7.3 |
| 正文截断 | `team-tools.js` 主动 `slice(0, maxChars)` + `truncated:true` | 🟡 旧版是报错不是截断 |

### 2.5 验收断言

| 断言 | 判据 |
|---|---|
| A1-1 发件必须落一封旧协议邮件 | `team:send` 成功且 `source==='team'` 时，`团队/状态/邮箱/<to>/new/` 里出现 `id === message.teamMessageId` 的 json |
| A1-2 邮件字段齐全 | 该 json 必须含 `id/from/to/subject/body/project/task/ackRequired/type/replyTo/ts` 十个键，`replyTo===''`，`type` 默认 `'note'` |
| A1-3 正文不超限 | `body.length <= teamConfig().messageMaxChars`（默认 600）；超限时 UI 必须收到 `truncated:true` 并给出 `MESSAGE_TRUNCATED` warning |
| A1-4 锁与邮件同源 | `pmDispatch` 为真时，`派单锁.json.messageId === 邮件 id`；为假时该文件**不得**因本次 send 出现 |
| A1-5 唤醒用四步文本 | `main.js` 里只能出现一处 `dsh.prompt(sessionId, wakeText)`，且 `wakeText` 来自 `wakeMessageFor`；不得再出现字符串 `请先确认角色、任务和边界` |
| A1-6 文案含四步关键字 | `wakeText` 必须同时匹配 `/boot --role/`、`/inbox --boot/`、`/--all/`、`/read --boot/`、`/ack --boot/`、`/--note/` |

---

## 3. 第 2 条：收件角色 `boot / inbox / read / ack` 的参数与顺序

### 3.1 参数总表（旧版）

| 命令 | 必填 | 可选 | 实现 | 输出（`--json` 时） |
|---|---|---|---|---|
| `boot` | `--role <role>` | `--project <名>`（默认 `team.activeProject`）、`--session <id>`（默认 `DSH_SESSION_ID` 或 `session-unknown`） | `ops.mjs:273-316` | `{ok, token, role, project, sessionId, rulesHash, briefing, unread[], tasks[], proposals[], grants[]}` |
| `inbox` | `--boot <token>` | `--all`（带 `cur/`）、`--json` | `ops.mjs:414-421` | `{ok, messages[]}`，每条带 `box:'new'|'cur'` |
| `read` | `--boot`、`--id <M-id>` | `--json` | `ops.mjs:423-429` | `{ok, message, alreadyRead}` |
| `ack` | `--boot`、`--id <M-id>` | `--note "…"`（默认 `已收到`，≤300 字）、`--json` | `ops.mjs:431-441` | `{ok, ack, already, msg, receiptMessage}` |
| `task claim` | `--boot`、`--id <T-id>` | `--json` | `ops.mjs:445+`（`cmdTask`） | 认领结果 |

**参数解析规则**（`core.mjs:158-185`，会咬人的两点）：

1. `--flag` 后面跟的第一个**不以 `--` 开头**的 token 会被当成它的值。所以 `send --to programmer1 --ack --subject X` 里 `--ack` 的值是 `true`；但 `--ack 收到` 会把 `收到` 吞成值。**写命令时布尔开关必须放在另一个 `--` 开关之前或末尾**。
2. 同一个开关出现两次会变成数组（`asArray` 处理），`--file` 就靠这个。

### 3.2 顺序与硬闸门

```text
1) boot ──► 写 启动/<token>.json（30min，rulesHash 绑四份文档）
2) 用该 token ──► inbox [--all]        （默认只看 new/）
3) 用该 token ──► read --id M-x        （new → cur，重复 read 返回 alreadyRead:true）
4) 用该 token ──► ack --id M-x --note  （内部先 read，再写 回执.jsonl + 发回执消息 + 清锁）
```

- **`boot` 是唯一不需要令牌的命令**；其余命令入口第一行都是 `bootFor()`（`ops.mjs:36-41`）。
- `bootFor` 除了校验令牌，还会校验 `--role`/`--project` 与令牌一致；**它不校验“这个命令该不该由这个角色做”**（`action` 参数没用上）。
- 令牌校验顺序（`store.mjs:328-345`）：不存在 → `BOOT_INVALID`；过期 → `BOOT_EXPIRED`；角色不符 → `BOOT_ROLE_MISMATCH`；项目不符 → `BOOT_PROJECT_MISMATCH`；四份文档任一变化 → `RULES_CHANGED`。
- **`ack` 不检查 `ackRequired`**：账本里确实存在 `ackRequired:false` 的消息被 ack 的记录（PARITY-ROUND6 §3.2 已举证）。
- **`read` 不是 `ack` 的前置**：`ackMessage` 自己调 `readMessage`（`store.mjs:444`），所以只 ack 也会把 `new→cur`。
- 退出码（`team.mjs:108-121`）：`TeamError` → `3`；内部异常 → `4`；`--json` 下失败输出 `{ok:false, code, message, details}` 到 stdout，人类模式走 stderr。

### 3.3 `boot` 到底读了什么、报了什么

- 读四份文档并哈希：`团队宪法.md`、`项目铁律.md`（项目目录优先，否则团队根）、`角色卡 角色/<role>.md`、`项目索引`（`store.mjs:272-301`）；缺任一 → `MISSING_DOC`（带 label/path）。
- `rulesHash = sha256(宪法+铁律+角色卡+团队.json)`（`store.mjs:294-299`）——**成员表也在里面**，所以改 `团队.json` 会让所有旧令牌作废。
- 启动简报（`ops.mjs:295-315`）必含这几行，顺序固定：
  `令牌:` / `规则哈希:` / `身份:` / `阶段:` / `纪律:` / `未读消息: N`（前 8 条 `[M-id] from(要回执): subject`）/ `待办任务:` / `待处理提案:` / `授权:` / `下一步: 先读 inbox …`。
- 简报有总长上限 `bootBriefMaxChars`（默认 2000），超了尾部截断（`:311-313`）。
- 角色第一轮的“启动卡”是另一份文案（`launch.mjs:24-34`）：**只做两件事**——`node 团队\工具\team.mjs boot --role <role> --project "<项目>"`，然后回一行“已就位”。注意它用的是**相对路径** `团队\工具\team.mjs`，而派单唤醒用的是绝对路径。

### 3.4 新落点（S7）

| 旧命令 | 新落点 | 状态 |
|---|---|---|
| `boot` | `team-tools.js bootToken()`（`team.mjs boot --json`，带 `--session`）、`withBootToken()` 失效重试 | 🟡 真令牌，但**执行者是壳**，角色从不执行 |
| `inbox` | `team-tools.js inboxFor()`（`inbox --boot … --json`，`all!==false` 时加 `--all`）→ `main.js team:inbox` → `preload teamInbox` → `app.js refreshInbox()` | ✅ 已闭环 |
| `read` | `team-tools.js readFor()`（`read --boot … --id …`）→ `main.js team:read` → `preload teamRead` → `app.js inboxReadNow()` | ✅ 已闭环 |
| `ack` | `team-tools.js ackDispatch()` → `main.js team:ack` → `preload teamAck` → `app.js openAckModal()` | 🟡 壳执行 |

**三处与旧版不同的口径，必须知道**：

1. `inboxFor` 里 `includeAll = input.all !== false`（默认 `true`）；`main.js team:inbox` 里 `all = p.all !== false`（默认 `true`）。旧 `inbox` 默认**只 new**。所以“未读”在新壳不能靠“没带 `--all`”得到，只能靠每条消息的 `box` 字段（`inboxFor` 已返回 `unread = messages.filter(box!=='cur').length`）。
2. `inboxFor`/`readFor` 都要求 `sessionId`，并与 `团队.json` 名册比对（不符 → `SESSION_ID_MISMATCH`）。旧版 `inbox` 只需要令牌；新壳多了一把“当前项目会话”的锁——这是跨项目隔离的收益，不是漂移。
3. 两个入口都会走 `withBootToken` → `bootToken()` → `team.mjs boot`。**读一次收件箱 = 替该角色签一次到**：新增 `启动/<token>.json`、`阅读.jsonl` 一行、`事件.jsonl` 一条 `boot`。旧版 `inbox` 不产生这些。

### 3.5 验收断言

| 断言 | 判据 |
|---|---|
| A2-1 四步可用 | 对任一角色连续执行 `boot → inbox --all → read --id → ack --id`，四条都 `ok:true`，且 `回执.jsonl` 行数 +2（ack + update） |
| A2-2 令牌闸门 | 去掉 `--boot` 或换一个角色/项目的令牌，必须得到 `BOOT_REQUIRED`/`BOOT_ROLE_MISMATCH`/`BOOT_PROJECT_MISMATCH`，退出码 3 |
| A2-3 规则变更作废 | 改一行 `团队.json` 后复用旧令牌，必须 `RULES_CHANGED` |
| A2-4 read 幂等 | 同一 `--id` read 两次，第二次 `alreadyRead:true`，`邮箱/<role>/cur` 文件数不变 |
| A2-5 ack 隐含已读 | 不 read 直接 ack，消息文件必须已在 `cur/` |
| A2-6 inbox 默认口径 | 新壳 `team:inbox` 默认 `all:true`，返回 `unread` 只按 `box!=='cur'` 计；不得用“消息总数”当未读数 |
| A2-7 读收件箱的副作用必须可见 | 若保留 `withBootToken` 读法，UI 必须能解释“读一次会新增一个启动令牌”；或改成只读直读邮箱（不经 boot）。当前无任何提示 |

---

## 4. 第 3 条：回执消息如何回到发件人

### 4.1 `ackMessage` 的完整动作序列（`store.mjs:435-475`）

```text
1. 取 team.config.ackNoteMaxChars（默认 300），note 超长 → RECEIPT_TOO_LONG（报错，不截断）
2. findMessage(role,id) 找不到 → MESSAGE_NOT_FOUND
3. 去重：回执.jsonl 里已有 {msgId===id && from===role} → 直接返回 {ack:已有, already:true, receiptMessage:null}
4. readMessage(role,id)                  // new → cur；同名冲突则删 new
5. 写回执行记录 A-<stamp>-<3hex>：{id,msgId,from:role,to:原from,project,note(≤300),log(≤160),ts}
6. 若 原消息.from !== 'system' 且 原消息.type !== 'receipt'：
     再 sendMessage({
       from: role, to: 原 from,
       subject: `回执: ${原 subject}`,
       body: `已处理 ${id}：${ack.note}`,
       project, task: 原 task, type:'receipt', replyTo:id, ackRequired:false
     })
   然后往 回执.jsonl 追加第二行 {...ack, update:true, receiptMessageId:新消息 id}
7. 返回 {ack, already:false, msg, receiptMessage}
```

### 4.2 三个落点（发件人到底能看到什么）

| 落点 | 内容 | 谁读得到 |
|---|---|---|
| `邮箱/<原发件人>/new/<ts>-<M-新id>.json` | `type:'receipt'`、`subject:'回执: <原主题>'`、`body:'已处理 <M-id>：<note>'`、`replyTo:<原 id>`、`ackRequired:false` | 原发件人下一次 `boot` 的 `未读消息` 里 +1；`inbox --all` 能看到；`read` 后进 `cur/` |
| `回执.jsonl` 两行 | ack 行 + `update:true` 行（带 `receiptMessageId`） | 旧看板 `boardData` 过滤 `update` 去重后展示；`team.mjs status/reconcile` 读 |
| `事件.jsonl` 一行 | `action:'ack'`、`data:{ackId, receiptMessageId}` | `verify` / `log` / 看板成员贡献计数 |

**防递归**：回执消息 `type:'receipt'`，再对它 ack 时第 6 步整块被跳过（`store.mjs:458`），所以只写 ack 行、不写 update 行、不发新邮件——“回执的回执”递归层数为 0。账本里 186 封 `receipt` 邮件全部是单向的。

**锁的清除发生在回执之后**：`cmdAck` 先 `ackMessage`，再 `clearDispatchLock(r.msg.project, args.id)`（`ops.mjs:434-435`）。所以：

- 回执写成功但**锁 id 不同**（例如这条不是当前派单）→ 不清；
- `ackMessage` 抛错（如 note 超长、`MESSAGE_NOT_FOUND`）→ **锁保留**；
- 回执行已写入、但第 6 步 `sendMessage` 抛错（原发件人被置为 inactive → `NO_RECIPIENT`）→ 异常冒泡，`clearDispatchLock` **不执行**，`事件.jsonl` 也没有 `ack` 行。此时 `回执.jsonl` 已有 ack 行，重跑 ack 会走 `already:true` 分支并继续清锁——所以是“卡一次，重试可恢复”，不是永久死锁，但**中途状态是脏的**。

### 4.3 新落点（S7）

| 旧动作 | 新落点 | 状态 |
|---|---|---|
| 写 ack 行 | `ackDispatch` → `team.mjs ack`（工具写） | ✅ 真协议 |
| 写 update 行 | 同上 | ✅ |
| 发回执邮件 | 同上（`store.mjs` 内 `sendMessage`） | ✅ 真协议 |
| 补会话身份 | `annotateReceiptIdentity(ackId, {sessionId, role, identitySource, workspaceId, checkedAt, actor, executor})` **重写整份 `回执.jsonl`** | 🟡 旧版 append-only，这里全量重写 |
| 降级回执 | `appendLocalReceipt()` 往 `回执.jsonl` **追加** `{source:'local', local:true}` 行 | 🟡 旧看板不过滤 local 行，会把降级回执当正式回执展示 |
| 发件人看回执 | 收件箱 UI 读旧协议邮箱 → 能看到 `type:'receipt'` 邮件 | ✅（新壳才第一次做到） |
| 团队台消息流 | 仍只读 `project.messages` 本地镜像，回执邮件不在里面 | 🟡 |

### 4.4 验收断言

| 断言 | 判据 |
|---|---|
| A3-1 回执双行 | 一次成功 ack 后 `回执.jsonl` 增加 2 行：第一行 `id===A-…` 且无 `update`，第二行同 `id` 且 `update:true`、`receiptMessageId` 指向新邮件 |
| A3-2 回执邮件字段 | 新邮件必须满足 `type==='receipt'`、`replyTo===被 ack 的 M-id`、`ackRequired===false`、`subject==='回执: '+原subject`、`body` 以 `已处理 ` 开头 |
| A3-3 不递归 | 对回执邮件再 ack：`回执.jsonl` **只 +1 行**（无 `update` 行），不产生新的 `type:'receipt'` 邮件，`事件.jsonl` 仍有 `ack` 行 |
| A3-4 去重 | 同一 M-id 以同一角色 ack 两次，第二次 `already:true` 且 `回执.jsonl` 行数不变、不发新邮件 |
| A3-5 发件人可见 | 收件箱切到原发件人角色，必须能看到 `回执: …` 一条，且 `box==='new'` |
| A3-6 重写不得改变行数 | `annotateReceiptIdentity` 前后 `回执.jsonl` 行数一致（只加字段），任意一行仍能 `JSON.parse` |

---

## 5. 第 4 条：派单锁如何清

### 5.1 路径与结构

- 路径：`团队/状态/项目/<slug(项目名,60)>/派单锁.json`（`ops.mjs:320-322`；`slug` 见 `core.mjs:192-196`，`store.mjs:177-179`）。
- 结构：`{messageId, to, task, subject, ts}`（`ops.mjs:326-330`）。

### 5.2 生命周期（旧协议真实语义）

| 事件 | 触发条件 | 代码 | 结果 |
|---|---|---|---|
| 创建 | `from==='pm'` 且 `--ack` 且 `to!=='pm'` | `ops.mjs:347` + `:373` | 写锁；**先写锁，再唤醒** |
| 阻塞下一条 | 同上，锁存在，无 `--force` | `ops.mjs:348-353` | `PM_DISPATCH_PENDING`，`details.pending=锁内容` |
| 强制通过 | 同上 + `--force` | `ops.mjs:348` | 跳过检查；新派单在 `:373` **覆盖**旧锁（不是释放） |
| 正常释放 | 收件角色 `ack --id` 且 id 与锁相同 | `ops.mjs:435` → `:331-337` | `fs.rmSync(派单锁.json)` |
| 释放失败容忍 | 读锁抛错 | `ops.mjs:333-336` | `catch {}` 静默；锁可能残留 |
| 超时 | **无** | — | 旧协议没有 TTL |
| 撤销 | **无 CLI** | — | 只能 ack / 手工删 / `--force` 覆盖 |
| 唤醒失败 | 锁已写、prompt 抛错 | `ops.mjs:400-408` | **锁保留**，返回 `wake.ok:false` |
| 非 PM / 非 ack / to=pm | — | `pmDispatch=false` | 完全不碰锁文件 |

**严格相等**：`clearDispatchLock` 只在 `lock.messageId === messageId` 时删（`:335`）。所以“回执一条不是当前锁的消息”不会误清锁，这是旧版唯一的并发保护。

**不要和通用锁混淆**：`team.mjs lock acquire/release` 用的是 `团队/状态/锁/<key>.lock`（`core.mjs:277-376`），60 秒 TTL、heartbeat、stale 判定，是防同时写文件用的；**派单锁没有 TTL**。

### 5.3 旧账本的“最后状态”（能证明什么、不能证明什么）

- 当前 `项目/*/派单锁.json` = **0 个**，但确实存在一条该回执却没回执的 PM 派单（`M-20261103-090106-f39ecf`，PM→tester，`ackRequired:true`，`回执.jsonl` 与 `事件.jsonl` 都无 ack 记录）。
- 结论：**不能**用它证明“旧协议会自动超时释锁”；只能说“最后一次运行后有人手工清过锁或用过 `--force` 覆盖”。
- 因此新壳的 10 分钟 TTL 是**新造语义**，不是还原（PARITY-ROUND6 已记，本轮复核仍成立：`ACK_TTL_MS = 10 * 60 * 1000`，`main.js` 顶部常量区）。

### 5.4 新落点（S7）

| 旧行为 | 新落点 | 判定 |
|---|---|---|
| 写锁 | `team.mjs send` 直接写（`--no-wake` 不影响） | ✅ |
| 本地第二把锁 | `project.pendingAck` + `pendingAckAt` | 🟡 双锁 |
| 阻塞下一条 | 本地 `pendingAck` 未过期直接抛“还有一条派单未回执”；旧工具那边也会 `PM_DISPATCH_PENDING` | 🟡 两道闸 |
| 正常释放 | `team:ack` 成功 → `team.mjs ack` 内部清旧锁 + 本地 `clearPendingAck` | ✅ |
| 超时释放 | 10 分钟 TTL：`team:send` 开头、`team:ack` 里、`reconcileExpiredLocks`、`publicProject` 展示层都会释放 | ❌ 新造 |
| 撤销 | `team:cancel`：无 `messageId` 时按本地 `pendingAck`；有旧锁时按 `messageId` 严格匹配释放；不匹配 → `LOCK_MISMATCH` 不释放 | 🟡 新造但比旧版多一条安全边 |
| 唤醒失败 | 释放旧锁 + 清本地 | ❌ 与旧版相反（旧版保留） |
| `--force` | 无等价入口 | ❌ |

### 5.5 验收断言

| 断言 | 判据 |
|---|---|
| A4-1 锁只在 ack 时清 | 派单后删本地 `pendingAck`（模拟重启），再 `team:cancel` 前读 `派单锁.json` 仍存在；`team:ack` 成功后该文件必须消失 |
| A4-2 严格匹配 | 手工把 `派单锁.json.messageId` 改成别的 id，再回执原消息：旧锁**必须保留**，且返回里有 `LOCK_MISMATCH` 或等价的“未释放” warning |
| A4-3 唤醒失败不静默 | 断 DSH 后 `team:send`：本地 `pendingAck` 必须被清，且 warnings 里必须有“已释放旧派单锁”一类记录（当前实现是释放，属于新语义，需在 UI 说明） |
| A4-4 TTL 不得冒充旧协议 | 代码里 `ACK_TTL_MS` 只能出现在“本地锁”路径；不得被写成“旧版 10 分钟超时”（旧版没有） |
| A4-5 覆盖而非释放 | 无 `--force` 等价物时，不允许出现“新派单静默覆盖旧锁”的路径 |

---

## 6. 第 5 条：旧 UI 如何展示收件箱 / 未读 / 回执

### 6.1 结论先说：旧 UI **没有**收件箱和未读

| 想找的东西 | 旧壳（`12-源码照搬/外壳`）里的实情 | 证据 |
|---|---|---|
| `team:inbox` / `team:read` IPC | **不存在**。IPC 表只有 `team:status/members/launch/workspaces/board/board-project/board-file/board-control/openProject/restore/workspace:create` | `main.js:163-925`（`ipcMain.handle` 全表，`team:` 段在 354/477/491/525/574/585/599/624/653/692/738） |
| 发消息 / 回执按钮 | **不存在**。没有 `team:send`、`team:ack`、`pendingAck` 任何字符串 | 同上 + `renderer/app.js` grep `teamSend|team:send|pendingAck` = 0 |
| 收件箱 DOM | **不存在**。旧 `renderer/index.html` 7,532 B，无 `inbox` 字样 | grep `index.html` = 0 |
| 未读数字 | 只在 `boot` 的**终端文本**里出现过 | `ops.mjs:302-303` |
| 旧壳能看到的“团队状态” | `team:status` 只读 `团队.json / 会话.json / 看板.json / 当前工作区.json`，`看板.json` 里带 `receipts` **计数**，但旧渲染没渲染它 | `main.js:354-364` |

### 6.2 旧壳里唯一叫“回执”的面板，其实是另一套账

- IPC：`collab:state`（`main.js:343-352`）读 `工作台\协作\state.json` + `协作\对账.md`。
- 渲染：`renderer/app.js:1112-1195`，四块内容——派单明细表（含状态筛选）、**最近回执流水（最近 10 条）**、单号/状态/时间/回执说明/证据的 tooltip、页脚“数据源 工作台\协作\state.json ｜ 回执由 collab.mjs ack 写入”。
- 这套 `协作/` 是 `collab.mjs` 的旧协作轨，**与 `团队/状态/回执.jsonl` 无关**：它读 `orders[].updatedAt / note / evidence`，不读 `msgId/from/to`。
- 结论：**把“旧 UI 有回执面板”当成“旧 UI 展示邮箱回执”是错的**。二者只是中文同名。

### 6.3 邮件回执真正的旧界面：看板浮窗

```text
旧壳 renderer/app.js:1227-1241  #btn-team-board → API.team.board()
旧壳 main.js:574-583            team:board → runNode([team.mjs,'board','--json']) → openTeamBoard()
旧壳 main.js:247-271            openTeamBoard：1120×780、frame:false、transparent:true、opacity:0.94、
                               alwaysOnTop('floating')、preload=board-preload.js、loadFile(看板.html)
ops.mjs:1347-1422              boardData()：receipts 去重 + 成员计数 + logs
board.mjs:176                  <section> 四、回执（最近 50 条）：时间 / 回执人 / 项目 / 消息 / 备注
board.mjs:212                  data-view="receipts" → 弹窗「回执明细」全量表格
board.mjs:178/214              成员表带「回执」计数列
board.mjs:100/106/115/165      ackRows / 卡片计数 / 概览
旧壳 main.js:585-597           team:board-project → 重新 board --project + loadFile + show + focus
ops.mjs:1361-1362              receipts = loadReceipts().filter(!update && msgId && 项目匹配) → 按 msgId|from 去重
ops.mjs:1406-1409              logs 里把回执并进“成员日志”
```

已生成的 `团队/看板.html` 可直接核对：第 43 行是“四、回执（最近 50 条）”表头，第 79 行是弹窗里的回执明细，第 81 行是成员表的“回执”列。

**看板的回执口径**（照做时必须一致）：

1. 只展示 `!update` 行（否则一条回执会显示两遍）；
2. 按 `msgId|from` 去重（同一对重复 ack 只留一条）；
3. 项目过滤条件是 `!r.project || r.project === 当前项目`（**没有 project 字段的老回执会出现在所有项目里**）；
4. HTML 取 `slice(-50).reverse()`（最新 50 条，倒序）；弹窗取全量；
5. 展示字段只有 `ts / from(角色名) / project / msgId / log||note`。

### 6.4 新落点（S7）

| 旧展示 | 新落点 | 状态 |
|---|---|---|
| 收件箱 | `#inbox-block`（`index.html`，含 `#inbox-roles` / `#inbox-filters` / `#inbox-count` / `#inbox-list` / `#inbox-detail` / `#inbox-source` / `#inbox-api-note` / `#btn-inbox-refresh`），入口 `#more-menu [data-more="inbox"]`（`index.html:86`）→ `runMoreAction('inbox')` → `openInboxFor()` | ✅ 新增（旧版没有） |
| 未读 | 两级：①旧协议 `box==='new'`；②本机浏览标记 `localStorage['awb.inbox.seen.v1']`（`INBOX_SEEN_KEY`） | 🟡 双轨 |
| 回执（per-message） | 团队台消息卡上的 `回执来源` / `待回执` / `人工确认` / 剩余时间 tag；`#dispatch-pending` 的“记录回执 / 撤销派单” | ✅ |
| 回执（账本列表） | **无**。没有 `#team-receipts`，没有 `team:receipts` | ❌ |
| 看板里的回执表 | 仍由旧 `team.mjs board` 生成，新壳用 `team:board-old` 浮窗打开 | 🟡 可看，但只在看板里 |

### 6.5 验收断言

| 断言 | 判据 |
|---|---|
| A5-1 旧版无收件箱（作为对照，不得回退成“假装旧版有”） | 文档/注释里不得出现“还原旧版收件箱 UI”；新收件箱必须标为**新增**能力 |
| A5-2 回执列表口径 | 若新增回执区块，必须复用 §6.3 的 5 条口径（去 update、msgId\|from 去重、项目过滤含空 project、最新 50 倒序、字段 5 个） |
| A5-3 两套“回执”不得混用 | UI 文案必须区分“邮箱回执（回执.jsonl）”与“协作台回执（协作/state.json）”；数据源标签写清路径 |
| A5-4 未读双轨必须标注 | 收件箱顶部（`#inbox-source` / `#inbox-api-note`）必须说明“未读以 `box` 为准 / 本机已读只是浏览标记” |
| A5-5 旧看板仍可用 | `team:board-old` 打开的 `看板.html` 里，“四、回执”行数 = `回执.jsonl` 去重（`!update` + `msgId\|from`）后**按当前项目过滤**的条数。当前账本：全量 165；`个人简历展示项目` 13（与 `状态/看板.json.receipts.length=13` 一致）、`团队工作台改造` 115、`六人敏捷工作区` 18、`测试工作台项目` 17、`个人博客项目` 2 |

---

## 7. 第 6 条：当前新壳还缺哪几个 IPC / 函数 / 选择器

> **本节绑定 S7 快照（§1.2 的 6 个 hash）**。行号会漂移，符号不会。

### 7.1 已经补齐的（S7 实测，别再当缺口）

| 能力 | 落点 | 证据 |
|---|---|---|
| 收件箱 IPC | `main.js` `ipcMain.handle('team:inbox')` | S7 `@3430`，返回 `{ok,role,project,sessionId,all,count,unread,messages,identity}` |
| 已读 IPC | `main.js` `ipcMain.handle('team:read')` | S7 `@3463`，返回 `{ok,role,messageId,message,alreadyRead,identity}` |
| preload 暴露 | `teamInbox` / `teamRead` | `preload.js:51-52` |
| 适配层函数 | `inboxFor()` / `readFor()` / `wakeMessageFor()` | `team-tools.js` `@1620 / @1668 / @1717`（导出见文件末尾 return 块） |
| 收件箱 UI | `#inbox-block` 一整块 + `renderInbox()` / `refreshInbox()` / `inboxReadNow()` / `openInboxAck()` / `openInboxRolePrompt()` | `index.html:378-396`；`app.js` `renderInbox@1911`、`refreshInbox`、`teamInbox(@2164`、`teamRead(@2191` |
| 角色自执行四步 | 收件箱详情的“让角色自己 read/ack” → `dshPrompt` | `app.js` `openInboxRolePrompt()`（文案在 `openInboxRolePrompt` 内） |
| 派单唤醒四步 | `wakeMessageFor()` → `main.js` `dsh.prompt(sessionId, wakeText)` | `main.js` S7 `@3717`；旧版一句话已删除（`请先确认角色、任务和边界` = 0 命中） |
| 壳执行标记 | `actor:'workbench-shell'` | `main.js` S7 8 处；`team-tools.js` 注释 `@1351-1355` |

### 7.2 仍然缺的（按优先级）

| # | 缺什么 | 类型 | 当前证据 | 不补的后果 |
|---:|---|---|---|---|
| G1 | `team:receipts` IPC | IPC | `ipcMain.handle('team:receipts')` 命中 0 | 回执账本只能靠旧看板看，团队台里看不到“谁回过谁” |
| G2 | `listReceiptsFor()` | 函数 | `team-tools.js` 里 `回执.jsonl` 只有 `annotateReceiptIdentity`（读+全量重写）与 `appendLocalReceipt`（append），**没有读取/过滤/去重函数** | 前端无法按 §6.3 口径展示 |
| G3 | `layout.mailDir` / `mailBox(role,box)` | 函数/路径 | `buildLayout()` 只有 `receiptsFile`，无邮箱路径（`mailDir` 命中 0） | 任何“直读邮箱”的只读路径都得自己拼 `状态/邮箱`，容易拼错/越界 |
| G4 | `teamReceipts` | preload | `teamReceipts` 命中 0 | 渲染层拿不到 |
| G5 | 回执区块选择器 | 选择器 | `#team-receipts` / `#team-receipts-list` / `[data-receipt-id]` 命中 0 | 无容器可渲染 |
| G6 | 六角色未读角标 | UI | `#inbox-count` 只算“当前选中角色”；`#team-pill` 不显示未读总数 | PM 的 59 封未读在日常界面里没有信号 |
| G7 | 唤醒文案与旧版对齐 | 文案 | `wakeMessageFor()` 与旧版 7 处差异、其中 3 处整行缺失（见 §7.3） | 角色仍可能“只回收到”/不读铁律/不认领任务 |
| G8 | 文案单源 | 架构 | 现在有**两套**四步文案：`team-tools.wakeMessageFor()`（派单）与 `app.js openInboxRolePrompt()`（收件箱） | 两处一改一漏就漂移；旧版只有 `ops.mjs:392-399` 一处 |
| G9 | 回执失败面 | 语义 | `team:ack` 要求本地 `project.messages` 里存在该消息（`派单不存在` 命中 3 处）；角色/CLI 写进邮箱的派单，UI 无法回执 | “旧协议里有、UI 里没有”的消息永远回不了执 |
| G10 | 读收件箱的令牌副作用 | 语义 | `inboxFor` → `withBootToken` → `bootToken` → `team.mjs boot`（新增 `启动/*.json` + `阅读.jsonl` + `boot` 事件） | 每读一次就替角色签一次到；审计上分不清“角色 boot”与“壳 boot” |

### 7.3 唤醒文案的具体差异（G7 展开）

`wakeMessageFor()`（`team-tools.js @1717-1757`）与旧 `ops.mjs:392-399` 逐行对比：

| 旧版有 | 新文案 | 影响 |
|---|---|---|
| 开头 `这是派单，不是通知：<id>（<subject>）。` | 标题行 `【团队派单 <id>】<subject>` | 弱化了“不是通知”的强制语气 |
| `先读 <项目目录>\项目铁律.md（每轮都读），再读项目信息/项目索引/你的文件索引与角色卡。` | **整行缺失** | 角色可能不读铁律（旧版硬要求） |
| `现在必须完成，不要只回“收到”：` | `请由你本人以「<角色名>」身份完成旧协议四步（不要巡检全队，不要跳过 boot）：` | 语义接近，但少了“不要只回收到” |
| 步骤 `1) boot / 2) inbox+read / 3) ack / 4) task claim` | `1) boot / 2) inbox / 3) read / 4) ack` | 少了 `task claim`；把 read 单列（旧版 read 与 inbox 合在一步） |
| `--note "已收到 <task 或 '任务'> + 边界"` | `--note "已收到 <task 或 messageId> + 边界"` | 无任务时旧版是“任务”，新版是消息 id |
| `最后只回一行：已回执/已认领的角色 + 任务 id；不要输出方案，不要巡检全队。` | **整行缺失** | 角色可能长篇输出 |
| 令牌由角色 boot 获得（文案不写令牌） | `--boot <令牌>` 占位符 | 更可执行，但要保证模型理解“<令牌> = 第 1 步输出” |

### 7.4 验收断言（每条缺口一个，可直接跑）

| 断言 | 判据 |
|---|---|
| A6-1 G1/G4/G5 一次验完 | `Select-String src\main.js -Pattern "team:receipts"` 命中 1；`Select-String src\preload.js -Pattern "teamReceipts"` 命中 1；`Select-String src\renderer\index.html -Pattern 'id="team-receipts'` 命中 1 |
| A6-2 G2 函数存在且有测试 | `Select-String src\team-tools.js -Pattern "function listReceiptsFor"` 命中 1；且它必须实现：去 `update` 行、按 `msgId\|from` 去重、`!project \|\| project===当前`、`sort(ts).reverse().slice(0,50)` |
| A6-3 G3 邮箱路径唯一出口 | `Select-String src\team-tools.js -Pattern "mailDir"` 命中 ≥1；`src/main.js` 不得再手拼 `'邮箱'` 字面量 |
| A6-4 G6 角标 | 六角色未读总数出现在 `#team-pill`（或独立 `#inbox-badge`）的文本里，且刷新后与 `sum(new/)` 相等（当前应为 **128**） |
| A6-5 G7/G8 文案单源 | `src/` 里“四步文案”只能有一个生成函数；`app.js` 不得再手拼 `boot --role … / inbox --all / read --id` 三段字符串。允许的唯一例外是通过 IPC 取 `wakeMessageFor().text` |
| A6-6 G9 回执可达性 | 对“邮箱里有、本地 `messages` 没有”的消息，UI 必须给出“不能回执”的明确原因（当前 `openInboxAck` 已用 `localMirror` 判断，需补断言：按钮 disabled + title 有原因） |
| A6-7 G10 副作用可见 | 每次 `team:inbox` 之后 `团队/状态/启动` 文件数 +1（首次/缓存过期时）；要么在 UI 标注，要么改成不经 boot 的只读读法。**二者必须选一个，不能默认静默** |

---

## 8. 一页速查：旧 → 新 对照总表

| # | 旧版事实（文件:行） | 新壳 S7 落点（符号） | 判定 |
|---:|---|---|---|
| 1 | 邮箱写入 `store.mjs:353-380` | `sendDispatch` → `team.mjs send --no-wake` | ✅ |
| 2 | 事件 `ops.mjs:176-183` | 工具内部 | ✅ |
| 3 | 派单锁写 `ops.mjs:326-330,373` | 工具内部 + 本地 `pendingAck` | 🟡 双锁 |
| 4 | 唤醒 7–8 行模板 `ops.mjs:392-399` | `wakeMessageFor` → `dsh.prompt(wakeText)` | 🟡 3 处整行缺失 |
| 5 | boot `ops.mjs:273-316` | `bootToken()`（壳执行） | 🟡 |
| 6 | 令牌 30min `store.mjs:307-326` | 同（壳缓存 `bootCache`） | ✅ |
| 7 | inbox `ops.mjs:414-421` | `inboxFor` → `team:inbox` → `#inbox-block` | ✅ |
| 8 | read `ops.mjs:423-429` | `readFor` → `team:read` | ✅ |
| 9 | ack `ops.mjs:431-441` | `ackDispatch` → `team:ack` | 🟡 壳执行 |
| 10 | 回执双行 `store.mjs:445-473` | 工具内部 | ✅ |
| 11 | 回执邮件 `store.mjs:458-473` | 工具内部（收件箱可见） | ✅ |
| 12 | 防递归 `store.mjs:458` | 同 | ✅ |
| 13 | 清锁 `ops.mjs:435,331-337` | 工具 + `clearPendingAck` | ✅ |
| 14 | 无 TTL | `ACK_TTL_MS` 10 分钟 | ❌ 新造 |
| 15 | 无 cancel | `team:cancel`（含 `LOCK_MISMATCH`） | 🟡 新造 |
| 16 | 旧 UI 无收件箱 | `#inbox-block` | ✅ 新增（非还原） |
| 17 | 旧 UI 回执只在看板 `board.mjs:176/212` | 团队台无回执区块 | ❌ 缺 |
| 18 | 账本 392 封 / 128 未读 / 165 回执 | `#inbox-count` 只算当前角色 | 🟡 |

---

## 9. 复核方式（hash 变了就照这里重验，不要照行号）

```powershell
# 0) 先看快照是否还是 S7（任一不同 → 下面按符号重验；S7 之后 main.js 又漂过两次，实到 98747196）
Get-FileHash D:\deepseek\agile-workbench\src\main.js -Algorithm SHA256        # S7=212D0EEB99728453… / 写完后=98747196B4E006B9…
Get-FileHash D:\deepseek\agile-workbench\src\team-tools.js -Algorithm SHA256  # 期望 BC5FF41E19580148…
Get-FileHash D:\deepseek\agile-workbench\src\renderer\app.js -Algorithm SHA256# 期望 DF9DE6128EC3E1D0…

# 1) 回执读取链是否已补
Select-String -Path .\src\main.js -Pattern "team:receipts"
Select-String -Path .\src\team-tools.js -Pattern "listReceiptsFor"
Select-String -Path .\src\preload.js -Pattern "teamReceipts"
Select-String -Path .\src\renderer\index.html -Pattern 'id="team-receipts'

# 2) 是否还有“一句话唤醒”残留
Select-String -Path .\src\main.js -Pattern "请先确认角色、任务和边界"

# 3) 四步文案是否仍是两处
Select-String -Path .\src\team-tools.js -Pattern "function wakeMessageFor"
Select-String -Path .\src\renderer\app.js -Pattern "inbox --all"

# 4) 账本口径（应恒为 392 / 128 / 328 / 165，除非真的又跑过旧工具）
$s='D:\deepseek\agile-workbench\团队\状态'
(Get-ChildItem "$s\邮箱" -Recurse -File -Filter *.json).Count
(Get-ChildItem "$s\邮箱" -Recurse -File -Filter *.json | Where-Object { $_.Directory.Name -eq 'new' }).Count
(Get-Content "$s\回执.jsonl").Count
(Get-Content "$s\回执.jsonl" | Where-Object { $_ -match '"update":true' }).Count
```

**判定规则**：

- 第 1 组任一命中 → G1–G5 已补，删掉对应缺口；
- 第 2 组命中 → 唤醒文案回退，直接判回归；
- 第 3 组两个都命中 → G8（文案双源）仍在；
- 第 4 组数字变化 → 说明有新 ack/新邮件写入，先确认是不是测试污染，再谈 parity。

---

## 10. 只读边界与产物

- 本轮只新增/修改 `docs/PARITY-ROUND7.md`。
- 未修改：`src/**`、`package.json`、`package-lock.json`、`node_modules`、`团队/**`、`项目/**`、`userdata-selftest/**`、`D:\deepseek\工作台\**`、`D:\deepseek\luanyujia-workbench\**`。
- 未运行：`npm run check` / `npm run selftest` / Electron（本轮审计期间 `src/` 正在被并行修改，跑测试得到的绿/红都不代表任何一个稳定快照；测过也不能算数）。
- 引用到的旧账本数字均为**只读统计**（`Get-ChildItem` / `Get-Content` 计数），未写入任何状态文件。
