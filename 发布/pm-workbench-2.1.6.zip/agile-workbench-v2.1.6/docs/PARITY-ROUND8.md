# 第八轮 · 旧版 UI“无收件箱”复核与新增面清理清单（只读）

> 范围：只回答四件事——①哪些新 UI 是旧版没有的、该删/该藏；②旧版还有哪些功能没补；③回执列表 / 看板浮窗 / Owner 工作流在旧版哪里展示；④按 P0/P1/P2 给出保留/删除/降级清单。
> 旧版基准：`D:\deepseek\luanyujia-workbench\12-源码照搬\外壳`（`main.js` / `preload.js` / `renderer/index.html` / `renderer/app.js`）+ 它生成的 `D:\deepseek\工作台\团队\看板.html`（数据源 `团队/工具/lib/board.mjs`）。
> 当前基准：`D:\deepseek\agile-workbench\src` 的 **S8 快照**（2026-11-05 11:57，hash 表见 §1.2）。
> 只读边界：本轮只新增本文件；未改 `src/`、`package.json`、`node_modules`、`团队/`、`项目/`，未改旧仓库 `D:\deepseek\luanyujia-workbench` 与 `D:\deepseek\工作台`。
> 写法约定：旧版文件字节稳定，行号可复现；**新壳在审计期间被并行修改**，行号只作定位提示，一律以“选择器 + 函数 + IPC 名”为准。

---

## 0. 直接回答（四问，先看这 12 条）

1. **旧版 UI 没有收件箱，也没有未读/已读面板。** 旧 `renderer/index.html`、`renderer/app.js`、`main.js`、`preload.js` 四个文件里 `inbox` / `收件` / `未读` / `team:send` / `team:ack` / `team:read` 全部 **0 命中**；旧 `preload.js` 的 `window.kun.team` 只有 `status/workspaces/workspaceCreate/launch/restore/openProject/board/members/workflow/workflowOwner/onWorkflow`，没有收件箱/发件/回执 IPC。
2. **当前 `#inbox-block` 是新增能力，不是 parity。** 它现在已被改成 `<details class="debug-fold">`（`index.html:434-457`，块内自己写着“旧版没有此面板”“调试工具，不是主界面”），这是正确方向；但 `#more-menu [data-more="inbox"]`、角色卡 `[data-role-inbox]`、团队消息行 `[data-msg-inbox]` 三个入口仍在，严格对齐应全部删除或收进开发开关。
3. **当前又新增了 `#team-receipts`“最近回执”块（`index.html:380-392`）。旧版 UI 也没有这个块。** 旧版邮件回执只出现在 **看板浮窗** 的“四、回执（最近 50 条）”（`board.mjs:176`）和“回执明细”弹窗（`board.mjs:212`）。`#team-receipts` 即使复刻了旧看板口径，也是把旧看板的内容搬进了团队台，属于 **新增面**，不是还原。
4. **旧版回执列表的唯一入口是“看板”。** 旧顶栏按钮 `#btn-team-board` 的 title 原文就是“团队看板：需求/任务/提案/评审/回执/文件”（`index.html:19`），点击走 `API.team.board()`（`app.js:1227-1241`）→ `team:board`（`main.js:574-583`）→ `openTeamBoard()`（`main.js:247-271`）的独立 BrowserWindow。
5. **旧版看板只有独立 BrowserWindow，没有内嵌 iframe。** 旧窗口参数：1120×780、`frame:false`、`transparent:true`、`opacity:0.94`、`alwaysOnTop('floating')`、`minWidth:300/minHeight:64`（`main.js:255-267`）。当前 `#board-panel` 是 iframe 内嵌浮窗（`index.html:495-520`），是新增面；`#btn-team-board` 这个**同名选择器**现在绑定到 `openBoardPanel()`（`app.js:5312`），行为已经和老版不同。
6. **旧版 Owner 工作流只在“流程浮窗”里。** 旧 DOM 只有一个节点 `div.flow-node[data-stage="bossreview"]`（`index.html:98`）和一条边 `[data-edge="owner-dispatch"]`（`index.html:99`）；旧 JS 在 `stage==='bossreview'` 时**自动弹**不可关闭的 Owner 评审弹窗（`app.js:1687-1721` + `maybeOwnerReview` `1723-1730`）。旧版没有 Owner 徽标、Owner 卡片、Owner 顶栏按钮，也没有 `#owner-badge` / `#owner-summary`。
7. **当前 Owner 有 11 个 Owner 相关 DOM 点（10 个可见入口 + `#owner-result`），而且明确“不自动弹窗”。** `#stage-owner`、`#btn-owner-quick`、`#project-owner-badge`、`#btn-owner`、`#btn-stage-owner`、`#owner-badge`、`#owner-summary`、`#btn-owner-open`、`#btn-flow-owner`、`#board-panel-owner`、`#owner-result`（`index.html:165/169/205/216/249/253-257/291/513`）；`openOwnerModal()` 是 `closable:true`（`app.js:4301-4313`），代码注释直接写“Owner 不自动弹窗”（`app.js:670/5627` 一类位置）。这不是旧版行为。
8. **旧版流程是 10 个节点 / 7 条边，当前是 8 个阶段 / 5 条边。** 旧 DOM：`pm-intake / requirement / review / bossreview / dispatch / dev / devreview / test / close / iterate`（`index.html:91-111`）；旧 JS 的 `order` 也是这 10 个（`app.js:1675`）。当前 `STAGES` 只有 `intake/requirement/review/owner/dispatch/dev/test/close`（`main.js:133-142`），`flowMarkup()` 按 `state.stages` 画（`app.js:2968`）；`devreview`、`iterate` 在 `src/` 里 **0 命中**，两条边 `dev-test`、`close-iterate` 也没有了。
9. **旧版流程靠文件监听推送，当前没有。** 旧 `startFlowWatch()` 用 `fs.watch(状态/项目/<key>, {recursive:true})` + 220ms 去抖，向所有窗口发 `workflow:changed`（`main.js:432-450`）；旧 preload 暴露 `API.team.onWorkflow(cb)`。当前 `src/` 里 `workflow:changed` / `onWorkflow` / `fs.watch` 均 **0 命中**。
10. **旧版顶栏有可见的“看板”“成员”两个按钮；当前顶栏没有。** 旧 `#btn-team-board`、`#btn-team-members` 就在 `index.html:19-20`；当前顶栏只有 `#team-pill` / `#session-pill`（`index.html:28-33`），`#btn-members` 点开的是团队台抽屉（`app.js:5146`），不是旧版成员弹窗。
11. **当前“团队台”抽屉本身也是新增面。** 旧版没有 `#team-drawer`、`#team-log`、`#dispatch-form`、`#team-receipts`、`#inbox-block`；旧版成员清单是 `#btn-team-members` 直接打开的 modal（`app.js:1639-1666`），消息/派单/回执都在旧协议 CLI 和旧看板里，不在壳的 DOM 里。
12. **一句话：** 旧版是“顶栏看板/成员 + 流程浮窗 + 独立看板窗口 + 终端里的 inbox/ack”；当前把 inbox、回执列表、团队消息、派单表单、内嵌看板都搬进了团队台。**按严格对齐，P0 先删/藏 inbox 与 `#team-receipts`，P1 恢复顶栏看板/成员、独立看板默认入口、Owner 自动弹窗、10 节点流程；P2 再补场景栏/协作台/扩展入口。**

---

## 1. 基准、快照与“源码在动”的处置

### 1.1 旧版基准（只读，字节稳定）

| 文件 | 大小 | 行数 | SHA256 前 16 | 用途 |
|---|---:|---:|---|---|
| `...\12-源码照搬\外壳\main.js` | 67,864 | 1,091 | `E54991F0A2EDA795` | 旧壳 IPC、看板窗口、Owner 工作流 |
| `...\外壳\preload.js` | 2,420 | 48 | `A99F86E6AB43E6DC` | 旧 `window.kun` API（无 inbox/send/ack） |
| `...\外壳\renderer\index.html` | 7,532 | 138 | `72F4F920103A524F` | 旧 UI 全量 DOM（无 sidebar/drawer/inbox） |
| `...\外壳\renderer\app.js` | 90,670 | 1,828 | `BAE3B227FD2813C4` | 旧渲染、流程、Owner、协作台 |
| `...\外壳\renderer\style.css` | 73,270 | 1,278 | `035CDFFC50471BE6` | 旧样式 |
| `D:\deepseek\工作台\团队\工具\lib\board.mjs` | 30,547 | 250 | `6CA2EAE3209F4FEF` | 旧看板（含“四、回执”） |
| `D:\deepseek\工作台\团队\工具\lib\ops.mjs` | 111,912 | 1,892 | `C399439DF429C000` | 旧协议 send/inbox/read/ack/锁 |

> 旧版 `index.html` 只有 **138 行 / 51 个 id**；当前 `index.html` 已到 **548 行 / 202 个 id**。这个量级差本身就说明“当前 UI”不是旧版逐像素，而是另一套壳。

### 1.2 当前 S8 快照（2026-11-05 11:57:29）

| 文件 | 大小 | SHA256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 342,991 | `36D9FA6F62B70690` | 11:56:56 |
| `src/team-tools.js` | 92,744 | `714F2495F0D8F2A2` | 11:56:43 |
| `src/preload.js` | 4,750 | `1955CC1DC8F79D63` | 11:47:09 |
| `src/renderer/app.js` | 260,416 | `BECEEC4556C790D9` | 11:53:57 |
| `src/renderer/index.html` | 36,953 | `BB70686271D092F1` | 11:49:56 |
| `src/renderer/style.css` | 101,066 | `73CCED0709A93B84` | 11:54:29 |

**审计期间源码在动，必须写进结论。** 本轮 11:40 开始读时是 `main.js` 327,053 / `team-tools.js` 85,886 / `preload.js` 4,547 / `app.js` 245,410 / `index.html` 35,000 / `style.css` 96,045；11:57 已变成上表。期间实际发生的变化包括：

- `team:receipts` / `listReceipts` / `teamReceipts` 从 0 变成存在（`main.js:3649`、`team-tools.js:1490`、`preload.js:54`）；
- `#team-receipts` 整块出现（`index.html:380-392`；11:49:56 写入）；
- `#inbox-block` 从普通 `<section>` 改成 `<details class="debug-fold">`，并补了“旧版没有此面板”（`index.html:434-457`；11:49:56 写入）；
- 11:47 版本的 `listReceipts` 合并 `update:true` 后仍保留 `update` 标记，前端 `receiptLedgerRows` 又过滤 `!row.update`，会让“个人简历展示项目”的 13 条回执显示为 0；11:56:43 已改成 `delete merged.update`，当前可显示 13 条（见 §7）。

**处置**：本文件绑定 S8 快照；行号只作定位提示。若你读到本文件时 hash 已变，先按 §8 的符号 grep 重验，再决定哪一条还成立。**不要拿本文件的“当前行号”去证明实现正确。**
**补记（写完本文件时又变了一次）**：`src/renderer/app.js` 在 12:02:05 变为 `45AFE17013544344` / 260,726 B；函数符号（`renderReceipts` / `renderInbox` / `openOwnerModal` 等）没变，行号整体漂了约 +5～+7。本文件 §4/§6/§7 的 `app.js:xxxx` 以 11:53:57 的 `BECEEC45` 为准；执行时按符号，不按行号。

---

## 2. 旧版 UI 没有收件箱：四份文件的 0 命中证据

### 2.1 关键字命中

| 文件 | `inbox` | `收件` | `未读` | `team:send` | `team:ack` | `team:read` |
|---|---:|---:|---:|---:|---:|---:|
| 旧 `renderer/index.html` | 0 | 0 | 0 | 0 | 0 | 0 |
| 旧 `renderer/app.js` | 0 | 0 | 0 | 0 | 0 | 0 |
| 旧 `main.js` | 0 | 0 | 0 | 0 | 0 | 0 |
| 旧 `preload.js` | 0 | 0 | 0 | 0 | 0 | 0 |

### 2.2 旧 preload 的完整团队 API（没有 inbox/read/ack）

`preload.js:28-40` 的 `window.kun.team` 只有：

```text
status / workspaces / workspaceCreate / launch / restore / openProject /
board / members / workflow / workflowOwner / onWorkflow
```

没有 `inbox`、没有 `read`、没有 `ack`、没有 `send`。这和旧 `main.js` 的 `ipcMain.handle` 表一致：`team:status`（354）、`team:members`（477）、`team:launch`（491）、`team:workspaces`（525）、`team:board`（574）、`team:board-project`（585）、`team:board-file`（599）、`team:board-control`（624）、`team:openProject`（653）、`team:restore`（692）、`team:workspace:create`（738）——**没有 `team:send` / `team:ack` / `team:inbox` / `team:read`**。

### 2.3 旧版“未读”只存在于终端简报

旧协议 `boot` 的启动简报里确实有“未读消息: N”（`ops.mjs:302-303`），但那是 **终端文本**，不是 DOM，也没有面板。旧版角色要自己 `inbox --all` / `read --id`，壳不显示。

### 2.4 结论

`#inbox-block` 是 **新增能力**，不是旧版还原。PARITY-ROUND7 §6.1/§6.4 已经得出同一结论，并在 §6.4 把 `#inbox-block` 标成“✅ 新增（旧版没有）”；QA-ROUND6 H7（`docs/QA-ROUND6.md:298-328`）与 PARITY-ROUND6 P6-03（`docs/PARITY-ROUND6.md:630-667`）建议“增加 team:inbox/team:read + 收件箱 UI”，那是**能力补齐建议**，不是旧版 UI 证据。严格对齐时，必须把这条建议降级为“新增功能”，不能继续叫“还原收件箱”。

---

## 3. 回执列表 / 看板浮窗 / Owner 工作流：旧版到底在哪展示

### 3.1 回执列表：只在看板浮窗

旧版看板由 `team.mjs board` 生成 `团队/看板.html`，回执在 `board.mjs` 的固定位置：

| 旧展示 | 旧文件/行 | 内容 |
|---|---|---|
| 看板第 4 节 | `board.mjs:176` | `<h2>四、回执（最近 50 条）</h2>`，表头 `时间 / 回执人 / 项目 / 消息 / 备注` |
| 回执明细弹窗 | `board.mjs:212` | `data-view="receipts"` → `open('回执明细', …)` 全量表格 |
| 成员表“回执”列 | `board.mjs:178` / `:214` | 每个成员的发消息/评审/签字/提交/回执计数 |
| 概览卡 / 质量汇总 | `board.mjs:100` / `:106` / `:115` / `:165` | “回执 N 条”卡片、`条回执` 汇总、pilot 检查 |
| 成员日志 | `board.mjs:180` | 回执也进入“成员日志（一句话）” |
| 数据口径 | `ops.mjs:1361-1362` | `loadReceipts().filter(!update && msgId && 项目匹配)`，按 `msgId|from` 去重 |

已生成的 `D:\deepseek\工作台\团队\看板.html` 可直接核对：第 39 行有“回执 13”卡片，第 43 行是“四、回执（最近 50 条）”，第 45 行成员表有“回执”列，第 46 行质量汇总有“13 条回执”，第 47 行成员日志有“回执”动作。

当前账本按旧看板口径（`!update` + `msgId|from` 去重 + 项目过滤）为：全量 **165**；`个人简历展示项目` 13、`团队工作台改造` 115、`六人敏捷工作区` 18、`测试工作台项目` 17、`个人博客项目` 2（PARITY-ROUND7 A5-5）。这些数字是判断“新回执列表是否真的对齐旧看板”的最快尺子。

**必须区分的一件事**：旧壳里确实有一个中文叫“回执”的面板——`renderCollabPanel()` 的“最近回执流水（最近 10 条）”（`app.js:1164-1194`），但它读的是 `工作台\协作\state.json`，字段是 `orders[].updatedAt / note / evidence`，**不是** `回执.jsonl` 的 `msgId / from / to`。它和邮箱回执只是中文同名，不能当旧版“邮件回执列表”的证据。旧 `team:status` 虽然返回 `看板.json` 里的 `receipts` 计数（`main.js:354-364`），旧渲染层并没有渲染它；不要拿它证明旧壳有回执面板。

### 3.2 看板浮窗：旧版唯一入口是独立 BrowserWindow

```text
旧 index.html:19         #btn-team-board（title 含“回执”）
旧 index.html:43         more 菜单 data-act="board"
旧 app.js:1227-1241      #btn-team-board → API.team.board()
旧 main.js:574-583       team:board → runNode([team.mjs,'board','--json']) → openTeamBoard()
旧 main.js:247-271       openTeamBoard：1120×780、frame:false、transparent:true、opacity:0.94、
                         alwaysOnTop('floating')、preload=board-preload.js、loadFile(看板.html)
旧 main.js:585-597       team:board-project：重新 board --project + loadFile + show/focus
旧 main.js:599-622       team:board-file：只读预览（文本/图片/外链）
旧 main.js:624-651       team:board-control：collapse/expand/maximize/minimize/close/zoom-in/zoom-out
旧 board-preload.js:3-7 window.boardWin.control / selectProject / openFile（旧看板窗口专用）
```

**旧版没有 `#board-panel`、没有 `#board-launcher`、没有内嵌 iframe。** 看板就是独立窗口，窗口自己带标题条和折叠/缩放按钮。旧窗口折叠高度 64px（`main.js:629`：`width:320,height:64`）。

### 3.3 Owner 工作流：流程浮窗节点 + 自动弹窗

| 旧展示 | 旧文件/行 | 说明 |
|---|---|---|
| 流程节点 | `index.html:98` | `<div class="flow-node flow-optional" data-stage="bossreview">Owner 评审 <small>可选</small></div>` |
| Owner 边 | `index.html:99` | `<span class="flow-edge" data-edge="owner-dispatch">待决定</span>` |
| 节点顺序 | `app.js:1675` | `order = ['pm-intake','requirement','review','bossreview','dispatch','dev','devreview','test','close','iterate']` |
| 自动弹窗 | `app.js:1723-1730` | `maybeOwnerReview(r)`：只在 `r.stage==='bossreview'` 弹；`ownerPromptedKey` 按 `roundKey` 去重 |
| 弹窗本体 | `app.js:1687-1721` | `openOwnerReview()`，`closable:false`；按钮“跳过评审 / 开始评审”“打回需求 / 通过并通知 PM”；通过必须写意见 |
| 节点状态 | `app.js:1754-1765` | 只更新 `bossreview` 节点的 `optional` class 和 small 文案（“本轮必审 / 可选”），没有 Owner 徽标/卡片 |
| 后端 | `main.js:451-475` | `workflow:get` → `computeWorkflow()`；`workflow:owner` 写 `项目/<name>/工作流.json` 的 `ownerReview`，再跑 `owner-note.mjs` 通知 PM，广播 `workflow:changed` |
| 阶段推导 | `main.js:377-430` | 读 `当前工作区.json`、`项目/<name>/工作流.json`、`任务/*.json`、`需求/R-*.md`、`提交/*.json` |
| 文件监听 | `main.js:432-450` | `fs.watch(状态/项目/<key>, {recursive:true})` + 220ms 去抖 → `workflow:changed` |

**旧版没有**：`#stage-owner`、`#btn-owner-quick`、`#project-owner-badge`、`#btn-owner`、`#owner-badge`、`#owner-summary`、`#btn-owner-open`、`#btn-flow-owner`、`#board-panel-owner`、`#owner-result`。旧 `app.js:1755` 虽然查询了 `#flow-owner-state`，但旧 `index.html` 里没有这个 id——这是一个**空查询/死代码**，不能当成旧版有 Owner 状态徽标。

---

## 4. 当前新增 UI 清单（旧版没有）

> 判定：**删除** = 严格对齐下不应存在；**隐藏** = 可保留代码但不得有可见入口/默认不展开；**降级** = 换成旧版对应载体（modal/独立窗口/只读链接）。

| # | 当前选择器 / 区块 | 当前函数 / 入口 | 旧版对应 | 判定 | 优先级 |
|---:|---|---|---|---|---|
| 1 | `#team-receipts`（`index.html:380-392`，含 `#team-receipts-list` / `#team-receipts-source` / `#team-receipts-summary` / `#btn-receipts-refresh` / `#team-receipts-note` / `.team-receipts-rule`） | `renderReceipts()`、`loadReceipts()`、`receiptLedgerRows()`（`app.js:1116/1216/1087`）；`setDrawer('team')` 时自动 `loadReceipts()` | 旧版只在看板第 4 节 + 回执明细弹窗（`board.mjs:176/212`） | **删除/隐藏**（或降级为“打开旧看板”链接） | **P0** |
| 2 | `#inbox-block`（`index.html:434-457`；含 `#inbox-roles` / `#inbox-filters` / `#inbox-count` / `#inbox-list` / `#inbox-detail` / `#inbox-source` / `#inbox-api-note` / `#btn-inbox-refresh`） | `renderInbox()`、`openInboxFor()`、`refreshInbox()`、`inboxReadNow()`、`openInboxAck()`、`openInboxRolePrompt()`（`app.js:2364/2466/2489/2536/2559/2571`） | **无**（旧 UI 0 命中） | 已降级为 `details.debug-fold`；严格对齐应**删除块**或仅留开发开关 | **P0**（入口）/ **P1**（块） |
| 2a | `#more-menu [data-more="inbox"]`（`index.html:101`） | `runMoreAction('inbox')` → `openInboxFor()` | 无 | **删除** | **P0** |
| 2b | 角色卡 `[data-role-inbox]`（`app.js:3108`） | `openInboxFor()` | 旧版没有角色卡收件箱按钮（旧成员是 modal，`app.js:1639-1666`） | **删除** | **P0** |
| 2c | 团队消息行 `[data-msg-inbox]`“邮箱(调试)”（`app.js:1972`） | `openInboxFor()` | 无 | **删除** | **P0** |
| 3 | `#dispatch-form`（`index.html:407-419`：`#dispatch-from` / `#dispatch-role` / `#dispatch-task` / `#dispatch-subject` / `#dispatch-body` / `#dispatch-ack` / `#dispatch-hint` / `#dispatch-send`） + `#dispatch-pending`（`:421`） | `renderDispatch()`、`sendDispatch()`、`openAckModal()`（`app.js:3182/3264/3317`） | 无；旧版 PM 派单是角色/CLI 里 `team.mjs send`，壳没有发件表单 | **删除/隐藏**（若要保留，标“新增”） | **P0/P1** |
| 4 | `#team-log`（`index.html:394-405`，含 `#team-log-filter` / `#team-msg-summary`） | `renderTeamLog()`（`app.js:1913`） | 无；旧版消息只在邮箱/终端，回执只在看板 | **删除/隐藏** | **P1** |
| 5 | `#team-drawer` 整个团队台（`index.html:356-467`） | `renderTeam()`、`renderTeamSessions()`、`renderTeamWorkspace()`（`app.js:1009/954/1270`） | 旧版没有团队台抽屉；成员清单是 `#btn-team-members` 直接开 modal（`app.js:1639-1666`） | **降级**为旧成员 modal + 旧看板窗口 | **P1** |
| 6 | `#board-panel`（`index.html:495-520`，含 `#board-panel-frame` iframe、`#board-panel-owner`、`#board-panel-project`、`#board-panel-open`、`#board-panel-collapse`、`#board-panel-max`） | `renderBoardPanel()`、`loadBoardPanel()`、`openBoardPanel()`、`toggleBoardPanel()`、`setBoardPanelOpen()`、`createBoardShim()`、`onBoardFrameLoad()`（`app.js:1468/1618/1853/...`） | 旧版只有独立 BrowserWindow（`main.js:247-271`） | **删除/隐藏**；默认改回 `team:board-old` | **P1** |
| 6a | `#board-launcher`（`index.html:473-476`） | `toggleBoardPanel()` | 旧版只有 `#flow-launcher`，没有看板悬浮按钮 | **删除/隐藏** | **P1** |
| 6b | `#team-board-summary` 块（`index.html:425-432`，含 `#team-board-state` / `#btn-team-board-2` / `#btn-team-board-refresh`） | `renderBoardSummary()`（`app.js:1343`） | 旧版没有“看板摘要”块；看板计数只在 `看板.html` 内 | **删除/隐藏** | **P1** |
| 7 | Owner 的 11 个 Owner 相关 DOM 点（10 个入口 + `#owner-result`）：`#stage-owner`、`#btn-owner-quick`、`#project-owner-badge`、`#btn-owner`、`#btn-stage-owner`、`#owner-badge`、`#owner-summary`、`#btn-owner-open`、`#btn-flow-owner`、`#board-panel-owner`、`#owner-result`（`index.html:165/169/205/216/249/253-257/291/513`） | `openOwnerModal()`、`ownerState()`（`app.js:4301/258`） | 旧版只有 `[data-stage="bossreview"]` 节点 + 自动 modal（`index.html:98`、`app.js:1687-1730`） | **隐藏重复入口**，只留流程节点 + modal | **P1** |
| 8 | `#project-drawer` 六个 tab：`overview/board/flow/proposals/files/roles`（`index.html:224-229`；`#view-overview` / `#view-board` / `#view-flow` / `#view-proposals` / `#view-files` / `#view-roles`） | `renderOverview()`、`renderBoard()`、`renderFlow()`、`renderProposals()`、`loadFiles()`、`renderRoles()` | 旧版没有项目抽屉；旧版是 `#scenario-view` 场景网格 + 流程浮窗 + 看板窗口 | **降级**为只读项目概览；`#view-board` 尤其要改名/隐藏 | **P2**（`#view-board` 为 P1/P2） |
| 9 | `#view-board`“任务看板”四列（`index.html:275-285`） | `renderBoard()`（`app.js:...`） | 旧版“看板”= 团队看板（独立窗口），不是四列任务板 | **改名/隐藏**，避免和旧“看板”同名冲突 | **P1/P2** |
| 10 | `#sidebar`、`#workspace-pop`、`#stage-bar`（`index.html:106-176`、`68-80`） | `renderSidebar()`、`renderWorkspacePopover()` 等 | 旧版没有侧栏；旧版工作区操作在顶栏 + 场景网格 | **保留但标“新壳承载，不是旧版”**；严格对齐可隐藏 | **P2** |
| 11 | `#team-pill` / `#session-pill`（`index.html:28-33`） | `renderHeader()` | 旧版没有这两个 chip；旧版是 `#btn-team-board` / `#btn-team-members` | **降级/改名**，恢复旧按钮 | **P2** |
| 12 | `#btn-members` 行为（`index.html:171`） | `setDrawer('team')`（`app.js:5146`） | 旧 `#btn-team-members` 直接 `openMembersModal()`（`app.js:1641`） | **恢复为直接 modal** | **P1** |
| 13 | `#btn-team-board` 行为（`index.html:460`，团队台内） | `openBoardPanel()`（`app.js:5312`） | 旧 `#btn-team-board` 在顶栏，开 BrowserWindow（`app.js:1227-1241`） | **恢复顶栏入口 + 独立窗口** | **P1** |
| 14 | `#btn-team-board-old`（`index.html:214`，title 写“打开内嵌团队看板浮窗”） | `openBoardPanel()`（`app.js:5295`） | 旧版没有内嵌；id 里的 `old` 反而指向新面 | **改名/改绑 `team:board-old`** | **P2** |

### 4.1 当前 `#inbox-block` 的真实状态（不是“主界面”）

- 元素：`<details id="inbox-block" class="team-block inbox-block debug-fold">`（`index.html:434`），默认**不展开**；
- 文案：`<span class="debug-fold-hint">旧版没有此面板</span>`（`:439`），`<div class="debug-note"><b>调试工具，不是主界面。</b>旧版工作台没有收件箱…`（`:442`）；
- 读取门：`renderInbox()` 先判断 `block.tagName === 'DETAILS' ? Boolean(block.open) : !block.hidden`（`app.js:2359-2361`），折叠时不会自动读邮箱；
- 入口：more 菜单（`:101`）、角色卡（`app.js:3108`）、团队消息行（`app.js:1972`）。
- **评价**：折叠 + 标注“旧版没有此面板”是合格的“降级/隐藏”；但三个入口仍然让用户能找到它，严格对齐还应删入口。块内 `#inbox-rule`（`:456`）仍写“壳不代写”，与主进程行为不符（见 §6 P0-3）。

### 4.2 当前 `#team-receipts` 的位置与判定

- 块在团队台第 3 块（`index.html:380-392`），在“六角色会话”之后、`#team-log` 之前；
- 打开团队台时 `setDrawer('team')` 自动 `loadReceipts()`（`app.js:608`）；
- 口径：`receiptLedgerRows()` 做 `!row.update`、`msgId|from` 去重、项目过滤含空 `project`、`ts` 倒序、`slice(0,50)`（`app.js:1087-1099`），确实复刻了旧看板口径；
- **但旧版 UI 没有这个块**，旧版只在看板第 4 节显示。它属于“把旧看板内容搬进团队台”的新增面。严格对齐应删除/隐藏，或降级成“打开旧看板（回执在第 4 节）”的按钮。
- 当前 `listReceipts` 已去掉 `update` 标记（`team-tools.js:1563-1565`），所以 `receiptLedgerRows` 的 `!row.update` 不会误杀；当前“个人简历展示项目”可显示 13 条（与旧看板 13 条一致）。这一点是**正确的实现**，但正确性不等于“旧版有这块 UI”。

---

## 5. 旧版功能仍缺（按旧版证据逐条）

| # | 旧版能力 | 旧版证据 | 当前状态 | 判定 / 优先级 |
|---:|---|---|---|---|
| 1 | 顶栏可见“看板”“成员”按钮 | `index.html:19-20` `#btn-team-board` / `#btn-team-members` | 顶栏没有；`#btn-members` 进团队台抽屉（`app.js:5146`）；看板入口在团队台/更多菜单 | **缺入口，P1** |
| 2 | 10 节点 / 7 条边的流程浮窗 | `index.html:91-111`；`app.js:1675` `order`；`app.js:1739-1752` 节点/边刷新 | 8 阶段 / 5 边（`main.js:133-142`、`app.js:2968`）；`devreview`、`iterate` 0 命中 | **缺 2 节点 2 边，P1** |
| 3 | 流程文件监听推送 `workflow:changed` | `main.js:432-450`；旧 preload `API.team.onWorkflow` | `workflow:changed` / `onWorkflow` / `fs.watch` 均 0 命中 | **缺，P1** |
| 4 | Owner 自动弹窗、不可关闭、按 `roundKey` 去重 | `app.js:1687-1721`（`closable:false`）、`1723-1730`（`maybeOwnerReview`） | `openOwnerModal()` `closable:true`（`app.js:4312`）；注释明确“Owner 不自动弹窗”；无 `ownerPromptedKey` | **缺，P1（若严格可升 P0）** |
| 5 | 看板默认独立 BrowserWindow + 旧窗口参数 | `main.js:247-271`、`574-583`；参数 1120×780 / transparent / opacity .94 / min 300×64 | `#btn-team-board` → `openBoardPanel()` 内嵌；`team:board-old` 存在但参数是 opaque .97 / min 440×320 / collapse 56（`main.js:3118-3128`） | **默认行为变了，P1；参数 P2** |
| 6 | `team:board-project` 切项目后重载/显示看板窗口 | `main.js:585-597` | 当前 `team:board-project` 只生成，不负责开窗（`main.js:3028`） | **语义变了，P2** |
| 7 | 成员 modal 里的“逐个显示成员（各发一句已就位）” | 旧 `app.js:1648-1662` | `openMembersModal()` 只有“去角色页 / 关闭”（`app.js:3512-3545`） | **缺，P2** |
| 8 | 场景栏 / 场景页签 / 场景网格 / `scene:context` | `index.html:55-63`（`#scenebar`、`#scenario-tabs`）、`:79-80`（`#scenario-view`、`#grid`）；`app.js:467-518`、`1801-1808`；`main.js:285-303`、`:777`；旧 preload `app.scenarios` / `scene.context` | `app:scenarios` / `scene:context` 0 命中；`FEATURE-MATRIX.md:25` 自认“场景页签 未完成” | **缺，P2（最大结构缺口）** |
| 9 | 协作台面板（`collab`，含“最近回执流水”） | `app.js:610`、`986-1213`；`main.js:343-352`；旧 preload `collab.state` | `collab:state` 0 命中 | **缺，P2**（注意它是 `协作/state.json`，不是邮箱回执） |
| 10 | 顶部 WebAI 条 / DeepSeek 余额 / 扩展组（插件/技能/MCP/工具） | `index.html:15` `#webai-strip`、`:26-31` `#tb-group-ext`、`:59` `#balance-chip`；旧 preload `webai.open` / `app.balance` | `webai` / `balance` 0 命中 | **缺，P2** |
| 11 | More 菜单的刷新场景 / 窗口序号 / 检查更新 / 工作台体检 / 初始化记忆模板 | `index.html:40/45/47/48/49`；旧 preload `app.updateCheck` / `workbench.health` / `mem.inject` | `updateCheck` / `workbench:health` / `mem:inject` 0 命中 | **缺，P2** |
| 12 | 顶栏 CPU/GPU/MEM | `index.html:18` `#tbs-load` | 当前 `#metrics` 在侧栏底（`index.html:144`） | **有等价物，位置迁移；保留** |
| 13 | 顶栏工作区/建团队/恢复/刷新/文件夹 | `index.html:21-25` | 当前 `#btn-workspace` / `#btn-team-start` / `#btn-restore` / `#btn-refresh` / `#btn-folder-top` | **有等价物；保留** |
| 14 | 旧 `#flow-owner-state` | `app.js:1755` 查询，但旧 `index.html` 无此 id | 当前也没有 | **旧版死查询，不算“旧功能”** |

---

## 6. 保留 / 删除 / 降级清单（P0 / P1 / P2）

> P0 = 直接让“严格对齐旧版”结论失真，或当前 UI 文案与代码事实冲突；本轮必须先处理。
> P1 = 旧版有可见入口/主流程，当前缺失或默认行为被换掉；下一轮必须恢复。
> P2 = 旧版有但不在团队主链，或纯新增增强；可延后、可保留但必须标“非旧版”。

### P0：先删/先改，否则不能叫“对齐旧版”

| 编号 | 对象 | 处置 | 证据 / 说明 |
|---|---|---|---|
| P0-1 | `#team-receipts` 整块（`index.html:380-392`） | **删除或隐藏**；若产品坚持保留，降级为“打开旧看板”按钮，明确标“新增” | 旧 UI 没有这个块；旧回执只在看板第 4 节（`board.mjs:176`）和回执明细弹窗（`:212`） |
| P0-2 | `#more-menu [data-more="inbox"]`（`index.html:101`）、角色卡 `[data-role-inbox]`（`app.js:3108`）、团队消息行 `[data-msg-inbox]`（`app.js:1972`） | **删除入口**；`#inbox-block` 若保留，只允许开发开关打开 | 旧 UI `inbox/收件/未读` 四文件 0 命中；当前块自己写“旧版没有此面板”（`index.html:439`） |
| P0-3 | 多处“壳不代写/工作台不代写/壳不能代写”文案：`index.html:422`（`#dispatch-rule`）、`:456`（`#inbox-rule`）、`renderInboxDetail()` 空态文案、`openAckModal()` 文案 | **改文案或删块**：要么写清 `actor:'workbench-shell'`，要么真的让角色执行 | `main.js:3607/3640` 的 `team:inbox/team:read` 身份是 `actor:'workbench-shell'`；`main.js:4153-4154` 的 `team:ack` 注释原文“壳进程执行 team.mjs ack：actor 必须是 workbench-shell，不能冒充角色”。当前 UI 说“壳不能代写”与代码相反 |
| P0-4 | `#dispatch-rule` / `#dispatch-hint` 里的“旧协议 PM 单派锁 10 分钟自动释放” | **删掉“旧协议/TTL”说法**，改成“新壳本地锁”或不显示 | 旧协议没有 TTL（PARITY-ROUND7 §5.2：旧版无超时、无 cancel；`派单锁.json` 只在 ack 同 id 时清）；当前 `ACK_TTL_MS = 10*60*1000` 是新造语义（`main.js:143`） |
| P0-5 | `#team-receipts-rule` 的“旧看板口径” | 若保留块，文案可以留；但**块的位置必须标“新增”**，不能暗示旧版团队台有回执表 | 旧版团队台不存在；旧版回执表只在看板窗口 |

### P1：恢复旧版可见入口 / 主流程

| 编号 | 对象 | 处置 | 证据 / 说明 |
|---|---|---|---|
| P1-1 | `#btn-team-board` / `#btn-team-members` 顶栏入口 | **恢复顶栏两个按钮**；`#btn-members` 直接 `openMembersModal()`，不要 `setDrawer('team')` | 旧 `index.html:19-20`；旧 `app.js:1641` `api.team.members()` + `openModal`；当前 `app.js:5146` 进抽屉 |
| P1-2 | `#team-drawer` 整块 | **降级为旧成员 modal + 旧看板窗口**；不要在抽屉里塞 inbox/receipt/log/dispatch | 旧版没有团队台抽屉；旧成员清单 modal `app.js:1639-1666` |
| P1-3 | `#board-panel` / `#board-launcher` / `#team-board-summary` | **隐藏**；`#btn-team-board` 改回 `team:board-old`；`#btn-team-board-old` 改绑 `team:board-old` | 旧 `#btn-team-board` → `team:board` → `openTeamBoard()` BrowserWindow（`app.js:1227-1241`、`main.js:247-271/574-583`） |
| P1-4 | Owner 的 11 个 Owner 相关点（10 个入口 + `#owner-result`） | **只留流程节点 + modal**；恢复 `stage==='bossreview'` 自动弹、`closable:false`、`roundKey` 去重；删 `#stage-owner` / `#btn-owner-quick` / `#project-owner-badge` / `#btn-owner` / `#btn-stage-owner` / `#owner-badge` / `#owner-summary` / `#btn-owner-open` / `#btn-flow-owner` / `#board-panel-owner` | 旧 `index.html:98`、`app.js:1687-1730`、`1754-1765`；旧 DOM 没有这些 id |
| P1-5 | 流程 10 节点 / 7 边 | 恢复 `devreview`、`iterate` 节点和 `dev-test`、`close-iterate` 边；`STAGES`/`flowMarkup` 对齐旧 `order` | 旧 `index.html:91-111`、`app.js:1675`；当前 `devreview`/`iterate` 0 命中 |
| P1-6 | `workflow:changed` 文件监听 | 恢复 `fs.watch` + 220ms 去抖 + `onWorkflow`；否则流程不会实时高亮 | 旧 `main.js:432-450`、旧 preload `API.team.onWorkflow`；当前 0 命中 |
| P1-7 | `#team-log`“团队消息” | **隐藏/删除**；旧版没有壳内消息流，消息在邮箱/终端，回执在看板 | 旧 UI 0 命中；旧消息只进 `邮箱/<role>/new`，旧 `team:status` 也不给壳内消息流 |
| P1-8 | `#dispatch-form` / `#dispatch-pending` | **隐藏/删除**；若要保留，标“新增”，并修正 P0-4 的 TTL 文案 | 旧版没有发件/回执表单；旧 PM 派单走 `team.mjs send`（`ops.mjs:339`） |
| P1-9 | `#view-board`“任务看板” | **改名“任务”或隐藏**；旧版“看板”专指团队看板窗口 | 旧 `#btn-team-board` title 就是“团队看板…回执…文件”；当前同名四列任务板会造成“看板”二义 |

### P2：旧版有、但不在团队主链；或纯新增增强

| 编号 | 对象 | 处置 | 证据 / 说明 |
|---|---|---|---|
| P2-1 | 场景栏 / 场景页签 / 场景网格 / `scene:context` / `app:scenarios` | **补**；或至少在 README/FEATURE-MATRIX 继续标“未完成”，不要宣称逐像素 | 旧 `index.html:55-63` / `79-80`；`app.js:467-518` / `1801-1808`；`main.js:285-303` / `777`；`FEATURE-MATRIX.md:25` |
| P2-2 | 协作台面板（“最近回执流水”） | **补**；必须标数据源 `工作台\协作\state.json`，不要与 `回执.jsonl` 混用 | 旧 `app.js:986-1213`、`main.js:343-352`；旧文案“数据源 工作台\协作\state.json”在 `app.js:1194` |
| P2-3 | 扩展组（插件/技能/MCP/工具）、WebAI 条、余额、更新/体检/记忆模板/窗口序号 | **按需补**；这些是旧版顶栏/更多菜单的可见面 | 旧 `index.html:15/26-31/45-49/59`；旧 preload `webai.open` / `app.balance` / `app.updateCheck` / `workbench.health` / `mem.inject` |
| P2-4 | 看板窗口视觉保真 | 若要逐像素：`transparent:true`、`opacity:0.94`、`minWidth:300/minHeight:64`、collapse 64；当前是 opaque `.97`、min 440×320、collapse 56（`main.js:3118-3128`） | 旧 `main.js:255-267`、`:629`；旧窗口 `alwaysOnTop('floating')` |
| P2-5 | `team:board-project` 语义 | 旧版切项目后 `loadFile + show + focus`（`main.js:585-597`）；当前只生成（`main.js:3028`）。若恢复旧入口，需把“切项目”绑回窗口 | 旧 `main.js:585-597` |
| P2-6 | 成员 modal 的“逐个显示成员” | 补回旧按钮/确认框，或明确用 `#btn-team-start` 的 seed 替代 | 旧 `app.js:1648-1662`；当前 `openMembersModal()` `app.js:3512-3545` 没有该按钮 |
| P2-7 | `#btn-team-board-old` 命名 | 改名（如 `#btn-team-board-window`）或改绑 `team:board-old`；当前 title 仍写“打开内嵌团队看板浮窗”（`index.html:214`） | 旧版没有“内嵌”；id 的 `old` 与实际行为相反 |
| P2-8 | 侧栏 / 工作区浮层 / 阶段栏 / `#team-pill` / `#session-pill` | **保留但标“新壳承载，不是旧版”**；严格逐像素时再隐藏 | 旧 `index.html` 没有 sidebar/workspace-pop/stage-bar/chip；旧工作区操作在顶栏 + 场景网格 |
| P2-9 | 项目抽屉的 proposals/files/roles/overview 四个 tab | **保留但降级为只读**；不要把它们当作旧版看板/成员入口 | 旧版提案/文件在场景网格与看板里；成员是 modal；没有项目抽屉 |

### 6.1 明确“保留”的旧版面

| 保留项 | 理由 |
|---|---|
| `#flow-launcher` / `#flow-panel` | 旧版唯一 Owner/流程浮窗入口；但必须恢复 10 节点 + 自动弹窗 |
| `#onboard` | 旧版有新手引导（`index.html:118`）；当前 `#onboard` 是等价物 |
| `openMembersModal()`（`app.js:3512`） | 旧版成员 modal 的等价物；恢复顶栏直接入口即可 |
| `team:board-old` / `openTeamBoardOld()`（`app.js:5106`） | 旧版 BrowserWindow 的等价物；应设为默认看板入口 |
| `#btn-workspace` / `#btn-team-start` / `#btn-restore` / `#btn-refresh` / `#btn-folder-top` | 旧版顶栏工作区/建团队/恢复/刷新/文件夹的等价物 |
| `#metrics` | 旧版 `#tbs-load` 的等价物（位置从顶栏移到侧栏） |
| `#btn-theme` / 版本 / 新手引导 | 旧版 more 菜单的主题/版本/引导等价物；保留 |
| `#dsh-view` | 旧版 `#engine-view` / `#engine-webview` 的等价物；保留 |

---

## 7. 回执列表的额外核对（当前新增块的正确性 ≠ 旧版有这块 UI）

### 7.1 当前实现的正确部分

`team-tools.listReceipts()`（`team-tools.js:1490`）当前：

- 只读 `layout.receiptsFile`，路径必须在团队根内，软链接 `realpath` 复核（`1503-1526`）；
- 只读尾部 8MiB，截断首行丢弃，标 `tailOnly`（`1527-1551`）；
- 按 `id` 合并 `update:true` 行，并 **`delete merged.update`**（`1563-1565`），所以一条回执只出现一次；
- `projects` 数组 + `includeUnassigned` 过滤（`1570-1575`），按 `ts` 倒序，`limit` 截断（`1577-1589`）。

前端 `receiptLedgerRows()`（`app.js:1087-1099`）再做 `!row.update`、`msgId|from` 去重、项目过滤含空 `project`、倒序；`renderReceipts()` 取前 50（`app.js:1116-1215`）。当前“个人简历展示项目”实测为 **13 条**（与旧看板第 4 节 13 条一致；全量 165 条去重后 165，旧看板口径 165）。

### 7.2 仍然与旧看板口径不同的地方

1. **空 `project` 行默认被排除**：`listReceipts` 里 `if (!value) return includeUnassigned;`（`team-tools.js:1572-1574`），而前端 `loadReceipts()` 只传 `projectId/project/limit`（`app.js:1244-1248`），没有传 `includeUnassigned:true`。旧看板是 `!r.project || r.project === 当前`（PARITY-ROUND7 §6.3），空 project 的老回执会出现在所有项目里。当前账本空 project 行 = 0，所以暂时看不出差异；一旦导入旧账本/老回执，行为会漂。
2. **位置不对**：旧看板是独立窗口，团队台没有回执表；当前 `#team-receipts` 是团队台第 3 块，且打开团队台就自动加载（`app.js:608`）。这是新增面，不是旧版。
3. **接口名漂移**：ROUND7 的 G2 期望 `listReceiptsFor()`；当前实现叫 `listReceipts()`（`team-tools.js:1490`），`listReceiptsFor` 仍 0 命中。后续按符号复核时不要 grep 错名字。

### 7.3 结论

- 如果目标是“严格对齐旧版 UI”：**删掉 `#team-receipts`**，回执仍然只在 `team:board-old` 打开的 `看板.html` 第 4 节看；`team:receipts` 后端可以保留给看板/自检，但不要渲染成团队台列表。
- 如果产品决定保留 `#team-receipts`：必须标“新增（旧版没有）”，并补 `includeUnassigned:true`（若要兼容老回执）；不要再写“旧版团队台回执表”。

---

## 8. 复核命令与验收断言

### 8.1 先确认快照

```powershell
cd D:\deepseek\agile-workbench
Get-FileHash src\main.js,src\team-tools.js,src\preload.js,src\renderer\app.js,src\renderer\index.html,src\renderer\style.css -Algorithm SHA256 |
  ForEach-Object { "{0} {1} {2} {3}" -f $_.Hash.Substring(0,16),(Get-Item $_.Path).Length,(Get-Item $_.Path).LastWriteTime.ToString('HH:mm:ss'),(Split-Path $_.Path -Leaf) }
```

S8 期初期望：`main 36D9FA6F… / team-tools 714F2495… / preload 1955CC1D… / app BECEEC45… / index BB706862… / style 73CCED07…`；写完本文件时 `app` 已到 `45AFE170…`（12:02:05）。任一不同 → 按符号重验，不要照行号。

### 8.2 旧版“无 inbox”复核（应全部 0）

```powershell
$old='D:\deepseek\luanyujia-workbench\12-源码照搬\外壳'
Select-String -Path "$old\renderer\index.html","$old\renderer\app.js","$old\main.js","$old\preload.js" `
  -Pattern 'inbox|收件|未读|team:send|team:ack|team:read'
```

### 8.3 当前新面符号

```powershell
Select-String -Path src\renderer\index.html -Pattern 'id="team-receipts"|id="inbox-block"|id="team-log"|id="dispatch-form"|id="board-panel"|id="board-launcher"'
Select-String -Path src\renderer\app.js -Pattern 'renderReceipts|renderInbox|renderTeamLog|renderDispatch|openBoardPanel|openOwnerModal'
Select-String -Path src\main.js -Pattern "team:receipts|team:inbox|team:read|team:ack|team:board-old"
Select-String -Path src\preload.js -Pattern 'teamReceipts|teamInbox|teamRead|teamAck|teamBoardOld'
```

### 8.4 回执账本（只读，应保持 392 / 128 / 328 / 165）

```powershell
$s='D:\deepseek\agile-workbench\团队\状态'
(Get-ChildItem "$s\邮箱" -Recurse -File -Filter *.json).Count
(Get-ChildItem "$s\邮箱" -Recurse -File -Filter *.json | Where-Object { $_.Directory.Name -eq 'new' }).Count
(Get-Content "$s\回执.jsonl").Count
(Get-Content "$s\回执.jsonl" | Where-Object { $_ -match '"update":true' }).Count
```

当前应为 `392 / 128 / 328 / 165`（本项目回执 13）。任何变化先确认是不是测试污染，再谈 parity。

### 8.5 验收断言

| 断言 | 判据 |
|---|---|
| A8-1 旧版无 inbox | §8.2 四文件全部 0 命中；文档/注释不得再写“还原旧版收件箱” |
| A8-2 inbox 无第一入口 | 严格对齐后 `#more-menu [data-more="inbox"]`、`[data-role-inbox]`、`[data-msg-inbox]` 均 0 命中；`#inbox-block` 只能由开发开关打开 |
| A8-3 回执只在看板 | 严格对齐后 `#team-receipts` 0 命中；`看板.html` 第 4 节行数 = 当前项目 `!update` + `msgId|from` 去重后的条数（当前 13） |
| A8-4 看板默认独立窗口 | 点 `#btn-team-board` 产生 `BrowserWindow`（`team:board-old`），不是 `#board-panel` iframe；`#board-panel` 不存在或 hidden |
| A8-5 成员入口 | 点 `#btn-members` 直接出“团队成员”modal，不是 `#team-drawer` |
| A8-6 Owner 自动闸门 | `stage==='bossreview'` 时自动弹；`closable:false`；同 `roundKey` 不重复；`#flow-panel [data-stage="bossreview"]` 高亮变化 |
| A8-7 10 节点流程 | `#flow-panel .flow-node` / `#flow-board .flow-node` 数量 = 10；`data-stage` 含 `devreview`、`iterate`；边含 `dev-test`、`close-iterate` |
| A8-8 流程推送 | 修改 `工作流.json` 后 1 秒内收到 `workflow:changed` / 流程图重绘；`onWorkflow` 存在 |
| A8-9 文案与 actor 一致 | UI 不得再出现“壳不代写/壳不能代写/工作台不代写”；若出现“壳执行”，必须与 `main.js` 的 `actor:'workbench-shell'` 对齐 |
| A8-10 TTL 文案 | UI 不得把 10 分钟写成“旧协议”；旧协议无 TTL（PARITY-ROUND7 §5.2） |
| A8-11 回执列表口径 | 若保留 `#team-receipts`：当前项目 13 条；`includeUnassigned:true` 时含空 project；否则文案标“尚未兼容空 project” |
| A8-12 窗口参数 | 若要逐像素：`transparent:true`、`opacity:0.94`、`minWidth:300`、`minHeight:64`、collapse 64；当前 `main.js:3118-3128` 是 `.97/440/320/56` |

---

## 9. 只读边界与残留

- 本轮只新增/修改 `docs/PARITY-ROUND8.md`。
- 未修改：`src/**`、`package.json`、`package-lock.json`、`node_modules`、`团队/**`、`项目/**`、`userdata-selftest/**`、`D:\deepseek\工作台\**`、`D:\deepseek\luanyujia-workbench\**`。
- 未运行：`npm run check` / `npm run selftest` / Electron。本轮新壳在 11:40–11:57 被并行修改（见 §1.2），跑测试得到的绿/红都不代表稳定快照。
- 引用到的账本数字均为只读统计（`Get-ChildItem` / `Get-Content` / Node 只读解析），未写入任何状态文件。
- **本文件不是“当前实现正确”的证明**，只证明在 S8 快照上，旧版 UI 没有 inbox / 团队台回执表 / 内嵌看板；当前这些面是新增。若 hash 已变，先按 §8 符号复核，再决定哪条还需做。
