# 第九轮 · 六角色通信链路与评审流程只读审计（旧代码 / 新壳对照）

> 范围：只回答三问——①六角色会话之间通信是否真的正常、旧版 `send/inbox/read/ack` 完整链路；②当前新壳哪些环节只是壳进程代跑、不是角色会话自己执行；③评审 `propose/show/review/sign/apply` 与旧版差在哪。
> 只读边界：本轮**只写本文件** `docs/PARITY-ROUND9.md`。未修改 `src/**`、`package.json`、`package-lock.json`、`node_modules/**`、`团队/**`、`项目/**`、`userdata-selftest/**`、旧仓库 `D:\deepseek\工作台` 与 `D:\deepseek\luanyujia-workbench`。未启动 Electron、未跑 `npm run check`/`selftest`、未向 DSH 发任何 RPC、未执行任何会写团队状态的 `team.mjs` 子命令（只跑了 `doctor` / `verify` 两条只读命令，复核见 §5.1）。
> 证据分级：**静态** = 只读源码（旧三文件行号字节稳定，新壳按“符号 + IPC 名 + 选择器”定位，行号只作定位提示）；**组件** = 在内存里调用旧 `lib/store.mjs` 的纯函数做哈希对照，不落盘；**账本** = 对 `团队/状态` 做只读统计；**未验证** = 需要 DSH 运行时才能确认的项，本轮明确标出。

---

## 0. 三问判定（先看这一页）

| 问题 | 判定 | 一句话依据 |
|---|---|---|
| ① 六角色会话之间通信是否正常 | **部分** | 旧引擎的“投递 + 回执回信”链路完整可证；新壳只证明了“壳替发件人写信 + 向收件会话投一条 prompt”，**没有任何代码证明收件角色真的执行过、也没有对账把回程闭环**；而当前落盘状态（状态库 0 项目、名册 activeProject 目录已删）**开箱跑不起来**。 |
| ② 新壳哪里是壳进程代跑 | **新壳代码路径里，所有写操作都由壳执行；0 个由角色会话保证执行** | 发件 / 回执 / 标已读 / 签到(boot) / 提案 / 评审 / 签字 / 应用 / 回滚 / 撤销派单 / Owner 决定 / 任务写，全部落在主进程；`team-tools.js` 的 **14 处** `await runNode(...)` 里 `boot/send/inbox/read/ack/board/ensure/launch/project use/owner-note` 与**旧协议评审桥**（`propose/show/review/sign/apply`）都是壳 spawn 旧 CLI；本地表单链则连旧 CLI 都不调，直接写 `workbench.json`。角色会话唯一的“参与”是被 `dsh.prompt` 叫醒后自己敲命令（旧协议仍可用），但这一步**新壳没有要求、没有回执、没有校验**。 |
| ③ 评审五步与旧版差在哪 | **本地链：不能算旧流程的替代；旧协议桥：能力齐了，界面只接了“刷新状态”，执行者仍是壳** | 旧版五步是“令牌 + 任务归属 + 授权 + 先 show（阅读回执）+ 哈希绑定签字 + PM-only + CAS/备份/回滚/产物/索引 + 三类通知邮件”。S10 里有两条新链：**本地表单链**（界面主路径）只写 `workbench.json`，没有 show/令牌/授权/签名摘要/通知；**旧协议桥**（`proposal:legacy`）把全部约束交回 `team.mjs`，界面只在“旧协议镜像”卡片上提供 `show` 刷新，建/评/签/应用仍走本地，且调用者是壳、`actor` 不落旧账。本地链镜像进旧目录的提案会被旧 `show` 判 `PROPOSAL_TAMPERED`（§4.4 有确定性复现）。 |

### 0.1 十六条要点

1. **旧版链路本身是“文件邮箱 + 会话唤醒”，不是会话直连**：发件只写 4 个文件，收件靠角色自己 `boot → inbox → read → ack`，回执靠“再发一封 mailbox 消息”（`ops.mjs:339-411`、`store.mjs:353-380`、`store.mjs:435-475`）。
2. **旧版 `inbox` 是零写入命令**；新壳 `team:inbox` 会先替该角色 `boot`，一次读产生 `启动/<token>.json` + `阅读.jsonl` 一行 + `事件.jsonl` 一条 `boot`（`team-tools.js:1879-1921` `inboxFor` → `withBootToken:1384` → `bootToken:1337` → `team.mjs boot`）。**只读入口带着写副作用和一把 30 分钟令牌**。
3. **旧版 `read` 不是 `ack` 的前置**（`ackMessage` 内部自己 `readMessage`，`store.mjs:444`）；但旧版 `review` 必须以 `show` 为前置（`ops.mjs:718-722`）。新壳把前一条保留了（ack 隐含已读），把后一条**整条删了**（没有 show、没有 `阅读.jsonl`）。
4. **“六角色互通”在旧账本里有硬证据**：392 封邮件、128 封未读、203 封要回执、186 封是回执回信，其中**非 PM 的角色之间互发 21 封**（例：`M-20261029-215214-9403e1 product->analyst review`）。这不是“PM 一个人转述”。
5. **旧版允许发给自己**：账本里有 **62 封 `pm->pm`**（签字/完成回执通知自己）。新壳 `team:send` 直接拒绝 `from === role`（`main.js:4172`），这 62 类消息在新壳**发不出来**。
6. **新壳发件要求“发件人 + 收件人两边都有当前项目的活会话”**（`team:send`：`main.js:4224-4235`；两处 `verifyProjectRoleSession` 调用 `:4245-4247`），且要过 `session/list` 核验“会话存在、未归档、属于本 workspace”（`verifyProjectRoleSession`，`main.js:2005-2058`）。**DSH 一断，连发件都发不了**，不是降级而是硬失败。
7. **新壳读收件箱也要求同一把会话尺子**（`main.js:4004-4017` → `resolveProjectTeamRole` → `verifyProjectRoleSession`）：DSH 离线时**磁盘上的邮箱读不出来**。旧版 `inbox` 只要令牌，不需要 DSH。
8. **新壳的 `team:read` 是壳替角色消费未读**（`main.js:4048-4085` → `readFor` → `team.mjs read` 把 `new` 改名进 `cur`）。S10 用 `comm.read.by` 区分：壳点的写 `by:'workbench-shell'`（`:4071-4082`），对账从 `cur` 推断的写 `by:'role'`（`:938-951`）。**S10 之前历史 `cur` 仍会被推断成“角色读的”。**
9. **跨项目读的拒绝发生在副作用之后**：`readFor` 先跑完旧 `read`（已经把邮件 `new→cur`），再比对 `message.project`，不匹配才报 `MESSAGE_PROJECT_MISMATCH`（`team-tools.js:1951` → `:1955-1960`）。拒绝时邮件已被读走，且旧工具已写了一条 `mail_read` 事件。
10. **角色自己 ack 后本地 `pendingAck` 的回收，S10 已修**：新增 `reconcileProjectCommStates`（`main.js` `reconcileProjectCommStates`），`statePayload` 每次刷新都会跑（1 秒缓存），`team:send` 开头也会强制跑，`team:inbox/read/ack/comm/reconcile` 同样调用。S9 时只有 `team:send` 一个点（当时的结论见 §8）——**这是审计窗口内被修掉的一条**。
11. **`team:ack` 是真代跑，而且文案自相矛盾**：主进程确实以收件角色会话执行 `team.mjs ack`，但写 `actor:'workbench-shell'`（`main.js` `team:ack` → `ackDispatch`）；`index.html` 的 `.dispatch-rule` 已经改成“工作台壳持收件角色会话身份执行旧协议 ack，回执 `actor=workbench-shell`”，而 `openAckModal` 仍写“壳不能代写”（`app.js` `openAckModal`）。**同一件事两套说法，同屏可见。**
12. **`LEGACY_REVIEW_ACTIONS` 在 S10 里被真正用上了**（`team-tools.js:2128`）：`legacyProposalAction()` 用它校验动作，然后 spawn `team.mjs propose/show/review/sign/apply`。所以“评审链完全不碰旧协议”这个 S9 判断已被推翻——**现在有两条评审链**（见第 13 条）。
13. **新壳现在有两条评审链，界面主路径仍是“本地”那条**：
    - **本地链（UI 在用）**：`proposal:create/review/sign/apply/rollback`（`main.js` 同名 handler）只写 `workbench.json`，不碰令牌/会话/旧协议；`proposal:create` 已改成**显式拒绝**带 `files[].staged`/`legacy`/`protocol` 的旧协议形状，多文件也改成报 `LEGACY_PROTOCOL_REQUIRED`。
    - **旧协议桥（IPC 有，界面只接了 `show`）**：`proposal:legacy` / `team:proposal-legacy`（`main.js:4010-4011`）→ `legacyProposalAction`（`team-tools.js:2126-2255`）→ `team.mjs propose|show|review|sign|apply`，带角色会话核验与 boot 令牌。界面已能**区分**旧协议镜像并调用 `proposal:legacy show` 刷新状态（`app.js` `proposalIsLegacy` / `refreshLegacyProposal`），但**建/评/签/应用四个动作仍只走本地链**。
14. **镜像进旧目录的“哈希不兼容”只对本地链提案成立**：`mirrorToTeamBoard` → `syncWorkbenchBoard`（`main.js:2438`、`team-tools.js:937-1127`）会把本地提案写成 `状态/项目/<slug>/提案/<P>/提案.json` + 评审/签字/提交，`proposalHash` 用的是内容哈希（§4.4 有确定性复现）。但 `syncWorkbenchBoard` 只覆盖自己写过的文件（`previous.source !== 'workbench'` 就 `continue`，`team-tools.js:965,1014,1098`），所以**旧 CLI 写的提案不会被它改**；legacy 桥产出的提案本身带旧 `proposalHash`，也不受影响。
15. **本地链 `proposal:apply` 仍然没有角色门，签字仍然不绑定内容**（`proposal:apply` 全程不读 `role`；`proposal:sign` 只写 `{by,decision,note,at}`；`apply` 只校验目标 `baseHash`，不校验 `stagedContent`）。**这条只对本地链成立**：legacy 桥把 `PM-only`、`checkApprovals`、签名摘要、CAS/备份/回滚全交给 `team.mjs apply`，那些约束是真的。
16. **“六角色通信开箱不可用”是可复现的事实**：`data/userdata/workbench.json` 不存在（状态库为空 → 0 个项目）；`团队/状态/团队.json.activeProject = 个人简历展示项目`，而该目录已删除；`team.mjs verify` 在该账本上报 **64 条事件链 HASH 问题 + 缺失文件**。详见 §2.6、§1.3。

---

## 1. 快照、证据与“源码在动”的处置

### 1.1 旧版基准（只读，字节稳定）

| 文件 | 大小 | SHA256 前 16 | 最后写入 | 用途 |
|---|---:|---|---|---|
| `D:\deepseek\工作台\团队\工具\lib\ops.mjs` | 111,912 | `C399439DF429C000` | 2026-11-03 07:03:22 | `boot/send/inbox/read/ack`、派单锁、唤醒文案、五步评审 |
| `D:\deepseek\工作台\团队\工具\team.mjs` | 5,354 | `E24B0583ABFEE18A` | 2026-11-03 03:52:38 | CLI 分派、退出码 |
| `D:\deepseek\工作台\团队\工具\lib\store.mjs` | 32,739 | `EA2FC2B17493CFCD` | 2026-11-03 03:52:27 | 邮箱、令牌、回执、`ackMessage`、提案哈希/签名摘要 |
| `D:\deepseek\agile-workbench\团队\工具\lib\ops.mjs` | 111,912 | `C399439DF429C000` | — | **与新仓库副本字节相同** |
| `D:\deepseek\agile-workbench\团队\工具\lib\store.mjs` | 32,739 | `EA2FC2B17493CFCD` | — | 同上 |
| `D:\deepseek\agile-workbench\团队\工具\team.mjs` | 5,354 | `E24B0583ABFEE18A` | — | 同上 |
| `D:\deepseek\luanyujia-workbench\12-源码照搬\外壳\main.js` | 67,864 | `E54991F0A2EDA795` | 2026-11-03 09:14:17 | 旧壳 IPC（无 `team:send/ack/inbox`） |

**正面证据**：新仓库里的 `团队/工具/**` 与旧仓库**逐字节相同**（`ops/store/team/core/launch/board` 六个文件 hash 全等）。所以“新壳调用的是真旧引擎”这一点成立，下面的差异**不是**引擎被改，而是**壳绕过或替代了引擎**。

### 1.2 新壳快照（审计期间连变三次；正文按 S10 复核，末尾附 S11）

| 文件 | 审计开始时（S9-） | 中途（12:46） | 结束时（S10，12:49） |
|---|---:|---:|---:|
| `src/main.js` | 345,355 / `7642B70E37AEA1A0` / 12:37:21 | 同 | **372,836 / `D9E1C3B54ECA9A76` / 12:49:35** |
| `src/team-tools.js` | 92,218 / `3DBD00C66F535441` / 12:33:24 | 同 | **111,864 / `EB5BBBEBFE934342` / 12:47:17** |
| `src/preload.js` | 4,750 / `1955CC1DC8F79D63` / 11:47:09 | 同 | **5,895 / `8D2F2EBA65F7AFF7` / 12:49:38** |
| `src/renderer/app.js` | 261,160 / `00F18FD7588295E5` / 12:32:42 | 283,345 / `DF8981C593F0A3FC` / 12:46:04 | **290,771 / `E653DB23381869A2` / 12:49:14** |
| `src/renderer/index.html` | 36,953 / `BB70686271D092F1` / 11:49:56 | 38,498 / `F68B0056606BC665` / 12:44:29 | **38,589 / `4D42ABCCF34BF68B` / 12:49:09** |
| `src/renderer/style.css` | 101,066 / `73CCED0709A93B84` / 11:54:29 | 同 | **108,190 / `3D47E4DD5AB8CD98` / 12:49:16** |

**必须写进结论**：审计窗口内 `src/**` 被并行改了至少三次（12:44–12:46、12:47–12:49、12:50–12:53，`.selftest-data` 同时在写）。**本报告第 0/2/3/4 节已按 S10（12:49）复核并修正**；S11 又把 `main.js` 推到 400,618 字节、`app.js` 推到 302,342 字节（§8.4）。**正文里 `main.js:NNN` 的精确行号只对应 S10（372,836 字节版本），S11 起整体再下移约 8–15 行**，请按“符号 + IPC 名”定位。凡 S10 新增/改写的结论，另见 §8“S9 → S10 变更补记”——那里逐条说明哪些早期判断被推翻、哪些仍然成立，以及 S11 又变了什么。渲染层引用以符号名为主（`dispatchSteps` / `openAckModal` / `renderProposals` / `teamInboxBoxFor` / `openInboxRolePrompt` / `refreshLegacyProposal`）。

### 1.3 账本与运行态（只读统计）

| 指标 | 数值 | 说明 |
|---|---:|---|
| `团队/状态/邮箱` 邮件总数 | **392** | 六角色全部 |
| 其中 `new/`（未读） | **128** | pm 59 / analyst 18 / tester 17 / programmer2 13 / programmer1 12 / product 9 |
| `ackRequired=true` | **203** | |
| 消息类型 | `receipt` 186、`note` 116、`review` 30、`proposal` 19、`grant` 18、`sign` 16、`welcome` 4、`reconcile` 3 | 近一半是回执回信 |
| 非 PM 的角色之间互发 | **21** 封 | 例：`product->analyst` 评审/收据、`programmer2->programmer1` 评审通知 |
| `pm->pm` | **62** 封 | 旧版允许自发；新壳禁止 |
| `回执.jsonl` | 328 行 / 86,352 B | `update:true` 163 行 → 真实回执 **165** |
| `回执.jsonl` 中 `identitySource` / `actor` / `sessionId` | **0 / 0 / 0** | 新壳从未在这本账上成功写过一次 ack |
| `事件.jsonl` | 1,212 行，最后一条 **2026-11-03T01:01:44Z** | 之后无任何新事件：账本是旧时代副本 |
| `启动/` 令牌文件 | 91 | 全部过期（旧版无清理器） |
| `状态/项目/*/派单锁.json` | **0** | 无残留锁 |
| `team.mjs doctor`（只读） | `ok:false`，`issues:["事件链问题 64"]` | 见 §2.6 |
| `team.mjs verify`（只读） | `ok:false`：64 条 `EVENT_CHAIN` + 多条 `MISSING`（个人简历展示项目文件全缺） | 同上 |

**账本最老的一条 `seq:1` 哈希就不匹配**（`got 88c0e1fd… expected 9250f321…`）。这意味着**在这份副本上，“事件链”这条自证机制本身是不成立的**：不能拿 `事件.jsonl` 当“谁做过什么”的证据，只能当“曾经有过这些动作”的线索。这一点直接影响第 1 问的判定口径。

### 1.4 只读边界实测

`团队/状态` 九个文件的 mtime 在本轮审计前后一致（`事件.jsonl` 11-05 07:05:18、`回执.jsonl` 11-03 08:48:15、`团队.json` 11-03 08:17:20、`看板.json/md` 11-05 07:05:26、`阅读.jsonl` 11-03 08:59:15），`状态/锁` 仍为 0 个文件。即 `doctor` / `verify` 两条只读命令没有写盘。

---

## 2. 第 1 问：六角色会话之间通信是否真的正常

### 2.1 旧版完整链路（谁执行、写什么、闸门在哪）

```text
[角色会话自己]                      [旧引擎 team.mjs / lib]                        [磁盘]
  │
  ├─1 boot ───────────────────────► cmdBoot  ops:273-316
  │                                  memberOrFail / loadProject / readDocSet(4 份文档)
  │                                  createBootToken  store:307-326  ──────────► 状态/启动/<token>.json
  │                                  addReadReceipt   store:826-833 ───────────► 状态/阅读.jsonl（+1 行）
  │                                  appendEvent(boot) ops:290-294 ───────────► 状态/事件.jsonl（+1 行）
  │  ◄── 启动简报（令牌/规则哈希/未读/任务/提案/授权）ops:295-315
  │
  ├─2 send（任意角色→任意角色）───► cmdSend ops:339-411
  │                                  bootFor  ops:36-41（令牌 role/project 必须一致）
  │                                  notify→sendMessage store:353-380 ────────► 邮箱/<to>/new/<ts>-<M-id>.json
  │                                  appendEvent(message) ops:176-183 ───────► 事件.jsonl（+1 行）
  │                                  pm 派单（pm + --ack + to≠pm）：
  │                                    writeDispatchLock ops:326-330,373 ─────► 状态/项目/<slug>/派单锁.json
  │                                    （已有锁且无 --force → PM_DISPATCH_PENDING ops:348-353）
  │                                  pm + --task：任务无 owner 则补 owner ops:355-368
  │                                  唤醒 ops:374-409：DshClient.prompt(sessionId, 7/8 行文案, queue)
  │
  ├─3 inbox --boot T [--all] ─────► cmdInbox ops:414-421 → listInbox store:382-397
  │                                  **零写入**；默认只 new；--all 才含 cur；每条带 box 字段
  │
  ├─4 read --id M-x ──────────────► cmdRead ops:423-429 → readMessage store:417-429
  │                                  把 new/<file>.json rename 到 cur/（EEXIST 则删 new）
  │                                  appendEvent(mail_read) ───────────────────► 事件.jsonl（+1 行）
  │
  └─5 ack --id M-x --note … ──────► cmdAck ops:431-441 → ackMessage store:435-475
                                     note 超 300 字 → RECEIPT_TOO_LONG（报错不截断）
                                     已有 {msgId,from} 回执 → already:true（不重复写）
                                     readMessage（隐含已读）
                                     appendLine(ack) ─────────────────────────► 回执.jsonl（+1 行）
                                     原消息 from≠system 且 type≠receipt 时：
                                       sendMessage(type:'receipt', replyTo:原id, ackRequired:false)
                                                                         ─► 邮箱/<原发件人>/new/…（回程）
                                       appendLine({...ack, update:true, receiptMessageId})
                                                                         ─► 回执.jsonl（再 +1 行）
                                   clearDispatchLock 仅在 lock.messageId === 被 ack 的 id 时删锁 ops:331-337,435
                                   appendEvent(ack) ────────────────────────► 事件.jsonl（+1 行）
```

**这套链路的关键性质**（决定第 1 问怎么答）：

| 性质 | 证据 | 含义 |
|---|---|---|
| 通信是**文件投递**，不是会话直连 | `store.mjs:349-380` | 两个人不需要同时在线；邮件先落盘 |
| “送达”只到 `new/` 文件 | 同上 | 没有任何送达确认 |
| 收件角色**必须自己** boot/read/ack | `ops.mjs:414-441`（每个命令都 `bootFor`） | 发件人无法替收件人确认“已读/已回执” |
| 回执是**再发一封邮件** | `store.mjs:458-472` | 回程也是一个 mailbox 文件，发件人下次 `boot` 的“未读”+1 |
| 回执不递归 | `store.mjs:458`（`type!=='receipt'`） | 对回执再 ack 只写 1 行、不发新邮件 |
| `ack` 不检查 `ackRequired` | `ops.mjs:431-441` 无该判断 | 不要求回执的消息也能被 ack（账本里有实例） |
| `read` 不是 `ack` 前置 | `store.mjs:444` | 只 ack 也会 new→cur |
| 令牌 30 分钟、文档一改即废 | `store.mjs:307-326,328-345` | `RULES_CHANGED` 让所有旧令牌失效 |
| 失败退出码 | `team.mjs:108-121` | `TeamError`→3，内部异常→4，`--json` 失败走 stdout |

### 2.2 旧账本对“六角色互通”的证明

- 392 封邮件里 **186 封是 `receipt`**：说明“A 发→B 回执→A 收到回信”这个环被真实走过至少 165 次（`回执.jsonl` 去重后 165 条）。
- **21 封非 PM 的角色互发**，例：
  - `M-20261029-215214-9403e1 product->analyst review 评审通过 P-20261029-215146-35aecf`
  - `M-20261031-234241-bc975c product->analyst note 请重发 P-20261031-233835-43c1aa 的7条评审意见（被截断）`
  - `M-20261103-084551-d4d94f programmer1->programmer2 review 评审通过 P-20261103-084428-b13596`
- `事件.jsonl` 里同一批消息伴随 `message` 226 条、`mail_read` 219 条、`ack` 165 条、`boot` 91 条，来自 **41 个不同 sessionId**（其中 **32 个是真实 `session-<uuid>`**，另 9 个是 `setup/launch/reconcile/workspace` 这类工具标记）。
- 结论：**旧版“六角色会话之间通信”不是设计假设，是跑过的**；而且角色之间确实互发，不只 PM 转述。

### 2.3 新壳的等价链路（实际执行者逐段拆）

```text
[渲染层] 点“发给角色”
   └─ teamSend  (preload)
        └─ main.js ipcMain.handle('team:send')  :4163
             ├─ requireProject(readStore(), projectId)        // 状态库没有该项目 → 直接失败
             ├─ ensureTeamName(project)                       // 可能 spawn workspace.mjs ensure / team.mjs project use
             ├─ pmDispatch && pendingAck → reconcileProjectCommStates(:4193) // S10：读邮箱+回执对账，撤本机假锁
             ├─ 双会话硬闸门 :4224-4235                      // 任一方没有 project.sessions[role] → SESSION_ID_REQUIRED
             ├─ verifyProjectRoleSession(from / to) :4245-4247 // session/list 核验：存在/未归档/属本 workspace
             ├─ teamTools.syncRoster(teamName, project.sessions) // 重写 状态/团队.json 的 sessionId（单快照）
             ├─ teamTools.sendDispatch(...) :4251
             │     └─ withBootToken(project, from)  :1384
             │           └─ bootToken → runNode(team.mjs boot --role <from> --project <名> --session <from会话>)
             │                 └─ 写 启动/<token>.json + 阅读.jsonl + 事件 boot
             │           └─ runNode(team.mjs send --boot T --to <role> --ack --no-wake …)  :1740
             │                 └─ 写 邮箱/<role>/new/<M>.json + 事件 message + 派单锁（pm 派单时）
             │     └─ wakeMessageFor(...) → 4 步文案（team-tools.js:2268-2308）
             ├─ 写本地 project.messages[] / pendingAck / events + comm 初始状态
             └─ dsh.prompt(收件角色会话, wakeText) :4394       // session/prompt, mode:'queue'（dsh-adapter.js:245-254）
                   └─ 失败 → 释放旧派单锁 + 清本地 pendingAck
```

**逐环节判定表**

| # | 环节 | 谁执行 | 证据 | 判定 |
|---:|---|---|---|---|
| 1 | 写旧协议邮件 | **壳**（spawn `team.mjs send`） | `team-tools.js:1698-1779` | ✅ 能（真旧协议） |
| 2 | 写派单锁 | 壳（旧引擎内部） | `ops.mjs:373`（壳调用） | ✅ 能 |
| 3 | 唤醒收件会话 | 壳（`dsh.prompt`，queue） | `main.js:4386-4394` | 🟡 只能证明“投进队列”，无送达/无执行确认 |
| 4 | 收件角色自己 boot/read/ack | **角色会话**（无代码保证） | 无 | ❌ 不保证；没有代码检查 |
| 5 | 壳代读收件箱 | 壳（先替角色 boot） | `main.js:4004`、`team-tools.js:1879` | 🟡 能读，但带写副作用 + 要求 DSH 在线 |
| 6 | 壳代标已读 | 壳 | `main.js:4048-4085` → `team.mjs read`（移动文件） | 🟡 能读；S10 起写 `comm.read.by='workbench-shell'` |
| 7 | 回执 | 两条路：角色自己 CLI / 壳 `team:ack` | `ops.mjs:431`、`main.js:4547` | 🟡 都能写；谁写的看 `actor`（旧记录为空） |
| 8 | 回程（回执邮件） | 旧引擎（`ackMessage` 内部 `sendMessage`） | `store.mjs:458-469` | ✅ 能（会写进原发件人邮箱） |
| 9 | 回程在界面上可见 | 只在“调试收件箱”/回执列表/comm 摘要 | `app.js` `inboxMessagesFor` + `#team-receipts` + `team:comm` | 🟡 团队台消息流只显示本机 `messages`，**入站邮件不进消息流** |
| 10 | 闭环对账（角色已 ack → 本地解锁） | **S10 已修**：`reconcileProjectCommStates` 多处调用 | `main.js:897-996`、`statePayload:1809-1814`、`team:send:4193` | ✅ 现在刷新状态即回收；S9 时只有 `team:send` 一个点 |

### 2.4 判定：**部分**

拆成四句可核对的话：

1. **旧引擎链路：能。** 有 165 条回执、186 封回执回信、21 封角色互发为证（§2.2）。
2. **新壳“发出去”：能，但条件苛刻。** 必须 ①状态库里有该项目 ②双方 `project.sessions` 都有 ③DSH 在线且两个会话都存在/未归档/属本 workspace ④`团队.json` 名册恰好是当前项目快照。任一不满足即硬失败（`main.js:4224-4247`、`team-tools.js:1698-1730`）。
3. **新壳“对方收到并回应”：不能证明。** 没有任何回执/校验证明角色会话执行了 prompt；账本里 `identitySource/actor/sessionId` 三类字段新壳写入 **0 行**（§1.3），说明新壳的 ack 路径**从未在这本账上成功跑过**。
4. **当前落盘状态：不能跑。** 见 §2.6。

### 2.5 通信侧的十一条具体缺陷（每条可复核）

| 编号 | 缺陷 | 证据 | 后果 |
|---|---|---|---|
| C1 | 读收件箱被 DSH 可用性绑死 | `main.js:4004-4017` → `resolveProjectTeamRole` → `verifyProjectRoleSession`（`dsh.listSessions` 失败即抛，`main.js:2005-2058`） | DSH 离线时磁盘上的邮箱也读不出；旧版 `inbox` 不需要 DSH |
| C2 | “只读收件箱”带三次写 + 一把令牌 | `team-tools.js:1879` `inboxFor` → `withBootToken:1384` → `bootToken:1337` → `team.mjs boot`（`ops.mjs:283-294`：写 `启动/`、`阅读.jsonl`、`事件 boot`） | 每读一次 = 替该角色签一次到；审计分不清“角色 boot”和“壳 boot”。**注**：S10 新增的 `commSnapshot`（`team-tools.js:1619-1690`）是**不 boot 的直读**，但只用于对账，收件箱面板仍走 `inboxFor` |
| C3 | 壳代标已读，消费角色未读 | `main.js:4048-4085` → `readFor:1927-1975` → `team.mjs read`（`store.mjs:417-429` 移动文件） | 角色下次 `inbox` 少一封未读 |
| C4 | 跨项目读：先移动后拒绝 | `team-tools.js:1951`（执行 read）→ `1955-1960`（比对 project 才报错） | 拒绝时邮件已被 `new→cur`，且旧工具已写 `mail_read` 事件；QA-ROUND8 M8 的修复是“事后拦截”，不是“事前隔离” |
| C5 | “已读”证据的归属，S10 部分修好 | `reconcileProjectCommStates:938-951` 把 `box==='cur'` 推断为 `comm.read.by='role'`；壳自己的 `team:read` 会先对账、再写 `by:'workbench-shell'`（`main.js:4053-4086`） | 残留：**S10 之前**由壳点出来的 `cur` 邮件，第一次对账会被判成 `by:'role'`；历史项目里“谁读了”仍不可辨 |
| C6 | 角色自回执后 UI 不解锁 —— **S10 已修** | `reconcileProjectCommStates`（`main.js:897-996`）在 `statePayload:1809-1814`、`team:send:4192`、`team:inbox:4019`、`team:read:4055`、`team:ack:4555` 都会跑；检测到回执即 `clearPendingAck`（`:986-988`） | S9 时只有 `team:send` 一个点（见 §8）；现在界面不再显示假锁 |
| C7 | 双锁 + 10 分钟 TTL 是新造语义 | 本地 `project.pendingAck`（`main.js:4163-4222`）+ 旧 `派单锁.json`；`ACK_TTL_MS = 10*60*1000`（`main.js` 顶部常量）；旧协议无 TTL（`ops.mjs:320-337`） | 两套锁各自过期/释放，容易“本地锁在、旧锁没了”或反之 |
| C8 | 名册是单项目快照，多项目并存必冲突 | `syncRoster`（`team-tools.js:475-509`）把“不在本 sessions 里的角色 sessionId 一律清空”；`sendDispatch:1698`、`legacyRoleContext:2014`、`ackDispatch` 三处都要求 `member.sessionId === 本次 sessionId` | A 项目发完、切到 B 项目再发，名册已被 B 覆盖；两个项目并行时 `SESSION_ID_MISMATCH` |
| C9 | 禁止自发，旧版允许 | `main.js:4172`；旧账本 62 封 `pm->pm` | “签字批准通知自己/完成回执通知自己”这类旧消息新壳发不出 |
| C10 | `inbox` 默认口径反了 | 新：`main.js:4008` `all = p.all !== false`（默认 true）→ `team-tools.js:1900,1903` 加 `--all`；旧：`ops.mjs:416` 默认只 `new` | 新壳“未读”不能靠“没带 --all”得到，只能过滤 `box`；误用总数当未读数 |
| C11 | 事件日志无法区分壳/角色 | 壳 boot 时显式传 `--session <角色的 sessionId>`（`team-tools.js:1354-1355`），旧引擎把它写进 `事件 boot.sessionId`（`ops.mjs:290-294`） | 账本里“这条 boot 是谁跑的”**没有字段可区分**；`actor` 只出现在 `回执.jsonl` |

### 2.6 “当前状态开箱能不能通信”——三条硬事实

1. **状态库是空的**：状态库路径 `app.getPath('userData')/workbench.json`（`main.js:1301-1304`），`userData = data/userdata`（`main.js:15-24`）。实测 `data/userdata/workbench.json` **不存在**，全仓只有 `_tmp/**` 下的测试副本。没有项目 → `requireProject` 直接抛 `项目不存在` → 所有 `team:*` IPC 走不到旧协议。
2. **团队名册的 activeProject 指向已删除目录**：`团队.json.activeProject = 个人简历展示项目`，但 `项目/个人简历展示项目` 不存在。按 `状态/项目/*/项目.json` 逐个核对：六个登记项目里 **2 个目录已删**（个人博客项目、个人简历展示项目），**4 个可 boot**（团队工作台改造 / 微光作品集 / 测试工作台项目 / 六人敏捷工作区——最后一个自己没有 `项目铁律.md`，`readDocSet` 会回退到团队根的 `团队/项目铁律.md`，`store.mjs:279-284`）。`loadProject` 对缺失目录抛 `PROJECT_DIR_MISSING`（`store.mjs:200-206`），所以**默认项目（activeProject）本身就是不可用的那个**。
3. **账本自身验不过**：`team.mjs verify` 报 64 条 `EVENT_CHAIN` HASH 问题（含 `seq:1`）+ 多条 `MISSING`。所以“按旧协议认真执行过”的证据只能靠**回执记录 / 邮箱内容**，不能靠事件链。

**另外**：名册里 6 个 `sessionId` 是 2026-11-02/03 的旧 DSH 实例产物（`session-8369a741…` 等）。本轮**没有**向 DSH 发 `session/list`，所以“这些会话现在还在不在”**未验证**；但无论在不在了，状态库为空这一条已经足够让六角色链开箱不可用。

---

## 3. 第 2 问：哪些环节只是壳进程代跑

### 3.1 一句话

**凡是“写”的动作，全部由壳执行；角色会话没有被要求、也没有被验证执行过任何一步。** 唯一的例外是 `openInboxRolePrompt` 这个“可选按钮”——它把四步指令发给角色，让角色自己敲，但它是**次要入口**，主按钮仍是壳代跑。

### 3.2 壳代跑旧 CLI 的 14 个调用点（`team-tools.js` 全部 `await runNode`）

| # | 壳调用的旧命令 | 位置 | 触发入口 | 代跑性质 |
|---:|---|---|---|---|
| 1 | `team.mjs init` | `:562` | 任意首次团队操作 | 初始化（合理） |
| 2 | `workspace.mjs ensure` | `:610` | `ensureProject` | 建项目骨架/登记（合理） |
| 3 | `team.mjs project list` | `:656` | `team:workspaces` | 只读 |
| 4 | `owner-note.mjs` | `:915` | `owner:decide` | 壳写 PM 系统消息；**旧壳也是这么调的**（旧 `外壳/main.js:469-470`），属对齐 |
| 5 | `team.mjs board` | `:1180` | `team:board` | 生成看板（合理） |
| 6 | **`team.mjs boot`** | `:1356` | `send/ack/inbox/read/legacy*` 的 `withBootToken` | **壳替角色签到**，并拿到 30 分钟令牌 |
| 7 | **`team.mjs send`** | `:1740` | `team:send` | **壳替发件角色写信** |
| 8 | **`team.mjs ack`** | `:1818` | `team:ack` | **壳替收件角色回执** |
| 9 | **`team.mjs inbox`** | `:1904` | `team:inbox` | **壳替角色读收件箱** |
| 10 | **`team.mjs read`** | `:1951` | `team:read` | **壳替角色标已读**（移动文件） |
| 11 | **`team.mjs propose|show|review|sign|apply`** | `:2148` | `proposal:legacy` / `team:proposal-legacy` | **壳替角色执行旧评审协议**（有令牌与会话核验，但执行者是壳） |
| 12 | **`team.mjs show`（apply 后补读）** | `:2176` | 同上，`apply` 成功后补一次 `show` | 壳为了回填提案字段顺手留一条阅读回执 |
| 13 | `team.mjs project use` | `:2321` | 切项目 | 切换当前项目（合理） |
| 14 | `launch.mjs` | `:2429` | `team:launch`/`team:restore` | 建六角色会话（合理，属 provisioning） |

其中 6/7/8/9/10/11/12 是**业务动作被壳代跑**；1/2/3/5/13/14 是壳该做的事（工具/脚手架），4 是对齐旧壳。

**关键点：第 11 条是 S10 新加的**——旧评审协议现在真的能被调用，但调用它的是壳：`legacyRoleContext`（`:2001-2022`）只核验“角色在名册、session 与名册一致”，`legacyProposalAction` 用该角色的 boot 令牌 spawn `team.mjs`，`actor` 没有任何落账字段。所以旧协议的**规则**回来了，**执行者**还是壳。

### 3.3 评审链：本地写 vs 旧协议桥（S10 起是两条）

| 动作 | 本地链（UI 在用） | 旧协议桥（UI 未接线） |
|---|---|---|
| 建提案 | `proposal:create` `main.js:3696` → `workbench.json` | `proposal:legacy` `action:'propose'` → `team.mjs propose` |
| show | **不存在** | `action:'show'` → `team.mjs show`（写 `阅读.jsonl`） |
| 评审 | `proposal:review` `:3764` → 本地 `reviews[]` | `action:'review'` → `team.mjs review`（校验 show/TTL/required reviewer） |
| 签字 | `proposal:sign` `:3788` → 本地 `signature` | `action:'sign'` → `team.mjs sign`（签名摘要/requiredSigners） |
| 应用 | `proposal:apply` `:3816` → 写文件 + `<项目>/_backup/commits` | `action:'apply'` → `team.mjs apply`（PM-only/checkApprovals/CAS/备份/产物/索引） |
| 回滚 | `proposal:rollback` `:3882`（新能力） | **无**（旧版没有 rollback） |
| 界面可达 | ✅ 提案卡片 + 三个弹窗 | 🟡 只接了 `show`（`refreshLegacyProposal`），建/评/签/应用无入口 |

**两条链互斥**：`proposal:create` 拒绝旧协议形状（`:3702-3707`），本地 `review/sign/apply/rollback` 拒绝 `protocol==='legacy'` 的提案（`rejectLocalWriteOnLegacyProposal:1657-1664`）；legacy 桥成功后 `mirrorLegacyProposal:1592-1654` 把结果写进本地 `proposals[]`（`protocol:'legacy'`），只作镜像。

**所以第 3 问的答案是“界面主路径在跑本地链，旧协议桥只提供状态刷新”**：用户点“评审/PM 签字/应用”，走的全是本地账本；旧协议那五步的约束在 S10 里确实可调用，但**建/评/签/应用只能由外部脚本触发**（界面只有 `show` 刷新按钮）。

### 3.4 壳只读旧账本的三处（不算代跑，但影响证据）

| 读取 | 位置 | 用途 |
|---|---|---|
| `回执.jsonl` | `team-tools.js:1480-1594` `listReceipts`（合并 `update` 行、`msgId\|from` 去重、8MiB 尾部截断） | `team:receipts` 面板 |
| 派单锁 | `readDispatchLockState` `:1259-1270` | `reconcileExternalAck` / 展示 |
| 邮箱（经 boot） | `inboxFor` `:1778-1820` | 调试收件箱 |

### 3.5 角色会话真正执行的只剩两条，且都不被代码保证

| 路径 | 机制 | 是否被要求 | 是否被验证 |
|---|---|---|---|
| 收件角色自己 `boot→inbox→read→ack` | 壳 `dsh.prompt(sessionId, 四步文案)`（`main.js:3964`、`team-tools.js:1881-1921`） | ❌ 只是“建议”，角色可以只回一句“收到” | ❌ 无回执、无对账（除 `team:send` 那一个点） |
| 收件箱“让角色自己执行 read/ack”按钮 | `openInboxRolePrompt` → `dshPrompt`（`app.js` `openInboxRolePrompt`） | ❌ 用户可选 | ❌ 同上 |

**代跑标记的真实覆盖面**（`main.js` 里 `workbench-shell` 共 29 处命中）：

| 动作 | 有 actor 标记？ | 位置（符号） |
|---|---|---|
| `team:ack`（壳真执行） | ✅ `actor:'workbench-shell'` | `team:ack` → `ackDispatch`；回执记录 `annotateReceiptIdentity` |
| `team:ack`（旧协议 already） | ✅ `actor='pre-existing'` | `team:ack` 的 already 分支 |
| `team:ack`（人工确认） | ✅ `actor='workbench-shell/manual'` | `team:ack` 的 manual 分支 |
| `team:send` | ✅ 返回体 + 本地消息标 `actor:'workbench-shell'` | `team:send` |
| `team:inbox` | ✅ 只在返回的 `identity.actor` | `team:inbox` |
| **`team.mjs boot`（壳替角色签到）** | ❌ | 事件里只有 `sessionId`，与角色自己 boot 无法区分 |
| **`team.mjs read`（壳替角色已读）** | 🟡 本地 `comm.read.by` 有；旧账 `事件.jsonl` 无 | `team:read` 写 `comm`，旧工具只写 `mail_read` |
| **`proposal:*` 本地五步** | ❌ | 只有 `project.events` 的中文一句话，没有 actor |
| **`proposal:legacy` 旧协议五步** | ❌ | 旧账里的 `propose/show/review/sign/apply` 事件只有角色 `sessionId`，与角色自己执行无法区分 |

**结论**：壳把“我代跑了回执”标注得很清楚（这是进步），但**“我代跑了 boot / read / 评审”完全没有标记**。审计时能看出“回执是谁写的”，看不出“已读是谁点的、提案是谁提的”。

### 3.6 三条后果

1. **回执可以完全由人点出来**：`openAckModal` → `team:ack`，主进程用收件角色会话执行 `team.mjs ack`，写 `actor=workbench-shell`。旧协议上这条回执**和角色自己 ack 完全一样**（同一条 `回执.jsonl` 行结构），只有多出来的身份行能区分。
2. **评审的“本地链”可以在 DSH 全离线时跑完**：`proposal:create/review/sign/apply` 不碰 DSH、不碰令牌、不碰会话（`main.js:3696-3938` 只有 `readStore/writeStore/fs`）。也就是说**界面上的“评审”当前根本不需要六角色会话存在**。旧协议桥则需要会话核验（`main.js:3969-3971`），但它没接线。
3. **“角色自己执行”没有可验证的出口**：旧账里 `回执.jsonl` 的 0 行 `identitySource/actor/sessionId` 说明新壳从未在其上成功 ack；本地 `comm` 能把“壳动作”和“对账推断”分开，但**推断本身不是角色签名**（C5）。**链路的最后一步仍是“壳说它对过账”。**

---

## 4. 第 3 问：`propose / show / review / sign / apply` 与旧版差在哪

### 4.1 旧版五步的硬约束（逐条有代码）

| 步骤 | 旧版要求 | 证据 |
|---|---|---|
| `propose` | 必须带 `--task`；任务必须存在、未 done、**owner 是本人**、有优先级 | `ops.mjs:582-586` |
| | 每个目标文件必须给 `--expect 目标=当前哈希`，且**必须等于当前哈希**（否则 `STALE_BASE`） | `ops.mjs:612-619` |
| | 必须有该角色的 **propose 授权**（`PM grant`） | `ops.mjs:620-622` |
| | 写目录黑名单：`node_modules/.git/.team/备份/_backup` | `ops.mjs:130` |
| | **风险自动升级**：命中 `.dsh/profiles/plugins/app.asar/…` → `critical`；命中 `团队/宪法/工具/协议/角色/模板` → `sensitive`；`--risk` 低于要求即 `RISK_TOO_LOW` | `ops.mjs:134-139,608-611` |
| | 单/多文件均可（`--file` 可重复）；按团队配置限大小（文档 16KB / 代码 64KB） | `ops.mjs:141-155,604-607` |
| | 相同未闭环提案去重 `DUPLICATE_PROPOSAL` | `ops.mjs:629-631` |
| | 按风险算 `minReviews / requiredReviewers / requiredSigners` 并写入提案 | `ops.mjs:66-81,646-651` |
| | 通知 PM：`type:'proposal'`、`ackRequired:true` 邮件 | `ops.mjs:657-661` |
| `show` | 先验提案哈希（`PROPOSAL_TAMPERED`）；**写阅读回执**（`阅读.jsonl`，kind=proposal，带 proposalHash + baseHash） | `ops.mjs:672-673,702`、`store.mjs:826-833` |
| `review` | 作者不能审自己；已 applied/rejected 不能审；**必须是 required reviewer** | `ops.mjs:713-717` |
| | **必须先 show 同一提案、同一哈希，且不超过 15 分钟**（`reviewReadTtlMinutes`） | `ops.mjs:718-722`、`store.mjs:835-849` |
| | 打回必须写 ≥10 字理由 | `ops.mjs:726` |
| | 状态机：reject→rejected；批准数达标→reviewed；否则 reviewing | `ops.mjs:739-742` |
| | 通知作者：`type:'review'`、`ackRequired:true` | `ops.mjs:747-751` |
| `sign` | 必须在该提案的 `requiredSigners` 里 | `ops.mjs:763-764` |
| | 作者自签：normal 直接禁止；sensitive/critical 必须显式 `--self` 且只能 approve | `ops.mjs:767-771` |
| | 非作者签字前必须已有**同哈希**的 review 通过 | `ops.mjs:772-778` |
| | 写 **签名摘要** `sig = sha256(role\|proposalId\|proposalHash\|baseHash\|newHash\|decision\|ts\|nonce)` | `ops.mjs:779-789`、`store.mjs:708-710` |
| | 全体签字完成才 approved | `ops.mjs:791-795` |
| | 通知 PM：`type:'sign'`、`ackRequired:true` | `ops.mjs:801-805` |
| `apply` | **只有 PM** 能 apply | `ops.mjs:811` |
| | 必须 `status==='approved'` | `ops.mjs:819` |
| | `checkApprovals(forApply)`：评审数、每个签字人的 `proposalHash/sig/sig 摘要` 全部复核；≥3 人团队禁止“PM 唯一评审 + 唯一签字”；owner 签字必须来自 `tty` | `ops.mjs:87-120,822-823` |
| | **CAS**：每个目标当前哈希必须等于提案 `baseHash`，否则 `STALE_BASE` 作废 | `ops.mjs:824-840` |
| | 备份到 `状态/项目/<slug>/备份/<C-id>`，**备份哈希必须等于 baseHash** | `ops.mjs:841-853` |
| | 写入前复核暂存文件哈希（`STAGED_TAMPERED`），写入后复核（`WRITE_MISMATCH`） | `ops.mjs:856-867` |
| | 失败自动回滚并复核回滚哈希；回滚不完整即停手 | `ops.mjs:872-893` |
| | 更新 `产物.json`（版本 +1）、写 `提交/<C>.json`（含 before/after/reviews/signatures）、重建项目索引 | `ops.mjs:895-923` |
| 回滚 | **旧版没有 rollback 命令**（`team.mjs` 命令表无此项，只有 selftest 的 `--fail-after-backup`） | `team.mjs:64-97` |

### 4.2 新壳的两条评审链（逐条对照）

| 步骤 | 本地链（界面在用） | 旧协议桥（`proposal:legacy`，界面只接 show） | 判定 |
|---|---|---|---|
| 建提案 | 表单选“作者角色” → 写 `project.proposals[]`；`--expect` 可选；**拒绝**旧协议形状与多文件（`proposal:create` 开头）；无令牌/授权/任务归属/风险升级/通知 | `action:'propose'` → `team.mjs propose`：要求 `task` + 每文件 `target`/`staged`/`expect`（`team-tools.js:2050-2084`），其余约束由旧引擎执行 | 本地 ❌ / 桥 ✅ |
| show | **不存在**（无 IPC、无 UI、无 `阅读.jsonl`） | `action:'show'` → `team.mjs show`（写阅读回执；`apply` 后还会自动补一次，`:2176`） | 本地 ❌ / 桥 ✅（壳代跑） |
| 评审 | 选一个非作者角色 → 写 `reviews[]`；理由非空；无 required reviewer / 无 show 前置 / 无 15 分钟 TTL / 无通知 | `action:'review'` → `team.mjs review`（required reviewer、`MUST_READ_FIRST`、打回 10 字、通知作者） | 本地 ❌ / 桥 ✅（壳代跑） |
| 签字 | 只有 PM；需 ≥1 条 approve；写 `{by,decision,note,at}`；**无签名摘要/无哈希绑定** | `action:'sign'` → `team.mjs sign`（requiredSigners、`--self` 规则、`signatureDigest`、通知 PM） | 本地 ❌ / 桥 ✅（壳代跑） |
| 应用 | 校验 `approved && signature` + 目标 `baseHash`；备份到 `<项目>/_backup/commits`；不校验 `stagedContent`；**不要求 PM** | `action:'apply'` → `team.mjs apply`（PM-only、`checkApprovals`、CAS、备份哈希、暂存/写入复核、产物、索引） | 本地 🟡 / 桥 ✅（壳代跑） |
| 回滚 | `proposal:rollback`（新能力，单文件，校验 `afterHash`/备份哈希） | **无** | 本地 🟢 新增 / 桥无 |
| 界面可达 | ✅ 提案卡片 + 评审/签字/应用/回滚弹窗 | 🟡 只有“刷新旧协议状态”（`show`） | — |

### 4.3 差异分组（旧版硬约束 → 本地链 / 旧协议桥）

| 组 | 旧版硬约束 | 本地链（界面） | 旧协议桥（只接 show） | 影响 |
|---|---|---|---|---|
| **身份** | `--boot` 令牌 + role/project 一致 + 会话 | ❌ 无 | ✅ `legacyRoleContext` 核验名册+会话，`withBootToken` 发令牌 | 本地链谁都能以任何角色建提案/评审 |
| **授权** | `hasGrant(role,'propose',project,target)` | ❌ 无 | ✅ 旧引擎 `NO_GRANT` | 本地链任何角色可改项目内任何文件 |
| **任务归属** | 任务必须属于本人且未完成 | ❌ 无（`task` 自由文本） | ✅ `team.mjs propose` | 本地提案可不对应任务 |
| **先读后审** | `show` 写阅读回执，`review` 校验 15 分钟内同哈希 | ❌ 整步缺失 | ✅ `team.mjs show/review` | 本地链“没看就批”无法被发现 |
| **风险分级** | 按路径自动升级 + `RISK_TOO_LOW` | ❌ 无（`risk` 可空） | ✅ 旧引擎 | 本地链可把 `团队/宪法/协议` 当 normal |
| **多文件** | `--file` 可重复 | ❌ 拒绝 | ✅ | 界面仍无法表达 3 文件提案 |
| **签字绑定** | `sig = sha256(...)` | ❌ 只写 `by/decision/note/at` | ✅ `signatureDigest` | 本地链签字不绑定内容 |
| **审批完整性** | `checkApprovals` | ❌ 无 | ✅ `team.mjs apply` | 本地链“PM 一人自审自签”合法 |
| **执行门** | PM-only | ❌ 无 | ✅ | 本地 `proposal:apply` 谁调都行 |
| **路径黑名单** | 禁 `node_modules/.git/.team/备份/_backup` | ❌ 只校验“在项目内”（`proposal:create` / `proposal:apply` 的 `startsWith(root)`） | ✅ `ops.mjs:130` | 本地链可提案写 `_backup/…`（备份就在同目录） |
| **暂存完整性** | `STAGED_TAMPERED` / `WRITE_MISMATCH` | ❌ 不校验 `stagedContent` | ✅ | 本地链可改库后应用 |
| **备份/产物/索引** | `状态/…/备份` + `产物.json` + 重建索引 | 🟡 `<项目>/_backup/commits`，无产物/索引 | ✅ | 旧 `verify`/`checkDrift` 看不到本地提交 |
| **通知** | `proposal` / `review` / `sign` 三类邮件 | ❌ 0 封 | ✅ 旧引擎 `notify` | 本地链六角色会话不知道有提案 |
| **镜像** | — | 写 `提案.json`/`评审/*`/`签字/*`，`source:'workbench'`，**哈希不兼容** | 写的是真旧提案 | 本地链镜像对旧工具是“被篡改的提案”（§4.4） |

### 4.4 确定性证据：**本地链**镜像的提案，旧 `show` 一定判 `PROPOSAL_TAMPERED`

> 范围：只针对本地链（`proposal:create` → `workbench.json` → `syncWorkbenchBoard` 镜像）。旧协议桥写的是 `team.mjs` 自己生成的提案，`proposalHash` 就是旧公式，不受这一条影响。

旧版 `computeProposalHash` = `sha256(JSON.stringify({id,project,task,author,title,rationale,risk,files:canonical,createdAt}))`（`store.mjs:628-644`）。
本地链写进 `提案.json` 的 `proposalHash` = `proposal.proposalHash || contentHash || hash`，而这三者在 `proposal:create` 里都等于**文件内容的 sha256**（`main.js` `proposal:create`；`team-tools.js:1026,1039`）。两者不是同一个函数。

组件探针（只读、只在内存里算，未写任何文件）：

```json
{
  "storedProposalHash": "7d111916a559770abf75063840da4eefea7abc1199eb5d7b2011dcb7092152d9",
  "oldComputeProposalHash": "66c737cfae1b2d4113c7e2862bc57a6eb095903325a0cc42bb5b16a0418c1ce3",
  "match": false,
  "oldShowWouldThrow": "PROPOSAL_TAMPERED"
}
```

同一探针对**真实旧提案** `P-20261031-233835-43c1aa` 复核，旧公式自洽（`stored === recomputed`），说明不是公式读错，而是**两套账本**。

**后果链**（按旧代码逐条推）：
1. 旧 `show` → `PROPOSAL_TAMPERED`（`ops.mjs:672-673`）；
2. 旧 `review` → 同样 `PROPOSAL_TAMPERED`（`:711-712`）；
3. 旧 `sign` → 同样（`:759-760`）；
4. 旧 `apply` → 同样（`:820-821`）；
5. 旧 `verify` → 对 `status==='applied'` 的壳提案报 `PROPOSAL_HASH`（`ops.mjs:1687-1690`）；即使绕过哈希，`checkApprovals(stored:true)` 也会因为壳写的 `签字/<role>.json` **没有 `sig`/`nonce`** 而报 `BAD_SIGNATURE`（`ops.mjs:110-114`）。

也就是说：**本地链的评审产出，对旧工具来说是“被篡改的提案”**。两边不能互相接手（legacy 桥的产出不在此列）。

### 4.5 三个本地链独有的安全问题（不是差异，是缺口）

| # | 问题 | 证据 | 触发方式 |
|---:|---|---|---|
| R1 | **本地 apply 没有角色门** | `main.js:3816-3880` 全程不读 `role`，也无 `=== 'pm'` 判断（对比旧 `ops.mjs:811`） | 任何能调 IPC 的渲染层代码都能应用本地提案 |
| R2 | **本地签字不绑定内容** | `proposal:sign` 只写 `{by,decision,note,at}`（`main.js:3808`），不写 `hash/proposalHash`；`apply` 只校验目标 `baseHash`（`:3837`），不校验 `stagedContent` | 签字后改 `workbench.json` 的 `stagedContent` → apply 写入被改过的内容，`proposal.hash` 仍是旧值 |
| R3 | **`_backup` 可被本地提案当目标** | 路径检查只有 `abs.startsWith(root)`（`:3721`）；旧版有 `备份\|_backup` 黑名单（`ops.mjs:130`）。而 `apply` 的备份目录就是 `<root>/_backup/commits`（`:3855`） | 提案目标写 `_backup/commits/<C>/x` 就能覆盖回滚备份 |

### 4.6 判定：**本地链不能算旧流程；旧协议桥是“补回来了但没接线”**

- **本地链**（界面唯一可达）不是“旧流程少实现了几步”，而是**同一组名词下的另一套东西**：旧版是“令牌 + 先读后审 + 哈希绑定 + 多人签字 + PM 执行 + 通知”的协议；本地链是“单人表单 + 本地账本 + 事后镜像”。它的产出对旧工具来说是“被篡改的提案”（§4.4），两边不能互相接手。
- **旧协议桥**（`proposal:legacy`）在 S10 把旧五步的**规则**接回来了：令牌、会话核验、show、required reviewer、签名摘要、PM-only、CAS/备份/回滚/产物/索引、三类通知，全部由 `team.mjs` 执行。但它：① **界面只接了 `show` 刷新**，建/评/签/应用点不到；② 执行者是壳进程，旧账里没有 `actor` 字段；③ 没有 rollback（旧版也没有）。
- **要让六角色按旧协议真正走评审**，最小改动不是“再加功能”，而是：把界面上的评审/签字/应用按钮改成调用 `proposal:legacy`（并且 `propose` 需要用户提供暂存文件与 `--expect`），同时接受“壳替角色执行、旧账无 actor”这一事实并在 UI 标注。当前方案是两条链并存、界面只走弱的那条。

---

## 5. 复核方式（全部只读，可直接跑）

### 5.1 本轮已跑的两条只读命令

```powershell
$env:TEAM_ROOT='D:\deepseek\agile-workbench\团队'
node .\团队\工具\team.mjs doctor --json      # ok:false, issues:["事件链问题 64"]，exit 1
node .\团队\工具\team.mjs verify --json      # ok:false, 64×EVENT_CHAIN(HASH) + 多条 MISSING
```
两条命令只读（`ops.mjs:1878-1895`、`:1679-1716` 均无写操作）；跑前跑后 `团队/状态` 九个文件 mtime 不变。

### 5.2 符号复核（行号漂移后按符号重验）

```powershell
# 1) 新壳到底调了哪些旧命令（S10 应恰好是 §3.2 那 14 个）
Select-String -Path .\src\team-tools.js -Pattern "await runNode\("

# 2) 评审链：本地 IPC 与旧协议桥都在，别只 grep 一半
Select-String -Path .\src\main.js    -Pattern "proposal:(create|review|sign|apply|rollback|legacy)"
Select-String -Path .\src\main.js    -Pattern "team:proposal-legacy"
Select-String -Path .\src\preload.js -Pattern "proposalLegacy"
Select-String -Path .\src\team-tools.js -Pattern "legacyProposalAction|LEGACY_REVIEW_ACTIONS"

# 2b) 界面接了旧协议桥的哪些动作（S10：只应命中 show/refreshLegacyProposal）
Select-String -Path .\src\renderer\app.js -Pattern "proposalLegacy|proposal:legacy|team:proposal-legacy"

# 3) 两条链是否互斥
Select-String -Path .\src\main.js -Pattern "LEGACY_PROTOCOL_REQUIRED|rejectLocalWriteOnLegacyProposal"

# 4) 壳代跑标记的覆盖面（S10 共 30+ 处，但 proposal:* 本地/旧桥都没有 actor）
Select-String -Path .\src\main.js -Pattern "workbench-shell"

# 5) 通信对账是否覆盖 UI 状态（S10 期望：statePayload 里有）
Select-String -Path .\src\main.js -Pattern "reconcileProjectCommStatesCached|reconcileProjectCommStates\("

# 6) 读邮件先副作用后校验
Select-String -Path .\src\team-tools.js -Pattern "MESSAGE_PROJECT_MISMATCH" -Context 6,2

# 7) inbox 默认口径
Select-String -Path .\src\main.js      -Pattern "all = p.all !== false"
Select-String -Path .\src\team-tools.js -Pattern "includeAll = input.all !== false"
Select-String -Path .\团队\工具\lib\ops.mjs -Pattern "includeCur: Boolean\(args.all\)"
```

### 5.3 账本口径（除非真的又跑过旧工具，应保持这些数）

```powershell
$s='D:\deepseek\agile-workbench\团队\状态'
(Get-ChildItem "$s\邮箱" -Recurse -File -Filter *.json).Count                                   # 392
(Get-ChildItem "$s\邮箱" -Recurse -File -Filter *.json | ? { $_.Directory.Name -eq 'new' }).Count # 128
(Get-Content "$s\回执.jsonl").Count                                                             # 328
(Get-Content "$s\回执.jsonl" | ? { $_ -match '"update":true' }).Count                            # 163
(Select-String "$s\回执.jsonl" -Pattern '"identitySource"|"actor"|"sessionId"').Count            # 期望 0
(Get-ChildItem "$s\启动" -File).Count                                                            # 91
```

### 5.4 验收断言（建议进 selftest 的 12 条）

| # | 断言 | 对应 |
|---:|---|---|
| A1 | 角色 CLI 自己 `ack` 后，**不必等下一次 `team:send`**，`state.pendingAck === null` 且 `ack:true` | C6 |
| A2 | `team:read` 一条**跨项目**邮件时，邮件仍在 `new/`（不得先移动后拒绝） | C4 |
| A3 | `team:inbox` 前后 `状态/启动` 文件数必须不变，或在返回里显式给出 `bootedTokenFile` 并 UI 提示 | C2 |
| A4 | DSH 离线时 `team:inbox` 仍能读到邮箱（只读路径不依赖 `session/list`），或明确报 `INBOX_REQUIRES_DSH` 而不是笼统失败 | C1 |
| A5 | 界面“已读”标签必须区分 `readBy:'role'` 与 `readBy:'workbench-shell'` | C5 |
| A6 | 两个项目并存时，A 项目 `team:send` 不得因 B 项目名册覆盖而 `SESSION_ID_MISMATCH` | C8 |
| A7 | `team:send` 允许 `from === to`（或 UI 明确说明为何禁止，并给出替代的“通知自己”路径） | C9 |
| A8 | 壳执行 `boot` 时，`事件.jsonl` 必须能区分 `actor:'workbench-shell'` 与角色自 boot | C11 |
| A9 | **本地链**提案写入后，旧 `team.mjs show --proposal <id>` 必须**不报** `PROPOSAL_TAMPERED`（否则不允许镜像进旧目录） | §4.4 |
| A10 | 旧 `team.mjs apply` 对**本地链**镜像提案必须能通过 `checkApprovals`（含 `sig` 校验） | §4.4 |
| A11 | 本地 `proposal:apply` 必须校验调用者为 `pm` | R1 |
| A12 | 签字后修改 `stagedContent`，本地 apply 必须拒绝（`SIGNATURE_STALE`） | R2 |
| A13 | 界面“评审/签字/应用”按钮必须走 `proposal:legacy`（或在按钮上明写“本地链，不走旧协议”） | §4.6 |
| A14 | `proposal:legacy` 成功后，旧账 `事件.jsonl` 必须能区分“壳代跑”与“角色自执行”（当前不能） | §3.2 第 11 条 |

---

## 6. 未覆盖 / 边界

1. **未做运行时验证**：本轮不启 Electron、不向 DSH 发 `session/list`/`session/prompt`。所以“名册里那 6 个旧 sessionId 现在还在不在”“`dsh.prompt` 对空闲会话是否真的会触发一轮”**未验证**；这两点只影响“发出去能不能到”，不影响 §3 的“谁执行”结论（那是静态可见的）。
2. **未在真实项目上跑 `team:send/ack/cancel`**：会写 `团队/状态`，违反只读边界。所有“能/不能”都基于源码路径 + 旧账本统计 + 内存哈希对照。
3. **渲染层/主进程在审计中连变两次**：`app.js` 12:32→12:46→12:49（261KB→283KB→291KB），`team-tools.js` 12:33→12:47（92KB→112KB），`preload.js` 11:47→12:49（4.7KB→5.9KB）。S10 新增了旧协议评审桥（`proposal:legacy`）、通信对账（`team:comm`/`team:reconcile`）、`commSnapshot`。本报告已按 S10 复核，早期判断的推翻/保留逐条记在 §8。**若你读到时 hash 又变，先跑 §5.2 的 7 组 grep，再看 §8 的“哪些结论已被改过”。**
4. **`includeUnassigned` 的口径要更正一次**：QA-ROUND8 M5 说“空 project 回执跨项目可见”是新壳放大。本轮核对旧代码：旧看板的过滤条件本来就是 `!r.project || r.project === 当前`（`ops.mjs:1361`），旧 `listInbox` 的过滤也是 `if (project && msg.project && msg.project !== project) continue`（`store.mjs:391`）。**空 project 在旧版同样跨项目可见**——这是隔离设计问题，**不是 parity 漂移**。新壳的 `includeUnassigned:true` 恰好对齐旧看板；要改应作为“共同缺陷”单独立项。
5. **QA-ROUND8 H2 已修**：`annotateReceiptIdentity` 现在只**追加**一行 `update:true` 身份行（`team-tools.js:1412-1448`），不再整文件读改写；`listReceipts`（`:1497-1611`）按 `id` 合并。本轮复核确认代码已变，H2 不再成立（这条身份行会让 `回执.jsonl` 的 `update` 行数继续增长，旧看板仍按 `!update` 过滤，兼容）。
6. **QA-ROUND8 M8 只修了一半**：`readFor` 增加了 `MESSAGE_PROJECT_MISMATCH`（`team-tools.js:1957-1960`），但校验在 `read` 之后（C4）。
7. **S10 的旧协议桥不等于“评审已闭环”**：它把规则接回来了，但 ①界面不调用；②执行者是壳、旧账没有 `actor`；③`legacyFlowOf`（`team-tools.js:2029-2045`）只能**反推** show 是否发生（有 review/sign 产物就认为 show 已完成），`show` 本身没有独立落账。所以“show 过”在 `proposal:legacy` 路径上仍不是可审计事实。

---

## 7. 只读边界与产物

- 本轮只新增 `docs/PARITY-ROUND9.md`。
- 未修改：`src/**`、`package.json`、`package-lock.json`、`node_modules/**`、`团队/**`、`项目/**`、`userdata-selftest/**`、`.selftest-data/**`、`D:\deepseek\工作台\**`、`D:\deepseek\luanyujia-workbench\**`。
- 未运行：`npm run check`、`npm run selftest`、Electron、任何 `team.mjs` 写命令。
- 唯一执行的旧代码：`team.mjs doctor` / `team.mjs verify`（只读，§5.1），以及内存里调用 `lib/store.mjs` 的 `computeProposalHash` 做哈希对照（不写盘）。
- 账本数字（392 / 128 / 203 / 186 / 328 / 163 / 165 / 91 / 1212）均为**只读统计**；`团队/状态` 文件 mtime 与 `锁/` 目录内容在审计前后一致（§1.4）。

---

## 8. S9 → S10 变更补记（哪些早期判断被推翻、哪些仍成立）

> 本节是为了让读者能区分“我读到的”和“它后来变成的”。时间线：**S9** = 12:32–12:37（本报告第一版依据）；**第一次漂移** 12:44–12:46（渲染层派单链路 UI）；**第二次漂移** 12:47–12:49（`team-tools.js` +19.6KB、`main.js` +27.5KB、`preload.js` +1.1KB，S10）。本报告正文已按 S10 改写，本节保留被推翻的判断，供复核。

### 8.1 S10 实际新增了什么（已逐项核对代码）

| 新增 | 位置 | 作用 |
|---|---|---|
| `commSnapshot()` | `team-tools.js:1619-1690` | **不 boot** 直读六角色邮箱 `new/cur` + `回执.jsonl` 尾部，产出“真实通信现场”快照 |
| `reconcileProjectCommStates()` | `main.js` 同名函数 | 用快照回填每条的 `delivered/wake/read/ack/selfExecuted`，并在检测到回执时 `clearPendingAck` |
| `statePayload` 内对账 | `main.js` `statePayload` | 每次状态刷新自动对账（1 秒缓存），不再需要手动“刷新回执” |
| `comm` 消息模型 | `main.js:790-841`、`publicMessageComm:843` | 每条消息带 `comm.{delivered,wake,read,ack,selfExecuted}` 与 `states/complete` |
| `proposal:legacy` / `team:proposal-legacy` | `main.js:4002-4003`、`team-tools.js:2126-2255` | **旧协议评审桥**：带会话核验 + boot 令牌，spawn `team.mjs propose/show/review/sign/apply` |
| `proposal:create` 拒绝旧形状 | `main.js:3702-3718` | 带 `files[].staged`/`legacy`/`protocol` 或多文件 → `LEGACY_PROTOCOL_REQUIRED`，不再静默截断 |
| `rejectLocalWriteOnLegacyProposal()` | `main.js:1657-1664` | 本地 `review/sign/apply/rollback` 不能改 legacy 提案 |
| `mirrorLegacyProposal()` | `main.js:1592-1654` | 把旧协议结果写进本地 `proposals[]`（`protocol:'legacy'`），只作镜像 |
| `team:comm` / `team:reconcile` | `main.js:4857-4907`、`preload.js:58-59` | 手动强制对账 / 查通信摘要 |
| `preload.proposalLegacy*` | `preload.js:67-72` | 六个方法暴露给渲染层 |
| 派单链路 UI | `app.js` `dispatchSteps` / `dispatchReadiness` / `renderDispatchResult` | 只展示“能证明的步骤”，不伪报 |

### 8.2 被推翻的判断（S9 → S10）

| S9 判断 | S10 事实 | 处理 |
|---|---|---|
| “`team-tools.js` 的 `LEGACY_REVIEW_ACTIONS` 是死常量，评审链一次都没调旧 CLI” | `legacyProposalAction` 用它校验并 spawn 五个动作（`:2128,2148`） | 已在 §0.1-#12、§3.2-#11、§3.3 改写 |
| “新壳评审链完全不碰旧协议” | 有旧协议桥（IPC + preload），界面后来只接了 `show` 刷新 | 已在 §3.3、§4.2 改成“两条链” |
| “角色自回执后 UI 不解锁（C6）” | `statePayload` 已自动对账并清锁（`main.js:1809-1814,986-988`） | C6 标为已修 |
| “`proposal:apply` 没有角色门 / 签字不绑内容” | 只对**本地链**成立；旧协议桥由 `team.mjs` 判 PM 并写 `sig` | §0.1-#15、§4.5 收紧到“本地链” |
| “镜像哈希不兼容” | 只对**本地链**提案成立；旧协议桥写的是真旧提案，`syncWorkbenchBoard` 也不覆盖旧 CLI 文件（`:965,1014`） | §0.1-#14、§4.4 收紧范围 |
| “多文件提案新壳无法表达” | 本地链仍拒绝；旧协议桥支持多文件 | §4.3 改成两列 |

### 8.3 仍然成立的判断（S10 复核）

| 判断 | S10 证据 |
|---|---|
| 六角色通信只做到“单向投递 + 可选代跑”，回程无强制、无身份证明 | 旧账 `回执.jsonl` 仍 0 行 `identitySource/actor/sessionId`；`wake` 仍是 `session/prompt` queue |
| 读收件箱要 DSH 在线 + 替角色 boot | `main.js` `team:inbox`（`resolveProjectTeamRole`）、`team-tools.js:1879`（`inboxFor`）；`commSnapshot` 虽不 boot，但面板仍走 `inboxFor` |
| 壳代标已读、消费角色未读 | `main.js:4048-4086` → `readFor:1951` |
| 跨项目 read 先移动后拒绝 | `team-tools.js:1951`（read）→ `:1957-1960`（才比对 project） |
| 双锁 + 10 分钟 TTL 是新造语义 | `main.js` `ACK_TTL_MS` + `pendingAck`；旧 `ops.mjs:320-337` 无 TTL |
| 名册单快照，多项目并存会 `SESSION_ID_MISMATCH` | `syncRoster`（`team-tools.js:475-509`）+ `legacyRoleContext:2014`、`sendDispatch`、`ackDispatch` 三处同名校验 |
| 禁止自发，旧版允许 62 封 `pm->pm` | `main.js:4172` |
| `inbox` 默认 `--all`（旧版默认只 new） | `main.js:4008`、`team-tools.js:1900` |
| 事件日志不能区分“壳 boot”与“角色 boot” | 壳显式传 `--session <角色会话>`（`team-tools.js:1354-1355`），旧引擎照写 |
| 本地链 apply 无角色门、签字不绑内容、`_backup` 可写 | `main.js:3808,3816-3880,3721` |
| 本地链镜像提案会被旧 `show` 判 `PROPOSAL_TAMPERED` | §4.4 的组件探针（两套哈希函数） |
| 开箱不可用（状态库空、activeProject 目录已删、verify 64 问题） | §1.3、§2.6；本轮两次快照前后 `团队/状态` 未被写 |

### 8.4 写完本文前的第三次漂移（S10 → S11，12:50–12:53）

| 文件 | S10（12:49） | 写本文时（12:53:44） |
|---|---:|---:|
| `src/main.js` | 372,836 / `D9E1C3B54ECA9A76` | **400,618 / `3B6E7B11B7529231`** |
| `src/team-tools.js` | 111,864 / `EB5BBBEBFE934342` | **111,989 / `A9B9F8E4AD897FA9`** |
| `src/preload.js` | 5,895 / `8D2F2EBA65F7AFF7` | 同 |
| `src/renderer/app.js` | 290,771 / `E653DB23381869A2` | **302,342 / `D87C550F5E8217BD`** |
| `src/renderer/index.html` | 38,589 / `4D42ABCCF34BF68B` | **38,665 / `D604CF6407DC3225`** |

**这次变化对结论的影响（已复核）**：

- `app.js` 新增了旧协议镜像的**识别与状态刷新**：`proposalIsLegacy` / `legacyProposalSteps` / `refreshLegacyProposal`（调用 `proposal:legacy` 的 `show`）。所以“界面 0 命中旧协议桥”在 S11 已不成立；正文已改成“只接了 show”。
- `proposal:*` 五个 handler 行号再次整体下移约 8–10 行（现为 `main.js:3704/3772/3796/3824/3890`），正文对这几个 handler 的引用改用符号名。
- **判定不变**：界面仍不能通过旧协议桥建/评/签/应用；`team:send` 仍禁自发（`main.js:4180`）；`statePayload` 仍带 comm 对账（`main.js:1822`）；`await runNode` 仍是 **14** 处。
- **不要把本文行号当契约**：以 §8.5 的 6 条 grep + 符号名为准；行号只对应“本节表格里那个 hash”的文件。
- **本文落盘后（12:54:42）最后一次核对**：`team-tools.js` 又变为 112,116 / `10631A3CBCD256E8`、`app.js` 变为 302,397 / `652B7F93CDEB40EA`，`main.js` 仍是 400,618 / `3B6E7B11B7529231`。这三处之后的变化**未再复查**；结论以 S10 为准，S11 只是补记。

### 8.5 如果源码再动，先跑这 6 条

```powershell
Select-String .\src\main.js      -Pattern "reconcileProjectCommStatesCached"      # 对账是否还在 statePayload
Select-String .\src\main.js      -Pattern "proposal:legacy|team:proposal-legacy"  # 旧协议桥是否还在
Select-String .\src\renderer\app.js -Pattern "proposalLegacy|refreshLegacyProposal" # 界面接了多少
Select-String .\src\team-tools.js -Pattern "await runNode\("                      # 壳代跑清单是否还是 14 条
Select-String .\src\main.js      -Pattern "actor: 'workbench-shell'"              # 代跑标记是否扩到 proposal
(Get-FileHash .\src\main.js -Algorithm SHA256).Hash.Substring(0,16)               # 是否仍是 3B6E（S11）
```
