# QA-FINAL-OPS · Owner actor / 旧索引与状态清理 / npm start / UI 放大 / 真实新项目 / D 盘

> 对象：`D:\deepseek\agile-workbench`
> 时间：2026-11-06 03:06–03:26（Asia/Shanghai）
> 方式：只读源码审计 + `npm run check` + `npm run test:scripts` + `npm run selftest`（D 盘隔离沙盘）+ 隔离 `npm start`（真实 Electron + 真实 DSH + CDP）+ 真实 `team.mjs` Owner 探针 + 真实项目只读核对
> 边界：未改 `src/**`、`package.json`、`团队/**`、真实 `项目/**`。本轮写入只在 `docs/QA-FINAL-OPS.md`、`_tmp/qa-ops-20261106/**`、隔离的 `_tmp/qa-ops-20261106/app-data/**` 与 `app-team/**`。真实数据在本轮期间被其它会话/进程并发写入（见 §6）。

## 0. 一句话结论

**`npm start`、UI 放大、真实新项目创建与 D 盘落位都通过；需求级 Owner 决定和 Owner 验收的 `actor` / `confirmation` 已真实落盘并可跨实例刷新。但旧版“项目级 Owner”入口仍未写 actor/confirmation；索引的 `files` 哈希/大小在清理后的 4 个项目和真实新项目里系统性过期；`微光作品集` 的“已验收”总览与工作流 `review` 仍互相矛盾。`npm run check` 与 `npm run selftest` 均通过，但自测本身没有覆盖 Owner actor 持久化。**

六项判定：`npm start` **PASS**；UI 放大 **PASS**；真实新项目 **PASS**；D 盘 **PASS**；Owner actor **PARTIAL**；旧索引/状态清理 **PARTIAL**。

---

## 1. 源码与运行快照

| 文件 | 字节 | SHA-256 前 16 | 最后写入（UTC） |
|---|---:|---|---|
| `src/team-tools.js` | 316,097 | `C178ED0CA70BBD62` | 2026-11-05T18:55:02Z |
| `src/main.js` | 517,918 | `55062A21D4C4DD34` | 2026-11-05T11:36:48Z |
| `src/renderer/app.js` | 512,188 | `33E90D1547E23CCE` | 2026-11-05T11:44:05Z |
| `src/renderer/style.css` | 147,682 | `53C7C8EF01708E22` | 2026-11-05T11:27:13Z |
| `src/renderer/index.html` | 47,649 | `0BBF7DEA069503F4` | 2026-11-05T11:27:56Z |
| `src/preload.js` | 7,812 | `40B0ABF9ACA0E050` | 2026-11-05T11:22:30Z |
| `scripts/run-electron.cjs` | 6,042 | `E7C1D8C54C6A4F2F` | 2026-11-05T18:44:26Z |
| `scripts/test-entrypoints.cjs` | 10,239 | `49985825DD532464` | 2026-11-05T18:44:52Z |
| `start.cmd` | 2,935 | `1D8E57CCFE8DA9BF` | 2026-11-05T18:42:18Z |
| `package.json` | 1,376 | `7E9E160BABD778F6` | 2026-11-05T18:46:29Z |
| `团队/工具/lib/ops.mjs` | 136,732 | `796D3A76DA60844D` | 2026-11-05T11:26:33Z |
| `团队/工具/lib/workflow.mjs` | 72,552 | `83A83DAB54981E2A` | 2026-11-05T11:29:06Z |
| `团队/工具/team.mjs` | 7,191 | `475BE3DC930B0D44` | 2026-11-05T11:23:57Z |

与上一轮 `docs/QA-FINAL.md`（20:10）相比，源码变化集中在 `src/team-tools.js`（291,123 → 316,097 B；相对备份 `_backup/owner-auth-merge-20261106-024336/team-tools.js` +619/−17 行）以及 `scripts/`、`start.cmd`、`package.json`、`README.md`。`src/main.js`、`src/renderer/app.js`、`style.css` 没有本轮新改动。

完整哈希：`_tmp/qa-ops-20261106/hashes.json`。

---

## 2. 命令结果

### 2.1 `npm run check`

```text
> node --check src/main.js && node --check src/preload.js && node --check src/renderer/app.js
  && node --check src/dsh-adapter.js && node --check src/team-tools.js
  && node --check scripts/run-electron.cjs && node --check scripts/test-entrypoints.cjs
```

退出码 0。**只是语法检查**，不覆盖行为。日志：`_tmp/qa-ops-20261106/check.log`。

### 2.2 `npm run test:scripts`

```text
SCRIPTS_OK 11/11
```

覆盖 `package.json` 的 start/selftest 入口、`ELECTRON_RUN_AS_NODE` 清理、参数/退出码透传、Electron 版本（v33.x 而不是 Node v20.x）、缺 Electron 时的错误、`start.cmd --check`、`start.cmd` 失败不阻塞、导出白名单。日志：`_tmp/qa-ops-20261106/test-scripts.log`。

### 2.3 `npm run selftest`（D 盘）

在继承 `ELECTRON_RUN_AS_NODE=1` 的环境下通过 `scripts/run-electron.cjs` 启动；自测根 `AWB_SELFTEST_ROOT=D:\deepseek\agile-workbench\_tmp\qa-ops-20261106\selftest`，`TEMP/TMP` 也指向同一 D 盘目录。

```text
SELFTEST_STORE          {"checks":20,"failed":0}
SELFTEST_COMPAT         {"checks":46,"failed":0}
SELFTEST_MAPPING_RESULT {"checks":39,"failed":0}
SELFTEST_ROUND5         {"checks":4,"failed":0}
SELFTEST_ROUND6         {"checks":17,"failed":0}
SELFTEST_ROUND9         {"checks":8,"failed":0}
SELFTEST_ROUND10        {"checks":8,"failed":0}
SELFTEST_OK
```

合计 **142 checks / 0 failed**，退出码 0。`SELFTEST_ROUND9.report.drive` 的 7 个目标全部为 `d:\`；`ROUND10.report.realCommands` 真实执行了 `team.mjs req review / owner / owner:accept / workflow`。日志：`_tmp/qa-ops-20261106/selftest.out.log`；`selftest.err.log` 里的 `SESSION_IDENTITY_MISMATCH`、`LEGACY_PROTOCOL_REQUIRED` 等是自测故意触发的负例，不是失败。

**自测的覆盖边界**：它断言了 Owner pending 不写 by/actor（`src/main.js:8559-8570`），但没有断言“确认后的 Owner 记录必须带 actor/confirmation”。这由本轮单独的 Owner 探针补证，见 2.4。

### 2.4 Owner actor 真实链路

1. `node src/team-tools.js --probe-owner-auth`（mocked 旧命令）：**21/21 checks 通过**。产物：`_tmp/qa-ops-20261106/owner-auth-probe.json`。
2. 真实 `team.mjs` 端到端探针（临时 TEAM_ROOT，真实 `req review → owner → task → claim/done → owner:accept`）：
   - **29/29 checks 通过**，0 failed；
   - 需求行和顶层 `ownerReview` 均保留 `actor=owner`、`channel=nonce`、`confirmation.nonceHash`；
   - 新 tools 实例刷新后仍能看到；
   - 验收 `acceptance` 仍是对象，没有被“验收标准字符串”展开成数字键；
   - 需求正文 1 个状态记录章节、1 条 accepted；
   - 索引只登记正文需求。
   产物：`_tmp/qa-ops-20261106/owner-probe2.json`。
3. 项目级 Owner（`owner:decide`）走真实 IPC：`owner:challenge → owner:confirm → owner:decide` 成功，但返回值和 `工作流.json` 只有 `{status,opinion,at,by,roundKey}`，**没有 actor/confirmation**。产物：`_tmp/qa-ops-20261106/owner-decide.out.json`。重启隔离实例后 `state.projects[0].ownerReview.actor = null`，确认不是内存丢失而是落盘就缺。

### 2.5 `npm start`（隔离实例）

```text
> node scripts/run-electron.cjs . --remote-debugging-port=9444
[环境] 检测到继承的 ELECTRON_RUN_AS_NODE=1，已在启动 Electron 前清除。
DevTools listening on ws://127.0.0.1:9444/...
```

- 环境为 `AWB_DATA_DIR=D:\...\_tmp\qa-ops-20261106\app-data`、`TEAM_ROOT=D:\...\app-team`、`TEMP/TMP` 在 D；
- CDP 目标出现 `type=page, title=敏捷工作台 · DSH 壳, url=.../src/renderer/index.html`；
- 通过真实“新建项目”弹窗创建 `QA-OPS-真实新项目`，返回 DSH workspace `3c2d8e33-d011-4cfc-bc36-ebf56df3ab3e`，六个角色目录/文档/索引/workspace.json 全部落盘；
- 关闭后重启同一数据根，项目仍在，`activeProjectId` 正确，workspace `bound=true`；
- 关闭窗口后 npm/Electron 进程退出，无残留 9444/9445 端口；
- 真实 DSH `webview` 可加载（`_tmp/qa-ops-20261106/real-dsh-webview.png`，标题 `DeepSeek Harness`）。启动日志里的 `GUEST_VIEW_MANAGER_CALL ERR_ABORTED` 没有造成可用性失败，未计为本轮问题。

日志：`_tmp/qa-ops-20261106/start.out.log`、`start.err.log`、`start2.*`。截图：`ui-drawer-default.png`、`ui-drawer-project.png`。

### 2.6 UI 放大

隔离实例 1480×920（默认窗口 1480×920）：

| 浮层 | zoom | 实际 rect | 视口 | 裁剪 |
|---|---:|---|---|---|
| `#project-drawer` | 1.18 | 1062×840 @ x=418, bottom=920 | 1480×920 | 0 |
| `#team-drawer` | 1.14 | 730×840 @ x=750, bottom=920 | 1480×920 | 0 |
| `#project-drawer` @1100×700 | 1.18 | 823×620 @ x=277, bottom=700 | 1100×700 | 0 |
| `#team-drawer` @1100×700 | 1.14 | 730×620 @ x=370, bottom=700 | 1100×700 | 0 |

看板浮窗（真实 `team:board-old` + `window.boardWin.control`）：

```text
zoom-in  默认 1120×780 → 1200×840
zoom-in  1200×840 → 1280×900
collapse 1280×56
zoom-in（折叠态）→ {ok:false, code:"BOARD_COLLAPSED"}
expand   1280×900
maximize 2576×1416（再点还原 1280×900）
close    scheduled
```

产物：`_tmp/qa-ops-20261106/ui-probe.out.json`、`ui-team-board.out.json`、`board-probe.json`。

### 2.7 `npm pack --dry-run`

50 个文件，不含 `项目/`、`data/`、`docs/`、`_tmp/`、`_backup/`、`团队/状态/`、看板运行态、`userdata*/`。上一轮 P3-1 的绝对路径问题仍在（5 个白名单文件含 `D:\deepseek\...`），见 §5。

---

## 3. 逐项判定

| # | 检查项 | 判定 | 关键证据 |
|---|---|---|---|
| 1 | Owner actor 持久化 | **PARTIAL** | 需求级 Owner + 验收 29/29 真实链路通过，真实项目 `六人敏捷验收-20261106` 的 `R-20261106-0001` 已出现 `actor=owner` / `nonceHash=913c1d83de2112cd`；但项目级 `owner:decide` / `workflow:owner` 仍不写 actor/confirmation（P1-1） |
| 2 | 旧索引 / 状态清理 | **PARTIAL** | 4 个项目的索引需求行、总览重复行、工作流双写、需求正文状态章节都已清干净，45 个变更文件、任务文件 0 变更、手写备注逐字节保留；但索引 `files` 的 34 处哈希/大小仍过期，真实新项目 8 处，微光状态仍冲突（P2-1/P2-2） |
| 3 | `npm start` | **PASS** | 继承 `ELECTRON_RUN_AS_NODE=1` 仍启动真实 Electron；页面、六角色、DSH workspace、重启持久化全部通过；11/11 入口脚本测试 |
| 4 | UI 放大 | **PASS** | 项目/团队浮层 1.18/1.14 在 1480×920 与 1100×700 均无裁剪；看板放大/折叠/展开/最大化/还原/关闭全部按预期改变或拒绝 |
| 5 | 真实新项目 | **PASS** | 隔离实例真实新建 `QA-OPS-真实新项目` 成功；真实数据中的 `六人敏捷验收-20261106` 也完成六角色目录、六会话、DSH workspace、Owner 决定与 dev 提交；但索引元数据过期（P2-1） |
| 6 | D 盘 | **PASS** | selftest 7/7 目标 `d:\`；应用数据/临时目录/项目/团队状态/DSH workspace 均在 D；C 盘 `%APPDATA%\敏捷工作台`、`%APPDATA%\Electron`、`%LOCALAPPDATA%\electron\Cache` mtime 均未变 |

---

## 4. 问题清单

### P1-1 旧版项目级 Owner 决定仍不落 `actor` / `confirmation`

**现象**：通过真实 IPC 走 `owner:challenge → owner:confirm → owner:decide`，确认成功、决定成功，但 `工作流.json` 顶层 `ownerReview` 只有：

```json
{
  "required": true,
  "status": "approved",
  "by": "Owner",
  "at": "2026-11-05T19:21:02.888Z",
  "roundKey": "P-015a2a6b|0|0|0",
  "opinion": "QA 项目级 Owner 认证字段检查"
}
```

没有 `actor`，也没有 `confirmation`（channel/nonceHash/at）。重启同一数据根后，`state.projects[0].ownerReview.actor` 仍为 `null`。`workflow:owner` 走的是同一条写入链。

**证据**

- `src/main.js:5747`：`recordOwnerDecision(current, { status, opinion: p.opinion, roundKey, by: 'Owner' })`，没有 actor/confirmation。
- `src/main.js:3971-3973`：`workflow:owner` 同样只传这四个字段。
- `src/team-tools.js:961-969`（`writeOwnerWorkflow`）：只 spread 旧对象并写 `status/by/at/roundKey/opinion`，没有补认证字段；`mergeOwnerAuthFields`（`:376-405`）只被需求级 Owner / 验收路径使用。
- 真实探针输出：`_tmp/qa-ops-20261106/owner-decide.out.json`；重启后状态：同一 `_tmp` 的隔离实例日志/`app-data`。
- 对比：真实 `team.mjs` 需求级 Owner 与验收 29/29 通过，真实项目 `工作流.json` 的 `ownerReview.actor='owner'`、`confirmation.nonceHash='913c1d83de2112cd'`。

**影响**：项目级 Owner 是界面明确暴露的“旧版”入口（`app.js:6605-6606`，`data-open-owner-legacy`），它的最终决定同样写唯一真相 `工作流.json`；现在确认过后文件仍无法证明确认发生过。而且 `owner:decide` 在写入成功后会 `consumeOwnerChallenge`，确认码已被消费，不能靠“再点一次”补写认证字段。它与上一轮 P1-1 同类，只是路径从“需求级”残留到了“项目级”。

**最小修法**：让 `owner:decide` / `workflow:owner` 把 `requireOwnerConfirmation` 得到的确认材料（`actor:'owner'`、`channel`、`nonceHash`、`confirmedAt`，不要存原始 confirmToken）传给 `recordOwnerDecision`，并在 `writeOwnerWorkflow` 中按字段合并；补一条 `npm run selftest` 断言，避免再次只测“拦截”不测“落盘”。

### P2-1 索引 `files` 的哈希/大小系统性过期（清理后 4 个项目 + 真实新项目）

**现象**：`项目索引.json` 的 `files[]` 记录的是生成索引“之前”的 `文件索引.md`，而 `team.mjs index` 在扫描之后才重写各目录 `文件索引.md`；因此每次 index 后，索引都会立刻记录旧哈希。新项目还多一个 `workspace.json`：索引在 `ensureProjectReady` 内生成，`workspace.json` 在之后的 `activateWorkspace` 才写。

**证据**

- 根因：`团队/工具/lib/ops.mjs:1213` 先 `scanProject`，`:1341` 写 `项目索引.json`，`:1347` 才 `writeRoleIndexes`；`src/main.js:2621` 先 `ensureProjectReady`（内部 index），`:2641` 才 `activateWorkspace` 写 `workspace.json`。
- 清理后的 4 个项目共 **34 处不符（涉及 32 个文件条目）**：
  - `MVP验收-20261105-1705`：8 个文件、9 处不符（6 个角色目录 + `需求/` + `site/` 的 `文件索引.md`；其中 `需求/文件索引.md` 同时 size 和 hash 不符）；
  - `UI验收-20261105-1745`：8 个文件、9 处不符；
  - `UI闭环-20261105-1852`：8 个文件、8 处不符；
  - `微光作品集`：8 个文件、8 处不符。
  - 例：`UI验收/项目索引.json` 的 `测试人员/文件索引.md` 记录 `ab9d4ed…`，磁盘 `fe795d2…`；`需求/文件索引.md` 记录 1201 B，磁盘 1200 B。
- 真实新项目 `六人敏捷验收-20261106`（03:23:29 最后一次 index）仍有 **8 处**：6 个角色目录 + `需求/` + `site/` 的 8 个 `文件索引.md`；例如 `site/文件索引.md` 记录 385 B，磁盘 446 B。
- 另有自引用问题：`项目索引.md` 的“必读文件”表把自身大小写成上一版。新项目 19:23 这次 index 后，表里仍是 **5171 B**，实际 **5373 B**；`UI验收` 是 5259 vs 5258。根因是 `ops.mjs:1235` 的 `selfRow` 取写入前的 `stat`。
- 清理脚本的 `verify.mjs:88-91` 只校验 `需求/文件索引.md` 里的 `00-需求总览` 哈希，没有校验 `项目索引.json.files`，所以 `SUMMARY checks=70 failed=0` 与这 34 处并不矛盾。

**影响**：索引的“文件明细 + 哈希”不是可信快照；任何按索引做完整性校验、缓存判断或角色核对都会误报。UI 当前用实时 `files:list` 扫描，所以页面文件列表不受影响，但索引作为“先读索引”的入口文件，元数据是错的；这也是“旧索引清理”没有真正收口的地方。

**最小修法**：把 `writeRoleIndexes` 移到 `scanProject` 之前，或在写 JSON 前重新 `scanProject`；自引用行不要依赖写入前 `stat`（改成不显示自身 size/hash，或先占位、写完后再算并固定宽度替换）；新项目在 `activateWorkspace` 成功后再补一次 index（或把 `workspace.json` 从首轮 `files` 排除）。修完对 4 个清理项目 + 真实新项目各跑一次 index，再复验 `files` 哈希。

### P2-2 `微光作品集` 的状态真相冲突

**现象**：同一项目的三个来源给出不同状态：

- `项目/微光作品集/需求/00-需求总览.md`：两行都是 `已验收`，更新时间 2026-11-03；
- 两份需求正文：没有 `- 状态：` 行，也没有 `## 状态记录`；
- `团队/状态/项目/微光作品集/工作流.json`：两个需求都是 `status: "review"`，项目 `phase: "idle"`。

界面读工作流，会显示 `review`；人读总览，会看到 `已验收`。清理脚本允许这种组合：`verify.mjs:9` 对微光写 `accepted:false`，但 `:78` 又允许总览状态为 `accepted|已验收`，等于把冲突“验绿”了。

**影响**：这是真实项目（不是测试项目），如果被恢复/打开，需求状态和验收结论会按入口不同而不同；也意味着“旧状态清理”对微光没有做状态归一。

**最小修法**：先确认业务真相，再二选一：若确实已验收，给正文补 `- 状态：accepted` 并走一次 `team.mjs index`/状态同步；若仍是 review，把总览两行改回 review。不要自动猜测。

### P3-1 旧索引/状态清理只覆盖了 4 个已登记项目，仓库里仍有旧格式与孤儿状态

**现象**：清理只对 `微光作品集`、`UI闭环-20261105-1852`、`UI验收-20261105-1745`、`MVP验收-20261105-1705` 跑了 index；其余旧目录仍在：

| 对象 | 状态 |
|---|---|
| `项目/六人敏捷工作区/项目索引.json` | 2026-11-02 生成，0 需求 |
| `项目/团队工作台改造/项目索引.json` | 2026-11-02 生成，1 条需求行 `需求/需求分析与场景闭环.md`（没有 `R-` 号） |
| `项目/测试工作台项目/项目索引.json` | 2026-11-02 生成，0 需求 |
| `团队/状态/项目/个人博客项目` | 旧状态目录，没有对应 `项目/个人博客项目` |
| `团队/状态/项目/个人简历展示项目` | 旧状态目录，没有对应项目目录 |
| `团队/状态/项目/六人敏捷工作区`、`团队工作台改造`、`测试工作台项目` | 旧状态目录，对应项目目录仍在 |

**影响**：这些目录被 `project:discover` 发现/恢复时，`team-tools.js:3128` 只在索引**缺失**时才刷新；已有旧索引会先被读到，`团队工作台改造` 的非 `R-` 需求行在第一次需求动作前不会被清掉。孤儿状态目录还会出现在旧版 `team:status` 看板快照里（本轮读到的 11-05 版本就列了 `个人博客项目`、`个人简历展示项目`）。这不是本轮 4 项目清理的回归，但“旧索引/状态清理”没有全仓收口。

**修法**：对这 3 个旧项目各跑一次 `team.mjs index`（或在 adopt 时强制刷新），再决定两个孤儿状态目录是归档还是删除；删除前需用户确认。

### P3-2 历史 Owner 记录仍显示“记录人未认证”，没有迁移

`MVP验收-20261105-1705`、`UI验收-20261105-1745`、`UI闭环-20261105-1852` 三个已验收项目的需求级 `ownerReview` / `acceptance` / 顶层 `ownerReview` 都没有 `actor` / `confirmation`（早于本轮修复）。打开这些项目的需求级 Owner 面板，`app.js:6589-6592` 会显示 `actor=记录人未认证`。这无法从旧数据里“补出”真 confirmation；本轮没有回填，也不应该伪造 `nonceHash`。如果产品要求旧数据也显示已认证，需要单独定义“历史记录”标识，而不是写 `actor=owner` 冒充确认。

### P3-3 上一轮 P3-1 的发布包绝对路径仍未修

`npm pack --dry-run` 的 50 个文件中仍有 5 个带作者本机绝对路径：

```text
团队/协议/01-会话与必读.md:5       D:\deepseek\工作台
团队/协议/06-风险重启扩编.md:63    D:\deepseek\工作台
团队/工具/workspace.mjs:3          D:\deepseek\工作台\项目
团队/工具/工作流命令.md:186        D:\deepseek\agile-workbench\_tmp
团队/模板/启动卡.md:6              D:\deepseek\工作台
```

导出脚本会 sanitize，`npm pack` 不会；这与上一轮 P3-1 相同，本轮未修。若仍用 `npm pack` 交付，需要清掉或在 `prepack` 复用 sanitize。

---

## 5. 已复核、未发现问题的部分

- **需求级 Owner actor/confirmation 真实链路**：真实 `team.mjs` 的 29/29 项检查通过；需求行、顶层、UI 快照均保留 `actor=owner`、`channel=nonce`、`confirmation.nonceHash`，新 tools 实例刷新后仍在。
- **真实项目中的 Owner 记录**：`六人敏捷验收-20261106` 的 `R-20261106-0001` 在 19:23 由真实 `team.mjs owner` 写入 `actor=owner`、`confirmation.channel=nonce`、`nonceHash=913c1d83de2112cd`，顶层 `ownerReview` 同样带确认材料；证明“需求级”修复在真实数据上生效。
- **验收不会被验收标准字符串污染**：29/29 探针中 `acceptance` 没有数字键；`E2E` 最终 `工作流.json` 的 `acceptance` 是对象。
- **清理内容本身**：4 个项目共 45 个变更文件；任务文件 0 变更；手写备注逐字节保留；需求正文状态章节 1 个、accepted ≤1；工作流 history/events 无 60 秒内重复；事件日志在核对时可解析（0 坏行），只追加，旧事件未改。
- **索引需求行**：4 个清理项目都只剩 `需求/R-*.md`，无 `/评审/`、`/验收/` 行；真实新项目也是 1 条 `需求/R-20261106-0001-…md`。
- **`npm start`**：继承 `ELECTRON_RUN_AS_NODE=1` 时由 `run-electron.cjs` 清除；真实 Electron 窗口、真实 DSH 工作区、真实项目创建、重启持久化均通过；`start.cmd --check` 与错误分支由 11/11 脚本测试覆盖。
- **UI 放大**：`#project-drawer` 1.18、`#team-drawer` 1.14；1480×920 与最小 1100×700 均不裁剪；看板 1120×780 → 1200×840 → 1280×900，折叠 56，折叠态拒绝缩放，展开/最大化/还原/关闭均正确。
- **真实新项目结构**：`六人敏捷验收-20261106` 有完整六角色目录、角色卡/文件索引、项目信息/铁律/协作准则/索引、`团队会话.md`、`workspace.json`、DSH workspace、六个会话；`项目信息.md` 不是占位模板。
- **D 盘**：selftest 7/7 目标 `d:\`；真实项目路径、DSH workspace、`data/userdata`、`app-data/tmp` 都在 D；C 盘三个 profile 目录 mtime 未变。数据根跟随仓库（`src/main.js:15-25`，本机仓库在 D），不是硬编码 D；README 的 `AWB_DATA_DIR` / `AWB_SELFTEST_ROOT` / `TEAM_ROOT` 可改，纯 D 盘机器仍需另配 `DSH_HOME`。
- **`.gitignore`**：`团队/看板.html`、`.md`、`.json`、`.png` 均已忽略（`.gitignore:11-14`），上一轮 P2-3 已修。
- **`npm pack` 内容范围**：50 个文件不含 `项目/`、`data/`、`docs/`、`_tmp/`、`_backup/`、`团队/状态/`、`userdata*/`；只有 5 个白名单文件内容里的绝对路径问题（P3-3）。

---

## 6. 边界与披露

- **并发写入**：本轮 QA 期间，另一个会话/进程在真实数据上创建并推进了 `六人敏捷验收-20261106`（03:16 创建，03:23 需求/Owner/dev 提交），并启动了六个 DSH 会话。真实 `data/userdata/workbench.json`、`团队/状态`、`项目/六人敏捷验收-20261106` 的 mtime 都被它更新；本报告引用的是该真实项目当时的状态，不是本会话写入。本会话没有写真实仓库的 `src/**`、`package.json`、`团队/**`、`项目/**`、`data/**`；唯一的外部写入是下条说明的隔离实例 DSH workspace。
- **selftest 用隔离沙盘**：`AWB_SELFTEST_ROOT` 指到 `_tmp/qa-ops-20261106/selftest`，不是默认 `.selftest-data`；自测没有写真实 `团队/状态`、真实 `项目/`、真实 `data/`。真实数据在本轮的变化来自上面的并发进程。
- **selftest 的 DSH 是 mock**：`SELFTEST_DSH.baseUrl` 是自测 mock；真实 DSH 路径由 2.5 的隔离 `npm start` 和真实项目 Owner 记录覆盖，但 selftest 本身不证明真实 DSH。
- **隔离实例的 DSH 副作用**：隔离 `npm start` 用真实 DSH 创建了 `QA-OPS-真实新项目` 的 workspace `3c2d8e33-d011-4cfc-bc36-ebf56df3ab3e`，路径在 `_tmp/qa-ops-20261106/projects/QA-OPS-真实新项目`；真实 DSH 侧栏会多一个同名工作区。`src/dsh-adapter.js` 没有公开的删除 workspace 方法，本轮没有擅自调用未知 RPC；如不需要，可由用户手动移除，或在确认后清理 `_tmp/qa-ops-20261106`。
- **Owner 真实链路探针**：使用临时 `TEAM_ROOT` + 真实 `团队/工具/team.mjs`，不是 mock；但 `ownerRequirementDecision` 走的是 `ownerConfirmed:true` 的 team-tools 入口，项目级 `owner:decide` 才直接走 app IPC。两者互补。
- **历史数据**：3 个已验收项目的 Owner 记录没有 actor/confirmation（早于本轮修复），本轮没有回填；P3-2 已说明。
- **`ELECTRON_RUN_AS_NODE`**：本会话 shell 默认带 `=1`；`npm run selftest`、`npm start` 都经 `run-electron.cjs` 清除，`start.cmd` 也清。按 README 与上一轮复现，直接 `npx electron .` 仍会踩到 `main.js:82` 的 `app.setPath` 崩溃，这是环境边界，不是本轮回归。
- **`npm run check` 只是语法**：7 个文件 `node --check`，不覆盖行为；`scripts/export-open-source.mjs` 不在 check 链里，但单独 `node --check` 通过（本轮额外跑过）。
- **UI 放大的范围**：`style.css:2746-2754` 只放大 `#project-drawer`（1.18）和 `#team-drawer`（1.14）；主壳、项目主视图和嵌入的 DSH `webview` 不缩放。本轮按“项目/团队面板放大”验收；若需求是整窗/全界面放大，则只算部分覆盖。
- **`npm pack` 与 export 不一致**：P3-3 仍是上一轮遗留；本轮未改。
- **真实 DSH 凭据**：`dsh-adapter` 默认从 `C:\Users\<user>\.dsh` 只读凭据；纯 D 盘机器需要另配 `DSH_HOME`，这是既有边界。
- **未改源码**：本轮只新增 `docs/QA-FINAL-OPS.md` 与 `_tmp/qa-ops-20261106/**`；未改 `src/**`、`package.json`、`团队/**`、真实 `项目/**`。

---

## 7. 建议处理顺序

1. **P1-1**：补项目级 Owner 的 actor/confirmation 落盘，并在 `npm run selftest` 增加“确认后 actor 存在”断言。
2. **P2-1**：修 index 的扫描/写序与 `selfRow`，对 4 个清理项目 + 真实新项目各重跑一次 index，复验 `files` 哈希/大小。
3. **P2-2**：确认 `微光作品集` 的真实状态，统一总览、正文、工作流；不要自动伪造验收。
4. **P3-1**：对 3 个旧项目跑 index，处理两个孤儿状态目录（需用户确认）。
5. **P3-2**：决定历史 Owner 记录是否要“历史未认证”标识或迁移策略。
6. **P3-3**：清掉发布包白名单文件中的本机绝对路径，或在 `prepack` 复用导出 sanitize。

修完后至少重跑：`npm run check`、`npm run test:scripts`、`npm run selftest`、`node src/team-tools.js --probe-owner-auth`、真实 Owner 29 项探针、隔离 `npm start` 的新建/重启、`npm pack --dry-run` 的绝对路径扫描。

---

## 8. 产物索引

| 产物 | 路径 |
|---|---|
| 本报告 | `docs/QA-FINAL-OPS.md` |
| 源码哈希 | `_tmp/qa-ops-20261106/hashes.json` |
| check / test:scripts | `_tmp/qa-ops-20261106/check.log`、`test-scripts.log` |
| selftest | `_tmp/qa-ops-20261106/selftest.out.log`、`selftest.err.log` |
| 真实 Owner 29 项 | `_tmp/qa-ops-20261106/owner-probe2.json` |
| mocked Owner 21 项 | `_tmp/qa-ops-20261106/owner-auth-probe.json` |
| 项目级 Owner 缺失 actor | `_tmp/qa-ops-20261106/owner-decide.out.json`、`owner-decide-probe.cjs` |
| 清理复验 | `_tmp/qa-ops-20261106/verify-cleanup.json`、`state.json` |
| UI 浮层/看板 | `_tmp/qa-ops-20261106/ui-probe.out.json`、`ui-team-board.out.json`、`board-probe.json` |
| 截图 | `_tmp/qa-ops-20261106/ui-drawer-default.png`、`ui-drawer-project.png`、`ui-drawer-min.png`、`real-dsh-webview.png` |
| npm start 日志 | `_tmp/qa-ops-20261106/start.out.log`、`start.err.log`、`start2.*` |
| 清理前备份 | `_tmp/team-state-cleanup-20261106-024229/before/` |
