# QA-FINAL · 索引 / 状态记录 / 4 位旧需求 / Owner 确认 / .gitignore / D 盘

> 对象：`D:\deepseek\agile-workbench`
> 时间：2026-11-05 19:52–20:16（Asia/Shanghai）
> 方式：只读源码审计 + `npm run check` + `npm run selftest`（D 盘真实 Electron/team.mjs）+ `%TEMP%\qa-probe` 隔离探针（真实 `team.mjs` / `workspace.mjs`）
> 边界：未改 `src/**`、`package.json`、`团队/**`、真实 `项目/**`。本轮写入只在 `.selftest-data/`、`docs/QA-FINAL.md`、`_tmp/qa-final-20261105/` 与 `%TEMP%\qa-probe`。真实 `团队/状态` 最后写入仍是 19:05:17，早于本轮。

## 0. 一句话结论

**新写入逻辑基本兑现：索引不再把评审/验收记录算需求，4 位旧需求只有正文也能评审/Owner/验收，状态记录双写能合并，Owner 未确认会被 IPC 拦住。但“确认有 actor”没有落到工作流真相里：壳层在旧命令写完后把带 `actor` / `confirmation` 的记录整个覆盖掉；另外三份存量需求正文仍有重复状态记录、三个存量项目索引仍把记录算需求，且没有自动迁移。`npm run check` 与 `npm run selftest` 均通过，但自测断言覆盖不到“actor 持久化”和“手写行保留”这两点。**

---

## 1. 源码与运行快照

| 文件 | 字节 | SHA-256 前 16 | 最后写入（UTC） |
|---|---:|---|---|
| `src/main.js` | 517,918 | `55062A21D4C4DD34` | 2026-11-05T11:36:48Z |
| `src/team-tools.js` | 289,763 | `D86FC464A00F841F` | 2026-11-05T11:26:15Z |
| `src/renderer/app.js` | 512,188 | `33E90D1547E23CCE` | 2026-11-05T11:44:05Z |
| `src/preload.js` | 7,812 | `40B0ABF9ACA0E050` | 2026-11-05T11:22:30Z |
| `src/renderer/index.html` | 47,649 | `0BBF7DEA069503F4` | 2026-11-05T11:27:56Z |
| `团队/工具/lib/ops.mjs` | 136,732 | `796D3A76DA60844D` | 2026-11-05T11:26:33Z |
| `团队/工具/lib/workflow.mjs` | 72,552 | `83A83DAB54981E2A` | 2026-11-05T11:29:06Z |
| `团队/工具/team.mjs` | 7,191 | `475BE3DC930B0D44` | 2026-11-05T11:23:57Z |
| `package.json` | 1,157 | — | 2026-11-05T11:18:16Z |
| `.gitignore` | 1,211 | — | 2026-11-05T11:17:17Z |

仓库位于 `D:\deepseek\agile-workbench`；`data/`、`.selftest-data/`、`_tmp/` 均在 D。

## 2. 命令结果

### 2.1 `npm run check`

```text
> node --check src/main.js && node --check src/preload.js && node --check src/renderer/app.js
  && node --check src/dsh-adapter.js && node --check src/team-tools.js
```

退出码 0。注意它只是语法检查，不覆盖行为。

### 2.2 `npm run selftest`

第一次按 `npm run selftest` 的等价命令（`electron . --selftest --user-data-dir=userdata-selftest`）直接跑失败，原因是本机 shell 继承了 `ELECTRON_RUN_AS_NODE=1`，Electron 被当成 Node 解释器：

```text
TypeError: Cannot read properties of undefined (reading 'setPath')
    at Object.<anonymous> (src/main.js:82:5)
```

`start.cmd:7` 本来就会清掉这个变量。清掉后重跑 `npm run selftest`（下面只截取 `checks`/`failed` 字段，完整 JSON 见日志）：

```text
SELFTEST_STORE        {"checks":20,"failed":0}
SELFTEST_COMPAT       {"checks":46,"failed":0}
SELFTEST_MAPPING_RESULT {"checks":39,"failed":0}
SELFTEST_ROUND5       {"checks":4,"failed":0}
SELFTEST_ROUND6       {"checks":17,"failed":0}
SELFTEST_ROUND9       {"checks":8,"failed":0}
SELFTEST_ROUND10      {"checks":8,"failed":0}
SELFTEST_OK
```

退出码 0，各轮 `checks` 合计 142 项、`failed` 全为 0；`SELFTEST_ROUND10.report.realCommands` 未跳过，真实 `team.mjs req review / owner / workflow` 命令均执行（`accept.status = accepted`）。日志：`_tmp/qa-final-20261105/selftest.log`。

自测只写 `.selftest-data`：真实 `data/` 最后写入 19:15:17、`团队/状态` 19:05:17，均早于本轮，未被自测改动。

### 2.3 隔离探针（真实旧工具，临时沙盘）

脚本与原始输出已存 `_tmp/qa-final-20261105/`：

| 探针 | 用途 | 结果 |
|---|---|---|
| `probe-index` | 一条正文 + 评审/验收记录，跑 `refreshProjectIndex` | `requirements=1`，JSON 只有正文行，Markdown 无 `/评审/`、`/验收/` |
| `probe-legacy` | 4 位号、只有正文，走评审 → Owner → 测试任务 → 验收 | 全部 `OK`，`driver=team.mjs …`，索引 1 行，正文 1 个状态记录 |
| `probe-heal` | 旧正文两个「## 状态记录」、两条 accepted，跑索引刷新 | `2/2` → `1/1` |
| `probe-manual` | 状态记录里加一行手写说明，再走验收 | 手写行被删除（见 P2-1） |

## 3. 逐项判定

| # | 检查项 | 判定 | 关键证据 |
|---|---|---|---|
| 1 | 项目索引不把评审/验收记录算需求 | **PASS（新写入）/ PARTIAL（存量）** | 探针 1 行；旧工具 `ops.mjs:1254` 只认直属正文；3 个存量项目索引仍是 3–4 行 |
| 2 | 需求正文状态记录不重复 | **PASS（新写入/合并）/ PARTIAL（存量）** | 探针双写后 `1 章节 / 1 条 accepted`；存量 3 份正文仍是 2 章节；另有 P2-1 删手写行 |
| 3 | 4 位老需求只有正文时评审/Owner/验收可走 | **PASS** | `probe-legacy` 三步全 `OK`；selftest 对应断言全过 |
| 4 | Owner 未确认不能通过，确认有 actor | **PARTIAL** | 未确认拦截成立；`actor`/`confirmation` 被壳层覆盖丢失（P1-1） |
| 5 | `.gitignore` / `files` 排除私有项目/临时/备份/凭据 | **PARTIAL** | `npm pack` 48 个文件干净；`.gitignore` 漏 `团队/看板.json`、`团队/看板.png`；包内有绝对路径（P3-1） |
| 6 | D 盘 | **PASS（本次运行）** | 自测 7/7 目标为 `d:\`；C 盘 profile 未更新；产品层面仍是“跟随仓库”，非硬编码 D |

---

### 3.1 项目索引不把评审/验收记录算需求

**新写入：通过。**

- 旧工具 `团队/工具/lib/ops.mjs:1249-1261` 的需求行只接受 `/^需求\/R-[^/\\]+\.md$/`，`需求/评审/**`、`需求/验收/**` 直接排除；4/6 位同号还按 `reqIdKey` 去重。
- 壳层 `src/team-tools.js:3109-3120`（`sanitizedIndexRequirementDocs`）、`:3128-3182`（重写 JSON 与 `## 三、需求目录`）在 `refreshProjectIndex`（`:3188-3232`）里再兜底一次。
- 探针：正文 `R-20260101-0001-测试需求.md` + `需求/评审/…` + `需求/验收/…`，刷新后 `requirements: 1`，JSON 唯一行 `需求/R-20260101-0001-测试需求.md`，Markdown 无记录路径（`probe-index.json`）。
- 自测断言 `项目索引不把评审/验收记录算需求`（`src/main.js:8000-8004`）与 `旧号项目索引只登记正文需求`（`:8116-8119`）全过。

**存量：未迁移。** 三个真实项目索引仍是旧格式：

| 项目 | 生成时间（UTC） | 需求行 | 其中评审/验收记录 |
|---|---|---:|---:|
| `项目\MVP验收-20261105-1705\项目索引.json` | 09:05:34 | 3 | 2 |
| `项目\UI验收-20261105-1745\项目索引.json` | 09:58:59 | 3 | 2 |
| `项目\UI闭环-20261105-1852\项目索引.json` | 11:05:16 | 4 | 3 |

三份都早于 `ops.mjs` 的最后写入 11:26:33Z。界面会用 `src/renderer/app.js:5028-5063` 在显示层过滤，所以页面上的需求数仍是对的；但文件本身、JSON 里的 `requirements`、以及“角色按索引找需求”的路径仍是错的。自愈只在下次需求动作或手工 `team.mjs index` 时发生（见 P2-2）。

### 3.2 需求正文状态记录不重复

**新写入：通过。**

- 壳层 `src/team-tools.js:4580-4616` 把所有 `## 状态记录` 合并成一个，并按“同状态 + 10 分钟窗口”去重；`updateRequirementDocStatus`（`:4622-4665`）只在验收/终止时追加一条。
- 旧工具 `团队/工具/lib/workflow.mjs:610-680`（`normalizeStatusRecord`）与 `:682-695`（`normalizeRequirementDocs`）在每次命令落盘前也做同样合并。
- 探针（正文已有评审/owner 记录，验收时旧命令和壳层各写一次 accepted）：最终 `sections=1`、`accepted=1`，保留的是旧命令带详细 note 的那条（`probe-legacy.json`）。
- 修复存量：`probe-heal` 的两个章节、两条 accepted → `1 章节 / 1 条`（`probe-heal.json`）。
- 自测断言 `需求正文状态记录去重`（`src/main.js:8007-8009`）与 `旧号验收正文状态记录去重`（`:8123-8126`）通过。

**存量：未迁移。** 三个项目的需求正文仍是 2 个 `## 状态记录`、2 条 accepted：

- `项目\MVP验收-20261105-1705\需求\R-…-MVP验收演示页…md`（09:05:37Z）
- `项目\UI验收-20261105-1745\需求\R-…-验收演示页…md`（10:00:07Z）
- `项目\UI闭环-20261105-1852\需求\R-…-闭环验收页…md`（11:03:07Z）

**副作用：会删手写行（P2-1）。** 见问题清单。

### 3.3 4 位老需求只有正文时评审/Owner/验收可走

**通过。** 独立探针 `probe-legacy`（4 位号 `R-20200101-0001`，只有 `需求/R-…md`，没有任务/工作流行）：

```text
boot product   OK
review         OK  driver=team.mjs req review   status=approved
owner          OK  driver=team.mjs owner        status=ready
task create    OK
claim/done     OK
accept         OK  driver=team.mjs owner + owner-note.mjs  status=accepted
```

实现路径：`ensureLegacyRequirementRecord`（`src/team-tools.js:3818-3930`）在 `reviewRequirement`（`:4319`）、`ownerRequirementDecision`（`:4432`）、`ownerAccept`（`:5625`）之前补工作流镜像行与旧任务；`requirementIdKey`（`:3338-3343`）把 4/6 位同号归一。自测对应断言 `4 位旧需求只有正文时可评审/Owner`（`src/main.js:8085-8087`）、`…可验收`（`:8111-8113`）通过。

边界：探针与自测一样，把工作流行手动推到 `test` 再走验收；“派单 → 开发 → 测试”全链未在 4 位旧需求上重跑。这不影响“评审/Owner/验收可走”的结论，但“旧项目全流程可跑”仍未被端到端覆盖。

### 3.4 Owner 未确认不能通过，确认有 actor

**未确认拦截：通过。**

四个写 Owner 的 IPC 都在调用 team-tools 前过 `requireOwnerConfirmation`：

- `workflow:owner`（`src/main.js:3956-3961`）
- `requirement:owner`（`:4162-4167`）
- `owner:accept`（`:4244-4249`）
- `owner:decide`（`:5732-5737`）

`validateOwnerConfirmation`（`:837-876`）区分 `OWNER_CONFIRM_REQUIRED / INVALID / EXPIRED / SCOPE_MISMATCH`；自测 `Owner 未确认时 requirement:owner 返回 OWNER_CONFIRM_REQUIRED`（`:8578-8580`）通过，且返回里带 challenge。

补充边界：这套闸门是“本机两步确认”（challenge → confirm），不是身份认证。`owner:challenge` 会把 nonce 返回给调用方，`owner:confirm` 用同一个 nonce 就换出 `confirmToken`；任何能调 IPC 的渲染代码都能自己走完两步（自测 `src/main.js:8582-8593` 就是这么做的），旧命令的 `--test-owner` 也关掉 TTY 要求（`src/team-tools.js:2655-2684`）。按产品现在写的“本机确认；不是 DSH 身份证明”（`src/renderer/app.js:5499`）这是自洽的；若仍要求“Owner 身份”，则上一轮 P0-2 仍未收口。

**确认有 actor：不成立（P1-1）。** 旧命令写入后，壳层把带 `actor` / `confirmation` 的记录整个覆盖：

- 旧工具写：`团队/工具/lib/workflow.mjs:1269-1270`（验收）、`:1303-1306`（需求级 Owner）都带 `actor: 'owner'` 与 `confirmation: { channel, at, nonceHash }`。
- 壳层覆盖：`src/team-tools.js:4490`、`:4502-4511`（需求级）、`:5715`、`:5725`（验收）重新赋值为不含 `actor` / `confirmation` 的对象。
- 探针最终 `工作流.json`：

```json
"ownerReview": {"status":"approved","by":"Owner","at":"…","opinion":"…","source":"team.mjs owner","command":"owner"}
"acceptance": {"status":"accepted","by":"owner","at":"…","opinion":"…"}
```

同一项目的 `任务/R-…json` 里仍保留：

```json
"ownerAcceptance": {"actor":"owner","confirmation":{"channel":"nonce","nonceHash":"754e38e753f7a6c9"},"…"}
```

- 界面读的是 `工作流.json`（`requirementView`，`src/team-tools.js:3991-4019` 只取 `row.ownerReview` / `row.acceptance`）。没有 `actor` 时 `src/renderer/app.js:6589-6592` 明确显示 `actor=记录人未认证`；只有本次页面还活着、内存里有 `OWNER_CONFIRM_ACTOR='owner'`（`:83`、`:5793`）时才显示“本机确认”。
- `owner:confirm`（`src/main.js:4047-4097`）返回 `confirmToken`，但没有 actor，也不把确认事件落盘。

影响：刷新/重启后，刚刚确认过的 Owner 决定会显示“记录人未认证”；`工作流.json`（唯一真相、索引/看板/界面数据源）无法证明确认发生过，只有 `任务/` 下的旧任务文件有；两个文件对同一动作的“确认证据”不一致。

### 3.5 `.gitignore` / `files` 排除私有项目/临时/备份/凭据

**`files`：通过。** `npm pack --dry-run --json` 共 48 个文件：

```text
LICENSE NOTICE.md README.md package.json start.cmd
src/**（5 个 js + renderer 3 个）
团队/工具/**（不含 export-open-source.mjs）
团队/角色/** 团队/模板/** 团队/协议/**
```

不含 `项目/`、`data/`、`docs/`、`_tmp/`、`_backup/`、`_archive/`、`团队/状态/`、`团队/日志/`、`看板.*`、`probe-receipts/`、`userdata*/`、`.selftest-data/`。`!团队/工具/export-open-source.mjs` 的排除在 `npm pack` 列表里生效。

**`.gitignore`：不完整（P2-3）。** 漏了 `团队/看板.json`、`团队/看板.png`；`团队/看板.html`、`团队/看板.md` 已被忽略（`.gitignore:8-12`）。这两个文件都是本机运行态：

- `团队/看板.json` 48,062 B，2026-11-05 19:05:17 生成，含 `owner: 徐野风`、`activeProject: UI闭环-20261105-1852`、9 个私有项目名与 `D:\deepseek\agile-workbench\项目\…` 绝对路径；应用在 `src/team-tools.js:1248-1250` 每次生成看板后会把 `状态/看板.json` 复制到团队根。
- `团队/看板.png` 152,496 B，截图内容为“团队看板 · 测试工作台项目”、负责人“徐野风”。

它们不在 `package.json` 的 `files` 里，所以 npm/导出不会带；但按当前 `.gitignore`，`git add .` 会把它们收进仓库（见 P2-3）。

**包内绝对路径：P3-1。** 白名单文件里仍有 `D:\deepseek\…`（见问题清单）。

### 3.6 D 盘

**本次运行：通过。**

- 仓库、`data/`、`.selftest-data/`、探针/日志都在 D；`src/main.js:15-25` 把 `LOCAL_DATA`/`USER_DATA`/`TEMP_ROOT` 指到仓库内，`:82-84` 设置 Electron 的 `userData/sessionData/temp`。
- 自测 `SELFTEST_ROUND9.report.drive`：7 个目标全部 `d:\`；`SELFTEST_ROUND10` 的“工作流状态全在 D 盘”断言（`src/main.js:8904-8907`）通过。
- 自测期间 C 盘 profile 未更新：`%APPDATA%\敏捷工作台` 最新 02:33:40，`%APPDATA%\Electron` 16:46:43，`%LOCALAPPDATA%\electron\Cache` 01:56:34，均早于本轮 19:54 起跑。
- 真实 `data/` 19:15:17、真实 `团队/状态` 19:05:17，自测没有碰。

**产品约束：不是硬编码 D。** `DATA_ROOT` 跟随仓库位置（`src/main.js:15-22`），把程序放到 C 盘就会写 C；本次能全落 D 是因为程序本身在 D。另有只读依赖：`src/dsh-adapter.js:18-27` 从 `DSH_HOME`（默认 `C:\Users\<user>\.dsh`）读 `.credentials.yaml`，纯 D 盘机器会缺 DSH 认证材料。这两点是既有边界，不是本轮新问题。

---

## 4. 问题清单

### P1-1 Owner 确认的 `actor` / `confirmation` 被壳层覆盖丢失

**现象**：旧命令已经把 `actor: 'owner'`、`confirmation: { channel, at, nonceHash }` 写进 `工作流.json`，壳层随后用不含这两个字段的对象覆盖；界面重启后显示 `actor=记录人未认证`。

**证据**

- 旧工具写入：`团队/工具/lib/workflow.mjs:1269-1270`、`:1303-1306`；`confirmationMeta` 见 `:1235-1239`。
- 壳层覆盖：`src/team-tools.js:4490`、`:4502-4511`、`:5715`、`:5725`。
- 探针落盘对比：`_tmp/qa-final-20261105/probe-legacy-工作流.json` vs `probe-legacy-任务.json`（后者有 `actor` 与 `nonceHash`，前者没有）。
- 界面兜底：`src/renderer/app.js:6589-6592`（`actor=记录人未认证`）、`:83`、`:5793`（内存常量 `OWNER_CONFIRM_ACTOR='owner'`）。
- `owner:confirm` 不落 actor：`src/main.js:4047-4097`。

**影响**：最终闸门的“确认”证据不进入唯一真相；审计/看板/UI 无法区分“Owner 确认过”和“调用方自报 by=Owner”。这正是上一轮 `MVP-ROUND3-BLOCKERS.md` P0-2 要求补的身份材料。

**最小修法**：壳层改成合并而不是覆盖，至少保留旧命令写回的字段：

```js
row.ownerReview = { ...(row.ownerReview || {}), status: decision, by: 'Owner', at, opinion, source: 'team.mjs owner', command: 'owner' };
row.acceptance  = { ...(row.acceptance  || {}), status: decision, by: role, at, opinion };
```

顶层 `state.ownerReview` 同样合并；或让 IPC 把 `confirmToken` 的 `nonceHash/channel/expiry` 交给 team-tools 写进记录。

### P2-1 需求正文「状态记录」里的非条目文字会被壳层删除

**现象**：壳层 `rewriteRequirementStatusRecords` 只收集能匹配 `- <ISO> <status>：<note>` 的行，其余行静默丢弃；验收/终止时会把需求正文里手写在状态记录中的说明删掉。

**证据**

- 壳层：`src/team-tools.js:4588-4592`（只 push 可解析行）、`:4595-4614`（重建章节时只写 `unique`）。
- 旧工具对照：`团队/工具/lib/workflow.mjs:616`（注释明确“非条目正文也保留，避免吞掉手写说明”）、`:648`（`if (!meta) { kept.push(line); continue; }`）。
- 探针：`probe-manual` 在 `## 状态记录` 放一行“手工说明：这一行不是程序写的，验收后不应被删。”，走完验收后该行消失，`sections=1`、只剩 3 条程序记录（`_tmp/qa-final-20261105/probe-manual.json`，`tailMatch=false`）。

**影响**：静默删除正文内容，且无备份；只在“状态记录里有人工文字 + 验收/终止”时触发，但一旦触发不可恢复。

**最小修法**：沿用旧工具的合并策略——只删除重复的“条目行”，非条目行原样保留；或删章节前先把非条目行搬到保留章节。

### P2-2 存量索引 / 状态记录未迁移

**现象**：代码已修，但三个既有项目仍是旧格式，打开/启动都不会自愈。

**证据**

| 对象 | 现状 | 生成/写入 |
|---|---|---|
| `MVP验收-20261105-1705/项目索引.json` | 3 行，2 条记录 | 09:05:34Z |
| `UI验收-20261105-1745/项目索引.json` | 3 行，2 条记录 | 09:58:59Z |
| `UI闭环-20261105-1852/项目索引.json` | 4 行，3 条记录 | 11:05:16Z |
| 三个项目的需求正文 | 各 2 个 `## 状态记录`、2 条 accepted | 09:05–11:03Z |

以上都早于修复文件 `ops.mjs`（11:26:33Z）/`team-tools.js`（11:26:15Z）。`ensureProjectStructure` 只在索引缺失时才跑 index（`src/team-tools.js:3061`），`bootRole` 不会整理旧正文；因此只有下一次需求动作或手工 `team.mjs index` 才会合并/重写。探针 `probe-heal` 证明刷新确实能修（2/2 → 1/1）。

**影响**：角色按 `项目索引.md` 找需求时会看到 3–4 行同号记录；JSON 的 `requirements` 计数错误。界面显示层已过滤（`app.js:5028-5063`），所以普通用户点开文档页看到的是对的，但文件与“先读索引”的流程仍是错的。

**修法**：在项目打开或首次 boot 时做一次幂等迁移（`team.mjs index` 即可，既会重写索引也会 `normalizeRequirementDocs`），或发布前对这三个项目各跑一次并记录。纯读 QA 没有替用户执行。

### P2-3 `.gitignore` 漏 `团队/看板.json`、`团队/看板.png`

**现象**：同目录的 `看板.html`、`看板.md` 已按“团队运行态”忽略，`看板.json`、`看板.png` 没有；它们含 owner 姓名、私有项目名与绝对路径。

**证据**

- `.gitignore:8-12` 只列了 `团队/状态/`、`团队/日志/`、`团队/看板.html`、`团队/看板.md`。
- `团队/看板.json`：48,062 B，19:05:17；`owner: 徐野风`、`activeProject: UI闭环-20261105-1852`、9 个项目名、`D:\deepseek\agile-workbench\项目\…` 路径。
- `团队/看板.png`：1424×935，画面含“团队看板 · 测试工作台项目”“负责人 徐野风”。
- 生成侧：`src/team-tools.js:1248-1250` 每次生成看板后把 `状态/看板.json` 复制到团队根；`看板.png` 是 11-03 留下的截图。

**影响**：`package.json` 的 `files` 不含它们，`npm pack`/导出安全；但 `.gitignore` 是给 git 的，当前 `git add .` 会把私有运行态收进仓库。

**修法**：在 `.gitignore` 的“团队运行态”段加 `团队/看板.json`、`团队/看板.png`（或直接 `团队/看板.*`，已有 html/md 可合并）；如 `看板.png` 是刻意保留的文档图，改名放 `docs/` 并脱敏。

### P3-1 `npm pack` 与 `export-open-source` 产物不一致：白名单文件仍含 `D:\deepseek\…`

**现象**：`files` 白名单只排除了目录，没有处理文件内容；5 个会进 npm 包的文件仍带作者本机绝对路径。

**证据**

```text
团队/工具/工作流命令.md:186  node 团队\工具\team.mjs selftest --tmp D:\deepseek\agile-workbench\_tmp
团队/模板/启动卡.md:6        工作区 D:\deepseek\工作台
团队/协议/01-会话与必读.md:5  同一工作区（D:\deepseek\工作台）
团队/协议/06-风险重启扩编.md:63  --workspace "D:\deepseek\工作台"
团队/工具/workspace.mjs:3      // 用法：… [--root D:\deepseek\工作台\项目]
```

`npm pack` 列表包含这些文件（`_tmp/qa-final-20261105/pack.json`）；导出脚本 `scripts/export-open-source.mjs:69-78` 会把 `D:\deepseek\…` 替换成 `<repo>/<workspace>/<dsh-root>`，所以 **export 产物干净、npm pack 不干净**，两个交付通道不一致。

**影响**：若有人用 `npm pack`/`npm publish` 交付，会把作者本机路径带出去；`npm pack --dry-run` 是 README 里写的预览方式，容易被当成可交付物。

**修法**：优先直接把示例路径改成 `<repo>` / `<workspace>` 占位（这样 export 的 sanitize 只作兜底）；或在 `package.json` 加 `prepack` 跑同一套 sanitize 并扫描。

---

## 5. 已复核、未发现问题的部分

- 产品评审 / Owner 决定 / Owner 验收的 `history` 与 `events` 各只写一次；自测 `auditCounts` 断言全过，未发现新的审计双写。
- 评审 / Owner / 验收后都会刷新索引；`projectIndex.ok=true`（自测 7916、7934、7988 通过）。
- 4 位旧需求号可读、可进工作流扫描、可补任务/工作流行；`REQ_FILE_RE` 已放宽到 4–8 位（`src/team-tools.js:3322-3323`）。
- Owner pending 不写 `by/actor`（自测 8559-8570 通过）；确认闸门在四个 IPC 上一致。
- 索引显示层过滤（`app.js:5028-5063`）与状态记录显示层去重（`:5078-5116`）行为正确，不回写文件。
- `.gitignore` 的私有项目、临时、备份、凭据段覆盖：`项目/`、`_tmp/`、`_backup/`、`_archive/`、`data/`、`userdata*/`、`.selftest-data/`、`probe-receipts/`、`团队/状态/`、`团队/日志/`、`.env*`、`config.local*.json`、`credentials.json`、`*.key`、`*.pem`、`.dsh/`、`dsh-home/`。

## 6. 边界与披露

- **`ELECTRON_RUN_AS_NODE`**：本会话 shell 默认带 `ELECTRON_RUN_AS_NODE=1`，第一次直接跑 Electron 会在 `src/main.js:82` 的 `app.setPath` 崩；`start.cmd:7` 本来会清掉。清掉后 `npm run selftest` 退出码 0、`SELFTEST_OK`。这不是产品缺陷，但复现时容易踩。
- **`npm run check` 只是 `node --check`**：5 个文件的语法检查，不覆盖行为；本报告的结论主要来自源码审计、自测与隔离探针。
- **自测用 mock DSH**：`SELFTEST_DSH` 的 `baseUrl` 是本地 mock 端口；真实 DSH 路径不在本轮证据链内。自测写 `.selftest-data`，真实 `data/`、`团队/状态` 未被改动（mtime 已核对）。
- **探针写 C 盘 `%TEMP%`**：4 个探针的沙盘与日志在 `%TEMP%\qa-probe`（C 盘），是 QA 产物，不是应用数据；应用自身 `userData/temp` 在 D。期间 `%TEMP%` 出现 1 个 0 字节、被占用、无法归属的 `.tmp`（20:02:26），与本报告的应用路径无关。
- **D 盘依赖**：`DATA_ROOT` 跟随仓库（非硬编码 D）；DSH 凭据默认从 `C:\Users\<user>\.dsh` 只读加载（`src/dsh-adapter.js:18-27`）。纯 D 盘机器需要另配 `DSH_HOME`。
- **未改源码**：本轮没有对 `src/**`、`package.json`、`团队/**`、真实 `项目/**` 做任何写入；新增文件只有 `docs/QA-FINAL.md`、`_tmp/qa-final-20261105/**`。

## 7. 建议处理顺序

1. **P1-1**：先修壳层覆盖，保住 `actor` / `confirmation`（这是最终闸门的证据）。
2. **P2-1**：改成“只删重复条目、保留人工行”，与旧工具对齐。
3. **P2-2**：对三个存量项目各跑一次 `team.mjs index`（或加打开时迁移），清掉索引与正文的旧格式。
4. **P2-3**：补 `.gitignore` 两条，确认 `看板.png` 是否还需要保留。
5. **P3-1**：清掉白名单文件里的绝对路径，或在 `prepack` 里复用 sanitize。

修完后重跑 `npm run check` + `npm run selftest`，并复跑 `_tmp/qa-final-20261105/` 的四个探针（尤其 `probe-legacy` 的 `工作流.json` 应出现 `actor` / `confirmation`，`probe-manual` 的手写行应保留）。
