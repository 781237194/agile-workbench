# QA-INSTALLER-NODE · 安装器 Node.js 自动准备与 README 一键命令

- 仓库：`D:\deepseek\agile-workbench`（D 盘）
- 时间：2026-11-06 21:01–21:16（Asia/Shanghai）
- 被测快照：`HEAD 0079e40` + 工作区未提交改动
  - `install.ps1` 56,553 B `1B4294254B6D10D489E035D2937E94DBA96EC5A56BDA34CB2A1C557C5A92F8C4`
  - `README.md` 17,295 B `B78737FC4D2DF735CC34DECB0030B18BD5ECBCD7E39F3787E9A6FE62695DEB94`
  - `安装PM工作台.cmd` 1,355 B `ADDD08AB9913837C94EAB0AD7B8859EFCF9E357EEF953CDBF8B85AAA9C3A9B5E`
  - `git status --short`：`M README.md`、`M install.ps1`。Node 自动下载与 README 一键段都**尚未提交**；`origin/main` 仍是 `0079e40`。
- 方式：只读源码审计 + Windows PowerShell 5.1 隔离 fixture 实测（有系统 Node / 无 Node / 官方源失败 / 断网 / 坏便携目录 / 外来目标 / 公开 main 旧安装器）+ 公开 main 三入口实测 + `npm run check` / `npm run test:scripts` / `npm pack --dry-run`
- 边界：**未修改仓库的** `src/**`、`install.ps1`、`README.md`、`package.json`、真实 `data/**`、`团队/状态/**`；**未写** `D:\PM工作台`。本轮只写本文档与 `_tmp/qa-installer-node-20261106/**`。fixture 的 `package.json` 去掉了 `devDependencies` 以避免下载 Electron，因此 Electron 的真实安装不在本轮证据内。

## 0. 一句话结论

**安装器本体的 Node 主路径 PASS；README 一键命令 FAIL（发布阻断）。**

工作区版安装器在无 Node 时会自动下载 v26.13.0 便携版并实际运行 node/npm，有 Node 时直接用系统 v24.22.1，失败输出可读，四组数据哨兵哈希全程不变；官方源失败也能回退 npmmirror。问题在“给朋友的一键入口”：

1. 公开 `main` 仍是旧安装器（34,109 B，无 `Get-NodeLtsRelease`），工作区 README 的三个入口都落回这份 main，拿不到本轮的新行为；无 Node 机器上旧安装器直接 `[缺少] Node.js（必须）` 并退出 1。
2. 工作区 README 入口 2 把 raw URL 换成了 jsdelivr；jsdelivr 以 `application/octet-stream` 返回，Windows 自带 PowerShell 5.1 把 UTF-8 BOM 解成 `ï»¿`，`-replace "^\uFEFF"` 匹配不到，`iex` 得到 **8 个语法错误**，安装根本不会开始。即使把新安装器推上 main，这条命令仍然坏。

## 1. 验收表

| # | 验收项 | 结论 | 关键证据 |
|---|---|---|---|
| 1 | 无 Node 自动下载 | **PASS（工作区安装器）** | PATH 置空后自动下载 `node-v26.13.0-win-x64.zip`（39.3 MB），SHA-256 通过，落地 `.runtime\node`，`node --version=v26.13.0`、`npm 11.20.0`，安装 exit 0；耗时 102.7 s |
| 2 | 有 Node 使用系统 | **PASS** | 系统 `v24.22.1` / npm `11.19.1`（`D:\Program Files\nodejs\node.exe`）被直接使用；日志“不下载便携版”，`.runtime\node` 不存在 |
| 3 | 失败可读 | **PASS** | 断网时 exit 1，中文写明官方/镜像两路失败、手动安装链接、日志路径；无半截 node.exe。坏便携目录也有原因和“先移走再重跑”的操作指引 |
| 4 | 不覆盖数据 | **PASS** | `data/dsh.json`、`data/userdata-keep.txt`、`项目/alpha/keep.txt`、`团队/状态/keep.json` 四组哨兵在系统 Node、无 Node、重复执行、坏便携、断网五种路径下 `CHANGED=0`；外来目标目录文件原样保留 |
| 5 | README 一键命令可用 | **FAIL（发布阻断）** | 工作区 README 的入口 1/3 落回公开 main 的旧安装器；入口 2 在 PowerShell 5.1 下 8 个解析错误，`iex` 无法执行；详见 §3.6、P0-1、P0-2 |
| 5a | 入口 1：本地 `安装PM工作台.cmd` | **PASS（仅工作区）** | `cmd /c 安装PM工作台.cmd -Help` exit 0，帮助含“Node.js 不需要预装”；公开 main 的 zip 里仍是旧 `install.ps1` |
| 5b | 入口 2：jsdelivr 一行命令 | **FAIL** | `Content-Type=application/octet-stream`；`Invoke-RestMethod` 返回首字符 `239,187,191`；`-replace "^\uFEFF"` 无效；`ParseInput` 8 个错误；`[scriptblock]::Create` 失败 |
| 5c | 入口 3：GitHub main zip | **FAIL（当前发布态）** | zip 内 `install.ps1` 34,109 B `6936D53B…C8A3EE`，无 `Get-NodeLtsRelease`；无 Node 运行 exit 1，提示“本安装器不会自动安装任何系统软件” |
| 6 | 官方源失败 → npmmirror 回退 | **PASS** | 选择性代理只阻断 nodejs.org，安装器改读 npmmirror 索引并下载 v26.13.0，exit 0；注意该路径没有拿到 SHA-256（见 P3-2） |
| 7 | 重复执行 / 复用 | **PASS** | 系统 Node 重跑：exit 0、仍用系统 Node、`CHANGED=0`；便携 Node 重跑：日志“使用已有的便携 Node.js v26.13.0，不重复下载”、`CHANGED=0` |
| 8 | 系统 Node 优先于已有便携版 | **PASS** | 同一仓库已有 v26.13.0 便携版时，带系统 PATH 重跑仍选系统 v24.22.1，不碰 `.runtime\node` |
| 9 | 坏便携目录不被覆盖 | **PASS** | 预置假 `.runtime\node\node.exe`：exit 1，明确“安装器不会覆盖它”，假文件哈希不变，未触发下载 |
| 10 | 外来目标目录不被覆盖 | **PASS** | `-InstallDir` 指向含 `user-file.txt=USER-DATA` 的非 PM 目录：exit 1，文件内容不变，目录仍只有 1 个文件 |
| 11 | 项目自检 / 打包 | **PASS** | `npm run check` exit 0；`npm run test:scripts` `SCRIPTS_OK 12/12`；`npm pack --dry-run` 60 files / 716.2 kB，含 `install.ps1` 56.6 kB |

> 结论口径：**安装器 Node 功能可放行**；**README 一键入口不可放行**。第 1 项 PASS 只代表工作区里的 `install.ps1`，不代表朋友按 README 拿到的安装器。

## 2. 被测快照与静态定位

### 2.1 文件与编码

| 文件 | 大小 | 首 3 字节 | 说明 |
|---|---:|---|---|
| `install.ps1` | 56,553 B | `EF BB BF` | UTF-8 BOM，`test:scripts` 明确要求 |
| `README.md` | 17,295 B | `23 20 50`（`# P`） | 无 BOM；入口 2 在 `README.md:97-101` |
| `安装PM工作台.cmd` | 1,355 B | `40 65 63`（`@ec`） | 无 BOM、CRLF，`test:scripts` 明确要求 |

### 2.2 Node 相关代码位置

| 位置 | 作用 |
|---|---|
| `install.ps1:289-342` | `Test-NodeRuntime`：`node --version` 必须 ≥20，再在同目录 / PATH 找可运行的 npm |
| `install.ps1:344-389` | `Get-SystemNodeRuntime`：PATH 的 `node`，加 `%ProgramFiles%\nodejs`、`%ProgramFiles(x86)%\nodejs`、`%LOCALAPPDATA%\Programs\nodejs`；跳过 `WindowsApps` 商店占位 |
| `install.ps1:391-441` | `Get-NodeLtsRelease`：读 nodejs.org 官方 `index.json`，失败再读 npmmirror |
| `install.ps1:443-466` | `Get-NodeChecksum`：从 `SHASUMS256.txt` 取对应 zip 的 SHA-256 |
| `install.ps1:484-539` | `Save-NodeDownload`：大小 ≥1 MB、zip 头 `PK`、可选 SHA-256；单源最多 2 次，双源时各 1 次 |
| `install.ps1:552-702` | `Install-PortableNode`：剩余空间、解压、node/npm 实跑、版本相等、`Directory.Move`、失败清理 |
| `install.ps1:704-771` | `Initialize-NodeRuntime`：系统 Node → 已有 `.runtime\node` → 下载；已有坏目录直接报错不覆盖 |
| `install.ps1:1119-1180` | 主流程 step 2–4：环境检查、准备源码、准备 Node |
| `install.ps1:1228-1234` | `npm install` 后找不到 Electron 只 `WARN`，不中断 |
| `install.ps1:1310-1332` | 失败汇总：原因、处理步骤、日志路径、`Remove-IncompleteTarget` |
| `install.ps1:1341-1354` | 失败暂停与 `exit $script:ExitCode` |

### 2.3 工作区与公开 main 的差异

| 项 | 工作区 | 公开 `origin/main` / jsdelivr / main zip |
|---|---|---|
| `install.ps1` | 56,553 B，含 `Get-NodeLtsRelease` / `Install-PortableNode` | 34,109 B，`Get-NodeLtsRelease` 命中 0，含 `[缺少] Node.js（必须）` |
| `README.md` | 17,295 B，写“Node.js 会自动装” | zip 内 15,928 B，无 Node 自动安装表述 |
| 无 Node 行为 | 自动下载 v26.13.0 | exit 1，`[缺少] Node.js（必须）`，明确“不会自动安装任何系统软件” |

## 3. 实测记录

所有 fixture 在 `_tmp/qa-installer-node-20261106/`。fixture 的 `package.json` 保留 `name=pm-workbench` / `start.cmd` / `src\main.js`，去掉 `devDependencies`，让 `npm install` 只验证 Node/npm 链路，不下载 Electron。

### 3.1 有 Node：直接使用系统 Node

fixture：`repo-system`，四个数据哨兵，PATH 保持正常。

```text
[21:05:36] OK  系统 Node.js v24.22.1（npm 11.19.1）：D:\Program Files\nodejs\node.exe
[21:05:36] OK  使用系统 Node.js v24.22.1（npm 11.19.1），不下载便携版
  Node.js：v24.22.1（使用系统 Node，不下载）
...
EXIT=0
RUNTIME_NODE_EXISTS=False
data\dsh.json CHANGED=0
data\userdata-keep.txt CHANGED=0
项目\alpha\keep.txt CHANGED=0
团队\状态\keep.json CHANGED=0
USER_PATH_CHANGED=0
MACHINE_PATH_CHANGED=0
PM_TARGET_CREATED=0
```

优先顺序复验：在 `repo-nonode`（已有 v26.13.0 便携版）上恢复系统 PATH 重跑，仍然打印“使用系统 Node.js v24.22.1”，说明系统 Node 优先于已有便携版，符合 README。

### 3.2 无 Node：自动下载便携 Node 并实跑

fixture：`repo-nonode`；子进程 PATH 只保留 `System32 / Windows / Wbem / WindowsPowerShell`，`Get-Command node` 与 `npm.cmd` 均为空；`%ProgramFiles%\nodejs`、`%ProgramFiles(x86)%\nodejs`、`%LOCALAPPDATA%\Programs\nodejs` 均无 `node.exe`。

```text
[21:05:47] WARN  没有可用的系统 Node.js 20+：未检测到 node
[21:05:47] INFO  安装时会自动下载 Windows x64 便携 Node.js LTS，不写系统 PATH。
[21:05:52] OK  Node.js LTS：v26.13.0（来自 nodejs.org 官方）
[21:05:52] INFO  下载地址：https://nodejs.org/dist/v26.13.0/node-v26.13.0-win-x64.zip
[21:05:52] INFO  下载地址：https://npmmirror.com/mirrors/node/v26.13.0/node-v26.13.0-win-x64.zip
[21:07:21] OK  SHA-256 校验通过
[21:07:21] OK  下载完成：39.3 MB
[21:07:26] OK  便携 Node.js 已就位：...\.runtime\node（v26.13.0，npm 11.20.0）
...
EXIT=0  DURATION_S=102.7
RUNTIME_NODE_EXISTS=True
RUNTIME_NODE_VERSION=v26.13.0
RUNTIME_NPM_EXISTS=True
data\dsh.json CHANGED=0
data\userdata-keep.txt CHANGED=0
项目\alpha\keep.txt CHANGED=0
团队\状态\keep.json CHANGED=0
USER_PATH_CHANGED=0
MACHINE_PATH_CHANGED=0
DOWNLOADS_DIR_LEFT=False
STAGING_DIRS_LEFT=0
```

补充：实测解压后 `.runtime\node` 为 **1,938 个文件 / 107.7 MB**，与 README 的“解压约 110 MB”一致。下载的 zip 在 `finally` 中删除，`downloads/` 与 staging 目录均未残留。

> 口径说明：本机系统 Node 实际在 `D:\Program Files\nodejs`，而 `$env:ProgramFiles` 是 `C:\Program Files`；PATH 置空后安装器的三个默认 fallback 路径都找不到它，因此这次测试等价于“安装器视角的无 Node”。真正全新机器同样没有 node.exe，走的也是这条分支。

### 3.3 官方源失败：npmmirror 回退

fixture：`repo-mirror`；用 `WebProxy('http://127.0.0.1:1')` + bypass `.*npmmirror\.com.*`，只阻断 nodejs.org。

```text
[21:12:03] RUN  读取 Node.js LTS 版本列表：nodejs.org 官方
[21:12:05] WARN  读取失败（nodejs.org 官方）：无法连接到远程服务器
[21:12:05] RUN  读取 Node.js LTS 版本列表：npmmirror 镜像
[21:12:05] OK  Node.js LTS：v26.13.0（来自 npmmirror 镜像）
[21:12:05] INFO  下载地址：https://npmmirror.com/mirrors/node/v26.13.0/node-v26.13.0-win-x64.zip
[21:12:06] WARN  无法获取 SHA-256 校验文件（...SHASUMS256.txt）：远程服务器返回错误: (404) 未找到。
[21:12:12] WARN  没有拿到官方校验值，已用 zip 文件头与可运行性校验兜底
[21:12:30] OK  便携 Node.js 已就位：...（v26.13.0，npm 11.20.0）
EXIT=0  DURATION_S=31
NODE_EXE=True  NODE_VERSION=v26.13.0
data\dsh.json CHANGED=0 ...
```

回退可用，但该路径**没有校验 SHA-256**；见 P3-2。

### 3.4 失败可读

fixture：`repo-fail`；`DefaultWebProxy=http://127.0.0.1:1` 同时阻断官方与镜像；无系统 Node。

```text
[21:08:09] WARN  没有可用的系统 Node.js 20+：未检测到 node
[21:08:09] RUN  读取 Node.js LTS 版本列表：nodejs.org 官方
[21:08:11] WARN  读取失败（nodejs.org 官方）：无法连接到远程服务器
[21:08:11] RUN  读取 Node.js LTS 版本列表：npmmirror 镜像
[21:08:13] WARN  读取失败（npmmirror 镜像）：无法连接到远程服务器

  [Node.js 自动安装失败] 无法获取 Node.js LTS 下载信息。
  nodejs.org 官方：无法连接到远程服务器
npmmirror 镜像：无法连接到远程服务器
请检查网络或代理后重试。
  安装器优先使用系统 Node.js 20+；没有时自动下载 Windows x64 便携版。
  也可以手动安装 Node.js LTS（20 或更高，自带 npm）后重跑：
    https://nodejs.org/zh-cn/download
  国内镜像：
    https://npmmirror.com/mirrors/node/
  手动安装不会覆盖已有项目和数据；下次运行会优先使用系统 Node。

============================================================
  安装未完成
============================================================
  原因：自动准备 Node.js 失败（没有修改系统环境，也没有覆盖已有 Node）。
  ...
  5. 把下面的日志发给作者/朋友排查
       ...\run-fail\install-20261106-210809.log
EXIT=1  DURATION_S=6.5
RUNTIME_DIR_EXISTS=True（空目录，0 个文件）
data\dsh.json CHANGED=0 ...
LOG_FILES=1
```

坏便携目录：`repo-broken-portable` 预置 `.runtime\node\node.exe` 内容 `NOT-A-REAL-NODE`，PATH 无 Node：

```text
原因：已有便携 Node 目录不可用，安装器不会覆盖它：...\.runtime\node
  原因：node 无法运行：...\.runtime\node\node.exe
如需重装，请先手动把该目录移走（例如改名为 node.broken），再重跑安装器。
EXIT=1
FAKE_NODE_CHANGED=0
RUNTIME_NODE_FILES=1
DOWNLOADED_ZIP_LEFT=0
data\dsh.json CHANGED=0 ...
NodeReleasesRead=False
```

结论：失败路径有具体原因、下一步操作和日志路径，exit 非 0；不会把坏目录当成可复用的 Node，也不会先下载再覆盖。

### 3.5 不覆盖数据 / 不覆盖目标

| 场景 | 结果 |
|---|---|
| `repo-system` 第 1 次 | exit 0；四组哨兵 `CHANGED=0` |
| `repo-system` 第 2 次 | exit 0；“当前目录就是仓库”，仍用系统 Node；`CHANGED=0` |
| `repo-nonode` 第 2 次 | exit 0；“使用已有的便携 Node.js v26.13.0，不重复下载”；`CHANGED=0` |
| `repo-nonode` + 系统 PATH | exit 0；系统 Node 优先；`CHANGED=0` |
| `foreign-target`（非 PM 且非空） | exit 1；`user-file.txt=USER-DATA` 哈希不变，目录仍只有 1 个文件，未创建 `.runtime`，未进入 Node 步骤 |
| `repo-broken-portable` | exit 1；假 `node.exe` 哈希不变，未下载 |
| 系统 PATH | 安装前后 `User` / `Machine` PATH 均未变化 |
| 默认目标 | 未创建 `D:\PM工作台` |

### 3.6 README 一键入口（本轮的主要失败）

#### 3.6.1 入口 1：本地 cmd 包装器

```text
cmd /c 安装PM工作台.cmd -Help → EXIT=0
帮助含“Node.js 不需要预装：优先使用系统 Node.js 20+；没有时自动下载 ...”
```

本地工作区入口 1 的调用链正常；但公开 main 的 zip 里 `安装PM工作台.cmd` 调用的是旧的 34,109 B `install.ps1`（见 3.6.3）。

#### 3.6.2 入口 2：工作区 README 的一行命令在 PowerShell 5.1 下直接语法失败

工作区 README（未提交版）`README.md:100` 的原文：

```powershell
iex ((irm https://cdn.jsdelivr.net/gh/781237194/agile-workbench@main/install.ps1) -replace "^\uFEFF", "")
```

在 Windows 自带 PowerShell **5.1.19041.6456** 中按同一表达式复现：

```text
jsdelivr:
  Content-Type = application/octet-stream
  CHARS = 34109
  FIRST = 239,187,191        # 即 "ï»¿"，UTF-8 BOM 被按 Latin-1 解码
  EXACT_PARSE_ERRORS = 8
  SCRIPTBLOCK_OK = False
  首条错误：At line:7 char:8 Unexpected token 'æ£æŸ¥' ...

raw.githubusercontent.com（同样是 main 的旧文件）:
  Content-Type = text/plain; charset=utf-8
  CHARS = 29673
  FIRST = 60,35,10           # "<#\n"，正确 UTF-8 解码
  PARSE_ERRORS = 0

把 jsdelivr 文本去掉前 3 个字符后再解析:
  PARSE_ERRORS = 0
  SCRIPTBLOCK_OK = True
  HEAD = <#
```

原因链是确定的：jsdelivr 对 `.ps1` 返回 `application/octet-stream`，PowerShell 5.1 的 `Invoke-RestMethod` 按 Latin-1 解码，UTF-8 BOM 变成三个可见字符 `ï»¿`；`-replace "^\uFEFF"` 匹配的是 U+FEFF，匹配不到 `ï»¿`；`iex` 看到 `ï»¿<#`，帮助块不再是注释，第 7 行起的中文注释被当代码，产生 8 个语法错误。**这不是“旧版脚本内容问题”，而是入口 2 的取回/解码问题，推上新安装器后仍会发生。**

补充：旧的 `HEAD` README 用的是 `raw.githubusercontent.com`；工作区这次把 URL 换成 jsdelivr 后，`-replace` 的 BOM 处理就失效了。diff 里这一行同时保留了“去掉 GitHub raw 返回的 UTF-8 BOM”的注释，注释与 URL 已经不匹配。

#### 3.6.3 入口 3：公开 main 的 zip 仍是旧安装器

```text
main.zip:
  bytes = 756,118
  sha256 = 2BB031B5E151C5C79F2119DCCBD26474C767BE4BC4373DE17F9A6ECD317FC6E2
  root = agile-workbench-main
  install.ps1 = 34,109 B, sha256 6936D53B307E5AD7F89A9F2CADD0486F7A28CAFD3576A2791FFC2902A0C8A3EE
  ZIP_HAS_NODE_AUTODOWNLOAD = False
  ZIP_HAS_OLD_NODE_REQUIRED = True
  README.md = 15,928 B, ZIP_README_HAS_NODE_AUTO = False
```

用这份 zip 的旧安装器在无 Node fixture 上运行：

```text
[1/6] 检查运行环境
  [缺少] Node.js（必须）
  PM工作台由 Node.js + Electron 运行，要求 Node.js 20 或更高版本（安装包自带 npm）。
  ...
  本安装器不会自动安装任何系统软件。
EXIT=1
RUNTIME_EXISTS=False
data\dsh.json CHANGED=0 ...
PM_TARGET_CREATED=False
```

即：工作区 README 的入口 1（clone/下载 main）和入口 3（main zip）都落回“没有 Node 就停”的旧安装器；入口 2 则先因 BOM 解码报语法错误。三条路都没有兑现工作区 README 的“Node.js 会自动装”。

### 3.7 项目自检与打包

```text
npm run check          → CHECK_EXIT=0
npm run test:scripts   → SCRIPTS_OK 12/12, SCRIPTS_EXIT=0
npm pack --dry-run     → 60 files, package size 716.2 kB
                         含 install.ps1 56.6 kB、安装PM工作台.cmd 1.4 kB、README.md 17.3 kB
```

`test:scripts` 本轮只断言 `install.ps1` 是 UTF-8 BOM、cmd 无 BOM + CRLF、白名单包含两文件；**没有**覆盖“入口 2 在 PowerShell 5.1 下能否解析/执行”，所以 12/12 不能证明 README 一键命令可用。

## 4. 问题清单

### P0-1（发布阻断，工作区未提交版）：README 入口 2 在 Windows PowerShell 5.1 下语法失败

- 位置：工作区 `README.md:97-101`，命令在 `README.md:100`（公开 main 的 README 尚未包含这次 jsdelivr 改动）。
- 现象：jsdelivr 返回 `application/octet-stream`；`irm` 得到首字符 `239,187,191`（`ï»¿`）；`-replace "^\uFEFF"` 无效；`iex` 解析 8 个错误，安装不开始。
- 证据：§3.6.2；同一文件走 raw（`text/plain; charset=utf-8`）时 0 个解析错误；jsdelivr 文本去掉前 3 字符后 0 个解析错误。
- 影响：当前工作区 README 若原样推送，入口 2 对默认 Windows PowerShell 5.1 用户**完全不可用**；换到新安装器后仍失败，属于独立于 P0-2 的发布阻断。公开 main 现在的 README 仍用 raw（可解析，但装的是旧安装器）。
- 修复（任选其一，建议 A）：
  - A. 按字节取回再按 UTF-8 解码，不依赖 `Content-Type`：

    ```powershell
    $r = Invoke-WebRequest -UseBasicParsing 'https://cdn.jsdelivr.net/gh/781237194/agile-workbench@main/install.ps1'
    $s = [System.Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
    iex ($s -replace "^\uFEFF", "")
    ```

    本轮已验证这条路径 0 个解析错误（`RawContentStream` 与 `WebClient.DownloadData` 两种取字节方式均通过）。
  - B. 改回 `raw.githubusercontent.com`（本轮 0 个解析错误）。这次 README 把 raw 换成 jsdelivr，若动机是可达性，换回前要先确认目标网络；若坚持 jsdelivr，用 A 方案按字节解码。
  - C. 保留 jsdelivr，但先做 mojibake 修复再 `iex`（不推荐，逻辑更绕）。
- 同时修改：
  - 把“去掉 GitHub raw 返回的 UTF-8 BOM”的注释改成与 URL 一致的说明；
  - 增加一个 PowerShell 5.1 冒烟测试：取回后 `[System.Management.Automation.Language.Parser]::ParseInput` 必须 0 错误，并断言文本含 `Get-NodeLtsRelease`；
  - 注意 jsdelivr `@main` 有缓存，推送到 main 后要确认 CDN 已刷新（必要时用 commit hash 或加版本查询参数），否则仍可能返回旧文件。

### P0-2（发布阻断）：公开 main 仍是旧安装器，工作区 README 的入口 1/3 都落回旧行为

- 位置：仓库状态与公开 `main`；不是某一行代码。
- 现象：`HEAD` / `origin/main` 都是 `0079e40`；工作区 `M install.ps1`、`M README.md` 未提交。jsdelivr / raw / main zip 三处取回的是同一份旧文件（zip 为 34,109 B，SHA `6936D53B…C8A3EE`；raw 解码后 29,673 字符），没有 `Get-NodeLtsRelease` / `Install-PortableNode`，且含 `[缺少] Node.js（必须）`。
- 证据：§2.3、§3.6.3；公开旧安装器在无 Node 机器上 exit 1，并明确“本安装器不会自动安装任何系统软件”。
- 影响：工作区 README 的核心承诺“只需要 Windows + 网络 + DSH，Node.js 会自动装”在公开仓库没有对应实现；若只推 README 不推 `install.ps1`，承诺就是假的。朋友按公开 main 的入口 1/3 安装会在第一步被 Node 拦住；工作区里的 56,553 B 新安装器只对拿到本地工作区的人有效。
- 修复：
  1. 提交并推送 `install.ps1`、`README.md`、`安装PM工作台.cmd`（cmd 本轮未改，但要确保与 `install.ps1` 同批发布）；
  2. 推送后在干净临时目录分别按入口 1/2/3 复跑；
  3. 验收断言：取回的 `install.ps1` 内容含 `Get-NodeLtsRelease`（本地工作区为 56,553 B / SHA-256 `1B429425…5A92F8C4`；远端字节可能因换行策略略有差异，以内容断言为准），无 Node 时能下载 v26.13.0 并 exit 0；
  4. 已安装的旧 `D:\PM工作台` 不会被自动升级（安装器对已有目录只 `npm install`），需要单独说明或另做更新路径；这不算本轮 Node 功能缺陷，但会影响老用户拿到修复。

### P2-1（沿用上一轮 P2-1，仍未修复）：Electron 缺失时安装器仍 exit 0 并打印“安装完成”

- 位置：`install.ps1:1228-1234`。
- 现象：`npm install` 退出 0 但 `node_modules\electron\dist\electron.exe` 不存在时，只 `WARN 没有找到 Electron`，摘要仍显示“安装完成”，exit 0。
- 证据：本轮所有 fixture 的 `npm install` 都因去掉 devDependencies 而 exit 0，安装器均打印“安装完成”；随后 `start.cmd --check` 在 `repo-system` 返回 `START_CHECK_EXIT=1`，提示“没有找到 Electron…请先 npm install”。
- 影响：用户在“一键安装”里看到成功，实际启动失败；与 README 的“装完即可启动”不一致。真实环境里 `NODE_ENV=production`、npm 配置跳过 devDependencies、或 Electron 下载失败都会走到这里。
- 建议：`npm install` 后若 `electron.exe` 不存在，直接 `throw` 并以 1 退出；如确需允许跳过，增加显式 `-SkipElectronCheck`，不能默认成功。

### P3-1：`.runtime` 未加入 `.gitignore`，克隆仓库会被塞进 107.7 MB 未跟踪文件

- 位置：`.gitignore`（已忽略 `node_modules/` 等，但没有 `.runtime`）。
- 证据：`git check-ignore -v .runtime\node\node.exe` → exit 1（未忽略）；实测便携目录 1,938 个文件 / 107.7 MB。
- 影响：入口 1 的用户是在 clone 出来的仓库里运行安装器；装完后 `git status` 会多出整个 `.runtime/`，`git clean -fdx` 也可能误删运行时。不影响安装成功，但属于明显的仓库卫生问题。
- 建议：`.gitignore` 增加 `.runtime/`；README 的数据目录表也补一行说明。

### P3-2：镜像回退没有 SHA-256，只靠 zip 头与可运行性

- 位置：`install.ps1:610-614`、`443-466`。
- 现象：官方 index 失败后走 npmmirror；本轮 npmmirror 的 `SHASUMS256.txt` 返回 404，`Get-NodeChecksum` 返回 `$null`，`Save-NodeDownload` 只检查大小、`PK` 头和最终 node/npm 可运行性。
- 证据：§3.3 日志“无法获取 SHA-256 校验文件（…404）”“没有拿到官方校验值，已用 zip 文件头与可运行性校验兜底”。
- 影响：镜像路径的完整性与官方路径不同；HTTPS 与镜像信任仍在，但少了一层内容哈希。README 已写“能拿到官方 SHA-256 时校验哈希”，行为与文档一致，但值得在发布说明里写清。
- 建议：即使官方 index 失败，也尝试直接取 `https://nodejs.org/dist/<version>/SHASUMS256.txt`；或内置一份 LTS 版本 → SHA-256 的固定表。

### P3-3：Node 下载失败会留下空 `.runtime` 目录

- 位置：`install.ps1:560`（先 `New-Item RuntimeRoot`，之后才读 LTS）。
- 证据：断网失败后 `repo-fail\.runtime` 存在，但 `RUNTIME_FILES=0`。
- 影响：无数据破坏，只是失败后多一个空目录；下次运行会正常复用/继续。
- 建议：失败清理时若 `.runtime` 为空则删除；或把 `New-Item` 移到下载/解压前。

### P3-4（沿用上一轮 P3-2）：帮助写“参数错误退出码 2”，实际为 1

- 位置：`install.ps1:61`、`:115`；参数绑定错误由 PowerShell 直接报，脚本内没有 `ExitCode = 2`。
- 证据：`powershell -File install.ps1 -Bogus` → `PARAM_EXIT=1`。
- 影响：按文档用 2 判断“参数错误”的自动化会误判为安装失败；不属于 Node 功能，但会干扰失败分类。
- 建议：帮助改成“0 成功；1 失败”，或在入口捕获参数错误显式 `exit 2`。

### 其他观察（未列为验收阻断）

- **下载 39 MB 期间约 90 秒无进度输出**：只有“下载 Node.js 第 1/1 次”一行，`$ProgressPreference='SilentlyContinue'` 屏蔽了进度条；朋友可能以为卡住。可接受，但可在 README 或输出里加“约 1–2 分钟”。
- **自定义目录且不在 PATH 的系统 Node 不会被识别**：`Get-SystemNodeRuntime` 只补默认的 `%ProgramFiles%\nodejs` 等路径；本机 Node 在 `D:\Program Files\nodejs`，PATH 置空后安装器把它当“无 Node”并下载便携版。结果仍成功，只是多下载 39 MB；如果希望“有 Node 就一定复用”，可加注册表/`where.exe`/常见 nvm 路径探测。
- **`-Launch` 失败时摘要仍可能打印“安装完成”**：`install.ps1:1294-1304` 设置 `ExitCode=1` 后继续走 `Show-Summary`；属于已有边界，本轮未实测启动 GUI。

## 5. 未覆盖 / 边界

1. **没有端到端验证真实 Electron 安装**：fixture 去掉了 `devDependencies`，只验证 Node/npm 链路；`npm install electron@^33` 的二进制下载与 `start.cmd` 启动未在本轮从零跑。P2-1 正是这条路径的已知风险。
2. **没有在真正全新 Windows VM 上跑**：无 Node 是用“PATH 置空 + 三个默认 fallback 路径均无 node.exe”模拟的；本机磁盘上仍有 `D:\Program Files\nodejs`，只是安装器找不到。全新机器还可能存在 nvm/volta/商店 Node 等未建模情况。
3. **没有跑入口 2 的完整 `iex` 端到端安装**：为避免写入默认 `D:\PM工作台`，本轮验证的是“同一表达式取回 + `-replace` + `ParseInput` / `ScriptBlock.Create`”，以及取回文本的内容；没有把 `iex` 真正执行到安装。语法的 8 个错误发生在执行前，足以判定入口 2 不可用。
4. **没有跑入口 1/3 的公开完整安装**：公开 main 的安装器是旧版，且入口 2 先失败；本轮用 zip 内旧安装器在无 Node fixture 上验证了它的失败行为，没有让它下载 GitHub 源码到默认目录。
5. **官方 index 成功但官方 zip 下载失败 → 镜像接管的路径未单独复跑**：本轮覆盖了“官方 index 失败 → 镜像 index/下载”和“两路都失败”，未构造“index 成功、zip 失败”的代理。
6. **没有覆盖**：macOS/Linux、ARM64 Windows、长路径、企业代理认证、TLS 拦截、杀毒软件拦截、`-Launch` / 快捷方式（上一轮 QA-INSTALLER-PORT 已覆盖快捷方式）、真实 DSH 连接。
7. **公开 main 的“旧安装器”判断以本轮实际取回的 jsdelivr/raw/codeload 内容为准**；`git ls-remote` 在 21:0x 因 GitHub 连接超时失败，但 raw/codeload/jsdelivr 均可达，且三处内容一致为 34,109 B 旧版。

## 6. 复现命令

```powershell
# 0) 证据根目录
$root = 'D:\deepseek\agile-workbench\_tmp\qa-installer-node-20261106'

# 1) 有系统 Node
cd "$root\repo-system"
powershell -NoProfile -ExecutionPolicy Bypass -File D:\deepseek\agile-workbench\install.ps1 `
  -NoShortcut -NonInteractive -LogDir "$root\run-system"

# 2) 无 Node：先清 PATH，再跑同一 fixture（repo-nonode 首次会下载 39 MB）
$env:PATH = 'C:\Windows\System32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0'
cd "$root\repo-nonode"
powershell -NoProfile -ExecutionPolicy Bypass -File D:\deepseek\agile-workbench\install.ps1 `
  -NoShortcut -NonInteractive -LogDir "$root\run-nonode"

# 3) 断网失败：wrapper 设置 DefaultWebProxy=127.0.0.1:1 后调用安装器
powershell -NoProfile -ExecutionPolicy Bypass -File "$root\run-fail.ps1"

# 4) 官方失败→镜像：wrapper 只 bypass npmmirror
powershell -NoProfile -ExecutionPolicy Bypass -File "$root\run-mirror.ps1"

# 5) README 入口 2 的解析复现（PowerShell 5.1）
powershell -NoProfile -ExecutionPolicy Bypass -File "$root\entry2-probe2.ps1"
powershell -NoProfile -ExecutionPolicy Bypass -File "$root\entry2-raw-probe.ps1"

# 6) 公开 main zip 内容
#    $root\main.zip 已保存；解压在 $root\main-zip-extract\agile-workbench-main
Get-FileHash "$root\main-zip-extract\agile-workbench-main\install.ps1" -Algorithm SHA256

# 7) 项目自检
cd D:\deepseek\agile-workbench
npm run check
npm run test:scripts
npm pack --dry-run
```

证据目录：`_tmp/qa-installer-node-20261106/`（每个 `run-*/stdout.txt`、`run-*/install-*.log`、`main.zip`、`main-zip-extract/`、`repo-*/` 哨兵、`entry2-*.ps1` 探针）。

## 7. 放行建议

**当前不建议按 README 对外宣称“双击或粘贴一行命令即可，Node.js 会自动装”。** 建议顺序：

1. **先修 P0-1**：按 §4 P0-1 的 A 方案改入口 2（按字节取回 + UTF-8 解码 + 去 BOM），并在 Windows PowerShell 5.1 下用 `ParseInput` 断言 0 错误；顺手修正注释。
2. **再修 P0-2**：提交并推送 `install.ps1`、`README.md`、`安装PM工作台.cmd`；确认 jsdelivr/raw/main zip 三处取回的都是新安装器（含 `Get-NodeLtsRelease`；本地工作区为 56,553 B / SHA-256 `1B429425…5A92F8C4`，远端字节可能因换行策略略有差异，以内容断言为准）。
3. **发布前复验三条入口**：在干净目录分别跑入口 1（cmd）、入口 2（一行命令）、入口 3（main zip）；断言无 Node 时自动下载 v26.13.0、exit 0、`start.cmd` 可启动。建议用一台没有 Node 的 Windows 10/11 实机或干净 VM。
4. **同时收掉 P2-1**：Electron 缺失必须非 0 退出，否则“一键安装成功”仍可能是假成功。
5. **低风险收尾**：`.runtime/` 加 `.gitignore`（P3-1）；失败清理空 `.runtime`（P3-3）；镜像回退补 SHA-256（P3-2）；帮助退出码与实现对齐（P3-4）。

完成 1–4 后，本报告的 5 项验收才具备“公开仓库 + 默认 PowerShell 5.1 + 无 Node 机器”意义上的全部 PASS 条件；当前快照只能给安装器本体（工作区版）放行。
