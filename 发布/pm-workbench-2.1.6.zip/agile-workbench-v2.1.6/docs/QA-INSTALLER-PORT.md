# QA-INSTALLER-PORT · 一键安装器与 DSH 端口自动发现

- 仓库：`D:\deepseek\agile-workbench`（D 盘）
- 时间：2026-11-06 20:01–20:12（Asia/Shanghai）
- 被测快照：`HEAD 551b2f8` + 工作区未提交改动
  - `install.ps1` 34,966 B `16460BFAD3801664184E4EEA8E99E12167724FDE3E5828E02D50CB10C702C97B`
  - `src/dsh-adapter.js` 30,864 B `0F9410442C81B14171A3300D2D7D63205144AB238B2A17067A77070AB7DDE8DA`
  - `src/main.js` 641,092 B `F4C8CF228B4813E17111F841E52066FC26FC241B0ABEA01F728E331049034102`
- 方式：只读源码审计 + PowerShell 5.1 隔离目录安装器实测 + 真实本机 DSH（63551）HTTP 探测 + 隔离 `AWB_DATA_DIR` 的 Electron/CDP 实测 + `npm run check` / `npm run test:scripts` / `npm pack --dry-run`
- 边界：**未修改** `src/**`、`install.ps1`、`README.md`、`package.json`、真实 `data/**`、`团队/状态/**`。本轮只写本文档与 `_tmp/qa-installer-port-20261106/**`。安装器默认目标 `D:\PM工作台` 的临时测试实例已删除（创建时间即测试时间，无 `data/`、无 `node_modules/`）。

## 0. 一句话结论

**安装器与端口发现的主路径在本机通过；当前“发布态”不通过。** 通过的是：幂等、缺 Node/npm/低版本处理、不覆盖数据、63551 探测、52358 失效、63607 拒绝、真实应用从 52358 自动恢复 63551。不通过的是：`main` 上还没有安装器与端口发现（一键安装实际拿到旧版，从公开 GitHub 按 README 的三个入口都拿不到安装器）、Electron 缺失时安装器仍报成功、401 兜底会把含 `dsh` 的非 DSH 服务认成 DSH、README 的 DSH 章节没写自动发现、帮助里的“退出码 2”从未发生。

## 1. 验收表

| 验收项 | 结论 | 证据 |
|---|---|---|
| 一键安装器幂等 | **PASS** | 同一隔离仓库连续跑 2 次，`data/dsh.json`、`data/userdata-keep.txt`、`项目/alpha/keep.txt`、`团队/状态/keep.json` 的 SHA-256 前后 `CHANGED=0`；第二次仍打印“当前目录就是仓库，直接使用” |
| 缺依赖：Node / npm / Node<20 | **PASS** | 三种情况均 exit 1、中文提示、目标目录未创建 |
| 缺依赖：Electron | **PARTIAL** | `npm install` 假成功但 `electron.exe` 缺失时，安装器只 `WARN` 并 exit 0，仍打印“安装完成”；随后 `start.cmd --check` exit 1。见 P2-1 |
| 不覆盖数据 | **PASS** | 非本项目且非空的目标目录：exit 1，`USER-DATA` 原样保留，目录内文件数仍为 1；复用已有仓库：exit 0，全部文件哈希不变 |
| 端口发现只认 DSH | **PARTIAL** | 63551 通过、52358/63607/非本机/普通 200/401/404/302 拒绝；但 `HTTP 401 + Basic realm="dsh"` 的非 DSH 服务被接受。见 P3-1 |
| 63551 可用 | **PASS** | `127.0.0.1:63551` 返回 401 `dsh web authentication required...`；真实应用 CDP：`online:true`、`319` 个会话、WebView `http://127.0.0.1:63551/` |
| 旧 52358 失效 | **PASS** | 无监听；TCP 连接失败；`probeDshWeb` 返回 `DSH_PROBE_OFFLINE`；真实应用把 `data/dsh.json` 从 52358 原子改为 63551 |
| README 说明 | **FAIL** | 本地 README 的安装段完整，但 DSH 章节仍写“默认 52711 / `DSH_WEB_URL` 优先级更高”，完全没提自动发现；`main` 上连安装段都没有。见 P2-2、P0-1 |
| 从公开 GitHub 一键安装 | **FAIL（发布阻断）** | `origin/main` 无 `install.ps1` / `安装PM工作台.cmd` / `discoverDshWeb`；实际下载 main zip 解压后 `hasInstallPs1=false`、`adapterHasDiscovery=false`。见 P0-1 |

## 2. 实测记录

### 2.1 静态检查、入口测试与打包

```text
npm run check          → CHECK_EXIT=0
npm run test:scripts   → SCRIPTS_OK 12/12, SCRIPTS_EXIT=0
npm pack --dry-run     → 60 files，含 install.ps1、安装PM工作台.cmd、README.md、start.cmd
```

`test:scripts` 新增的安装器用例同时验证了编码/换行：`install.ps1` 首 3 字节 `ef bb bf`（UTF-8 BOM），`安装PM工作台.cmd` 首 3 字节 `40 65 63`（无 BOM）、含 CRLF、无裸 LF。两者均通过。

### 2.2 安装器幂等 / 数据安全（隔离目录）

测试仓库副本：`_tmp/qa-installer-port-20261106/repo`，故意放入 `data/dsh.json`、`data/userdata-keep.txt`、`项目/alpha/keep.txt`、`团队/状态/keep.json` 四个哨兵；用假 `npm.cmd`（只回显 `FAKE-NPM %*` 并 exit 0）避免下载 Electron。

```text
第 1 次：exit 0
  当前目录就是仓库，直接使用：...\repo
  安装完成：...\repo
第 2 次：exit 0
  同一路径，CHANGED=0
```

- 非本项目目标：`nonrepo-target` 内放 `user-file.txt=USER-DATA`，`-InstallDir` 指向它 → exit 1，输出“目标目录已存在且不是 PM工作台，安装停止，绝不覆盖已有文件”；文件仍为 `USER-DATA`，目录内仍只有 1 个文件。
- 复用已有仓库：`-InstallDir ...\repo` → exit 0，`目标目录已是 PM工作台，直接复用`，`CHANGED=0`。
- 下载失败清理：`-ZipUrl http://127.0.0.1:1/nope.zip` → 两次失败后 exit 1，新建的 `download-fail-target` 被删除（`TARGET_LEFT=False`）。
- 快捷方式：`-ShortcutDir ...\shortcuts-repo` → exit 0；`PM工作台.lnk` 的 `TargetPath=...\repo\start.cmd`、`WorkingDirectory=...\repo`、`IconLocation=...\assets\pm-workbench.ico,0`，目标校验一致。
- 双击入口帮助：`cmd /c 安装PM工作台.cmd -Help` → exit 0，正常打印帮助。

### 2.3 缺依赖

| 场景 | 结果 |
|---|---|
| PATH 无 node | exit 1；`[缺少] Node.js（必须）` + 下载地址；目标目录未创建 |
| 假 node 输出 `v18.19.0` | exit 1；`[版本过低] 当前 Node.js：v18.19.0，要求 20 或更高`；目标目录未创建 |
| 假 node 输出 `v20.11.0`、PATH 无 npm | exit 1；`[缺少] npm（必须，随 Node.js 一起安装）`；目标目录未创建 |
| 假 npm exit 0、无 `electron.exe` | **exit 0 + “安装完成”**，只有 `WARN 没有找到 Electron`；`start.cmd --check` exit 1（见 P2-1） |

### 2.4 端口发现（真实本机）

真实监听：`127.0.0.1:63551` PID 15400（`DeepSeek Harness.exe`），`127.0.0.1:63607` PID 138928（ego-cast worker），`52358` 无监听。

| 探测 | 结果 |
|---|---|
| `http://127.0.0.1:63551` | `ok:true`、HTTP 401、`signature=dsh-web-auth`、正文 `dsh web authentication required; reopen the URL printed by dsh web.` |
| `http://127.0.0.1:52358` | `ok:false`、`DSH_PROBE_OFFLINE` |
| `http://127.0.0.1:63607` | `ok:false`、HTTP 404、`{"ok":false,"error":"not found"}` |
| `http://10.0.0.1:63551` | `ok:false`、`DSH_PROBE_NON_LOCAL` |
| 假 200 `hello world` / 假 404 / 假 401 `authentication required` / 假 302 | 全部 `ok:false`、`DSH_PROBE_NOT_DSH` |
| 假 401 `Basic realm="dsh"`（非 DSH） | **`ok:true`、`signature=dsh-401`**（见 P3-1） |

真实进程发现（去掉 `DSH_WEB_URL`，避免环境变量抢答）：

```json
{
  "ok": true,
  "code": "DSH_FOUND",
  "baseUrl": "http://127.0.0.1:63551",
  "source": "process-port",
  "process": { "ok": true, "method": "wmic", "dshProcesses": 2, "ports": [63551] },
  "candidates": ["52358:saved", "63551:process-port", "52711:default"],
  "durationMs": 307
}
```

- 当前保存 63551 时：`source=saved`，`DSH_FOUND`，不重写配置。
- 跳过进程发现、保存 52358 时：`ok:false`、`code=DSH_NOT_FOUND`、14 个候选（52358 / 52711 / 各自 ±3），`message` 明确写“保留原地址 http://127.0.0.1:52358”。
- `_tmp/dsh-discovery-unit-20261106.cjs`：`FAILURES=[]`、`UNIT_EXIT=0`（13 项断言，含 63607 拒绝、非本机拒绝、候选 ≤20）。

### 2.5 真实应用：52358 → 63551

隔离数据根：`_tmp/qa-installer-port-20261106/e2e`，启动前 `dsh.json` 为 `http://127.0.0.1:52358`；`DSH_WEB_URL` 已从子进程环境删除。

```text
[dsh] 自动发现 DSH：http://127.0.0.1:52358 → http://127.0.0.1:63551（已写入 dsh.json）；WebView=dom
```

CDP 复核（`window.workbench.dshStatus()` / `dshRediscover()`）：

```json
{
  "status": { "online": true, "code": "OK", "sessions": 319, "baseUrl": "http://127.0.0.1:63551" },
  "viewSrc": "http://127.0.0.1:63551/",
  "rediscover": { "ok": true, "code": "DSH_ALREADY_CURRENT", "changed": false, "persisted": false, "cookieOk": true }
}
```

- `e2e/dsh.json` 已变为 63551（`updatedAt` 为本次启动时间）。
- 真实 `data/dsh.json` 未被本轮触碰（`updatedAt` 仍为本轮之前的 11:26:56Z）。
- 启动 stderr 有 4 行 `ERR_ABORTED loading 'http://127.0.0.1:63551/'`，属 webview 切换时的导航中止噪声；最终页面与 CDP 都是 63551，不影响功能。

### 2.6 README / 公开 main

本地 README 已写清一键安装的 3 个入口、参数、日志、幂等与“不覆盖数据”，这部分与实测一致。但 `origin/main`（551b2f8）仍是旧内容：

```text
git ls-tree -r --name-only origin/main | Select-String 'install|安装PM'   → 无结果
git show origin/main:src/dsh-adapter.js                                   → 无 discoverDshWeb
git show origin/main:src/main.js                                          → 初始地址仍是 DSH_WEB_URL || SAVED || 52711
git show origin/main:README.md                                            → 无“一键安装”，README 仅 7,612 B
```

实际跑安装器默认下载（`codeload.../main`，0.7 MB）后解压的 zip：

```json
{
  "hasInstallPs1": false,
  "hasCmd": false,
  "adapterHasDiscovery": false,
  "readmeHasOneClick": false
}
```

即：从公开 GitHub 按 README 操作，入口 1（仓库里双击 cmd）、入口 2（raw main 的 install.ps1）、入口 3（main zip 里双击 cmd）目前都拿不到安装器；即使绕过入口直接拿到 install.ps1，它默认安装的 main 也是无自动发现的旧版。

## 3. 问题清单

### P0-1（发布阻断）：安装器与端口发现改动未进入 `main`，一键安装实际装的是旧版

- 证据：`git status` 显示 `install.ps1`、`安装PM工作台.cmd` 为未跟踪，`README.md`、`package.json`、`scripts/*`、`src/dsh-adapter.js`、`src/main.js`、`src/preload.js` 为未提交修改；`origin/main` 仍是 551b2f8，无安装器、无 `discoverDshWeb`、README 无安装段。
- 影响：从公开 GitHub 按 README 的三个入口都拿不到安装器；默认安装器下载的 main zip 装出来默认连 52711，不会自动发现 63551。直接违反“63551 可用 / 旧 52358 失效”的交付口径。
- 修复：把上述文件提交并推送到 `main`；然后在一个干净临时目录按 README 入口 1/2/3 各跑一次，确认 `install.ps1` 存在、安装后 `src/dsh-adapter.js` 含 `discoverDshWeb`、能从 52358 恢复 63551。
- 说明：这是“当前发布态”问题，不是功能代码问题；提交/推送并复验后即可关闭。

### P2-1：Electron 缺失时安装器仍以 0 退出并打印“安装完成”

- 位置：`install.ps1:733-739`。
- 现象：`npm install` 退出 0 但 `node_modules\electron\dist\electron.exe` 不存在时，只 `WARN`，不 `throw`；摘要仍显示“安装完成”。随后 `start.cmd --check` exit 1，提示“没有找到 Electron…请先 npm install”。
- 证据：隔离仓库 + 假 npm（exit 0）→ 安装器 `exit 0`、`安装完成`、`WARN 没有找到 Electron`；`start.cmd --check` → `START_CHECK_EXIT=1`。
- 影响：用户看到“装好了”，实际启动失败；这是“缺依赖”路径的假成功。
- 建议：`npm install` 后若 `electron.exe` 不存在，直接 `throw`（exit 1）并提示重跑 `npm install`；如确需允许跳过，增加显式 `-SkipElectronCheck`，但不能默认成功。

### P2-2：README 的 DSH 章节没有自动发现，且 `DSH_WEB_URL` / 默认端口描述与实现不一致

- 位置：`README.md:192-204`、`README.md:246-247`。
- 现状：README 仍写“默认值：`http://127.0.0.1:52711`”“`DSH_WEB_URL`（优先级更高）”，没有提“当前地址 → 环境变量提示 → DSH 进程参数/监听端口 → 默认 52711 → ±3”这套发现顺序；而代码注释明确 `DSH_WEB_URL` 只是初始地址/候选提示（`src/main.js:11218-11227`），发现成功会覆盖失效的本地地址。
- 影响：用户无法理解 63551 从哪来、为什么 `dsh.json` 会被改写；把 `DSH_WEB_URL` 当硬 pin 的人会得到相反结果。
- 建议：在 README §4 增加“端口自动发现”小节，写清候选顺序、仅当前地址为本机时才自动发现、失败保留原地址、手动 `dshRediscover`、`DSH_WEB_URL` 不是硬 pin；把“默认值”改为“最后 fallback”。

### P3-1：401 兜底过宽，非 DSH 的 401 服务可被认成 DSH

- 位置：`src/dsh-adapter.js:304-311`（`dshResponseSignature`）、`:352-353`（acceptedStatus）。
- 现象：任何 HTTP 401 且正文含独立单词 `dsh` 的响应都会得到 `dsh-401` 签名并被接受。实测一个非 DSH 的本地服务返回 `401 Basic realm="dsh"`，`probeDshWeb` 返回 `ok:true`、`signature:dsh-401`。
- 影响：若这个服务恰好在“保存地址/默认端口”上，`pickBestProbe` 会优先选保存地址（priority 0），工作台可能把 `dsh.json` 写到非 DSH 地址，随后认证失败；“只认 DSH”不是严格成立。当前 63551 的真实 401 由更强的 `dsh-web-auth` 命中，不依赖这个兜底。
- 建议：删除 `401 && /\bdsh\b/` 兜底，或只接受已知 DSH 特征（`dsh web authentication required`、`<title>DeepSeek Harness`、`name="dsh-app|dsh-web"`）；如确需兼容旧版，增加一条明确的 DSH 响应头/字段，不要用裸 `dsh` 单词。

### P3-2：帮助写“参数错误退出码 2”，实际参数错误退出 1

- 位置：`install.ps1:55`（帮助文本“退出码：0 成功；1 安装失败；2 参数错误”）、`:815-857`（异常处理只设 `ExitCode=1`）。
- 现象：`-Bogus`、`-InstallDir` 缺值都由 PowerShell 参数绑定直接报错，`powershell -File` 的实际退出码均为 **1**；脚本内没有任何 `ExitCode = 2` 的赋值。
- 影响：按文档用 2 判断“参数错误”的自动化会误判为安装失败。
- 建议：要么把帮助改成“0 成功；1 失败”，要么在脚本入口捕获参数错误并显式 `exit 2`。

## 4. 未覆盖 / 边界

1. **没有在全新机器上真跑 `npm install` 下载 Electron**：安装器的控制流用假 npm 验证，避免几百 MB 下载；真实 GitHub zip 下载/解压已实测（默认路径那次），但 Electron 二进制安装本身未在本轮从零验证。P2-1 正是这条路径的风险。
2. **手动“远程地址 → 本机 63551”切换未独立复跑**：本轮只复验了“已是 63551 时手动 `dshRediscover` 返回 `DSH_ALREADY_CURRENT`”；`_tmp/DSH-PORT-DISCOVERY-REPORT.md` §3.6 的手动成功证据未由本轮重新生成。
3. **未跑全量 `npm run selftest`**：本轮只跑 `check` 与 `test:scripts`；`_tmp` 报告称 selftest 只有既有 ROUND11 失败，本轮未独立确认，不计入通过证据。
4. **非 Windows**：`collectDshProcessInfo` 在非 win32 返回 `DSH_PLATFORM_UNSUPPORTED`，只剩保存地址/默认端口/±3 小范围探测；DSH Desktop 的随机端口在 macOS/Linux 上无法按进程发现。README 的跨平台声明主要指应用可运行，不包含本发现能力。
5. **既有安装不会自动升级**：安装器对已经是 PM工作台的目录只 `npm install`，不重新下载源码；老 `D:\PM工作台` 要获得本次端口发现，需要重新拉取仓库或手动更新。这与 README 的“只补依赖”一致，但升级场景要另说。
6. **webview 切换噪声**：启动日志有 `ERR_ABORTED`（切换 63551 时），最终加载成功；属非致命噪声，未列为缺陷。

## 5. 复现命令

```powershell
cd D:\deepseek\agile-workbench
npm run check
npm run test:scripts
node _tmp\dsh-discovery-unit-20261106.cjs
npm pack --dry-run

# 真实端口
@'
const { probeDshWeb, discoverDshWeb } = require('./src/dsh-adapter');
(async () => {
  for (const u of ['http://127.0.0.1:63551','http://127.0.0.1:52358','http://127.0.0.1:63607']) {
    const p = await probeDshWeb(u, { timeoutMs: 1000 });
    console.log(u, p.ok, p.code, p.status, p.signature);
  }
  const d = await discoverDshWeb({ savedBaseUrl: 'http://127.0.0.1:52358', timeoutMs: 1200, env: {} });
  console.log(JSON.stringify({ ok: d.ok, baseUrl: d.baseUrl, source: d.source, process: d.process }, null, 2));
})();
'@ | node -
```

安装器隔离复现：

```powershell
$root = 'D:\deepseek\agile-workbench\_tmp\qa-installer-port-20261106'
# repo 副本 + 哨兵文件 + 假 npm 已留在该目录；重跑：
cd "$root\repo"
$env:PATH = "$root\shim;$env:PATH"
powershell -NoProfile -ExecutionPolicy Bypass -File D:\deepseek\agile-workbench\install.ps1 `
  -NoShortcut -NonInteractive -LogDir "$root\logs-repro"
```

证据目录：`_tmp/qa-installer-port-20261106/`（`run1.out.txt`、`logs1/`、`logs2/`、`nonrepo-target/`、`e2e/app.out.log`、`e2e/dsh.json`、`pack.json` 等）。
