# QA-MVP-CORE · MVP 核心链路只读验收

> 对象：`D:\deepseek\agile-workbench`
> 时间：2026-11-05 17:00–17:10（UTC+8）
> 方式：只读审计 + D 盘隔离沙盘。未修改 `src/**`、`package.json`、`团队/**`、真实 `项目/**`；所有写操作都在 `_tmp/qa-mvp-core-20261105/` 内。
> 结论只对下面这份源码快照负责。

**一句话结论：三条新命令是真实存在的，CLI 主链和沙盘里的六角色闭环都能走通；但还不能按“可验收、可审计的六角色闭环”发布。** Owner 无身份、PM 可自审需求、派单不唤醒且不写回执锁、boot 放行占位模板、评审/Owner 落账重复、需求总览状态分叉、项目索引停在旧状态——这些都不是界面文案问题，是数据和闸门问题。

---

## 一、快照与边界

| 文件 | 字节 | SHA-256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 475,115 | `ED812497D4F7A94C` | 11-05 16:47:00 |
| `src/team-tools.js` | 250,696 | `A268800BAF24FF55` | 11-05 16:47:00 |
| `src/renderer/app.js` | 460,602 | `2F28D416E25170EB` | 11-05 16:55:18 |
| `团队/工具/team.mjs` | 6,198 | `B08FC4B5E5B22D5C` | 11-05 16:37:41 |
| `团队/工具/lib/ops.mjs` | 120,020 | `1A00B6A082AAC5D3` | 11-05 16:37:29 |
| `团队/工具/lib/workflow.mjs` | 40,660 | `496F13DDDFB7FC8D` | 11-05 16:41:11 |
| `团队/工具/lib/selftest.mjs` | 26,787 | `73173F8AB54341EE` | 11-05 16:40:32 |

- 本轮没有修改任何源码；报告之外只在 `_tmp` 写测试沙盘。
- 本轮开始前 `src/main.js`、`team-tools.js` 已是 16:47 版本；`app.js` 在 16:55 被另一进程改过，早于本轮 selftest，已纳入快照。
- 本会话继承 `ELECTRON_RUN_AS_NODE=1`，直接跑 `npm run selftest` 会把 Electron 当 Node；本轮已显式移除该变量后再跑，结果见下。这不属于产品缺陷，但复验时必须处理。
- `npm run selftest` 使用自带 mock DSH（见 §2.3），**没有启动真实六角色会话**；真实命令由 `团队/工具/team.mjs` 真跑。

---

## 二、实际跑过的命令与结果

### 2.1 `npm run check`

```text
> agile-workbench@0.1.0 check
> node --check src/main.js && node --check src/preload.js && node --check src/renderer/app.js && node --check src/dsh-adapter.js && node --check src/team-tools.js
EXIT=0
```

**PASS（语法）**。注意它只检查 5 个文件，不检查 `团队/工具/team.mjs`、`lib/workflow.mjs`、`lib/selftest.mjs`，所以不能拿它证明三条命令的实现可用；三条命令的覆盖来自 §2.2/2.3。

### 2.2 团队 CLI selftest：29/29 PASS

```powershell
node 团队\工具\team.mjs selftest --keep
```

结果：`SELFTEST 29/29 PASS`，退出码 0。覆盖：

- `init`、`project add`、`boot`、无令牌拒绝、grant、消息/已读/回执/回信、任务 claim；
- `propose → show → review → sign → apply`、`MUST_READ_FIRST`、16KB 限制、同 base 双提案 `STALE_BASE`、缺签字 `NOT_APPROVED`、锁争用、规则变更 `RULES_CHANGED`、apply 中途失败自动回滚；
- `req review`：缺令牌、缺 id、非法结论、打回无理由、非产品角色全部被拒；正向落账到工作流/任务/正文/总览/评审记录/备份；
- `owner`：产品闸门、缺参数、非法决定被拒；正向写需求级决定；
- Owner 验收：测试未 done 时 `TEST_NOT_DONE`，测试 done 后验收并收口需求任务；
- `workflow iterate`：轮次 +1、在途任务保留、已验收不动；
- `workflow terminate`：终止状态、任务收口、需求文档状态、重复动作 `WORKFLOW_TERMINATED`；
- 三条命令后 `verify` 全绿（81 个事件）；
- 工作区 `workspace.mjs create` 的六角色目录/准则/索引。

### 2.3 `npm run selftest`（D 盘隔离根）

```powershell
$env:AWB_SELFTEST_ROOT='D:\deepseek\agile-workbench\_tmp\qa-mvp-core-20261105\selftest'
$env:TMP='D:\deepseek\agile-workbench\_tmp\qa-mvp-core-20261105\tmp'
$env:TEMP=$env:TMP
Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
npm run selftest
```

结果：`SELFTEST_OK`，退出码 0。关键行：

| 轮次/断言 | 结果 |
|---|---|
| `SELFTEST_STORE` | 20/20 checks，0 failed |
| `SELFTEST_COMPAT` | 46 checks，0 failed |
| `SELFTEST_MAPPING_RESULT` | 39 checks，0 failed |
| `SELFTEST_ROUND5` / `ROUND6` / `ROUND9` | 4/4、17/17、8/8 |
| `SELFTEST_ROUND10` | 8 checks，0 failed；`commands.missing=[]` |
| `ROUND10.realCommands` | 8 项检查 0 failed；`req review`、`owner`、`owner --action accept`、`workflow iterate`、`workflow terminate` 均为真实 argv |
| `ROUND10.structure` | 六个角色目录、`项目信息.md`、`项目铁律.md`、`协作准则.md`、`项目索引.md/json` 全部存在 |
| `ROUND10.dev` | 提案/互审/apply/开发 done/测试 done/`accepted` 全部走通 |

**重要读法**：`ROUND10.final.strictReview/strictOwner/strictIterate/...` 显示 `LEGACY_PROTOCOL_REQUIRED`，这是“严格桩故意抽掉命令”的负例断言，不是真实命令失败；真实命令结果在 `ROUND10.realCommands`。

**边界**：`SELFTEST_DSH.baseUrl` 是 `http://127.0.0.1:53305`（selftest 自建 mock DSH），`ROUND10.final.prompts` 为 `before=54 / after=54`，没有真实 DSH 唤醒；不能拿这个 `SELFTEST_OK` 证明“真实六个 DSH 角色自己执行了”。

### 2.4 应用层真实沙盘：33/34 个动作直接成功，1 个是预期的按轮令牌失败

用 `src/team-tools.js` 的 `create({ teamRoot })` 在 `_tmp/qa-mvp-core-20261105/app-probe` 驱动，不经过 mock DSH，真实调用 `团队/工具/team.mjs`：

- `ensureProjectReady`：六角色目录、`项目信息.md`、`项目铁律.md`、`协作准则.md`、`项目索引.md/json`、`需求/00-需求总览.md` 全部创建；工作台默认项目根是 `D:\deepseek\agile-workbench\项目\<项目名>`（`createProject` 的 `root/path` 逻辑）。
- 六角色 `bootRole`：全部 `ok=true`、`bootRead.complete=true`；
- `createRequirement` → `reviewRequirement`（真实 `req review`）→ `ownerRequirementDecision`（真实 `owner`）→ `dispatchRequirement`；
- `claimWorkflowTask` → `devSubmit`（真实 `propose`）→ `devReview`（真实 `show+review`）→ `devApply`（真实 `show+review+sign+apply`）→ 开发 `done`；
- `dispatchTest` → 测试 `claim/done`；
- `ownerAccept`：测试前 `TEST_NOT_DONE`，测试 done 后 `accepted`；
- `iterateWorkflow`：round 2；随后**未重新 boot** 直接 `terminateWorkflow` 返回 `BOOT_REQUIRED`；重新 boot 后 `terminate` 成功，`phase=terminated`，未完成需求与任务关闭。

唯一失败的 `terminateWorkflow BOOT_REQUIRED` 是“迭代后 PM 令牌仍属于第 1 轮”的预期行为，重新 boot 即可；不按缺陷计。**但这也说明 UI/脚本必须在迭代后重新 boot PM，不能连续点迭代再终止。**

### 2.5 定向探针

| 探针 | 结果 | 证据 |
|---|---|---|
| 产品角色在场时，PM 能否自审需求 | **能**：`REVIEW_OK=True status=approved by=pm` | `_tmp/qa-mvp-core-20261105/pm-self-review.log` |
| 无 `--boot` 的任意本地调用能否写 Owner 决定 | **能**：`OWNER_OK=True by=Owner channel=stdio` | `_tmp/.../owner-no-boot.log` |
| 派单后是否有回执锁 | **无**：`readDispatchLockState=null`；第二个需求仍可派 | `app-probe/probe-result.json` |
| 测试未 done 能否 Owner 验收 | **不能**：`TEST_NOT_DONE` | 同上 |
| 自己审自己的提案 | **不能**：`SELF_REVIEW` | 同上 |
| `workflow terminate` 是否清理遗留派单锁 | **不清理**：锁文件仍在 | `_tmp/.../lock-term.log` |
| 三条命令能力探测 | `available=true, missing=[]` | `_tmp/.../capabilities.json` |

---

## 三、逐项判定

| 检查项 | 判定 | 简要依据 |
|---|---|---|
| 三条命令真实可用 | **PASS（命令级）** | `missing=[]`；help 可见；CLI selftest 29/29；`ROUND10.realCommands` 8 项检查 0 failed |
| 项目创建目录 | **PARTIAL** | 工作台 `createProject`/`ensureProjectReady` 六角色目录+文档齐全；DSH 离线会整单回滚；CLI `project add` 只建半套 |
| boot | **PARTIAL** | 六角色可 boot、`complete=true`；但占位 `项目信息.md` 也能通过；CLI boot 的必读集更弱 |
| 需求评审 | **PARTIAL** | 真实 `req review` 落账；但 PM 可自审；总览重复/冲突；审计事件重复 |
| Owner | **FAIL（身份）** | 决定/验收都无 boot/nonce/TTY 凭据；任意本地调用可写 `by:"Owner"` |
| 派单 | **PARTIAL/FAIL（闸门）** | 有 mailbox 通知；无 wake、无 `派单锁.json`，可连续派多单 |
| 互审 | **PARTIAL** | 另一程序员可审、自己审自己被拒；但壳代跑且用了环境 `DSH_SESSION_ID`，不是角色会话 |
| 测试 | **PASS** | 测试派单/claim/done 可走；测试未完成时 Owner 验收被 `TEST_NOT_DONE` 挡住 |
| 验收 | **PARTIAL** | 测试闸门+任务收口可走；Owner 身份不可信 |
| 迭代/终止 | **PARTIAL** | round/phase/任务收口/文档状态可走；重复审计事件、索引不刷新、遗留派单锁；迭代后需重新 boot |
| D 盘 | **PASS（本轮）** | 隔离根、Electron userData/tmp、CLI selftest 临时目录均在 D；`ROUND9.driveD` 全绿 |

---

## 四、问题清单

### P0-1｜Owner 决定/验收没有身份，`by:"Owner"` 只是字符串

**现象**

`owner` 命令没有 `--boot`；`cmdOwner` 只校验 `--project/--requirement/--decision/--opinion`，`channel` 只区分 `tty`/`stdio`。`ownerDecision` 无条件写 `by:'Owner'`。工作台 IPC `requirement:owner` 和 `owner:accept` 默认 `role:'owner'`（`src/main.js`），渲染层或任意本地脚本都能替 Owner 通过/验收。

**证据**

```powershell
# 没有 --boot，不是 TTY，仍然成功
node 团队\工具\team.mjs owner --project PM自审 --requirement R-20261105-170617-b704 `
  --decision skipped --opinion "无 boot 的任意调用方写入 Owner 决定" --json
# => ok:true, ownerReview.by:"Owner", channel:"stdio"
```

- `_tmp/qa-mvp-core-20261105/owner-no-boot.log`
- `app-probe` 中 `ownerRequirementDecision` 也没有 Owner 凭据；工作台路径还把 `channel` 从落账里丢了。
- `src/main.js` 的 `requirement:owner` / `owner:accept` 都默认 `role: 'owner'`；`ownerAccept` 默认 `role='owner'`。

**影响**

- Owner 验收可以在没有 Owner 会话、没有 Owner 终端、没有 Owner 确认的情况下完成。
- 账本上的 `by:"Owner"` 不能证明 Owner 做过决定；如果 MVP 卖点是“六角色 + Owner 闸门”，这是发版阻断。

**建议**

二选一，并写进发布说明：

1. 给 `owner` / `owner:accept` 加一次性 nonce 或本机凭据，校验后记录 `nonceHash/expiry/channel`，无有效凭据返回 `OWNER_IDENTITY_REQUIRED`；
2. 明确降级为单人编排台：字段改为 `recordedBy:"operator"` / `actor:"workbench-shell"`，UI 不再显示“Owner 本人已通过/已验收”。

---

### P1-1｜产品角色在场时，PM 仍可自审需求

**现象**

`团队/工具/lib/ops.mjs` 的 `cmdReqReview` 允许 `['product','pm']`，没有判断“团队里是否已有产品角色”或当前阶段。PM 拿自己的 boot 令牌即可替产品通过需求评审。

**证据**

在六角色都在的名册下（`pm,programmer1,product,analyst,programmer2,tester`）：

```text
req= R-20261105-170834-815d
req review --boot <PM 令牌> --verdict approve --comments "产品在场，PM 仍然自审通过"
=> REVIEW_OK=True status=approved by=pm
```

- `_tmp/qa-mvp-core-20261105/pm-self-review.log`
- 工作台封装层 `reviewRequirement` 只允许 `product`，所以这是 CLI/旧协议旁路，不是 UI 正向路径；但“三命令”本身正是 CLI。

**影响**

- PM 可以创建需求再自己批准，产品评审闸门形同虚设；Owner 新需求由 PM 代办时更明显。
- 与 `流程.md` 的“产品评审”和角色独立原则冲突。

**建议**

- 只有“团队无产品角色且处于 pilot”时才允许 PM 代审；否则 `NOT_PRODUCT`。
- 增加负例：产品在场时 PM `req review` 必须失败。

---

### P1-2｜互审/PM 签字是壳代跑，记录里的 `sessionId` 是环境 `DSH_SESSION_ID`，不是角色会话

**现象**

`devSubmit` / `devReview` / `devApply` 都传 `allowMissingSession: true`。没有 `团队会话.json` 时，旧 CLI 的 `sessionOf()` 取 `process.env.DSH_SESSION_ID`；于是提案 `authorSession`、PM 评审/签字 `sessionId` 都会变成启动壳的那个 DSH 会话。

**证据**

本轮环境的 `DSH_SESSION_ID=8c21939f-7c1c-40b3-b5be-260c40439a8f`。`app-probe` 的提案文件里：

```json
"author": "programmer1",
"authorSession": "8c21939f-7c1c-40b3-b5be-260c40439a8f"
```

`评审/pm.json` 和 `签字/pm.json` 的 `sessionId` 也是同一个值。它看起来“有会话”，实际是本 QA 壳的会话，不是 programmer1 或 PM 的项目角色会话。

**影响**

- “A/B 互审”“PM 看过才签字”在审计上仍可能是壳一人完成；非空 `sessionId` 反而更容易让人误信。
- 与 `流程.md` 的“互审必须由另一名程序员、PM 签字”冲突。

**建议**

- `devReview` / `devApply` 绑定真实角色会话（复用 `verifyProjectRoleSession`），缺会话返回 `SESSION_ID_REQUIRED`；
- 壳代跑时记录 `actor:"workbench-shell"` / `executor`，不要写角色 `sessionId`；
- 不要从父进程继承 `DSH_SESSION_ID` 当作角色会话。

---

### P1-3｜派单只写邮箱通知，不唤醒、不写回执锁，PM 可以连续派多单

**现象**

`src/team-tools.js` 的 `sendWorkflowNotice` 固定拼：

```js
['send','--boot',token,'--to',to,'--subject',subject,'--body',body,'--no-wake', ...]
```

没有 `--ack`。`dispatchRequirement` / `dispatchTest` 都复用它。旧 `cmdSend` 只在 `--ack` 时写 `派单锁.json`；工作流派单不写锁。

**证据**

`app-probe` 中：

- 第一次 `dispatchRequirement` 后 `readDispatchLockState(NAME)` 为 `null`；
- 第一个开发任务尚未回执时，第二个需求仍 `dispatchRequirement` 成功（`ok:true`），锁仍为 `null`；
- 邮箱里只有 `ackRequired:false` 的 `type:"dispatch"` 通知，没有 wake 记录；`task create` 另发的一条 `ackRequired:true` note 也不产生派单锁。

**影响**

- 空闲角色不会被 DSH prompt 唤醒；PM 连派多人不会触发“一次一个”。
- 与 `流程.md` 的 PM 硬闸门 #6 直接冲突；UI 显示“已派发”，实际可能没人处理。

**建议**

- 工作流派单复用 `sendDispatch`（默认 `--ack` + wake），把 `wake/ack/lock` 结果写回 `工作流.json`；
- 如果没有 wake 能力，UI 必须明确标“仅通知（未唤醒/未加锁）”，不能显示成旧派单成功；
- 增加“第二单必须 `PM_DISPATCH_PENDING`”用例。

---

### P1-4｜boot 先补模板再放行，占位 `项目信息.md` 也能通过

**现象**

`bootRole` 在 `readBootDocs()` 之前调用 `ensureProjectStructure()`；后者会创建 `项目信息.md`（正文是“（待 PM 填写）”）、`需求/00-需求总览.md`（空表头）、六角色目录/角色卡/索引。随后 boot 读取刚生成的模板，`bootRead.complete=true`。

**证据**

`app-probe` 的 `项目信息.md` 仍是：

```markdown
## 一、项目目标
（待 PM 填写：这个项目到底要做什么、为什么做）
```

但六角色 `bootRead.complete` 全部 true；随后仍完成了需求创建、产品评审、Owner skip、派单。CLI `project add` 只建半套目录（见 P2-1），`boot` 也照样成功。

**影响**

- “项目信息没写清前，PM 不叫其他角色”被自动模板绕过；评审/Owner 建立在一份占位符上。
- 审计无法区分“角色真的读了项目信息”和“壳刚生成模板”。

**建议**

- `bootRole` 先读后补：缺必读就 `MISSING_DOC`，只有 `project:create`/显式 ensure 才允许补模板；
- 评审/Owner 前检测占位符（`（待…填写）`、空表头），命中返回 `PLACEHOLDER_DOC`；
- CLI `boot` 使用与 `bootRole` 相同的必读集，至少包含 `项目信息.md`、`协作准则.md`、`需求/00-需求总览.md`。

---

### P1-5｜需求总览被两个写入方写成多行，状态互相矛盾

**现象**

`app-probe` 两个需求，`需求/00-需求总览.md` 出现 **8 行**，同一需求出现 4 次，状态同时有 `accepted`、`approved`、`ready`，还有缺列/错列的行。

**证据**

```markdown
| R-20261105-170439-af86 | 核心链路需求 | P1 | accepted | 需求评审/... |
| R-...af86 | [R-...af86-核心链路需求.md](...) | P1 | approved | - | ... |
| R-...af86 | [R-...af86-核心链路需求.md](...) | P1 | ready | - | ... |
| R-...af86 | [R-...af86-核心链路需求.md](...) | P1 | accepted | - | ... |
...
```

根因：

- `src/team-tools.js` 的 `writeRequirementDoc` 在总览里追加 5 列行（`id/title/priority/status/acceptance`）；
- `团队/工具/lib/workflow.mjs` 的 `setOverviewRow` 只更新“列数 ≥8”的行，看到 5 列行就再插一条 7 列行；
- `src/team-tools.js` 的 `updateRequirementDocStatus` 只找第一行 `| id |` 改 `cells[4]` 后 `break`。

**影响**

- 需求总览是角色“先读目录”的入口；现在同一个需求有四个状态，无法作为验收/审计依据。
- 与“一个需求一个文件、总览是目录”的设计直接冲突。

**建议**

- 统一一套列格式和一个写入方；按 `id` 更新已有行，不要按列数分支；
- 对历史总览做一次迁移（每个 id 只保留一行）；
- 增加“review → owner → accept → terminate 后总览仍只有一行且状态正确”的断言。

---

### P1-6｜`工作流.json` 的 history/events 被壳重复追加

**现象**

真实 CLI 已经写了一次审评/Owner/迭代记录，壳的 `mutateWorkflowState` 又写一次。`app-probe` 中一个需求的 history 统计：

```text
product_review   2
owner_review     2
owner_accept     2
```

`工作流.json` 的 events：

```text
requirement_review   4（两个需求，各 2 次）
owner_requirement    4（各 2 次）
owner_accept         2
iterate              2
```

`terminate` 本轮只有 1 条，但其他关键动作均重复。`owner_accept` 两条还分别写 `by:"Owner"` 和 `by:"owner"`。

**影响**

- 审计链看起来“每个动作记两次”，事件计数/时序不可信；
- 与“每次动作一条记录”的协议冲突；重复记录还会放大 `verify` 的事件统计。

**建议**

- 明确唯一写入方：壳只镜像旧命令返回值，不再次 `pushHistory` / `pushWorkflowEvent`；
- 或按 `(action, requirementId, at, command)` 去重；
- 增加“一次 review 只增加 1 条 history/event”的断言，并修 `by` 大小写。

---

### P1-7｜项目索引停在旧状态，且把评审记录当成需求

**现象**

完整链路走完并终止后，`项目索引.md` 仍显示：

```text
- [P1] R-20261105-170439-af86 open - — 核心链路需求
- [P1] T-20261105-170441-cf2d working programmer1 — ...
- [P2] R-20261105-170441-564d open - — 并行派单探针
- [P2] T-20261105-170442-ae2c working programmer2 — ...
```

而实际任务全部 done、工作流已 terminated。`项目索引.json` 的 `tasks` 为空/不存在，`requirements` 有 6 条，其中 4 条是 `需求/评审/*.md`（评审记录），不是需求。

索引最后生成时间是 `2026-11-05 17:04:45`（devApply 时），17:04:46 的测试/验收、17:05:20 的终止都没有刷新它。

**影响**

- 用户按“先读索引再找文件”的规则看到的是旧任务；终止后仍会以为有开发/测试在途。
- `项目索引.json` 把评审记录登记成需求，后续 `find`/看板/自动化可能误判需求数量。

**建议**

- `doneWorkflowTask`、`ownerAccept`、`iterateWorkflow`、`terminateWorkflow` 结束时刷新项目索引，或明确标记“索引已过期”并阻断依赖它的操作；
- `需求/评审/**` 不要进入 `requirements` 列表；
- 给 `项目索引.json` 增加 `tasks` 结构，或删掉 `.md` 里的任务表，避免两套口径。

---

### P2-1｜CLI `project add` 只建半套项目，和 `createProject` 不是同一条路径

**现象**

`project add --name PM自审` 后目录只有：

```text
README.md
项目说明.md
项目铁律.md
项目索引.md/json
需求/
```

没有 `项目经理/产品/需求分析师/程序员A/程序员B/测试人员/`，没有 `项目信息.md`，没有 `协作准则.md`。随后 `boot` 仍然成功，`req create`/`req review` 也能走。

工作台的 `createProject` 走 `ensureProjectReady`，六角色目录/文档/索引齐全（见 `ROUND10.structure`）。这是两条不同的创建路径。

**影响**

- 用 CLI 建的项目是半成品，boot 还能掩盖缺失；
- 文档/角色以为“项目已经建好”，实际没有六角色结构。

**建议**

- `project add` 直接复用 `workspace ensure`/`ensureProjectReady`；或者明确标为“最小登记”，并在 `boot` 前强制 ensure；
- 增加 `project add` 后结构断言。

---

### P2-2｜`workflow terminate` 不释放遗留派单锁

**现象**

用旧协议 `send --ack` 建立 `派单锁.json` 后，`workflow terminate` 成功，锁文件仍然存在。

**证据**

`_tmp/qa-mvp-core-20261105/lock-term.log`：

```text
lock exists after send: True
lock exists after terminate: True
{
  "messageId": "M-20261105-170637-7a20be",
  "to": "programmer1",
  "subject": "派单待回执"
}
```

**影响**

- 终止/重启/下一轮时，遗留锁可能继续挡住派单（直到 TTL 或人工删除）；
- “终止”没有完成清理。

**建议**

- `terminateWorkflow` 同时释放该项目下所有 `派单锁.json`，并写一条 `lock_released` 事件；
- 增加“terminate 后无遗留锁”的断言。

---

### P2-3｜项目创建硬依赖 DSH，离线会整单回滚

**现象**

`createProject` 先建本地记录/目录，再 `activateWorkspace`；DSH 不可达时直接 throw 并 `rollbackCreatedProject`。selftest 里对应：

```json
"createRollback":{"path":"...第十轮回滚","code":"DSH_OFFLINE"}
"SELFTEST_COMPAT.offlineCreateError":"[DSH_OFFLINE] ... fetch failed"
"offlineProjectRecord":false
```

**影响**

- DSH 未启动、重启中、地址配错时，用户连“建一个本地项目”都做不到；第一步就失败。
- 对“本地优先”的定位是明显冲突；如果产品明确要求 DSH 在线，UI 应在填写前禁用并说明，而不是填完再回滚。

**建议**

- 允许 `workspace.pending=true`：本地目录/六角色结构先落，DSH 绑定后补；
- 或 UI 在 DSH 离线时禁用“新建项目”并给单一入口提示。

---

## 五、未证明与边界

1. **真实 DSH 六会话未验证**：`npm run selftest` 的 DSH 是 mock（`127.0.0.1:53305`），`ROUND10.final.prompts 54→54`，没有真实角色被唤醒。本轮能证明的是：
   - 三条命令本身真实可用；
   - 工作台后端真调用旧 CLI；
   - mock DSH 下界面/主进程流程完整。
   不能证明“真实六个 DSH 角色自己完成闭环”。

2. **`npm run check` 覆盖不足**：只做 5 个 JS 文件的语法检查，不覆盖 `团队/工具`；本次通过不等于三条命令无语法/运行时问题，后者的证据是 CLI selftest 和应用层沙盘。

3. **D 盘结论有前提**：本轮把 `AWB_SELFTEST_ROOT`、`TMP/TEMP/TMPDIR` 都指向 D；CLI selftest 默认使用 `os.tmpdir()`，不设 `TMP/TEMP` 时会落系统 C 盘临时目录。`ROUND9.driveD` 的 7 个路径全在 D；Electron 的 userData/tmp 也在 D。
   - 另：C `AppData\Local\Temp` 在 17:01–17:03 出现过 `mvp-*.mjs/txt`，时间重叠但内容与本轮命令不符（本轮 TMP 已重定向 D），无法归因于本轮，未计入 PASS/FAIL。

4. **未逐按钮点击 UI**：三命令的 UI 入口/禁用逻辑在 `src/renderer/app.js` 可见，后端 IPC 也在；本轮通过 selftest 的 UI 轮次和真实命令调用验证后端，没有对每个按钮做 CDP 点击。若需要 UI 级验收，应单独做一轮。

5. **源码在动**：`app.js` 在 16:55 有第三方改动；本报告的快照是 17:00–17:10。若文件哈希再变，先按 §2 复跑，不要直接复用结论。

---

## 六、给 PM 的发布建议

**可以演示，不要按“可验收六角色闭环”发布。**

- 三条新命令、项目目录、boot、评审、派单、互审、测试、验收、迭代/终止的**代码路径**已经能走通，CLI 沙盘 29/29、应用层沙盘 33/34、Electron selftest `SELFTEST_OK`。
- 发布前至少要先处理：
  1. **P0-1 Owner 身份**（保留闸门就加凭据；不保留就明确降级文案/字段）；
  2. **P1-1 PM 自审**、**P1-2 互审会话伪造**、**P1-3 派单唤醒/锁**——这三项直接决定“六角色”是不是真的；
  3. **P1-4/P1-5/P1-6/P1-7**——决定账本和需求总览是否可信；
  4. **P2-1/P2-2/P2-3**——决定 CLI 建项目、终止清理、离线可用性。
- 修完后用真实 DSH 跑一遍 `建项目 → 六会话 → 需求 → 产品评审 → Owner → 派单 → 提案/互审/apply → 测试 → Owner 验收 → iterate/terminate`，并保留六个 `sessionId`、一次 commit、一次测试 done、一次 Owner accept 的证据；不要把 mock selftest 绿当成真实绿。

---

## 附：证据索引

| 内容 | 路径 |
|---|---|
| `npm run check` 日志 | `_tmp/qa-mvp-core-20261105/check.log` |
| CLI selftest 29/29 | `_tmp/qa-mvp-core-20261105/cli-selftest.log` |
| Electron selftest 全量输出 | `_tmp/qa-mvp-core-20261105/selftest-console.log` |
| 应用层沙盘结果 JSON | `_tmp/qa-mvp-core-20261105/app-probe/probe-result.json` |
| 应用层沙盘控制台 | `_tmp/qa-mvp-core-20261105/app-core-probe.log` |
| PM 自审证据 | `_tmp/qa-mvp-core-20261105/pm-self-review.log` |
| 无 boot 写 Owner 证据 | `_tmp/qa-mvp-core-20261105/owner-no-boot.log` |
| terminate 遗留锁证据 | `_tmp/qa-mvp-core-20261105/lock-term.log` |
| 能力探测 `missing=[]` | `_tmp/qa-mvp-core-20261105/capabilities.json` |
| 需求总览分叉样本 | `_tmp/qa-mvp-core-20261105/app-probe/项目/核心流程/需求/00-需求总览.md` |
| 工作流重复 history/events 样本 | `_tmp/qa-mvp-core-20261105/app-probe/团队/状态/项目/核心流程/工作流.json` |
| 陈旧项目索引样本 | `_tmp/qa-mvp-core-20261105/app-probe/项目/核心流程/项目索引.md`、`项目索引.json` |
| 提案/评审/签字会话样本 | `_tmp/qa-mvp-core-20261105/app-probe/团队/状态/项目/核心流程/提案/P-20261105-170443-92ac3f/` |
