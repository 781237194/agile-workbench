# QA-MVP-CORE2 · MVP 核心链路二轮只读验收

> 对象：`D:\deepseek\agile-workbench`
> 时间：2026-11-05 17:42–17:56（UTC+8）
> 方式：只读源码审计 + 隔离沙盘（CLI / Electron / mock DSH）。未修改 `src/**`、`package.json`、真实 `项目/**`、真实 `团队/状态/**`；除本报告外，所有写操作都在 `_tmp/qa-core2-20261105/`。
> 结论只对下面的源码快照负责；审计开始与结束时哈希一致。

**一句话结论：新建项目从 0 到第一条需求、boot、产品评审、Owner pending、迭代守卫，这五条在沙盘里已经走通；但“真实项目”仍被 4 位需求号挡住，而且同一个原因会让迭代守卫直接失效。上一轮的 Owner 身份（P0）和审计双写（P1）仍未修。**

---

## 一、快照与边界

| 文件 | 字节 | SHA-256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 485,999 | `9702CD2BBE56F3BB` | 11-05 17:31:10 |
| `src/team-tools.js` | 257,673 | `98EC8125AE4A4DA7` | 11-05 17:26:40 |
| `src/renderer/app.js` | 474,347 | `6D6F44138EF79C19` | 11-05 17:39:58 |
| `团队/工具/team.mjs` | 6,371 | `C4A8579A7CE3167B` | 11-05 17:24:33 |
| `团队/工具/lib/ops.mjs` | 120,047 | `9A7E315265C2E33C` | 11-05 17:24:26 |
| `团队/工具/lib/workflow.mjs` | 44,260 | `E987C0C580440926` | 11-05 17:30:06 |
| `团队/工具/lib/selftest.mjs` | 31,436 | `F9CCD376372866FB` | 11-05 17:30:23 |

- 本会话继承 `ELECTRON_RUN_AS_NODE=1`；跑 Electron 前已显式清掉，否则 Electron 会被当 Node 执行。这是环境问题，不是产品缺陷。
- `npm run check` 只检查 5 个 src 入口，不检查 `团队/工具/**`；下面的结论不依赖它。
- 真实 DSH 六会话未验证：UI 探针使用 `mock-dsh.cjs`（127.0.0.1:9411），只用于建项目/工作区登记；没有启动真实六角色。
- 真实项目原件没有被修改；`微光作品集` 是复制到 `_tmp` 后恢复的。

---

## 二、六个重点的判定

| 检查项 | 判定 | 一句话证据 |
|---|---|---|
| 新项目无需求不卡死 | **PASS** | 新建空项目后 truth 为“旧命令齐全”，新建需求与六角色 boot 按钮全部可点；`workflow:state` 返回真实能力，不再 `legacy:null` |
| PM 不能自审 | **PASS（角色路径）** | PM 的 `req review` 返回 `NOT_PRODUCT`；UI IPC 传 `role:'pm'` 返回 `ROLE_NOT_ALLOWED` |
| Owner pending | **PASS（pending 表达）** | 产品评审通过后 `ownerReview.status=pending`，没有 `by`/`actor`；UI 显示“Owner 尚未决定 · 待 Owner（无记录）” |
| 占位模板 | **PASS** | 新项目 PM boot 返回 `PLACEHOLDER_DOC` 并列出占位原文；写实 `项目信息/项目铁律` 后全队 boot 6/6 |
| 迭代守卫 | **PARTIAL** | 正常项目：有在办需求时按钮禁用、后端 `ITERATE_BLOCKED`；真实项目：两条需求“消失”，`iterate` 成功到第 2 轮 |
| 真实项目 | **FAIL** | `微光作品集` 有两份 4 位需求号文档，壳读到 0 份；UI 显示“还没有需求”，索引却登记了这两条 |

---

## 三、PASS 项的实际证据

### 3.1 新项目无需求不卡死

新建 `QA空项目` 后刷新页面，DOM 实际为：

```text
#project-truth:
数据真源 ｜ preload 已加载 ｜ IPC 齐全 ｜ 文件 40 ｜ workflow 已读 ｜ briefing 已读 ｜ 旧命令齐全 ｜ boot 0/6 ｜ 账本一致 ｜ 模板占位 2

[data-legacy-req-action=requirement-create] disabled=false
  title=新建第一条需求：提交时后端会先取得所选产品/需求分析师的 boot 令牌（首次自动 boot）

[data-legacy-boot]（6 个角色） disabled=false
#legacy-boot-all disabled=false，text=全队 boot（缺 6）
```

对照上一轮 P0 的根因：`src/main.js` 的 `local-fallback` 现在会返回 `legacy` 与 `capabilities`（`fallbackCaps`，`main.js:2699-2710`），不再写 `legacy:null`；`app.js` 的 `legacyActionCommandGate` 因此能确认 `req create`/`boot` 存在。Electron selftest 的 `ROUND10` 也包含这条断言，整轮 `SELFTEST_OK`。

### 3.2 PM 不能自审

CLI（PM 自己的 boot 令牌）：

```json
{"ok":false,"code":"NOT_PRODUCT",
 "message":"需求评审只能由产品设计师或需求分析师执行；PM 不能自审，其他角色不能代审",
 "details":{"role":"pm","allowed":["product","analyst"]}}
```

UI IPC：

```json
{"ok":false,"code":"ROLE_NOT_ALLOWED","message":"需求评审必须由产品设计师执行"}
```

对应实现：`团队/工具/lib/ops.mjs:1843-1847` 先判角色；`src/team-tools.js:3774` 的 UI 路径也先判 `product`。

**边界**：这证明“角色字符串”不能是 PM；它不证明调用方一定是产品本人。任何本地调用方都可以 `boot --role product` 或传 `role:'product'`，身份问题见 §4.2。

### 3.3 Owner pending

产品评审通过后直接读 `工作流.json`：

```json
{"status":"approved","phase":"owner_review","ownerStatus":"pending","hasBy":false,
 "topOwnerStatus":"pending","topHasBy":false,
 "topOwner":"{\"required\":true,\"status\":\"pending\",\"kind\":\"requirement\",\"roundKey\":\"QA空项目|1|1\"}"}
```

UI 需求卡：

```text
Owner 尚未决定 · 待 Owner（无记录）
```

对应实现：`团队/工具/lib/workflow.mjs:575` 只写 `{status:'pending'}`；`src/team-tools.js:3827-3829` 同样不写 `by`/`actor`。上一轮“产品一通过就显示 by=Owner”的 P1 已修。

### 3.4 占位模板

新项目 PM boot 实际返回：

```text
[PLACEHOLDER_DOC] 角色「pm」boot 被拒绝：项目信息（（待 PM 填写：这个项目到底要做什么、为什么做）、
（待 PM 填写：谁用、在什么场景用、现有替代方案）、（待 PM 填写：要交付的页面/接口/文档/测试报告）、
（待 PM 填写：明确排除项，防止角色自行扩需求）、（待填）、（待 PM 填写：截止时间、技术/成本/合规约束））
仍是模板占位；先把项目目标/边界/铁律正文写清再 boot
```

写实两份文档后点“全队 boot”：

```text
toast: 全队 boot 完成：6 个角色都已读全（后端逐角色返回；界面发起不冒充角色本人）
#project-truth: ... boot 6/6 ... 模板占位 1
```

剩下 1 份是 `需求/00-需求总览.md` 的 `（待登记）` 行；创建第一条需求后变 0。

**口径旁注**：`bootPlaceholderDocs()` 只检查 `项目信息.md` 和 `项目铁律.md`（`src/team-tools.js:3060-3067`），而 UI 的 `legacyPlaceholderDocs()` 还检查 `需求总览`。所以会出现“boot 6/6，但 UI 显示模板占位 1 · 禁止推进”的中间态；当前创建第一条需求会清掉它，不阻断主链，但两处口径最好统一或写清。

### 3.5 迭代守卫（正常项目）

两条在办需求时，UI 迭代按钮：

```text
disabled=true
title=还有 2 条需求在办：R-20261105-174918-394a（待 PM 派单）、R-20261105-175147-0584（待 PM 派单）；
      迭代会让本轮 boot 全部作废、在办需求留在旧轮。先完成 Owner 验收，或改用「终止」。
```

同一守卫在稍早一次探针（当时只有 1 条在办需求）的直接 IPC 返回：

```json
{"ok":false,"code":"ITERATE_BLOCKED","message":"还有 1 条需求未收口（R-20261105-174918-394a:approved）；先验收或终止，再启动下一轮","round":1}
```

随后第二条需求也进入 `ready`，UI 标题变成“还有 2 条需求在办”，仍然禁用；两次都命中了守卫，只是需求数不同。

对应实现：`src/renderer/app.js:3885-3935` 的 `legacyIterateGuard`；`src/team-tools.js:4066-4113` 的 `iterateGuard`；`团队/工具/lib/workflow.mjs:864-882` 的 `assertIterateAllowed`。CLI selftest 也覆盖了“有在办需求时拒绝且不写轮次”。

---

## 四、问题清单

### 4.1 P1（本轮新发现）｜真实项目 4 位需求号在壳里“消失”，并让迭代守卫失效

**现象**

把真实项目 `项目/微光作品集` 复制到沙盘后恢复：

- `项目索引.json` 里明明有两条需求：
  - `R-20261103-0001` → `需求/R-20261103-0001-首页作品流.md`
  - `R-20261103-0002` → `需求/R-20261103-0002-作品详情.md`
- `workflowState` 返回 `reqCount=0`；
- `workflowBoot` 的 `bootRead.requirements.count=0`；
- UI 需求区显示“还没有需求”；
- 在这个状态下 `workflow iterate` 成功：`round 1 → 2`，`stopped=[]`、`closedTasks=[]`，两条需求仍在旧轮。

**根因**

1. `src/team-tools.js:3070`：

   ```js
   const REQ_FILE_RE = /^R-\d{8}-\d{6}(?:-[0-9a-f]{2,8})?/i;
   ```

   只认 6 位序号；`R-20261103-0001-*` 这类旧工作台的 4 位号直接读不到。

2. `src/team-tools.js:3545-3555` 的 `readWorkflowSnapshot` 只从 `工作流.json` 和 `任务/` 组装需求；没有需求正文扫描，所以即使正则修好，旧项目里只有 `R-*.md`、没有 `工作流.json` 行时仍然是 0。

3. `src/team-tools.js:4066-4113` 的 `iterateGuard` 只检查 `state.requirements` 和任务；旧项目的两条正文不在其中，迭代自然放行。

4. `src/team-tools.js:3788-3789` 的 `reviewRequirement` 要求 `state.requirements[requirementId]` 存在。用 CLI 建的同为 6 位的需求（未进 `工作流.json`）实测返回：

   ```json
   {"ok":false,"code":"REQUIREMENT_NOT_FOUND","message":"工作流里没有需求 R-20261105-175301-142c"}
   ```

   所以这不是“只改 4 位正则”就能收口的问题。

**影响**

- 真实项目恢复后看起来是空项目；用户可能重复创建同名需求，旧的两条永远不进入评审/派单/验收。
- 同一原因绕过迭代守卫：两条未收口需求还在，轮次却已经 +1，六角色 boot 全部跨轮失效，需求留在旧轮。
- 索引与工作流两个真相源分叉：索引说“有 2 条”，工作流说“没有需求”。

**最小修法**

- `REQ_FILE_RE` 放宽到 4–8 位序号；
- `readWorkflowSnapshot` 把 `需求/R-*.md` 合并进 `requirements`（状态未知时标 `review`/`unknown`，不要丢）；
- `reviewRequirement` / `ownerRequirementDecision` 能按正文或任务解析，不要求一定已有 `工作流.json` 行；
- `iterateGuard` 在 `state/tasks` 之外扫描 `需求/R-*.md`，有未收口正文就 `ITERATE_BLOCKED`；
- 加三条回归：4 位号可读、只有正文没有工作流行时可评审、真实项目有在办需求时 iterate 必须被拒。

**证据**

- `_tmp/qa-core2-20261105/real-projects.json`（`微光作品集`：`docFiles=2`、`readCount=0`）
- `_tmp/qa-core2-20261105/ui/root/微光作品集/项目索引.json`（2 条）
- `_tmp/qa-core2-20261105/ui/team/状态/项目/微光作品集/工作流.json`（`round=2`、`requirements={}`）
- `_tmp/qa-core2-20261105/ui/iterate-real.json`
- `_tmp/qa-core2-20261105/ui-probe-notes.md` §6

---

### 4.2 P0（上一轮已报，仍存在）｜Owner 决定/验收没有身份

**现象**

`owner` 命令仍然没有 `--boot`、没有 nonce、没有 TTY 要求；任意本地调用可直接写：

```powershell
node 团队\工具\team.mjs owner --project 'QA空项目' --requirement 'R-20261105-174918-394a' `
  --decision approved --opinion '没有 boot 的外部调用写 Owner 决定' --json
# exit 0, ok=true
```

落账：

```json
{"status":"approved","by":"Owner","actor":false,"channel":"stdio","topStatus":"approved","topBy":"Owner"}
```

UI 现在会诚实地写“by=Owner · 真实 actor 未记录”，但 `by` 仍是 `Owner`，不是执行者身份。`src/main.js` 的 `requirement:owner` / `owner:accept` 仍默认 `role:'owner'`。

**影响**

- Owner 闸门仍可被任何能调 preload/CLI 的本地调用方完成；“六角色 + Owner 闸门”如果作为卖点，这是发版阻断。
- 本轮只修了“pending 不伪造 Owner 记录”，没有修“Owner 记录是谁写的”。

**最小修法**（二选一，必须写进发布说明）

1. 保留闸门：加一次性 nonce / 本机凭据 / TTY，校验后记录 `nonceHash`、`expiry`、`channel`；无凭据返回 `OWNER_IDENTITY_REQUIRED`；
2. 明确降级为单人编排台：字段改为 `recordedBy:"operator"` / `actor:"workbench-shell"`，UI 不再显示“Owner 本人已通过/已验收”。

**证据**

- `_tmp/qa-core2-20261105/ui/owner-no-boot.json`
- `团队/工具/lib/ops.mjs` `cmdOwner`（无 `--boot`）
- `团队/工具/lib/workflow.mjs:704,730-733`（`by:'Owner'`，无 actor）
- 上一轮：`docs/QA-MVP-CORE.md` P0-1

---

### 4.3 P1（上一轮已报，仍存在）｜壳与旧命令双写审计事件/历史

**现象**

通过 app IPC 完成一次动作，`工作流.json` 会多出两条同义记录：

- 产品评审：`product_review=2`、`requirement_review=2`；
- Owner 决定：`owner_review=2`、`owner_requirement=2`。

实测计数：

```text
产品评审后：reqReviewEvents=2, productReviewHistory=2, historyTotal=3
Owner 决定后：ownerReqEvents=2, ownerReviewHistory=2, historyTotal=4
```

**根因**

旧命令自己已经写了一次（`团队/工具/lib/workflow.mjs:571,586`、`:736,761`），`src/team-tools.js` 又在 `mutateWorkflowState` 里再 push 一次：

- 产品评审：`src/team-tools.js:3818-3838`
- Owner 决定：`src/team-tools.js:3926-3953`

**影响**

- 审计链看起来“每个动作记两次”，事件计数/时序不可信；与“一次动作一条记录”的协议冲突。
- 本轮 Owner pending 的修复让 pending 干净了，但已决策动作的双写仍在。

**最小修法**

- 明确唯一写入方：旧命令写，壳只镜像返回值，不再 push；
- 或按 `(action, requirementId, at, command)` 去重；
- 加断言：一次 review 只增加 1 条 history/event。

**证据**

- `_tmp/qa-core2-20261105/ui/team/状态/项目/QA空项目/工作流.json`
- `_tmp/qa-core2-20261105/ui-probe-notes.md` §8

---

### 4.4 P2｜Owner 已决策文案仍写“待 Owner”

**现象**

Owner 已通过/已跳过时，需求卡仍显示：

```text
Owner 已通过 · 待 Owner（by=Owner · 真实 actor 未记录）
Owner 已跳过 · 待 Owner（by=Owner · 真实 actor 未记录）
```

前半句说“已通过/已跳过”，后半句又说“待 Owner”，同一行自相矛盾。

**根因**

`src/renderer/app.js:4079-4088` 的 `legacyOwnerRecordText`：

- `pending/optional` 正确返回“尚未决定 · 待 Owner（无记录）”；
- 有结论但 `actor` 为空时走 `return `${label} ${statusLabel} · 待 Owner（by=... · 真实 actor 未记录）``，把“已决策”也说成“待 Owner”。

**影响**

- 用户无法从文案判断 Owner 到底已经决定还是仍在等待；审计读者也容易被“待 Owner”误导。
- 这是 pending 修复后的显示残留，不影响状态机。

**最小修法**

- 有结论但 actor 未记录时写“已通过（记录人未认证）”，不要写“待 Owner”；
- 或按 §4.2 方案 B 统一成 `recordedBy=workbench-shell`。

---

### 4.5 P2｜项目索引不随需求动作刷新

**现象**

- `项目索引.md` 最后写入：`2026-11-05 17:48:04`（建项目/ensure）。
- `需求/00-需求总览.md` 最后写入：`2026-11-05 17:52:01`（Owner 决定）。
- 17:49/17:52 创建/评审/决定的两条需求没有进入 `项目索引.md` 的“需求目录”表；`项目索引.json` 仍停留在建项目时的空需求列表。

**根因**

- `src/team-tools.js` 只在 `ensureProjectStructure` 发现索引缺失时跑 `team.mjs index`（`:2947-2953`）；
- 需求创建/产品评审/Owner 决定/验收路径结束后没有刷新索引；`项目索引.md` 由 `generateIndex` 重建，但没有被调用。

**影响**

- 角色按“先读索引再找文件”的规则会看不到新需求；PM/测试的对账口径与真实状态分叉。
- 与上一轮 P1-7 同类，只是本轮用新建项目再次复现。

**最小修法**

- 在上述动作成功后调用 `team.mjs index --project <name>`（或把索引标成 stale 并阻断依赖它的操作）；
- 索引 JSON 的 `requirements` 与 `工作流.json` 用同一个真相源。

---

## 五、未证明与边界

1. **真实 DSH 六会话未验证**：本轮 UI 探针用 mock DSH；`npm run selftest` 的 DSH 也是 mock，`prompts before=after=54`。能证明的是壳/旧命令/状态机路径，不是“真实六个角色自己完成闭环”。
2. **UI 探针不是逐按钮点击**：建项目/恢复/建需求通过 preload IPC 调用；boot、全队 boot 是真实点击。产品评审/Owner 决定/迭代守卫通过 IPC 和 DOM 读取验证；没有对每个弹窗做 CDP 点击。
3. **`npm run check` 覆盖不足**：只检查 5 个 src 文件，不检查 `团队/工具/**`；CLI selftest 33/33 和 Electron `SELFTEST_OK` 才是主要证据。
4. **真实项目只做了复制恢复**：`微光作品集` 复制到 `_tmp` 后恢复；没有改写原件。4 位号问题在源码和复制件上可复现，不依赖原件状态。
5. **源码可能继续变化**：本报告快照见 §1；若哈希变了，先按 §2/§6 复跑，不要直接复用结论。
6. **索引刷新问题**：本轮只验证了“创建/评审/Owner 决定”不刷新；没有逐条验证 apply/终止/迭代是否刷新。

---

## 六、复跑命令

```powershell
# 1) 语法（只覆盖 src 5 个入口）
cd D:\deepseek\agile-workbench
Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
npm run check

# 2) 团队 CLI 沙盘（33 项）
node 团队\工具\team.mjs selftest --keep --tmp "D:\deepseek\agile-workbench\_tmp\qa-core2-20261105\cli-tmp"

# 3) Electron 全量自测（隔离根）
$env:AWB_SELFTEST_ROOT="D:\deepseek\agile-workbench\_tmp\qa-core2-20261105\selftest"
$env:TMP="D:\deepseek\agile-workbench\_tmp\qa-core2-20261105\tmp"
$env:TEMP=$env:TMP
.\node_modules\.bin\electron.cmd . --selftest --user-data-dir="$env:AWB_SELFTEST_ROOT\userdata"

# 4) 真实项目需求读取探针（只读）
node _tmp\qa-core2-20261105\probe-real-projects.cjs
```

---

## 七、证据索引

| 内容 | 路径 |
|---|---|
| `npm run check` | `_tmp/qa-core2-20261105/check.log` |
| CLI selftest 33/33 | `_tmp/qa-core2-20261105/cli-selftest.log` |
| Electron selftest `SELFTEST_OK` | `_tmp/qa-core2-20261105/electron-selftest.log` |
| 真实项目读取探针 | `_tmp/qa-core2-20261105/real-projects.json` |
| UI 探针记录（新项目/占位/评审/Owner/迭代/真实项目） | `_tmp/qa-core2-20261105/ui-probe-notes.md` |
| 产品评审原始 JSON | `_tmp/qa-core2-20261105/ui/product-review.json` |
| Owner 无 boot 写入 | `_tmp/qa-core2-20261105/ui/owner-no-boot.json` |
| 真实项目 iterate 到第 2 轮 | `_tmp/qa-core2-20261105/ui/iterate-real.json` |
| 真实项目索引（2 条 4 位需求） | `_tmp/qa-core2-20261105/ui/root/微光作品集/项目索引.json` |
| 真实项目工作流（round=2，requirements={}） | `_tmp/qa-core2-20261105/ui/team/状态/项目/微光作品集/工作流.json` |
| 双写计数样本 | `_tmp/qa-core2-20261105/ui/team/状态/项目/QA空项目/工作流.json` |
| 陈旧索引样本 | `_tmp/qa-core2-20261105/ui/root/QA空项目/项目索引.md` |

---

## 八、发布建议

**可以演示“新建项目 → 第一条需求 → 产品评审 → Owner pending → 迭代守卫”的沙盘链路；不能按“真实项目可恢复、可审计”发布。**

发布前至少处理：

1. **§4.1 真实项目 4 位需求号 + 迭代守卫绕过**（本轮新发现，直接决定“恢复旧项目”能不能用）；
2. **§4.2 Owner 身份**（如果 Owner 闸门是卖点，仍是 P0；如果定位单人编排台，必须改字段和文案）；
3. **§4.3 审计双写**（在宣称“可审计”之前必须唯一写入方）；
4. §4.4/§4.5 是文案与索引一致性问题，可以和下一轮一起修。

修完后用真实 DSH 跑一遍：真实项目恢复 → 六角色 boot → 4 位需求可读 → 产品评审 → Owner 决定/验收 → 有在办需求时 iterate 必须 `ITERATE_BLOCKED`，并保留六个 `sessionId`、一次评审、一次 Owner 决定、一条 `工作流.json` 记录作为证据；不要拿 mock selftest 绿当成真实绿。
