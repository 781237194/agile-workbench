# QA-MVP-ROUND3 · 新项目开箱 / 4 位需求号 / 索引刷新 / 审计去重 / D 盘

> 对象：`D:\deepseek\agile-workbench`
> 时间：2026-11-05 18:47–18:58（Asia/Shanghai）
> 方式：只读源码审计 + `npm run check` + D 盘 Electron `npm run selftest` + `_tmp` 隔离 TeamTools 探针（真实 `team.mjs`/`workspace.mjs`，mock 仅来自 selftest）。
> 边界：未修改 `src/**`、`package.json`、真实 `项目/**`；本轮自己产生的写入只在 `_tmp/qa-mvp-round3-20261105/` 与 `.selftest-data/`。真实 `团队/状态` 在 18:54–18:57 出现另一个 UI 探针项目 `UI闭环-20261105-1852` 的写入，不是本报告的证据链，也不把它的结果算到本轮结论里。

## 0. 一句话结论

**新项目开箱和审计去重本轮通过；4 位需求号“能读能建”但旧项目里“只有正文”的需求仍不能评审/Owner；索引刷新会正常触发，但会把评审/验收记录当成需求，导致一条需求在索引里变成三行。D 盘本次运行通过，“只写 D 盘”仍不是产品硬约束。**

---

## 1. 源码快照

| 文件 | 字节 | SHA-256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 495,404 | `7E491B13D675343A` | 18:34:04 |
| `src/team-tools.js` | 269,565 | `3626C781B72518F1` | 18:36:35 |
| `src/renderer/app.js` | 484,739 | `B4A99AFAA60F0D1A` | 18:41:52 |
| `src/preload.js` | 7,433 | `43D94AF143AB9823` | 13:47:04 |
| `src/renderer/index.html` | 47,331 | `FFBB819B796D2EC4` | 18:26:55 |
| `团队/工具/team.mjs` | 6,868 | `292177D8CD08B6CC` | 18:26:08 |
| `团队/工具/lib/ops.mjs` | 127,740 | `22B02E5565BCA95E` | 18:33:36 |
| `团队/工具/lib/workflow.mjs` | 53,628 | `F63DA2C8DA5BC2CB` | 18:28:27 |
| `团队/工具/lib/store.mjs` | 42,152 | `948BC746ABA33A24` | 18:28:24 |
| `团队/工具/lib/reqid.mjs` | 5,684 | `FB873622B26FA9A7` | 18:28:24 |
| `团队/工具/lib/selftest.mjs` | 46,095 | `1FA22802C304CA27` | 18:34:31 |

`npm run check` 前后、selftest 前后上述哈希一致；本轮没有改源码。

## 2. 判定表

| 重点 | 判定 | 一句话证据 |
|---|---|---|
| 新项目开箱 | **PASS（DSH 在线路径）** | 新项目 `ensure` 后 `项目信息.md`/`项目铁律.md` 都是实文（无占位）；PM 首次 boot `OK`；第一条需求 `R-20261105-0001`（4 位）、单份正文；产品评审、Owner 决定全通。 |
| 4 位需求号 | **PARTIAL** | 新项目默认生成 4 位；真实 `项目/微光作品集` 的 2 条 4 位旧号可读（`accepted`）。但只有 `需求/R-*.md`、没有 `工作流.json` 行/任务文件的 4 位需求，评审/Owner 仍返回 `REQUIREMENT_NOT_FOUND`。 |
| 索引刷新 | **PARTIAL** | 创建/评审/Owner 后确实调用 `index` 且 `ok:true`；但一条需求在评审+Owner 后，`projectIndex.requirements` 从 1 变 2、3，索引表出现 3 行同 ID，后两行指向 `需求/评审/` 记录。 |
| 审计去重 | **PASS** | 产品评审、Owner 决定各只写 1 条 `history`/`event`；`事件.jsonl` 也各 1 条；selftest 对 review/owner/accept 的“只写一次”断言全过。 |
| D 盘 | **PASS（本次运行）/ PARTIAL（产品保证）** | 仓库、`data/`、`.selftest-data/`、自测临时根均在 D；`SELFTEST_ROUND9.drive.checks` 7/7 `d:\`；C 盘 `%APPDATA%\敏捷工作台` 仍停在 02:15。但数据根跟随仓库/`AWB_DATA_DIR`，没有硬编码 D 盘。 |

---

## 3. 新项目开箱：PASS

### 3.1 实测（真实 team.mjs/workspace.mjs，`_tmp` 沙盘）

隔离 TeamTools 探针（`_tmp/qa-mvp-round3-20261105/probe/round3-probe.cjs`）依次做：

1. `ensureProjectReady` 建 `QA开箱`：
   - `structure.ok=true`，`missing=[]`；
   - `项目信息.md` 1,449 B，`项目铁律.md` 497 B；
   - 两份都不命中 `/（待…）|待填写|待补|TODO|TBD/`，不是模板。
2. 首次 `bootRole('pm')`：`ok:true`、`complete:true`、`placeholders:null`。
3. `createRequirement`：`ok:true`，ID `R-20261105-0001`（**4 位**），`docCount=1`，标题含全角冒号仍只有一份正文：
   `需求/R-20261105-0001-第一条需求_开箱即用.md`。
4. 产品 boot 后 `reviewRequirement`：`ok:true`，`driver:team.mjs req review`。
5. `ownerRequirementDecision`：`ok:true`，`driver:team.mjs owner`，需求 `status=ready`。

Electron selftest 的 `SELFTEST_ROUND10` 同时通过“新建项目自动写真实项目信息/铁律”“首次 boot 不被 `PLACEHOLDER_DOC`/`PROJECT_IRON_TEMPLATE` 拒绝”“自动补文档后 boot 通过”等断言，见 `_tmp/qa-mvp-round3-20261105/selftest-default.log`。

### 3.2 边界（既有，不列入本轮新问题）

新项目创建仍要求 DSH 在线：`src/main.js:2465-2470` 的 `activateWorkspace` 失败会抛错并 `rollbackCreatedProject`；selftest 的 `createRollback` 仍以 `DSH_OFFLINE` 失败为预期。**如果“开箱”包含“DSH 离线也能先建本地项目”，这一项仍不通过**；本轮 PASS 只覆盖 DSH 在线（mock）路径。这是上一轮 `MVP-ROUND3-BLOCKERS.md` P1-4，不是本轮新发现。

---

## 4. 4 位需求号：PARTIAL

### 4.1 PASS 部分

- `REQ_FILE_RE` 已放宽为 `/^R-\d{8}-\d{4,8}(?:-[0-9a-f]{2,8})?/i`（`src/team-tools.js:3179`）。
- 真实 `项目/微光作品集` 只读探测：`readRequirementDocs` 返回 `count=2`：
  - `R-20261103-0001` · 首页作品流 · `accepted`
  - `R-20261103-0002` · 作品详情 · `accepted`
  `readWorkflowSnapshot` 也把两条以 `origin:legacy-doc` 放进了需求列表。
- 新项目默认编号已是 4 位，创建标题带全角冒号也只有一份正文；上一轮 P0-1 的“同 ID 两份正文”在本探针未复现。

### 4.2 P1：只有正文的 4 位旧需求，评审/Owner 仍是死路

**现象**

在隔离项目里放一份只有正文的旧需求（4 位号、`- 状态：review`，没有 `任务/R-*.json`、没有 `工作流.json` 需求行）：

```text
需求/R-20261103-0001-旧号需求.md
```

`readWorkflowSnapshot` 能看到它（`origin:legacy-doc`，`status:review`），产品也能 boot 成功（`requirements.count=1`），但：

```json
reviewRequirement:
{"ok":false,"code":"REQUIREMENT_NOT_FOUND","message":"工作流里没有需求 R-20261103-0001"}

ownerRequirementDecision:
{"ok":false,"code":"REQUIREMENT_NOT_FOUND","message":"工作流里没有需求 R-20261103-0001"}
```

**证据**

- `src/team-tools.js:3742-3765`：`readWorkflowSnapshot` 把 `需求/R-*.md` 合并进**只读快照**。
- `src/team-tools.js:4004-4005`：`reviewRequirement` 在调用旧 `req review` 之前先查 `read.state.requirements[requirementId]`，没有就 `REQUIREMENT_NOT_FOUND`。
- `src/team-tools.js:4111-4112`：`ownerRequirementDecision` 同样先查工作流行；`ownerAccept` 也在 `:5210-5213` 先查行。
- `src/renderer/app.js:5449-5450`：只要需求 `status` 是 `review`/`rejected`，界面就渲染「产品评审」按钮；按钮本身不区分“工作流行是否存在”。点击后自动 boot 产品，再调用 `requirement:review`，最终就是这个 `REQUIREMENT_NOT_FOUND`。
- 探针结果：`_tmp/qa-mvp-round3-20261105/probe/round3-summary.json` 的 `legacy` 段；完整日志 `_tmp/qa-mvp-round3-20261105/probe/round3-probe.log`。

**影响**

- 恢复一个旧项目后，只要里面有未收口的 4 位需求（只有正文、没有旧任务/工作流行），界面会显示可点的「产品评审」和「Owner 决定」，但后端永远返回 `REQUIREMENT_NOT_FOUND`；用户会以为文件坏了或权限坏了。
- 这类需求无法进入评审、Owner、派单、验收；“4 位需求号可读”只完成了显示，没有完成可操作。
- 与上一轮 `QA-MVP-CORE2.md` §4.1 的最小修法第 3 条（“reviewRequirement / ownerRequirementDecision 能按正文或任务解析”）对应；该条本轮仍未收口。

**最小修法**

- 在 `reviewRequirement` / `ownerRequirementDecision` / `ownerAccept` 的“查工作流行”之前，如果 `需求/` 下有同 ID 正文但 `state.requirements[id]` 不存在，先补一条工作流镜像行（可标 `origin:'legacy-doc'`），或走旧的 `ensureRequirementRow` 等价路径；不要再让旧命令/正文和工作流行二选一。
- 如果不打算支持“只有正文”的旧项目，则 UI 对 `origin:'legacy-doc'` 且没有工作流行的需求不渲染评审/Owner 按钮，明确提示“先在旧工具建任务/导入”，不要让按钮可点后报 `REQUIREMENT_NOT_FOUND`。

**验收**

- 全新项目里放一份只有正文的 4 位 `review` 需求 → 产品评审成功，`工作流.json` 新增一行，`history`/`event` 各 1 条，需求总览/索引指向同一份正文。
- Owner 决定同样成功；重复点击不产生第二条记录。

### 4.3 P2：显式 `--id` 可以跨 4/6 位撞号，`REQ_ID_TAKEN` 不触发

**现象**

项目已有 `R-20261105-0001`（4 位任务文件）后，直接执行：

```powershell
node 团队\工具\team.mjs req create --boot <product-token> `
  --title '跨宽度重复' --priority P2 --acceptance '验证 4/6 位同号' `
  --id R-20261105-000001 --json
```

返回 `ok:true`，并生成第二个任务文件：

```text
任务/R-20261105-0001.json
任务/R-20261105-000001.json      ← 新增；两号按 sameReqId 是“同一条需求”
需求/R-20261105-0001-第一条需求_开箱即用.md   ← 仍只有这一份正文
需求/00-需求总览.md               ← 仍只有 R-20261105-0001 一行
```

`req list` 返回 2 条：`R-20261105-0001,R-20261105-000001`；但正文和总览都只有 1 份/1 行。

**证据**

- `团队/工具/lib/store.mjs:704-707`：显式 `--id` 只检查 `exists(taskPath(project, parsed.id))`，即**精确文件名**；不检查 `sameReqId` 的另一种宽度。
- `团队/工具/lib/store.mjs:712-729`：`findTaskFile` 反过来又用 `sameReqId(candidate, wanted)` 做 4/6 位互认查找；两个文件会被视作同一需求。
- `团队/工具/lib/reqid.mjs:60-64`：`sameReqId` 把 `R-YYYYMMDD-0001` 与 `R-YYYYMMDD-000001` 判为同号。
- 探针输出：`_tmp/qa-mvp-round3-20261105/probe/round3-probe.log` 的 `req_count=2 ids=...`；`round3-summary.json`。

**影响**

- 两个任务文件对应“同一条需求”，但正文/总览只有一份；后续 `req review`、`owner`、`task claim/done` 可能分别命中不同任务文件，审计上说不清改的是哪条。
- 修复报告声称“`--id` 两种宽度都收，重复报 `REQ_ID_TAKEN`”，实际只挡住了**同宽度精确重复**；跨宽度重复仍可创建。

**最小修法**

- `createTask` 显式 `--id` 分支在落盘前遍历 `任务/R-*.json`，用 `sameReqId` 判重；命中即 `REQ_ID_TAKEN`。同时检查 `需求/` 下同号正文。
- 回归：已有 `0001` 时 `--id 000001` 必须拒绝；已有 `000001` 时 `--id 0001` 也必须拒绝。

---

## 5. 索引刷新：PARTIAL

### 5.1 P2：评审/验收记录被当成“需求”，一条需求变成多行

**现象**

新项目 `QA开箱` 只有 1 条真实需求 `R-20261105-0001`。动作后的索引计数：

| 动作 | `projectIndex.files` | `projectIndex.requirements` |
|---|---:|---:|
| 创建需求 | 24 | 1 |
| 产品评审后 | 25 | **2** |
| Owner 决定后 | 26 | **3** |

`项目索引.md` 的“三、需求目录”实际是：

```text
| R-20261105-0001 | 需求/评审/R-20261105-0001-20261105-185158-a87c.md       | R-20261105-0001 · 产品需求评审 | 已登记 |
| R-20261105-0001 | 需求/评审/R-20261105-0001-owner-20261105-185158-ae20.md | R-20261105-0001 · Owner 需求决定 | 已登记 |
| R-20261105-0001 | 需求/R-20261105-0001-第一条需求_开箱即用.md             | R-20261105-0001 · 第一条需求：开箱即用 | 已登记 |
```

界面会把 `projectIndex.requirements` 显示成“3 条需求”（`src/renderer/app.js:4070`），尽管工作流里只有 1 条。

**根因**

- `团队/工具/lib/ops.mjs:1202` 的 `generateIndex` 用 `scanProject` **递归**扫描项目文件。
- `团队/工具/lib/ops.mjs:1238` 的 `reqRows` 只排除了 4 个固定的顶层文件：

  ```js
  const reqRows = rows.filter((r) => r.target.startsWith('需求/')
    && !['需求/00-需求总览.md','需求/需求模板.md','需求/README.md','需求/文件索引.md'].includes(r.target));
  ```

  没有排除 `需求/评审/**`、`需求/验收/**`；评审和验收记录由 `writeDecisionRecord` 写在 `需求/评审/`、`需求/验收/`（`团队/工具/lib/workflow.mjs:495-498`），文件名又以 `R-...` 开头，`reqIdOf` 能取出同号。
- `团队/工具/lib/ops.mjs:1280` 又按 `reqRows.slice(0, 40)` 渲染需求表；每次评审/Owner/验收都会多一条记录，长期会把真实需求挤出 40 行上限。

**影响**

- “索引刷新”虽然执行了，但刷新结果是错的：索引中的需求数、需求行与实际工作流不一致；角色按索引找需求会看到重复项/评审记录。
- 这个问题在上一轮 `QA-MVP-CORE2.md` §4.5 的“索引不刷新”修复后出现，属于刷新逻辑的**内容正确性**问题，不是刷新没触发。
- Electron selftest 只断言 `projectIndex.ok === true`（`src/main.js:7624`、`:7641`），没有断言需求行数/唯一性，所以绿测抓不到。

**最小修法**

- `generateIndex` 的需求行只取 `需求/` 的**直接子文件** `需求/R-*.md`，或显式排除 `需求/评审/`、`需求/验收/` 目录。
- 或在 `writeDecisionRecord` 里把评审/验收记录放到 `需求/评审/` 的独立索引区，不计入 `requirements`。
- 加断言：一条需求经过创建/评审/Owner/验收后，`项目索引.json.requirements` 仍只有 1 条同 ID，`项目索引.md` 需求表只有 1 行。

**验收**

- 单需求项目走完评审+Owner+验收，`projectIndex.requirements` 始终为 1；索引表没有 `需求/评审/`、`需求/验收/` 行。
- 真实 `微光作品集` 的索引仍只有 2 条需求，不因新增评审记录而增加。

---

## 6. 审计去重：PASS

### 6.1 实测计数

隔离项目 `QA开箱` 一次产品评审、一次 Owner 决定后：

| 位置 | 动作 | 条数 |
|---|---|---:|
| `工作流.json` 需求行 `history` | `product_review` | 1 |
| `工作流.json` `events` | `requirement_review` | 1 |
| `工作流.json` 需求行 `history` | `owner_review` | 1 |
| `工作流.json` `events` | `owner_requirement` | 1 |
| `团队/状态/事件.jsonl` | `requirement_review` | 1 |
| `团队/状态/事件.jsonl` | `owner_requirement` | 1 |

重复调用产品评审在 `boot` 闸门处被 `BOOT_REQUIRED` 挡住（需求状态已变，需要重读），没有产生第二条记录；这不是双写。

### 6.2 selftest 的正向断言

`SELFTEST_ROUND10` 的 `auditCounts` 断言（`src/main.js:7622-7623`、`:7639-7640`、`:7692-7693`）在 D 盘 selftest 中全部通过：

- 产品评审：`productHistory=1 && productEvents=1`
- Owner 决定：`ownerHistory=1 && ownerEvents=1`
- Owner 验收：`acceptHistory=1 && acceptEvents=1`

结论：本轮的“同一动作只写一次 history/event”成立；未发现新的审计双写。

---

## 7. D 盘：本次 PASS

### 7.1 `npm run check`

```powershell
cd D:\deepseek\agile-workbench
Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
npm run check
```

结果：`EXIT=0`。但该脚本只 `node --check` 5 个 `src` 入口（`main.js`、`preload.js`、`renderer/app.js`、`dsh-adapter.js`、`team-tools.js`），不检查 `团队/工具/**`；团队工具由 selftest 覆盖。

### 7.2 `npm run selftest`（D 盘，字面命令）

```powershell
cd D:\deepseek\agile-workbench
Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
npm run selftest
```

结果：`EXIT=0`，日志末尾 `SELFTEST_OK`，`SELFTEST_FAIL` 0 次；各组 `failed=0`：

| 组 | checks | failed |
|---|---:|---:|
| `SELFTEST_STORE` | 20 | 0 |
| `SELFTEST_COMPAT` | 46 | 0 |
| `SELFTEST_MAPPING_RESULT` | 39 | 0 |
| `SELFTEST_ROUND5` | 4 | 0 |
| `SELFTEST_ROUND6` | 17 | 0 |
| `SELFTEST_ROUND9` | 8 | 0 |
| `SELFTEST_ROUND10` | 8 | 0 |

`SELFTEST_ROUND9.drive.checks` 7 个路径全部 `d:\`：仓库、`团队`、自测根、项目状态、提案、legacy 文件、回执文件。`data/` 的 mtime 在本轮前为 18:39，selftest 使用 `.selftest-data/`，没有写真实 `data/`；C 盘 `%APPDATA%\敏捷工作台` 仍为 02:15、`%APPDATA%\Electron` 仍为 16:46，均早于本轮。

### 7.3 D 盘边界（既有，不是本轮新发现）

- `src/main.js:15` 的数据根是 `AWB_DATA_DIR || <仓库>/data`，没有校验盘符；仓库/环境变量在 C 盘时数据会写 C。
- `src/team-tools.js:2046-2057` 的 `assertDataDrive` 只比较“目标盘 == 团队状态盘”，不是硬编码 D；仓库换到 E 盘就允许 E 盘。上一轮 `QA-ROUND9.md` Q9-08 已报，本轮仍在。
- 因此本报告只能说“**本次 D 盘运行通过**”，不能说“产品保证只写 D 盘”。

---

## 8. 复验命令与证据

```powershell
cd D:\deepseek\agile-workbench
Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue

# 1) 语法
npm run check

# 2) D 盘 Electron selftest（字面命令）
npm run selftest

# 3) 五项隔离探针（真实 team.mjs / workspace.mjs；不写真实项目/团队状态）
$env:TEAM_PROJECTS_ROOT='D:\deepseek\agile-workbench\_tmp\qa-mvp-round3-20261105\probe\projects'
node _tmp\qa-mvp-round3-20261105\probe\round3-probe.cjs
```

| 内容 | 路径 |
|---|---|
| `npm run check` 日志 | `_tmp/qa-mvp-round3-20261105/check.log` |
| D 盘 selftest 日志 | `_tmp/qa-mvp-round3-20261105/selftest-default.log` |
| selftest 退出码 | `_tmp/qa-mvp-round3-20261105/selftest-default-exit.txt` |
| 五项探针完整日志 | `_tmp/qa-mvp-round3-20261105/probe/round3-probe.log` |
| 五项探针原始 JSON | `_tmp/qa-mvp-round3-20261105/probe/round3-probe.json` |
| 五项探针摘要 | `_tmp/qa-mvp-round3-20261105/probe/round3-summary.json` |
| 索引多行的 `项目索引.md` | `_tmp/qa-mvp-round3-20261105/probe/projects/QA开箱/项目索引.md` |
| 一条需求的工作流/计数 | `_tmp/qa-mvp-round3-20261105/probe/team/状态/项目/QA开箱/工作流.json` |
| 事件日志 | `_tmp/qa-mvp-round3-20261105/probe/team/状态/事件.jsonl` |

## 9. 边界与未证明

1. **没有启动真实 DSH 六会话**：Electron selftest 的 DSH 是本地 mock（`startMockDsh`），UI 探针也没有在真实 52711 上建项目/建团队。本报告证明的是壳 + `team.mjs` + 状态机路径，不是“真实六个角色自己完成闭环”。
2. **4 位旧号评审的 UI 路径没有逐按钮点击**：结论来自真实后端函数 + `app.js` 按钮条件 + 探针返回；按钮确实会出现在 `status:review` 的 `legacy-doc` 行上（`src/renderer/app.js:5449-5450`）。
3. **索引多行只在单需求小项目实测**：结论按 `generateIndex` 递归规则同样适用于多需求/多评审记录；没有在真实 `微光作品集` 上执行写入验证（只读真实项目）。
4. **真实 `团队/状态` 的 `UI闭环-20261105-1852` 写入是同期另一个 UI 探针进程**，不是本轮 QA 自己；本报告不采用它的结果。
5. **D 盘只证明本次运行**：要变成产品保证，需要把数据根固定到 D 或显式 `DATA_DRIVE_REQUIRED` 校验，见 §7.3。

## 10. 发布建议

1. **先修 P1（§4.2）**：恢复旧项目后，只有正文的 4 位需求必须能评审/Owner，或明确禁止并给出导入入口；否则“4 位需求号可读”只到显示层。
2. **再修 P2（§5.1）**：索引需求行只认直接子文件，避免评审/验收记录污染需求数；这是“索引刷新”能否被信任的关键。
3. §4.3 的跨宽度 `--id` 撞号是边界问题，但修起来很小，建议和编号回归一起收口。
4. D 盘边界（§7.3）是既有 P3，若本轮发布说明仍写“只写 D 盘”，需要先改成“本次运行/同盘”或补硬校验。
