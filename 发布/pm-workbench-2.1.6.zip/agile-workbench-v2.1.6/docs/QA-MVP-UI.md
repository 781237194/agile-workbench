# MVP UI 只读 QA：建项目 → 建团队 → 六角色 → 流程 → Owner → 迭代/终止

- 仓库：`D:\deepseek\agile-workbench`
- 时间：2026-11-05 16:57–17:26（Asia/Shanghai）
- 边界：**只新增本文件**。临时环境全部在 `_tmp\qa-mvp-ui\`；未改 `src\**`、`package.json`、`package-lock.json`、真实 `data\**`、真实 `团队\状态\**`、真实 `项目\**`，也未改旧仓库 `D:\deepseek\工作台`。
- 方法：读渲染层/主进程源码 → 用**真实 `src\**` 与真实 `团队\工具`** 启动真实 Electron（`AWB_DATA_DIR` / `AWB_STORE` / `TEAM_ROOT` / `TEMP` 全部指向沙盘）→ CDP 读 DOM、点真实按钮、截图 → 另用一个**只读故障注入副本**验证“缺旧命令”路径。
- 对照：`docs/QA-ROUND12-UI.md`（上一轮 UI）、`docs/MVP-BLOCKERS.md`（链路与 Owner 根因）；本报告只判 UI 行为，不重复判后端 P0/P1。
- DSH：沙盘里用 `_tmp\qa-mvp-ui\mock-dsh.cjs`（127.0.0.1:9401）实现 `session/list`、`workspace/create`、`session/create`、`session/rename`、`session/prompt`、`session/selectModel` 等真实 RPC 形状，用于建项目/建团队，**不碰用户真实 DSH 的任何会话**。另有一次真实 DSH（127.0.0.1:52711）只读加载，只调了 `session/list`。
- 截图与脚本：`_tmp\qa-mvp-ui\`（`shots\`、`mock-dsh.cjs`、`launch.cmd`、`launch-oldtools.cmd`、`app-oldtools\`）。

> **源码快照**（本报告只对这个快照负责；QA 前后哈希一致）：

| 文件 | 字节 | SHA-256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 475,115 | `ED812497D4F7A94C` | 16:47:00 |
| `src/team-tools.js` | 250,696 | `A268800BAF24FF55` | 16:47:00 |
| `src/preload.js` | 7,433 | `43D94AF143AB9823` | 13:47:04 |
| `src/renderer/app.js` | 460,602 | `2F28D416E25170EB` | 16:55:18 |
| `src/renderer/index.html` | 47,200 | `2271AF226C49064E` | 16:40:00 |
| `团队/工具/team.mjs` | 6,198 | `B08FC4B5E5B22D5C` | 16:37:41 |
| `团队/工具/lib/workflow.mjs` | 40,660 | `496F13DDDFB7FC8D` | 16:41:11 |

---

## 0. 一句话结论

**建项目、建团队这两个动作本身能完成，但建完之后界面走不到第一条需求**：新项目还没有任何需求时，`workflow:state` 返回 `local-fallback` 且把所有旧命令能力丢成 `legacy: null`，于是“新建需求”“boot”“产品评审”等按钮全部被禁用，界面还显示“缺旧命令 12”——而同一份 `团队/工具` 的能力其实是 `missing: []`。这是本轮唯一的 P0，直接堵死 MVP 主链第一步。

在此之外，boot 过期与缺命令的禁用/恢复已经做对（上轮两个 P1 已修）；Owner 仍然把“产品评审时预写的 `by: 'Owner'` 占位”显示成 Owner 已记录，迭代按钮在没有阶段守卫时也可点，这两条是本轮 P1/P2。

---

## 1. 检查面结论

| 检查面 | 结论 | 一句话证据 |
|---|---|---|
| DSH 主画面 | **可用**（1 个旧 P3 仍在，不重复计） | 真实 DSH 页面标题 `DeepSeek Harness`、`已连接 DSH · 214 个会话`；沙盘 mock 页面也能加载；首屏仍可能短暂同屏出现旧“引擎没有连上”卡（R12 P3 未变）。 |
| 建项目 / 建团队 | **不通过（P0）** | mock DSH 下建项目成功、建团队成功（6 会话 + 6 条就位）；但建完后 truth 仍是 `旧命令 未读取`、`boot 0/6`，“新建需求”“全队 boot”全禁用。 |
| 六角色目录 / 必读 | **数据通过，入口被 P0 挡住** | 目录 6/6、角色卡 6/6、文件索引 6/6、boot 证据带令牌哈希；但新项目里六个 `boot` 按钮都因 `legacy.capabilities` 未返回而禁用。 |
| 流程按钮 | **有需求后通过；新项目不通过** | 有需求后产品评审 / Owner 决定 / PM 派单 / Owner 验收从 UI 执行成功（开发/测试中间步走 IPC）；新项目里“＋ 产品/需求新需求”`disabled=true`。 |
| boot 过期 | **通过（上轮 P1 已修）** | 把 6 条 boot 前移 40 分钟：truth 变 `boot 0/6 · 过期 6`、徽章 `boot 已过期 · 禁止推进`、六角色按钮变可点的“重新 boot”；点 pm 后 `1/6 · 过期 5`。 |
| 缺命令 | **通过（上轮 P1 已修）** | 旧工具副本（`team.mjs` 6,986 B，缺 workflow/owner/req review）：truth `旧命令缺 3`，迭代/终止按钮禁用并写“缺「workflow」”，产品评审禁用并写“缺「req review」”。 |
| Owner | **不通过（P1）** | 产品评审一通过，需求卡就显示 `Owner pending · Owner（by=Owner · actor 未记录）`；Owner 验收记录 `by=owner`，全链路没有身份证明或“未认证”标注。 |
| 迭代 / 终止 | **终止通过；迭代 P2** | 终止必须写原因（空原因被后端 `[OPINION_REQUIRED]` 拒绝，弹窗不关）；但在“待 PM 派单”时点迭代仍成功：轮次 +1、需求留在“第 1 轮”、六角色 boot 全部跨轮失效，界面没有任何拦截或警告。 |

---

## 2. P0：新项目建完就卡死，第一条需求和 boot 都点不了

### 2.1 复现（真实 UI，非 mock 状态注入）

沙盘步骤：真实 `createProject` → 真实 `dshProvision`（建团队）→ 打开项目面板。项目名 `QA死锁项目`，DSH 为 9401 的 mock，`团队/工具` 是当前仓库那一份（`legacyCapabilities().missing = []`）。

建团队成功后，左侧已经是 `团队 6/6 / 会话 6`，但：

```text
#project-truth
preload 已加载 | IPC 齐全 | 文件 40 | workflow 已读 | briefing 已读 | 旧命令 未读取 | boot 0/6 | 账本一致 | 模板占位 2

.legacy-gate-facts
boot/已读 0/6
文件就绪 8/9
已过期 0 个角色
缺旧命令 12
文档变更 0 个角色
阶段 idle
```

DOM 实测（三个入口都是禁用）：

```text
[data-legacy-req-action="requirement-create"]  disabled=true
  title="旧命令能力未读取（workflow:state 没有返回 legacy.capabilities）：不能确认命令存在，按钮保持禁用"

[data-legacy-req-action="owner-create"]        disabled=true（同一原因）
[data-legacy-boot]（6 个角色）                  disabled=true（同一原因）
#legacy-boot-all                               文字“全队 boot（缺 6）”，disabled=true
```

`workflow:state` 的真实返回：

```json
{ "ok": true, "truthSource": "local-fallback", "phase": null, "legacy": null,
  "requirements": [], "boots": {}, "workflow": null }
```

同一时刻直接调 `teamTools.readWorkflowSnapshot('QA死锁项目', <path>)` 是成功的，且带 `legacy.capabilities`（`managed:false`、`requirements:0`、`missing:[]`）——是主进程把它丢掉了，不是工具没能力。

截图：`_tmp\qa-mvp-ui\shots\20-deadlock-fresh.png`（建团队前）、`22-deadlock-flow.png`（建团队后仍死锁）、`23-deadlock-roles.png`（六角色 boot 全禁用）。

### 2.2 源码路径

1. `src/main.js:2662-2664`：`workflow:state` 只在 `legacy.legacy.managed || workflowTasks.length || requirements.length` 时返回旧工具快照：

   ```js
   if (legacy && legacy.ok && (legacy.legacy && legacy.legacy.managed
     || workflowTasks.length
     || (legacy.requirements && legacy.requirements.length))) {
   ```

   条件成立才 `return { ...legacy, ... }`（2665-2681）；否则落到下面的 fallback。

2. `src/main.js:2688-2702`：否则走 `local-fallback`，并且**显式写死 `legacy: null`**：

   ```js
   return {
     ok: true,
     ...
     truthSource: 'local-fallback',
     phase: null,
     requirements: [],
     boots: {},
     workflow: null,
     legacy: null,
     ...
   };
   ```

3. `src/renderer/app.js:3706-3710`：渲染层只从 `workflow.legacy.capabilities` 取能力；`legacy` 为 `null` 就等于“能力未知”。

4. `src/renderer/app.js:3775-3781`：能力未知时，`legacyActionCommandGate` 对**所有**动作返回禁用：

   ```js
   const { caps } = legacyCapabilityData();
   if (!caps) {
     return { ok: false, missing: commands.slice(),
       reason: '旧命令能力未读取（workflow:state 没有返回 legacy.capabilities）：不能确认命令存在，按钮保持禁用' };
   }
   ```

5. `src/renderer/app.js:4140`：真相条此时还会把它写成“旧命令缺 N”，与“未知”混为一谈；gate facts 里的 `缺旧命令 12` 是 `legacyFlowCommandGaps()`（`:3808-3814`）把各动作缺失命令去重后的数量，不是真的缺 12 条命令。

### 2.3 影响

- **新项目在 UI 上没有第一步**：既不能 boot（六角色在，但 boot 按钮全禁用），也不能新建需求；建团队 6/6 之后仍然如此。
- 唯一绕路是从 preload/CLI 直接调 `requirement:create`（本轮为了继续测后面流程，就是这样造出第一条需求的）。普通用户没有这个入口。
- 这不是数据缺失：同一个 `team.mjs` 能力齐全；只是 `workflow:state` 在“还没有需求”时把 `legacy` 丢了，UI 把“未知”当“缺失”。
- 对一个以“建项目 → 建团队 → 六角色 → 需求 → …”为主链的 MVP，这是发布阻断项。

### 2.4 最小修法（二选一）

- **A（推荐，主进程修）**：`local-fallback` 分支也返回 `legacy`（至少 `{ available, commands, missing, reqReview, ... }`），`legacy: null` 改为从 `readWorkflowSnapshot` 的 legacy 字段透传；`truthSource` 仍可标 `local-fallback`。
- **B（渲染层兜底）**：`legacyCapabilityData()` 在 `legacy` 缺失时改用 `workflow:get` / `team:status` 里的能力；同时在 `caps` 未知时不要把“新建需求 / boot”这类**不依赖能力矩阵**的动作禁用（它们只依赖 IPC 是否存在），并把真相条改成“旧命令 未知”而不是“缺 12”。

### 2.5 验收

- 新建一个空项目（无 `工作流.json`、无需求）→ 打开项目面板：真相条为“旧命令齐全”（或至少不是“未读取/缺 12”），“＋ 产品/需求新需求”和六角色 boot 可点；点 boot 返回真实 `BOOT_OK`。
- 建团队 6/6 后再走一遍：boot 仍可点，不再需要 CLI 造需求。

---

## 3. P1：Owner 还没决定，界面已经显示 `Owner` 的记录

### 3.1 证据

1. 在 `QA过期项目` 上完成产品评审（approve）后，需求卡立刻变成：

   ```text
   产品评审 approve · 产品设计师（by=product · actor 未记录）
   Owner pending · Owner（by=Owner · actor 未记录）
   ```

   截图：`_tmp\qa-mvp-ui\shots\21-owner-pending-fabricated.png`。

2. 团队台“评审 / 回执 · 真实 actor”里，Owner 验收记录又是另一种写法：

   ```text
   R-20261105-170446-7737 · Owner 验收
   Owner · 通过
   by=owner · actor=执行者未记录
   ```

   同一份工作流里，需求评审写 `by=Owner`，验收写 `by=owner`；两者都没有执行者/身份来源。

3. 源码：

   - `团队/工具/lib/workflow.mjs:571-572`：**产品评审通过时**就写

     ```js
     row.ownerReview = { status: 'pending', by: 'Owner', at: null, opinion: '' };
     ```

   - `团队/工具/lib/workflow.mjs:704`：验收记录写 `by: 'Owner'`，来源字段只是 `channel: 'tty'/'stdio'`。
   - `src/main.js:3879`、`src/main.js:3950`：`requirement:owner` / `owner:accept` 默认 `role: 'owner'`。
   - `src/renderer/app.js:5157-5159`：需求卡只要 `ownerReview` 存在就渲染 `by`，不管 `status` 是不是 `pending`。
   - 旧 `owner` 命令没有 nonce / TTY / 凭据（`MVP-BLOCKERS.md` P0-1 已判）；本报告不重复判后端，只记界面表达。

### 3.2 影响

- 产品评审刚通过、Owner 还没看，界面就出现一条 `by=Owner` 的记录；审计读者会把它当成“Owner 已留下记录”。
- Owner 通过/验收本身仍是无身份的自称（任何能调 IPC 的本地调用方都能完成），而 UI 文案是“Owner 决定 / Owner 验收”“Owner approved”，没有“由工作台代记 / 未认证”的提示。
- 对“Owner 闸门”是卖点的产品，这使 UI 层也无法自证这条记录是谁做的。

### 3.3 最小修法

- `pending` 记录不要写/不要显示 `by`：`ownerReview: { status:'pending' }`，UI 显示“Owner 尚未决定（无记录）”。
- 验收/评审记录若保留 `by: 'Owner'`，UI 增加“记录人：工作台壳（未认证）”或按方案 B 改成 `actor=workbench-shell`。
- 统一 `Owner` / `owner` 的大小写，避免同一字段两种拼写。

---

## 4. P2：迭代按钮没有阶段守卫，点一次就把本轮 boot 全部作废

### 4.1 证据

在 `QA流程项目`，需求状态 `待 PM 派单`、truth `boot 6/6` 时：

```text
#legacy-iterate  disabled=false  title="启动下一轮（PM）"
#legacy-terminate disabled=false title="终止工作流（PM）"
```

点“迭代”只弹一个“说明”文本框（可空），没有“当前还有 1 条需求未收口”的提示。执行后后端返回 `OK`，随后：

```text
workflow:state →
  round: 2
  requirements: [{ id: "R-20261105-170446-7737", status: "ready", round: 1, queued: false }]

#project-truth →
  ... | boot 0/6 | ...

需求卡 →
  待 PM 派单 / 第 1 轮
```

即：工作流已经第 2 轮，在办需求仍标“第 1 轮”，六角色 boot 全部因 `roundMismatch` 失效；界面没有“轮次不一致”的整体提示，只把 boot 归零。

### 4.2 源码

- `src/renderer/app.js:4375-4396`：“迭代 / 终止”只按 `pmReady && iterateGate.ok` 启用，没有看 `phase`、有没有在办需求、是否有未收口任务。

  ```js
  const iterateReady = pmReady && iterateGate.ok;
  const terminateReady = pmReady && terminateGate.ok;
  ```

- `团队/工具/lib/workflow.mjs:856-876`：`iterate` 只做“round+1、释放 queued”，不检查在办需求状态，也不关闭/迁移当前需求。
- `src/renderer/app.js:4788-4790`：迭代表单只有“说明”，没有必填校验。

### 4.3 影响

- 误点一次“迭代”，本轮所有角色的 boot 证据作废（必须全队重 boot），需求还停在旧轮次；用户只看到 boot 从 6/6 变 0/6，很难把原因归到“我刚才点了迭代”。
- 与“终止”不同，迭代没有二次确认语义（没有“会作废本轮 boot”的警告），却是同样危险的状态变更。

### 4.4 最小修法

- 只在“没有未收口需求 / 上一条需求已 accepted”时启用迭代；否则禁用并写“还有 N 条需求未收口，先验收或终止”。
- 或保留可点，但弹窗明确写“本轮 boot 将全部作废、在办需求留在第 N 轮”，并要求写说明。
- 迭代后如果 `requirements[].round !== state.round`，在需求卡和真相条上显式标“旧轮需求 · 操作会被后端拒绝”，不要只让 boot 变 0/6。

---

## 5. P3：终止后 gate 徽章仍写“未核验”，与正文“已终止”矛盾

终止成功后（`shots\14-terminated.png`）：

```text
.legacy-gate-result  → “工作流已终止：不再接受推进”
#legacy-gate-badge   → “未核验 · 禁止推进”（红色）
#project-truth       → “… | boot 6/6 | …”（没有 terminated 芯片）
```

`src/renderer/app.js:4353-4357` 的徽章只分 `open` / `expired` / 其他，没有 `terminated` 分支，所以终止态落进“未核验”。这会让用户以为“还没核验”，而不是“已经终止”。

建议：`phase === 'terminated'` 时徽章写“已终止 · 只读”，truth 条增加 `已终止` 芯片（并保留 boot 记录但不再显示为“可推进”）。

---

## 6. P3：新项目固定显示“文件就绪 8/9”，把“其他文档 0 份”算成缺一项

新项目（无任何角色附加文档）的 gate facts 固定是：

```text
文件就绪 8/9
```

而同屏 `#legacy-docs-summary` 写的是：

```text
目录 6/6 · 角色卡 6/6 · 文件索引 6/6 · 其他文档 0 份 · 项目索引 存在 · boot 6/6 · 只读
```

源码 `src/renderer/app.js:4247-4249` 把 9 项都当必要条件，其中最后一项是 `Boolean(ready.others)`；新项目本来就没有“其他文档”，于是永远红 8/9。用户会去找那份不存在的文件。

建议：`others` 不作为 9 项之一（或标“可选 0 份”），就绪分母改为 8。

---

## 7. 已验证通过的部分

### 7.1 boot 过期（上轮 P1 已修）

把 `_tmp\qa-mvp-ui\team\状态\项目\QA过期项目\工作流.json` 的六条 `boots.*.at` 前移 40 分钟，刷新后：

| 检查 | 实测 |
|---|---|
| truth | `boot 0/6 · 过期 6` |
| 徽章 | `boot 已过期 · 禁止推进`（红） |
| gate 正文 | “有 6 个角色的 boot 已过期（默认 30 分钟）…点该角色的「重新 boot」或「全队 boot」” |
| 六角色按钮 | 文本 `重新 boot`，`disabled=false`，title 写“boot 已过期（超过 30 分钟） · 需重新 boot” |
| `#legacy-boot-all` | `全队 boot（过期 6）`，`disabled=false` |
| 点 pm 的“重新 boot” | truth 变 `boot 1/6 · 过期 5`，pm 变 `已 boot` |

源码：`src/renderer/app.js:3452-3467` 已把 `expiresAt` / `expired` / `roundMismatch` 纳入 `ready`；不再出现上轮“绿色可推进 + 全部按钮禁用”的死锁。截图：`shots\15-boot-expired.png`。

### 7.2 缺旧命令（上轮 P1 已修）

用一个**只读副本** `_tmp\qa-mvp-ui\app-oldtools\`（`src` 与当前一致，`团队\工具` 换成 `D:\deepseek\工作台\团队\工具`，`team.mjs` 6,986 B，`legacyCapabilities().missing = ["workflow","owner","req review"]`）启动，结果：

```text
#project-truth → “旧命令缺 3”
[data-legacy-req-action="iterate"]   disabled=true
  title="当前 team.mjs 缺旧命令「workflow」：按钮已禁用，先升级团队工具；界面不会伪造成功"
[data-legacy-req-action="terminate"] disabled=true（同上）
[data-legacy-req-action="requirement-review"] disabled=true
  title="当前 team.mjs 缺旧命令「req review」：按钮已禁用…"
[data-legacy-req-action="owner-create"] 仍可点（它只需要 req create），实点返回 OK
```

截图：`shots\16-oldtools.png`。这证明“缺命令→按钮禁用→写清缺哪条”已经闭环，不再是上轮的“可点死按钮”。

### 7.3 建团队与六角色数据

- `dshProvision` 在 mock DSH 下创建 6 个会话、补发 6 条“已就位”，左侧 `团队 6/6 / 会话 6`，`团队.json` 的 `activeProject` 切到当前项目；toast：`新建 6 个角色会话；补发 6 条首轮就位；1 条非致命告警`（`shots\05-team-ready.png`）。
- 六角色页：`目录 6/6 · 角色卡 6/6 · 文件索引 6/6`，表格逐行显示目录/角色卡/索引、`已映射 mock-sess-…`、`已 boot / 已读全 11/05 17:08`、`工作流.json boots：必读齐全 · 令牌 9c4706…`（`shots\19-roles.png`）。
- 必读文档是真实正文，不是模板预览；boot 证据带 `hashChecks` / tokenHash，缺证据时写“未记录”。
- 模板占位仍存在时，gate 徽章是黄色的 `可推进 · 模板占位 2 份`，不再同时给绿色“已读全”（R12 P2 的呈现已修）。

### 7.4 有需求后的主链按钮

为了绕开 P0，先通过 preload 直接建了第一条需求（`R-20261105-170446-7737`）。之后**评审 / boot / Owner / 派单 / 验收从 UI 按钮点**；开发与测试的中间步骤（认领、提案、互审、apply、task done）为了节省时间走同一套 preload IPC，不是 UI 点击——这几步只用于把状态推到 `test_done`，不作为按钮 UI 的通过证据：

1. 产品评审（UI）→ `OK`，需求变“待 Owner 决定”，弹出错误时弹窗保留错误码；
2. 全队 boot（UI）→ 6/6；
3. Owner 决定（UI）→ 通过 `OK`，需求变“待 PM 派单”；
4. PM 派单（UI）→ `OK`，生成开发任务 `T-20261105-170729-d3a3`；
5. 开发认领 / 提交提案 / 互审 / PM 签字 apply / 完成开发（IPC）；
6. 派测试 / 测试认领 / 完成测试（IPC，带证据）；
7. Owner 验收（UI）→ 通过 `OK`，需求“已验收”。

Owner 验收弹窗会按决定分列证据要求：“通过/打回需 tester（已 boot/已读全）；转下一轮/终止需 PM（已 boot/已读全）”，与实际后端校验一致。截图：`shots\10-owner-dialog.png`、`12-accept-dialog.png`。

### 7.5 终止必须写原因

空原因点“执行”→ 弹窗不关，显示：

```text
[OPINION_REQUIRED] 终止工作流必须写原因（--opinion）：为什么要停、遗留什么
```

补原因后执行 `OK`，需求/任务收口，迭代/终止/新需求按钮全部 `disabled=true`（title“工作流已终止”），历史需求只读；`shots\14-terminated.png`。唯一遗留是 §5 的徽章文案。

---

## 8. 观察（未计入缺陷，供产品/PM 决定）

1. **每走一步都要重 boot 六角色**：产品评审、Owner 决定、派单、验收都会改写 `需求/00-需求总览.md` 等 boot 哈希覆盖的文档，动作完成后 truth 立刻从 `boot 6/6` 变 `0/6`，下一步按钮禁用，必须再点“全队 boot”。UI 是诚实的（写“boot 后文档已变更”），但按“每轮 boot”的产品语义，这会变成“每个动作前 boot 一轮”。如果这是有意的安全设计，建议在文档/引导里写明；如果不是，boot 哈希范围应排除“会被流程自己改写”的文件。
2. **DSH 主画面**：真实 DSH 页面可加载（`DeepSeek Harness` / 214 会话），mock 页面也能作为主画面；首屏仍可能出现旧的“DSH 引擎没有连上”卡片与“已连接 DSH · 214 个会话”同屏（R12 P3），数秒后自愈，本轮不重复计为问题。
3. **建团队告警只有数量**：首次建团队 toast 末尾是“1 条非致命告警”，界面没有展开/详情入口；复跑同一项目时 `warnings` 已为空，用户再也看不到那条告警是什么。建议在团队台保留最近一次 provision 的 warnings。
4. **`index.html` 的 webview 初始 `src` 仍是 `http://127.0.0.1:52711`**（`src/renderer/index.html:181`）；配置了别的地址时，首帧仍会先打开本机 52711 上的实例，随后才被 `applyDshViewSrc()` 改掉。R12 已记为边界问题，本轮未改。

---

## 9. 只读边界与副作用

- 新增文件：仅 `docs\QA-MVP-UI.md`；所有临时文件在 `_tmp\qa-mvp-ui\`（`data\`、`team\`、`projects\`、`temp\`、`shots\`、`app-oldtools\`）。
- 未修改：`src\**`、`package.json`、`package-lock.json`、真实 `data\**`、真实 `团队\状态\**`、真实 `项目\**`、`.selftest-data\**`、旧仓库 `D:\deepseek\工作台`、`D:\deepseek\luanyujia-workbench`。
- 真实 `团队\状态\事件.jsonl` 在 17:05 有写入，但项目名是 `MVP验收-20261105-1705` / `微光作品集`，来自同时进行的另一场验收；本 QA 的三个项目名（QA流程/QA过期/QA死锁）没有出现在真实事件里。真实 `data\**` 的最大时间戳仍是 16:31。
- 启动过两个沙盘 Electron（CDP 9351 / 9352）和一个 mock DSH（9401），QA 结束后已停止；用户 14:51 启动的原始工作台进程仍在，未被重启。
- `npm run check` 未跑（不证明 UI）；源码哈希 QA 前后一致（见首表）。

---

## 10. 我没能证明的部分

- **建项目 / 建团队使用的是 mock DSH**，不是用户真实的六角色 agent 执行；本报告只证明 UI 在真实 IPC / 真实 `团队/工具` / 真实 Electron 下的行为，不证明真实 DSH `workspace/create` / `session/create` / seed 的表现完全一致。
- **boot 过期是改时间模拟的**（前移 40 分钟），没有真的等 30 分钟；`expiresAt` 的计算与后端 `requireWorkflowBoot` 同为 `bootTtlMinutes`（30），但没有跨时区/时钟回拨测试。
- **缺命令是故障注入**（只读副本 + 旧 `团队/工具`），不是当前发行物真实状态；当前 `team.mjs` 的命令矩阵是齐的。
- **迭代 / 终止**只在沙盘项目上执行，没有在真实项目上验证；终止后六角色 DSH 会话是否仍在活动，本轮没有驱动真实会话，未验证。
- **Owner 身份**的根因在后端（`MVP-BLOCKERS.md` P0-1），UI 只能选择怎么表达；本轮没有测试 nonce/TTY 凭据，因为当前实现没有。
- DSH 主画面只验证了“容器能加载/连接”，没有在真实 DSH 页面里点“定位会话”“重载工作区”等依赖页面 DOM 的动作。

---

## 附：复验入口（选择器 / 文件）

| 要复验的现象 | 入口 |
|---|---|
| 新项目死锁 / 旧命令未读取 | `#project-truth`、`.legacy-gate-facts`、`[data-legacy-req-action=requirement-create]`、`[data-legacy-boot]` |
| `workflow:state` 丢能力 | `window.workbench.workflowState({projectId})` → `truthSource` / `legacy` |
| Owner pending 占位 | 产品评审通过后的 `#legacy-requirements` 文本、`#team-actor-list` |
| 迭代无守卫 | `#legacy-iterate`（`disabled` / `title`）、执行后的 `workflow:state.round` 与 `requirements[].round` |
| 终止后徽章 | `#legacy-gate-badge`、`.legacy-gate-result` |
| 文件就绪 8/9 | `.legacy-gate-facts`、`#legacy-docs-summary` |
| boot 过期 | `#legacy-gate-badge`、`[data-legacy-boot]`、`#legacy-boot-all` |
| 缺命令 | `#project-truth`、各 `[data-legacy-req-action]` 的 `title` |

沙盘脚本：`_tmp\qa-mvp-ui\mock-dsh.cjs`（mock DSH）、`launch.cmd`（正常沙盘）、`launch-oldtools.cmd`（缺命令副本）、`cdp.cjs`（CDP 读 DOM / 截图）。

---

## 对账回执

- 对账人：只读 UI QA
- 复核人：待 PM / 开发
- 结论：**有异常，停手**（P0 一个：新项目无法从 UI 开始第一轮；P1 一个：Owner 占位记录；P2 一个：迭代无阶段守卫）
- 备注：P0 是 `workflow:state` 的 fallback 丢 `legacy` 引起，修复点很小但影响主链第一步；P1 与 `MVP-BLOCKERS.md` P0-1 同根，UI 只能改善表达，不能替代后端身份方案。
