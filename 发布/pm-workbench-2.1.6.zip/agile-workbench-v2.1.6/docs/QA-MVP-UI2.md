# MVP UI 第二轮只读 QA：新项目首链 / Owner 显示 / 过期 / 迭代 / DSH 主画面

- 仓库：`D:\deepseek\agile-workbench`
- 时间：2026-11-05 17:44–18:05（Asia/Shanghai）
- 边界：**只新增本文件**。临时环境全部在 `_tmp\qa-mvp-ui2\`；未改 `src\**`、`package.json`、`package-lock.json`、真实 `data\**`、真实 `团队\状态\**`、真实 `项目\**`，也未改旧仓库 `D:\deepseek\工作台`。
- 方法：用**当前真实 `src\**` 与真实 `团队\工具`** 启动真实 Electron（`AWB_DATA_DIR` / `AWB_STORE` / `TEAM_ROOT` / `TEMP` 全部指向沙盘）→ CDP 读 DOM、点真实按钮、截图。建项目 / 建团队走 `_tmp\qa-mvp-ui2\mock-dsh.cjs`（127.0.0.1:9403）的 mock DSH；另起一个只读实例加载**真实 DSH 52711** 只做主画面验证，不建项目、不建会话。
- 对照：`docs/QA-MVP-UI.md`（上一轮 UI QA）、`_tmp\团队工具修复报告-20261105.md`（17:24 的四处团队工具修复）。本报告只判 UI 行为与 UI/后端口径是否一致，不重复判后端身份方案。
- 环境：Windows / Electron 33 / Chromium 130；沙盘项目 `QA2-新项目`、`QA2-空项目`；外部手改文档只发生在沙盘 `projects\**`。

> **源码快照**（本报告只对这个快照负责；QA 前后哈希一致）：

| 文件 | 字节 | SHA-256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 485,999 | `9702CD2BBE56F3BB` | 17:31:10 |
| `src/team-tools.js` | 257,673 | `98EC8125AE4A4DA7` | 17:26:40 |
| `src/preload.js` | 7,433 | `43D94AF143AB9823` | 13:47:04 |
| `src/renderer/app.js` | 474,347 | `6D6F44138EF79C19` | 17:39:58 |
| `src/renderer/index.html` | 47,200 | `2271AF226C49064E` | 16:40:00 |
| `团队/工具/team.mjs` | 6,371 | `C4A8579A7CE3167B` | 17:24:33 |
| `团队/工具/lib/store.mjs` | 36,499 | `A5943EC3B446077E` | 17:30:16 |
| `团队/工具/lib/workflow.mjs` | 44,260 | `E987C0C580440926` | 17:30:06 |

---

## 0. 一句话结论

**上一轮的 P0（新项目里「新建需求 / boot」按钮全禁用）已经修好**：空项目的 `workflow:state` 现在带 `legacy.capabilities`，真相条是「旧命令齐全」，`文件就绪 8/8`，`＋ 产品/需求新需求` 与六个 boot 按钮都可点。

**但新项目仍然走不到第一条需求**：点「全队 boot」会得到 `PLACEHOLDER_DOC`（项目信息还是模板）；把项目信息写实后，又会被 `PROJECT_IRON_TEMPLATE`（项目铁律还是团队默认模板）挡住；而界面只有「查看」只读预览、文件预览里的「用系统程序打开」和「打开目录」，没有应用内编辑，闸门与错误弹窗也不直接把这两个入口递到用户手上。必须在应用外手改至少 `项目信息.md`、`项目铁律.md` 两份文件，主链才能继续——这达不到「新项目开箱可建需求 / 可全队 boot」的验收口径。

除此之外：**boot 过期、迭代守卫、Owner pending（不再伪造 by=Owner）、DSH 主画面都通过**。两个 P2 分别是「闸门的文档判断与后端不一致/不刷新」和「Owner 通过后仍显示『待 Owner』」。

---

## 1. 检查面结论

| 检查面 | 结论 | 一句话证据 |
|---|---|---|
| 新项目建需求 | **不通过（P1，需应用外手改文档）** | 空项目首条需求弹窗报 `[PLACEHOLDER_DOC] 项目信息…`；写实项目信息后报 `[PROJECT_IRON_TEMPLATE] 项目铁律…`；两份都写实后建需求 `OK`（`R-20261105-175817-b3f2`）。 |
| 全队 boot | **条件通过（P1）** | 空项目 `全队 boot` 6 个角色全被 `PLACEHOLDER_DOC` 拒绝；手改文档后 `全队 boot` 成功 `6/6`；过期状态可逐角色/全队重 boot。 |
| Owner 显示 | **部分通过**：pending 已修；**通过后文案 P2** | 产品评审后需求卡是 `Owner 尚未决定 · 待 Owner（无记录）`，团队台没有 Owner 行；Owner 通过后变成 `Owner 已通过 · 待 Owner（by=Owner · 真实 actor 未记录）`，团队台是 `待 Owner · 通过`。 |
| 过期 | **通过** | 六条 boot 前移 40 分钟后：`boot 0/6 · 过期 6`、徽章 `boot 已过期 6 · 禁止推进`、`全队 boot（过期 6）`；重 boot 后 `6/6 · 可推进`。 |
| 迭代 | **通过** | 有 1 条「待 PM 派单」时迭代禁用，title 写「迭代会让本轮 boot 全部作废…先完成 Owner 验收，或改用『终止』」；空项目写「还没有需求…」。 |
| DSH 主画面 | **通过** | 真实 DSH 实例：`已连接 DSH · 226 个会话`，webview 标题 `DeepSeek Harness`、URL `http://127.0.0.1:52711/`；mock 也能作为主画面加载。 |
| 上一轮 P3「文件就绪 8/9」 | **已修** | 空项目与有文档项目都显示 `文件就绪 8/8`。 |

---

## 2. P1：新项目第一条需求 / 全队 boot 仍被文档闸门挡住，界面没有应用内编辑入口

### 2.1 复现（真实 UI，不是状态注入）

新建 `QA2-空项目` → 点顶栏「建团队」（mock DSH 下 6 个会话创建成功，`团队 6/6 / 会话 6`）→ 打开项目面板「流程」→「＋ 产品/需求新需求」。

此时**能力与按钮都已经正常**：

```text
#project-truth
preload 已加载 | IPC 齐全 | 文件 40 | workflow 已读 | briefing 已读 |
旧命令齐全 | boot 0/6 | 账本一致 | 模板占位 2

.legacy-gate-facts
boot/已读 0/6 · 文件就绪 8/8 · 已过期 0 个角色 · 模板占位 2 份 ·
缺旧命令 0 · 文档变更 0 个角色 · 阶段 idle

[data-legacy-req-action="requirement-create"]  disabled=false
  title="新建第一条需求：提交时后端会先取得所选产品/需求分析师的 boot 令牌（首次自动 boot）"
[data-legacy-boot]（六角色）                  disabled=false
#legacy-boot-all                              disabled=false，文字「全队 boot（缺 6）」
```

上一轮 P0 的 `legacy: null` 已改为透传能力：`src/main.js:2697-2725` 的 local-fallback 现在返回 `legacy`（含 `capabilities` / `missingCommands`），所以真相条不再出现「旧命令 未读取」，`文件就绪` 也按 8 项算。

但提交第一条需求后，弹窗不关，错误是：

```text
[PLACEHOLDER_DOC] 项目信息 还是占位模板
（（待 PM 填写：这个项目到底要做什么、为什么做）、（待 PM 填写：谁用、在什么场景用、
现有替代方案）、…）：D:\…\_tmp\qa-mvp-ui2\projects\QA2-空项目\项目信息.md
```

点「全队 boot」同一时刻也是 6 个角色全部失败，toast 首行：

```text
全队 boot 完成，但有 6 个角色未读全：项目经理：[PLACEHOLDER_DOC]
角色「pm」boot 被拒绝：项目信息（…仍是模板占位；先把项目目标/边界/铁律正文写清再 boot
```

截图：`_tmp\qa-mvp-ui2\shots\07-fresh-req-blocked.png`。

### 2.2 分界：写实哪几份文档才能继续

在应用外（只改沙盘项目目录）依次补文档，逐步重试，得到清晰的三段：

| 已补文档 | 结果 |
|---|---|
| 只补 `项目信息.md` | 建需求 / boot 改为 `[PROJECT_IRON_TEMPLATE] 项目铁律.md 还是团队默认模板，没有按项目落地：…\项目铁律.md` |
| 再补项目专用的 `项目铁律.md` | 建需求 `OK`，生成 `R-20261105-175817-b3f2`；`全队 boot` 成功 `6/6`（`全队 boot 完成：6 个角色都已读全`） |
| `需求/00-需求总览.md` 仍是模板表 | 后端 boot 仍成功；界面徽章仍可能写「模板占位 1 · 禁止推进」，直到重新加载（见 §3） |

即：**boot 的硬前提是 `项目信息.md` + 项目专用 `项目铁律.md`；`需求总览` 的占位并不是 boot 的拒绝项**（这点与界面文案不符，见 §3）。

### 2.3 为什么说这是 UI 问题，不是单纯的后端设计

1. 新建项目的脚手架写的就是占位/团队模板：
   - `src/team-tools.js:2821-2833`：`projectInfoTemplate()` 生成「（待项目经理填写）」「（待填写）」。
   - `src/team-tools.js:2928-2939`：缺 `项目信息.md` 就写这个模板；缺 `项目铁律.md` 直接把团队根 `项目铁律.md` 原样复制。
2. 后端闸门恰好拒绝这两样：
   - `团队/工具/lib/store.mjs:316-368`：`assertProjectDocFilled` 对「（待…）」返回 `PLACEHOLDER_DOC`；项目铁律与团队模板同文返回 `PROJECT_IRON_TEMPLATE`。
   - 这是 17:24 修复报告 #3 的预期行为，**不是回归**。
3. 但 UI 没有把「下一步」给出来：
   - 「必读与目录」里的文档只有 `查看`（`data-legacy-doc`）与只读预览，没有编辑；`文件` 页的预览底部有「用系统程序打开」，但要求用户先知道去文件页找 `项目信息.md` / `项目铁律.md`，闸门和错误弹窗并不提供这个入口。
   - 没有应用内编辑器；实际出口是「用系统程序打开」或「打开目录」，用户必须自己找编辑器改两个文件，再回来点刷新（而刷新还不重读文档，见 §3）。
   - 新建项目表单只收「项目名称 / 根目录」，没有项目目标、边界、铁律的输入项。
4. 界面还把「铁律模板」漏出了闸门清单：
   - `src/renderer/app.js:102-108` 的 `LEGACY_PROJECT_DOCS` 包含 `项目铁律`，但 `legacyPlaceholderDocs()`（`:3406-3412`）只用正则 `/（待[^）]*）|待填写|待补/` 判断；
   - 团队模板铁律里没有「待」字，所以**闸门可能只显示 `需求总览` 占位（甚至 0 份），boot 仍会因 `PROJECT_IRON_TEMPLATE` 失败**。本轮的 `PROJECT_IRON_TEMPLATE` 是在点「执行」后才以错误返回的，闸门没有预告。

### 2.4 影响

- 对一个以「建项目 → 建团队 → 第一条需求」为主链的 MVP，新用户建完项目后的第一个动作就会失败；且错误信息里是整段占位句子的枚举（toast 600+ 字），不是一句可执行的下一步。
- 用户必须离开应用、用外部编辑器改两份文件；改完还要再点一次「刷新」——而「刷新」并不重读文档（§3），于是很容易以为「改了没用」。
- 这不是「旧命令缺失」的 P0：能力矩阵、按钮、IPC 都是通的；它是**脚手架产物与闸门不一致 + 缺少应用内补文档入口**的集成缺口。

### 2.5 最小修法（二选一，建议 A+B）

- **A（推荐，补入口）**：新建项目表单增加「项目目标 / 边界 / 铁律」三项（至少目标+边界），创建时写入真实 `项目信息.md`，并按模板生成一份项目专用 `项目铁律.md`；或在闸门条与 `PLACEHOLDER_DOC` 弹窗里直接给「编辑项目信息 / 编辑项目铁律」按钮（哪怕只是调用系统默认编辑器打开该文件）。
- **B（补闸门）**：`legacyPlaceholderDocs()` 增加「项目铁律与团队模板同文」检测（可用哈希比较），闸门 chip 写「项目铁律仍是团队模板」，不要让用户点了 boot 才知道。
- 顺带把错误 toast 截短为「项目信息仍是模板；点这里编辑 / 打开目录」，完整占位列表留在详情里。

### 2.6 验收

- 新建一个空项目（无任何手改）→ `全队 boot` 返回 `6/6`，且「＋ 产品/需求新需求」能提交出第一条需求；全程不离开应用。
- 若产品决定保留「必须 PM 写实」的闸门，则新建后第一次点 boot / 新建需求时，界面必须给出可点的编辑入口与一句下一步，而不是仅返回 `PLACEHOLDER_DOC`。

---

## 3. P2：闸门的文档判断与后端不一致，且「刷新」不重读文档

这一节有两个可独立复现的现象，都会让用户看到**不真实的「禁止推进」**。

### 3.1 现象 A：`需求总览` 占位被说成 boot 阻断，实际 boot 能过

`QA2-新项目` 补完 `项目信息.md` + 项目专用 `项目铁律.md` 后，闸门仍写 `模板占位 2`（其中一份缓存来自补文档之前，见 §3.2），正文写：

```text
#project-truth  → … | boot 6/6 | 账本一致 | 模板占位 2
#legacy-gate-badge → 模板占位 2 · 禁止推进
.legacy-gate-result →
  「项目信息、需求总览 仍是模板占位；boot 与推进都会被后端拒绝（PLACEHOLDER_DOC），
    先把项目目标/边界/铁律正文写清。」
```

但同一时刻点「全队 boot」返回：

```text
全队 boot 完成：6 个角色都已读全（后端逐角色返回；界面发起不冒充角色本人）
```

即：**`需求总览` 占位并不会让后端 boot 失败**；闸门把它算进 `PLACEHOLDER_DOC` 并宣称 boot 会被拒，是过度声明。为排除「只是缓存旧文案」，又在沙盘 `需求总览` 里加了一行 `（待填）`，直接跑 `team.mjs boot --role pm --project QA2-空项目`，返回 `ok:true` + 令牌 + 简报（测试后已恢复原文件）。反过来，真正的 boot 阻断项 `PROJECT_IRON_TEMPLATE` 又不在闸门清单里（§2.3）。`需求总览` 只在「推进 / 迭代」的 UI 守卫里被使用，后端并不靠它拒 boot。

### 3.2 现象 B：点「刷新」不重读文档正文，模板占位状态会卡住

在 `QA2-空项目` 上只补 `项目信息.md`，然后点项目面板里的「刷新」/ `#legacy-refresh`：

```text
点之前：模板占位 2 份（项目信息、需求总览）
点之后：模板占位 2 份   ← 项目信息已经写实，仍然显示 2
切到另一个项目再切回：模板占位 1 份（只剩需求总览）
```

再在 `QA2-空项目` 建出需求后（`需求总览` 已被 `req create` 重写为真实表），不重载界面时：

```text
#legacy-gate-badge → 模板占位 1 · 禁止推进
```

`location.reload()` 后同一项目：

```text
.legacy-gate-facts → 模板占位 0 份
#legacy-gate-badge → 未 boot/未读 · 禁止推进（原因变成 boot，不再是占位）
```

也就是说，界面上的「模板占位」有可能是**旧缓存**，不是文件现状；这会直接挡住「推进」按钮，并让用户以为文档没保存。

### 3.3 源码路径

- `src/renderer/app.js:4128-4159` `legacyReadDoc()`：一旦 `legacyUi.docs[rel]` 有缓存就直接返回，**没有 mtime/大小校验**。
- `src/renderer/app.js:4161-4174` `loadLegacyDocs(force)`：`force` 只绕过 30 秒节流，重读 `files:list` / `workflow:state` / `briefing`，但从不清理 `legacyUi.docs`；随后 `:4259-4263` 仍走 `legacyReadDoc()` 的缓存。
- 只有切项目（`resetLegacyUiFor`，`:4106-4126`）或整页重载才会清空文档缓存；`#legacy-refresh` 与顶栏「刷新」都到不了这一步。
- `src/renderer/app.js:102-108` 与 `:3406-3412`：`需求总览` 在 `LEGACY_PROJECT_DOCS` 里，正则命中就计入 `模板占位`；没有区分「boot 必读」与「推进/迭代必读」。

### 3.4 影响与修法

- 影响：用户手改文档后点「刷新」，界面仍写「模板占位 / 禁止推进」；用户会重复改文件或怀疑保存失败。工作流动作（建需求会重写 `需求总览`）之后也会留下同类假状态。
- 修法：
  1. `loadLegacyDocs(true)` 清空 `legacyUi.docs`（或记录 `size+mtime`，变了才重读）；工作流动作成功后主动刷新相关文档。
  2. 闸门分两层：`boot 阻断`（项目信息占位、铁律模板）与 `推进/迭代阻断`（需求总览、占位等），文案不要统一写成「boot 会被拒」。
  3. 给 `项目铁律` 增加与团队模板同文的检测，纳入闸门。

---

## 4. P2：Owner 通过后仍显示「待 Owner」，与「已通过」自相矛盾

### 4.1 先记通过项：pending 不再伪造 `by=Owner`

产品评审通过、Owner 还没决定时，需求卡与团队台都没有 Owner 记录：

```text
需求卡：Owner 尚未决定 · 待 Owner（无记录）
团队台「评审 / 回执 · 真实 actor」：只有 R-… · 产品评审 / 产品设计师 · 通过，
没有 Owner 行。
```

这正是上一轮 P1 要修的点；源码 `团队/工具/lib/workflow.mjs:575` 也只剩 `row.ownerReview = { status: 'pending' };`，不再预写 `by: 'Owner'`。**通过。**

### 4.2 不通过：Owner 通过后的显示

在 UI 点「Owner 决定」→ 通过 → 填写意见 → 后端 `OK` 后，需求卡变成：

```text
Owner 已通过 · 待 Owner（by=Owner · 真实 actor 未记录）
```

团队台「评审 / 回执」同一记录：

```text
R-20261105-175047-bac6 · Owner 评审
待 Owner · 通过
by=Owner · actor=待 Owner（真实 actor 未记录） · Owner 本人看过，通过
```

截图：`_tmp\qa-mvp-ui2\shots\06-flow-owner.png`、`05-owner-iterate.png`。

一处是「已通过」+「待 Owner」，一处是标题「待 Owner」+ 结论「通过」；对不熟悉实现的读者，这会被读成「Owner 还没决定」，而实际记录已经是 approved。

### 4.3 源码与记录

- `src/renderer/app.js:4079-4089`：

  ```js
  if (!actor) return `${label} ${statusLabel} · 待 Owner（by=${by || '未记录'} · 真实 actor 未记录）`;
  ```

  注释（`:4092-4096`）写明这是**故意**的：有结论但 actor 未记录时，不补造成 Owner 本人，按「待 Owner」显示。
- `src/renderer/app.js:5594-5606`：团队台对 Owner 行把名字直接替换成「待 Owner」：

  ```js
  const ownerAwaitingActor = Boolean(row.owner) && !actor;
  … ${esc(ownerAwaitingActor ? '待 Owner' : legacyActorName(by))} · ${esc(verdict)}
  ```

- 实际 `工作流.json` 的记录（`QA2-新项目`）：

  ```json
  { "status": "approved", "by": "Owner", "at": "…", "opinion": "Owner 本人看过，通过",
    "source": "team.mjs owner", "command": "owner" }
  ```

  没有 `actor`，也没有 `channel`；`by: "Owner"` 是工作台壳代写的。

### 4.4 建议

- 不要把「待 Owner」复用成「记录人未认证」。改成：
  - 卡片：`Owner 已通过（记录来源：工作台；未认证 Owner 本人）`
  - 团队台标题：`Owner（未认证） · 通过`
  - 若后端能补 `channel: 'stdio'|'tty'`，显示 `通道 stdio`；补不了就明确写「无通道记录」。
- pending 文案保持现状（`Owner 尚未决定 · 无记录`）。
- 身份根因仍归后端（`MVP-BLOCKERS.md` P0-1）；本报告只判显示层，不要求 UI 伪造 actor。

---

## 5. 已验证通过的部分

### 5.1 全队 boot（写实文档后）

在 `QA2-空项目` 补 `项目信息.md` + 项目专用 `项目铁律.md` 后：

```text
toast: 全队 boot 完成：6 个角色都已读全（后端逐角色返回；界面发起不冒充角色本人）
#project-truth: … | boot 6/6 | 账本一致
#legacy-gate-badge: 已 boot/已读 · 可推进
```

真相条变为 `boot 6/6`，徽章转为 `已 boot/已读 · 可推进`；说明开箱阻断来自文档闸门，而不是 boot IPC 或能力矩阵（六角色按钮的逐行状态以 briefing 计数为准，本轮没有再逐行截图）。

### 5.2 boot 过期（上一轮 P1 保持通过）

把 `团队\状态\项目\QA2-新项目\工作流.json` 六条 `boots.*.at` 前移 40 分钟，重载界面：

| 检查 | 实测 |
|---|---|
| truth | `boot 0/6 · 过期 6` |
| 徽章 | `boot 已过期 6 · 禁止推进`（红） |
| gate 正文 | 「有 6 个角色的 boot 已过期（默认 30 分钟），后端会按 `BOOT_EXPIRED` 拒绝推进；点下方「重新 boot」…」 |
| 六角色按钮 | 文本 `重新 boot`，`disabled=false`，title「boot 已过期（超过 30 分钟） · …」 |
| `#legacy-boot-all` | `全队 boot（过期 6）`，可点 |
| 点全队 boot 后 | `boot 6/6`、徽章 `已 boot/已读 · 可推进` |

### 5.3 迭代守卫（上一轮 P2 已修）

`QA2-新项目` 需求 `R-20261105-175047-bac6` 状态「待 PM 派单」时：

```text
#legacy-iterate disabled=true
title="还有 1 条需求在办：R-20261105-175047-bac6（待 PM 派单）；
迭代会让本轮 boot 全部作废、在办需求留在旧轮。先完成 Owner 验收，或改用「终止」。"
```

空项目（无需求）时：

```text
title="还没有需求：先建需求并完成 Owner 验收，验收后才能迭代"
```

后端同时在 `团队/工具/lib/workflow.mjs:825/875` 有 `iterateBlocker` / `ITERATE_BLOCKED`，壳层与工具双闸门一致。本轮没有在「已验收」状态上真正执行迭代（见 §8）。

### 5.4 DSH 主画面（真实 DSH）

第二个只读实例（`_tmp\qa-mvp-ui2\dshcheck`，未配 mock，默认 52711）：

```text
#dsh-label  → DSH 已连接
#dsh-detail → 已连接 DSH · 226 个会话
#dsh-off    → hidden
webview     → title "DeepSeek Harness", url http://127.0.0.1:52711/
```

截图：`_tmp\qa-mvp-ui2\shots\04-dsh-real.png`。画面里是真实的 DeepSeek Harness 会话列表与输入框，不是错误页/401 页。mock 实例的主画面也能正常加载（`00-start.png` 等）。

### 5.5 其他保持项

- `文件就绪 8/8`：上一轮 P3「永远 8/9」已修；空项目不再把「其他文档 0 份」算成缺项。
- 「打开项目文件夹」「项目索引」「团队台」等入口可用；建团队 6/6、会话映射与角色卡均能读。
- 终止按钮在 PM 未 boot/文档变更时禁用并写明原因（本轮未执行终止，只读按钮态）。

---

## 6. 观察（未计入缺陷）

1. **「禁止推进」与单步按钮不是同一把闸**：`QA2-空项目` 徽章写 `模板占位 1 · 禁止推进` 时，`产品评审` 按钮仍可点并执行 `OK`。这可能是「禁止推进」仅指「查看本轮动作 / 推进按钮」，但同屏语义容易让人以为整轮只读。建议把徽章改成「推进按钮已锁」或在 gate 正文写清「单步评审仍可执行」。
2. **`全队 boot（缺 6）` 的「缺」不准确**：六条 boot 都在、只是文档变更后失效时，按钮仍写「缺 6」；过期时才改「过期 6」。建议分「未 boot / 已过期 / 文档变更」三种计数。
3. 每一步动作都会重写 `需求总览` / `需求/*.md`，导致六角色 boot 立刻失效、下一步要重 boot（上一轮已记录）。这是有意的哈希安全设计还是一次产品取舍，本轮不重复判，但建议在引导里写明「动作后先重 boot」。
4. `PLACEHOLDER_DOC` 的 toast 把 `项目信息.md` 里所有占位句整段拼出来（本轮实测 600+ 字），手机上会溢出；建议截断并给「编辑/打开目录」。

---

## 7. 只读边界与副作用

- 新增：仅 `docs\QA-MVP-UI2.md`（本文件）；临时文件全部在 `_tmp\qa-mvp-ui2\`（`data\`、`team\`、`projects\`、`dshcheck\`、`temp\`、`shots\`、`mock-dsh.cjs`、`cdp.cjs`、`cdp-shot2.cjs`、`launch.cmd`）。
- 未修改：`src\**`、`package.json`、`package-lock.json`、真实 `data\**`、真实 `团队\状态\**`、真实 `项目\**`、`.selftest-data\**`、旧仓库 `D:\deepseek\工作台`。
- 沙盘内手改过 `projects\QA2-新项目\项目信息.md`、`项目铁律.md` 与 `projects\QA2-空项目\项目信息.md`、`项目铁律.md`，仅用于越过文档闸门验证后续链路；这些目录均在 `_tmp\qa-mvp-ui2\projects\`。
- 启动过两个沙盘 Electron（CDP 9353 / 9354）和一个 mock DSH（9403）；QA 结束已关闭，未重启用户 14:51 启动的原始工作台，也未动 17:32 启动的 `ui-p0p1-probe`（9365）和 17:45 的 `ui-acc` 实例（9401）。
- 真实 DSH（52711）只做了 `session/list` 探测与 webview 加载，没有创建 workspace / session，没有向真实会话发 prompt。
- 源码哈希 QA 前后一致（见首表）；`npm run check` 未跑（不证明 UI）。

---

## 8. 我没能证明的部分

- **建项目 / 建团队使用 mock DSH**，不是真实 DSH 的六角色 agent 执行；本报告只证明 UI 在真实 IPC / 真实 `团队/工具` / 真实 Electron 下的行为，不证明真实 `workspace/create` / `session/create` / seed 完全一致。
- **boot 过期是改时间模拟的**（前移 40 分钟），没有真的等 30 分钟；没有跨时区/时钟回拨测试。
- **迭代只在「有在办需求」和「无需求」两种禁用态验证**；没有把一条需求完整验收后真实执行 iterate，不证明「允许时」的成功路径。
- **Owner 通过后的记录 `by=Owner` 是壳代写**；没有 nonce / TTY / 凭据可验，身份根因在后端。本轮只判显示文案。
- **DSH 主画面只验证容器加载/连接**，没有在真实 DSH 页面里点「定位会话」「重载工作区」等依赖页面 DOM 的动作。
- 真实「新建项目 → 建团队」没有在真实 DSH 上跑（避免创建真实会话）；若真实 DSH 的 `workspace/create` 行为不同，建团队 UI 的 toast/6 会话计数需要另验。

---

## 附：复验入口（选择器 / 文件）

| 要复验的现象 | 入口 |
|---|---|
| 新项目按钮可用（P0 已修） | `#project-truth`、`.legacy-gate-facts`、`[data-legacy-req-action="requirement-create"]`、`[data-legacy-boot]`、`#legacy-boot-all` |
| 首条需求被文档闸门挡 | 需求弹窗 `.modal-error`；`#legacy-boot-all` 的 toast |
| 铁律模板阻断 | `[PROJECT_IRON_TEMPLATE]` 错误、`项目铁律.md`、`团队\工具\lib\store.mjs:316-368` |
| 闸门文档判断 | `.legacy-gate-facts` 的「模板占位 N 份」、`.legacy-gate-result` 正文 |
| 刷新不重读 | 手改 `项目信息.md` 后点 `#legacy-refresh`，对比切项目/整页重载后的 `模板占位` 数 |
| Owner pending | 产品评审通过后的 `#legacy-requirements` 文本、`#team-actor-list` |
| Owner 通过后文案 | 需求卡 `Owner 已通过 · 待 Owner…`、团队台 `待 Owner · 通过` |
| 过期 | `#project-truth`、`#legacy-gate-badge`、`[data-legacy-boot]`、`#legacy-boot-all` |
| 迭代守卫 | `#legacy-iterate` 的 `disabled` / `title`、`legacyIterateGuard()`（`app.js:3889`） |
| DSH 主画面 | `#dsh-label`、`#dsh-detail`、`#dsh-off`、`#dsh-view` 的 URL/标题 |

沙盘脚本：`_tmp\qa-mvp-ui2\mock-dsh.cjs`（mock DSH 9403）、`launch.cmd`（9353）、`dshcheck\launch.cmd`（9354，真实 DSH）、`cdp.cjs` / `cdp-shot2.cjs`（CDP 读 DOM / 截图）。

---

## 对账回执

- 对账人：只读 UI QA（第二轮）
- 复核人：待 PM / 开发
- 结论：**有条件通过，停手待修**——上一轮 P0 已修；本轮 P1 一个（新项目首链仍被文档闸门挡住且无应用内编辑入口），P2 两个（闸门文档判断/刷新缓存不一致；Owner 通过后仍显示「待 Owner」）。
- 备注：过期、迭代禁用、Owner pending、DSH 主画面、8/8 就绪均通过；P1 的修法很小（补表单/编辑入口/闸门补铁律检测），但决定「新项目开箱能不能走第一步」，建议先修再进下一轮验收。
