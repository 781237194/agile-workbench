# 敏捷工作台 v0.1 · 只读验收报告

- 验收对象：`D:\deepseek\agile-workbench`（v0.1.0，Electron 33.4.11 / Node 24.22.1）
- 验收方式：`npm run check` + 仓库自带 `--selftest` + 五组**仓库外**隔离探针（`require` 真实 `src/main.js`，复用真实 IPC）
- 验收边界：未修改 `src/`、`package.json`、`团队/` 与旧仓库数据；本文件之外只新增了自测本身会写的 `selftest.png` / `selftest-flow.png` 与 `userdata-qa-final/`（Chromium 配置）
- 结论：主流程与大部分闸门是通的，但**四条数据安全路径存在真实缺陷**（状态库清零、提案覆盖、回滚假成功、并发丢写），另有一处派单锁无出口

---

## 一、五个关键问题

### S1【致命】状态库半截/损坏 = 整层静默清零，并被下一次写入永久覆盖

**位置**：[`src/main.js:60`](../src/main.js#L60) `readStore()`、[`src/main.js:70`](../src/main.js#L70) `writeStore()`

**现象**
1. `writeStore()` 用 `fs.writeFileSync` 直接覆盖 `workbench.json`，没有临时文件 + rename，没有 fsync，也没有历史副本。
2. `readStore()` 的 `catch` 把**任何**解析失败都变成 `emptyStore()`，`statePayload()` 里也没有任何 `warning/storeError/recover` 字段。
3. 于是崩溃、断电、磁盘满、同步盘半截写入 → 界面显示"没有项目"，用户看不到任何异常；下一次任意写操作会把坏文件覆盖成空库，原记录不可逆丢失。

**复现**（实测）
1. 建 2 个项目、若干任务/提案，退出应用。
2. 把 `workbench.json`（8148 B）截断成前一半（4146 B），模拟中断写入。
3. 重开应用：`state.projects = 0`，`activeProjectId = null`，返回字段只有 `version/roles/stages/projects/activeProjectId/defaultRoot/dsh/team`，**无任何告警字段**；此时 `task:create` 报"还没有项目"。
4. 新建一个项目：磁盘文件被改写为 650 B，原项目名已不在文件里；原项目目录与 `_backup/commits/` 还在，但任务、提案、提交、回执记录全部失联。

**建议**
- 原子写：写 `workbench.json.tmp` → `fsync` → `rename`，保留 `workbench.json.bak`（上一版）。
- 解析失败时**禁止**返回空库：把坏文件改名隔离为 `workbench.corrupt-<ts>.json`，state 里回传 `storeError`，界面进入"恢复模式"并提示"检测到状态文件损坏，已保留副本，新建项目将覆盖旧记录，是否继续"。
- 写前检测坏文件存在则拒绝写入，直到用户确认。

---

### S2【高】提案 apply 无冲突检测，静默覆盖评审后被改动的文件；`hash` 字段语义还不固定

**位置**：[`src/main.js:510`](../src/main.js#L510) `proposal:apply`、[`src/main.js:465`](../src/main.js#L465) `hash`、[`src/renderer/app.js:403`](../src/renderer/app.js#L403)

**现象**
- 创建提案时把 `sha256(待写入内容)` 存为 `proposal.hash`，apply 时**从不校验**目标文件是否仍是评审时的版本，也没有 base 版本号/基础哈希。
- 同一文件可以并存多个"已签字"提案，后 apply 的直接覆盖先 apply 的，双方都显示成功。
- `hash` 有两种语义：带 `content` 时 = 新内容哈希；不带 `content` 时 = 当前文件哈希（仅评审提案）。界面统一显示为"SHA-256"，但两种值都不是"提案绑定文件版本"。

**复现**（实测）
1. 文件 `产品/方案.md` = `BASE`。
2. 提案 N（内容 `NEW`）评审通过、PM 签字 —— 此刻文件是 `BASE`。
3. 提案 O（内容 `OTHER`）签字并 apply → 文件变 `OTHER`。
4. 回到 N 点"应用提案" → `ok:true`、`applied:true`，文件变 `NEW`；**`OTHER` 被静默覆盖，界面无冲突提示**，只在 N 的备份目录里留了一份 `OTHER`。
5. 对照：对同一文件立即并发两次 apply，第二次被"提案已经应用"正确拒绝；说明缺的不是并发锁，而是**版本校验**。

**建议**
- 提案创建时记录 `baseHash = sha256(现有文件)`（不存在则 `null`）与 `baseCommit`。
- apply 前校验：`sha256(当前文件) === baseHash`，不一致返回 `CONFLICT`，要求重新评审或显式"强制覆盖"。
- 同一 `fileRel` 同时只允许一个未回滚的 applied 提案；`hash` 明确拆成 `contentHash` 与 `baseHash` 两个字段，避免一字段两义。

---

### S3【高】rollback 备份缺失时"假成功"：返回 ok、置 `applied=false`，文件实际没恢复

**位置**：[`src/main.js:543`](../src/main.js#L543) `proposal:rollback`（关键分支 [`src/main.js:551`](../src/main.js#L551)–[`556`](../src/main.js#L556)）

**现象**
- 备份路径存在但文件被删（清理工具、同步盘、`_backup` 手动清理）时，`if (commit.backupPath && fs.existsSync(...))` 为假；`else if (!commit.existed)` 也为假（原文件存在过）→ **两个分支都不执行**，但后面照样 `applied=false`、照样返回 `ok:true`，界面提示"已回滚"。
- 第二个变体：提案创建后文件被删除，apply 时 `backupPath = ''` 而 `commit.existed` 仍沿用 `proposal.existed = true`，同样两个分支都不进。

**复现**（实测，两个变体都验证过）
1. apply 一个已存在文件的提案 → 生成 `_backup/commits/C-2eb360c9/方案.md`（内容 `BASE`），当前文件 `EDIT`。
2. 删除 `_backup/commits/C-2eb360c9/` 整个目录。
3. 点"回滚" → `{ok:true, applied:false}`，**文件仍是 `EDIT`**，`restored=false`。
4. 变体：提案创建后删掉目标文件再 apply（`backupPath:""`, `existed:true`），再 rollback → `{ok:true, applied:false}`，文件仍是 `AFTER-DELETE`。

**建议**
- rollback 前校验备份存在且哈希匹配；缺失时返回明确错误（`BACKUP_MISSING`），**不要**改 `applied`。
- commit 记录里存备份的 `sha256`，回滚后校验目标文件哈希 = 备份哈希，再置 `applied=false`。
- `commit.existed` 用 **apply 时刻**的真实存在性，不要沿用创建提案时的值。

---

### S4【高】写操作跨 `await` 持有旧快照 → 并发创建的任务/提案/回执被静默覆盖

**位置**：[`src/main.js:669`](../src/main.js#L669) `dsh:prompt`（670 读快照 → 676 `await` → 678 写回）、[`src/main.js:312`](../src/main.js#L312) `team:ensure-project`、[`src/main.js:335`](../src/main.js#L335) `team:launch`

**现象**
这三个 handler 都是 `readStore()` → `await`（DSH RPC 最长 10s；团队工具 60/180s）→ 在**内存旧快照**上 `addEvent` → `writeStore(store)`。await 期间其他 IPC 写入磁盘的内容会被整体回滚覆盖，且被覆盖的调用**都返回成功**。`dsh:prompt` 是界面"唤醒角色"按钮的真实路径。

**复现**（实测，用本机 mock DSH 延迟 3 秒，不碰真实 DSH）
1. 项目 A 有 `sessions.analyst`，点角色页"唤醒"发一条消息（实测 RPC 3031 ms）。
2. 在这 3 秒内新建任务 B（项目 A）和任务 C（项目 B）——两个调用都 fulfilled。
3. 唤醒返回后刷新：项目 A 只剩唤醒前的任务，项目 B 的任务列表为空；磁盘 store 同样为 `tasksA:["A-唤醒前"]`、`tasksB:[]`。事件里只有唤醒记录，没有任何"被覆盖"痕迹。
4. 同类：`team:ensure-project` 并发建任务 B + 提案 C → 两者都 `ok`，最终 `tasks:["A-建项目后"]`、`proposals:0`。

**建议**
- 写事务化：await 之后**重新 `readStore()`**，按 id 找回对象再改再写；或引入 `storeVersion` 做 CAS（版本不符则重读重试）。
- 单进程写队列（Promise 串行）即可消除本类问题，改动面很小。
- 至少先修 `dsh:prompt`、`team:ensure-project`、`team:launch` 三处，不要把 store 快照跨 await 传递。

---

### S5【中高】派单锁没有超时/撤销出口，唤醒失败也照样置锁

**位置**：[`src/main.js:563`](../src/main.js#L563) `team:send`（锁判断 [`568`](../src/main.js#L568)、置锁 [`578`](../src/main.js#L578)、唤醒失败 [`585`](../src/main.js#L585)–[`592`](../src/main.js#L592)）

**现象**
- `pendingAck` 一旦写入只有 `team:ack` 能清；没有 `team:cancel` / 超时 / 释放接口（实测 `window.workbench.teamCancel`、`teamRelease` 均为 `undefined`）。
- 目标角色没有 DSH 会话时，`dsh.prompt` 不执行，`wake.ok=false`，但消息和锁已落盘；界面 toast 是"派单已记录（DSH 未唤醒）"，紧接着下一次派单就被拒。
- 锁与回执都没有角色身份校验，任何人只要写一句回执就能解锁。

**复现**（实测）
1. 项目未启动团队（`sessions` 为空），派单给 `analyst` → `ok:true`，`wake:{ok:false, why:"没有 DSH 会话"}`，`pendingAck = M-66c075db` 已写入 store。
2. 再派单给 `tester` → 被拒"还有一条派单未回执，先等回执再派下一个"。
3. 空回执被拒"回执必须写一句处理结果"；除了编一条回执，没有任何撤销入口。

**建议**
- 派单状态机加 `pending / pendingWake / acked / cancelled / expired`，附 TTL（如 30 分钟）与"撤销派单"按钮。
- 唤醒失败时不要置 `pendingAck`（或置为 `pendingWake` 并允许重发），避免把项目锁死。
- 回执记录 `role + 来源(sessionId/人工)`，人工代填要显式标注。

---

## 二、其它已确认（未进前 5）

| # | 级别 | 问题 | 证据 |
|---|---|---|---|
| A | 中 | "恢复项目"只凭目录里有 `README.md` 或 `项目信息.md` 就登记，随后向该目录写入 16 个条目（`_tmp`、`site`、`src`、`workspace.json`、六个角色目录、`项目信息.md`、`项目索引.md/json`、`协作准则.md`、`项目铁律.md`）。任意无关仓库都能被"恢复"并被写入 | 实测：含 `README.md`+`main.py` 的临时目录 adopt 成功，目录项从 2 个变 18 个 |
| B | 中 | `requireProject()` 在 `projectId` 不存在时静默回退到当前项目（[`src/main.js:152`](../src/main.js#L152)） | `updateTask({projectId:'P-not-exist', taskId:<当前项目任务>})` 返回 ok，任务状态真的被改了 |
| C | 中 | 可重复签字：已 `approved` 的提案再签一次 `rejected` 会直接翻转终态，覆盖原签字 | `proposal:sign` 只拦 `status==='rejected'`（[`src/main.js:500`](../src/main.js#L500)）；实测第二次签字后 `finalStatus:"rejected"` |
| D | 中 | `dsh:provision` 失败无结构化错误码、无部分成功持久化：6 个会话在循环里创建，`writeStore` 在循环外；中途失败会留下 DSH 孤儿会话，重试还会重复创建 | 离线实测：`TypeError: fetch failed`（无 `code`），`sessions` 保持 0；代码 [`src/main.js:647`](../src/main.js#L647) |
| E | 低 | `npm run check` 只检查 4 个文件，**不含最大的 `src/team-tools.js`**（27 KB） | [`package.json:13`](../package.json#L13)；单独 `node --check src/team-tools.js` 通过，属检查覆盖洞而非现存语法错 |
| F | 低 | `task:update` 传非法 `status` 静默返回 ok，仍写一条 `任务 X → 旧状态` 事件 | [`src/main.js:429`](../src/main.js#L429)；实测 `invalidStatusReturnedOk:true`、`status` 保持 `todo` |
| G | 低 | 阶段推导与文档顺序不一致：Owner 未决时只要有开发/测试任务就直接进 `dev`/`test`，Owner 闸门不显示 | [`src/main.js:79`](../src/main.js#L79)；`owner.status=optional` + 开发任务 → 阶段 `dev` |
| H | 低 | 项目目录被删/被移走后全程静默：`files:list` 返回 `ok:true, files:0`（界面显示"项目目录为空"），`files:open`/`project:open` 返回字符串 `Failed to open path` 但渲染层不检查（点了没反应）；项目记录、建任务、阶段推导照常工作 | 实测删掉项目目录后 `{ok:true, files:0}`、`openProject` 返回 `"Failed to open path"`、`createTask` 仍 `ok:true` |

---

## 三、已验证项（本次实测通过）

| 项 | 证据 |
|---|---|
| `npm run check` | 退出码 0（4 个文件语法通过） |
| 自带自测 `electron . --selftest --user-data-dir=...` | `SELFTEST_OK`，退出码 0，耗时约 5 秒；`SELFTEST_TEAM_CLEANUP {"removed":["验证项目"]}` |
| 状态/IPC 桥 | 6 角色、8 阶段、`createProject/ownerDecide/teamWorkspaces/teamEnsureProject/teamLaunch/teamBoard` 均暴露 |
| 项目/任务/看板 | 创建项目 → 建任务 → 看板四列；`team:board` 生成 HTML 并返回 `summary` |
| 流程阶段 | 实测 `intake → owner →（approved）dispatch → dev → test → close`，`rejected → requirement` |
| 文件索引 | 新建项目可正常列出全部条目（本次两轮 34 / 37 条）；`node_modules`/`.git`/`_tmp`/`userdata` 被过滤，深度 4 层上限 |
| 提案/评审/签字闸门 | 作者不能自评、理由必填、角色与结论枚举校验、未签字不能 apply、重复 apply 拒绝、并发 apply 只成功一次、未 apply 不能 rollback、重复 rollback 拒绝、>256 KB 拒绝、空标题/无效作者/空路径/不存在文件均拒绝 |
| 路径越界 | `files:open` 的 `..\..\..\Windows\win.ini`、`../../workbench.json` 均被拒（"路径越界"）；`proposal:create` 的 `../../escape.txt` 与 `C:\Windows\Temp\...` 均被拒（"文件不在项目内"）；`产品/../_tmp/inner.txt` 正常归一 |
| 派单/回执闸门 | 不能派给 PM、空内容拒绝、无效角色拒绝、未知消息 ack 拒绝、空回执拒绝、并发第二个派单被拒、回执后 `pendingAck` 清空 |
| 团队工具错误归一 | `TIMEOUT` / `PROJECT_DIR_MISSING` / `TOOL_MISSING` / `DSH_OFFLINE` 均为结构化 code；10 ms 强制超时被归一为 `TIMEOUT` |
| 中文/空格路径 | `中文 路径·验收` 的 init/ensure/dry-run/列表全部通过 |
| DSH 探测 | 真实 `session/list` 连上 154 个会话；mock 端点下 `dsh:prompt` 协议信封正确 |
| 测试隔离 | 自测未改动 `团队/状态/*`（时间戳早于本次运行）；`--user-data-dir` 内只有 Chromium 配置，应用状态被强制落在 `.selftest-data` 且结束即删 |

---

## 四、环境备注（非产品缺陷，但影响复现）

1. **给定命令在 DSH 终端里会直接崩**：本会话继承 `ELECTRON_RUN_AS_NODE=1`，`electron.exe . --selftest` 被当成普通 Node 执行，报
   `TypeError: Cannot read properties of undefined (reading 'whenReady')`（[`src/main.js:999`](../src/main.js#L999)）并退出 1。
   清除该变量后同一命令 `SELFTEST_OK`。建议 `src/main.js` 启动时检测该变量并打印一句可操作提示，而不是抛栈。
2. `--user-data-dir` 在 `--selftest` 下对应用状态无效：`AWB_STORE` 被强制到仓库内 `.selftest-data`（[`src/main.js:12`](../src/main.js#L12)），该目录在启动和结束时被 `rmSync`。[`src/main.js:775`](../src/main.js#L775)
   因此**两个自测实例不能并行**（会互删状态库）；目录名"qa-final"容易让人误以为数据落在那里。
3. 自测会覆盖仓库根的 `selftest.png` / `selftest-flow.png`（本次实测哈希与体积变化：flow 116047 → 64665 B）。验收会留下这两处改动，建议把截图输出改到 `user-data-dir` 或临时目录。

---

## 五、探针方法（可复现）

- `npm run check`；`electron.exe . --selftest --user-data-dir=...`（先清 `ELECTRON_RUN_AS_NODE`）。
- 五个仓库外探针（`%TEMP%\awb-qa-probe\probe1..5.js`）：启动 Electron，`require('D:/deepseek/agile-workbench/src/main.js')` 复用真实 IPC 与真实渲染进程；`AWB_STORE`、`TEAM_ROOT` 指向临时目录，仓库内状态零写入。
  - probe1：路径越界、提案链、回滚、派单锁、团队 IPC 丢更新、阶段、恢复、DSH 离线。
  - probe2：过期提案 apply、hash 语义、删除后 apply/rollback、重复签字、项目兜底、状态库损坏。
  - probe3：评审/签字/apply/派单负路径不变量。
  - probe4：本机 mock DSH（合法信封 + 3 s 延迟）验证 `dsh:prompt` 旧快照回写，不触碰真实 DSH 会话。
  - probe5：删除项目目录后的 `files:list` / `files:open` / `project:open` / 建任务行为。
- 探针只读取仓库代码，所有写入都落在 `%TEMP%` 与本报告。
