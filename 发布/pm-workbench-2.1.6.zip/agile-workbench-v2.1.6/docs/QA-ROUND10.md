# 第十轮只读 QA 报告 · agile-workbench

- 仓库：`D:\deepseek\agile-workbench`
- 时间：2026-11-05 14:18–14:30（Asia/Shanghai）
- 边界：只新增本文件；临时证据全部在 `_tmp\qa10-*`；证据运行把 `TEMP/TMP` 指到 `_tmp`；未修改 `src/`、`package.json`、旧仓库、真实 `团队\状态`。Electron selftest 会自行覆盖根目录两张截图，运行前已备份、运行后已恢复原字节（`selftest.png` SHA-256 回到 `BA66B36F…CCD4`，`selftest-flow.png` 回到 `2017F6A9…BE2C`）。
- 方法：读源码 + `npm run check` + 隔离 Electron selftest（mock DSH）+ `团队\工具\team.mjs selftest` + 在 `_tmp` 内直接驱动真实 `team.mjs` 做针对性探针 + 只读 `verify`/`doctor` 检查真实状态。
- 重要前提：Electron selftest 的 DSH 是 mock，没有真实 agent；它证明的是“主进程/壳能调通旧 CLI”，不是“六个角色真的自己执行了”。真实 DSH 当前也没有本仓库 `项目\*` 下的六角色会话。

---

## 一、结论速览

| 审计问题 | 结论 | 一句话证据 |
|---|---|---|
| 项目创建是否先建六角色目录/索引/铁律 | **分路径，整体不成立** | UI 先写本地库，再异步 ensure；CLI `project add` 根本不建六角色目录。 |
| 每轮是否强制 boot 读铁律/项目信息/角色卡/他人文档 | **不完整** | 旧 boot 只读宪法、项目铁律（可回退全局）、全局角色卡、项目索引；不读项目信息、不读项目角色卡、不读他人文档。 |
| 需求评审→PM派单→开发互审→测试→Owner验收是否真的走旧工具 | **只有一部分** | `req create`/`task`/`propose…apply` 是旧工具；`req review`、`owner`、`workflow`（迭代/终止）旧工具没有，壳写 `工作流.json` 补。 |
| 是否有本地第二套真相 | **有，且不只一套** | `workbench.json`、`工作流.json`、`项目清单.md`、`项目索引`、`项目.json` 并存，并有双向同步/互相覆盖。 |
| 新需求迭代/终止 | **只在本地 `工作流.json` 生效** | 旧任务、旧需求文档、需求总览不会同步更新；终止后旧 CLI 仍可建任务。 |
| D 盘 | **主程序数据在 D 盘，但真实状态仍混入旧 `D:\deepseek\工作台` 路径** | `activeProject` 指向不存在的目录；`项目清单.md` 指向旧仓库；`verify` 失败 10 项。 |

---

## 二、验证命令与结果

### 2.1 `npm run check`

```text
> agile-workbench@0.1.0 check
> node --check src/main.js && node --check src/preload.js && node --check src/renderer/app.js && node --check src/dsh-adapter.js && node --check src/team-tools.js

CHECK_EXIT=0
```

结论：5 个 JS 入口语法通过；它**不跑行为测试**，不能作为工作流正确的证据。日志：`_tmp/qa10-npm-check.log`。

### 2.2 D 盘 Electron selftest

```powershell
$env:AWB_SELFTEST_ROOT='D:\deepseek\agile-workbench\_tmp\qa10-electron\state'
$env:TEMP='D:\deepseek\agile-workbench\_tmp\qa10-electron\temp'
$env:TMP=$env:TEMP
npm run selftest -- --user-data-dir=D:\deepseek\agile-workbench\_tmp\qa10-electron\userdata
```

结果：`SELFTEST_OK`，退出码 0。关键结果：

| 项 | 结果 |
|---|---|
| STORE | 20 checks / 0 failed |
| COMPAT | 45 checks / 0 failed |
| MAPPING | 39 checks / 0 failed |
| ROUND5 / ROUND6 / ROUND9 | 4 / 17 / 8 checks，0 failed |
| ROUND10 | `failed:[]`；六角色目录和 5 份文档存在；6 个 boot；开发互审 `peer=approve`；Owner 验收 `accepted` |
| ROUND10 关键语义 | `requirement.driver="工作流.json（旧 shell 文件契约）"`；`missingCode / strictReview / strictOwner` 全部 `LEGACY_PROTOCOL_REQUIRED` |
| ROUND10 prompt | `before:54 → after:54`，全程没有向 DSH 发 prompt |

日志：`_tmp/qa10-electron/selftest.log`。

**这条 selftest 自己就证明了缺口**：需求评审和 Owner 的 strict 路径都返回 `LEGACY_PROTOCOL_REQUIRED`，需求驱动是壳的 `工作流.json`，不是旧命令；同时它把“0 个 prompt”当成功，说明流程只写邮箱/文件，没有真正唤醒角色。

### 2.3 `团队\工具\team.mjs selftest`

结果：`SELFTEST 20/20 PASS`，退出码 0。日志：`_tmp/qa10-team-selftest.log`。

但它的 `project add + 索引` 只验证命令返回成功，不验证六角色目录/项目信息/协作准则；后面的工作区测试才验证 `workspace create`。所以“20/20”不能证明 `project add` 是完整的项目创建路径。

### 2.4 在 `_tmp` 里直接驱动旧 CLI 的针对性探针

所有探针使用独立 `TEAM_ROOT/TEAM_PROJECTS_ROOT`，不碰真实状态：

| 探针 | 结果 | 证据 |
|---|---|---|
| `project add` 后检查结构 | 无六角色目录、无 `项目信息.md`、无 `协作准则.md`；`roleIndexes=0` | `_tmp/qa10-sandbox/add.json` |
| 对上述半成品跑 `boot --role pm` | **成功拿到令牌**；令牌 `docHashes` 只有宪法/铁律/角色卡/项目索引/团队配置 | `_tmp/qa10-sandbox/boot.json`、`team\状态\启动\<token>.json` |
| boot 后重建索引，再用旧令牌 `send` | **成功**（exit 0） | `_tmp/qa10-sandbox/send-after-index.json` |
| 同一个旧令牌跑 `find` | 被拒：`INDEX_CHANGED` | `_tmp/qa10-sandbox/find-after-index.json` |
| `req create` 不带 `--acceptance` | **成功**；`acceptance:""`；`需求/` 目录不存在 | `_tmp/qa10-sandbox/req-no-acceptance.json` |
| `task create --requirement R-X`（不存在的需求） | **成功**，任务直接 `working`，owner=programmer1 | `_tmp/qa10-sandbox/direct-task.json` |
| PM 对上述 programmer1 的任务执行 `task done` | **成功**，无开发/测试证据也可 done | `_tmp/qa10-sandbox/pm-done.json` |
| `req review` / `workflow` / `owner` | `BAD_SUBCOMMAND` / `未知命令` / `未知命令` | 探针输出见 `_tmp/qa10-sandbox/` |

### 2.5 真实状态只读检查

```text
node 团队\工具\team.mjs verify   → FAIL，10 个问题
node 团队\工具\team.mjs doctor   → 事件链问题 64
```

- `团队/状态/团队.json:7` 的 `activeProject` 是 `个人简历展示项目`，但 `项目\个人简历展示项目` 不存在；`verify` 对该项目报 10 项 `MISSING`（需求总览、site 文件、验收报告等）。
- `项目\` 下只有 5 个目录，`团队\状态\项目\` 下登记了 6 个项目。
- 真实 `六人敏捷工作区` 缺 `项目信息.md`、`项目铁律.md`、`需求/00-需求总览.md`，索引自己标了“缺文件”，但 README 仍写 `verify` 全绿。
- `项目\项目清单.md:5-6` 和 `六人敏捷工作区\项目索引.md:64` 仍指向旧仓库 `D:\deepseek\工作台\...`。

---

## 三、问题清单（按严重度）

### Q10-01（P0，治理）需求评审、Owner 决定、迭代/终止不是旧工具，`工作流.json` 是壳扩展的第二状态机

**证据**

- 旧 CLI 明确没有这些命令：`src/team-tools.js:60-61` 把 `workflow / owner / req review` 列为可选缺失；`:2357-2361` 注释直接写“当前版本没有实现”。
- `reviewRequirement` 在旧命令缺失时写 `工作流.json`：`src/team-tools.js:3334-3408`，`driver` 为 `工作流.json（旧 shell 文件契约）`；`ownerRequirementDecision` 同样：`:3411-3519`。
- 迭代/终止只改 `工作流.json`：`:3542-3619`；`工作流.json` 的 schema 2、requirements/boots 由壳定义：`:2518-2599`。
- 旧 `team.mjs help` 没有 `workflow`/`owner`/`req review`；探针分别返回 `BAD_SUBCOMMAND`/`未知命令`。
- Electron selftest 自己期望这个缺口：`src/main.js:7421-7427` 断言“旧命令缺失但走文件契约”；`:7571-7573` 断言 `workflow/owner/reqReview=false`。

**影响**

需求评审→PM派单→开发互审→测试→Owner验收这条链，只有 `req create`、`task`、`propose/show/review/sign/apply` 真走旧 CLI；需求评审和 Owner 闸门是壳在自己的 JSON 上做的。任何角色直接调用旧 CLI 都不受这些闸门约束，所谓“唯一真相”不成立。

**建议**

要么把 `req review`、`owner`、`workflow` 真正加进旧 CLI 并让壳只做翻译；要么明确宣布旧 CLI 不是业务写入口，在 `team.mjs` 里拒绝裸写并强制走壳。不能一边叫“旧文件契约”，一边把它当旧工具。

---

### Q10-02（P0，治理）Owner 验收没有身份/TTY 闸门，PM 可以替 Owner `accepted`

**证据**

- `ownerAccept` 允许 `owner` 和 `pm`：`src/team-tools.js:4271-4278`；`accepted` 分支只写本地状态：`:4295-4298`。
- IPC 默认角色就是 `owner`，没有任何终端确认：`src/main.js:3791-3797`；`workflow:owner` / `requirement:owner` 同样没有 TTY 校验。
- 旧工具的 owner 批准反而有 TTY 闸门：`团队/工具/lib/ops.mjs:1780-1794`，无 TTY 直接 `OWNER_TTY_REQUIRED`。
- `ownerAccept` 的注释写“PM 可代办启动下一轮/终止”，但代码没有把 `accepted` 从 PM 的权限里排除。

**影响**

“Owner 验收”退化为渲染层按钮；PM 或任何能调用 preload 的代码可以传 `role:'pm'` 直接验收通过。旧工具的终端批准/签名链在这里完全没有使用。

**建议**

`accepted` 只允许 `owner`；绑定真实终端确认或至少绑定 owner 会话 + 一次性 nonce；PM 只能 `iterate/terminate`，不能 `accepted/rejected`。

---

### Q10-03（P1，流程）旧 `req create` 允许空验收标准，而且不写需求文档

**证据**

- `cmdReq` 直接把 `acceptance: args.acceptance || ''` 交给 `createTask`，没有非空校验：`团队/工具/lib/ops.mjs:519-531`；`createTask` 也不校验：`团队/工具/lib/store.mjs:483-513`。
- 探针：`req create` 不带 `--acceptance` 退出 0，返回 `acceptance:""`，项目里没有 `需求/` 目录。
- 需求文档是壳额外写的：`src/team-tools.js:3034-3073`；旧 CLI 只产生任务 JSON。

**影响**

“无验收标准不开发”只在新壳的 `createRequirement` 里成立，旧 CLI 可以创建空验收需求；这些需求没有 `R-*.md` 正文，项目索引/需求总览也找不到，后续评审没有可读依据。

**建议**

在旧 `cmdReq create` 内强制 `--acceptance`，并生成 `需求/R-*.md` + `00-需求总览.md`；或者禁止直接调用旧 `req create`。

---

### Q10-04（P1，流程）旧 `task create` 可绑定不存在的需求，PM 可直接 `task done` 关闭开发任务

**证据**

- `task create` 接受任意 `--requirement`，不检查需求是否存在/已评审：`团队/工具/lib/ops.mjs:448-460`；`createTask` 只存字符串：`团队/工具/lib/store.mjs:483-513`。
- `finishTask` 允许 `role === 'pm'` 完成任何人的任务：`团队/工具/lib/store.mjs:555-566`；`cmdTask done` 没有额外 owner 校验：`团队/工具/lib/ops.mjs:487-493`。
- 探针：`task create --requirement R-X` 成功并直接 owner=programmer1/status=working；随后 PM `task done` 成功，evidence 写“无开发/测试”。
- 团队宪法写的是“任务只有 owner 能 claim / done”（`团队/团队宪法.md:14`），旧工具已经违反。

**影响**

PM 可以绕过需求评审、开发 claim、互审、测试、Owner 验收，直接用旧 CLI 建任务并关任务。即使壳里的 `工作流.json` 仍显示 `dev`，旧任务已经 `done`，两个账本永久分叉。

**建议**

`task create` 校验 requirement 存在且状态为 ready；`task done` 只允许 owner（PM 仅在显式 owner 覆盖并留审计时）；旧任务状态变化要反向触发工作流校验或直接拒绝。

---

### Q10-05（P1，流程）工作流里的 PM 派单/测试派单不带 `--ack`、不唤醒，派单锁没有生效

**证据**

- `sendWorkflowNotice` 固定传 `--no-wake`，且没有 `--ack`：`src/team-tools.js:3624-3644`。
- `dispatchRequirement` 用它派开发任务：`:3747-3752`；`dispatchTest` 用它派测试任务：`:4233-4238`。
- 旧 `send` 的 PM 派单锁只在 `--ack` 时才写入：`团队/工具/lib/ops.mjs:346-353`；不传 `--ack` 就没有 `PM_DISPATCH_PENDING`。
- Electron Round10 `prompts before=54 / after=54`，证明没有向角色 DSH 会话发唤醒；selftest 却认为这是通过。

**影响**

PM 可以连续给多个角色派单而不触发“一次只能派一个”的锁；消息只落到邮箱，空闲角色不会被唤醒。若角色不主动轮询，工作流会停在“已派单”但无人处理。

**建议**

工作流派单复用 `sendDispatch`（带 `--ack`，由主进程显式 `dsh.prompt(wakeText)`）；把 wake/ack 写入 `comm` 并在 `dispatchRequirement` 返回；selftest 应断言至少一次 prompt/ack，而不是断言 0 prompt。

---

### Q10-06（P1，启动纪律）旧 boot 不读项目信息/项目角色卡/他人文档，项目铁律可回退全局

**证据**

- `readDocSet` 只读五样：宪法、项目铁律（不存在时回退 `团队/项目铁律.md`）、**全局** `团队/角色/<role>.md`、项目索引、团队配置：`团队/工具/lib/store.mjs:272-300`。
- 没有任何 `项目信息.md`、项目目录 `角色卡.md`、其他角色文档进入哈希：boot 令牌 `docHashes` 只有 `constitution/iron/roleCard/projectIndex/teamConfig`。
- 项目角色卡是 `workspace.mjs` 单独创建的（`团队/工具/workspace.mjs:248-252`），但旧 boot 读的是全局卡；壳的 `bootDocSpecs` 也把项目角色卡标成 `required:false`（`src/team-tools.js:2820-2833`）。
- 探针：项目没有 `项目信息.md`、没有六角色目录，`boot` 仍成功；真实 `六人敏捷工作区` 索引标了“项目铁律/项目信息缺文件”，boot 仍能走全局回退。

**影响**

“每轮先读铁律/项目信息/角色卡”只对壳的 `workflowBoot` 部分成立；角色被唤醒时收到的命令是 `team.mjs boot`（`src/team-tools.js:4397`），走的是弱 boot。项目信息缺失不会阻止启动，项目角色卡改了也不会作废令牌。他人文档更是完全依赖角色自觉，没有强制读的证据。

**建议**

`readDocSet` 强制项目信息、项目角色卡；删掉全局铁律回退；boot 简报输出必读文档的路径+哈希并拒绝缺失；唤醒文案改用壳的 `workflowBoot`，不要让角色直接跑弱 boot。

---

### Q10-07（P1，版本栅栏）项目索引变了，旧 boot 令牌仍然可用；只有 `find` 检查

**证据**

- 令牌保存了 `projectIndexHash`，但 `requireBoot` 只比较 `rulesHash`，不比较索引：`团队/工具/lib/store.mjs:328-345`。
- 只有 `cmdFind` 自己检查 `b.projectIndexHash !== currentHash`：`团队/工具/lib/ops.mjs:556-565`。
- 探针：索引哈希 `991de8…` → `0f5d08…` 后，用旧令牌 `send` 退出 0；同一令牌 `find` 才返回 `INDEX_CHANGED`。

**影响**

`send/ack/task/req/propose/review/sign/apply` 都可以在索引变化后继续写。角色可能按旧索引找文件、对旧版本签字；`find` 与写命令的规则不一致，容易误判“令牌还有效”。

**建议**

`requireBoot` 统一比较 `projectIndexHash`；索引变更后所有写命令返回 `INDEX_CHANGED`，让角色重新 boot；`find` 的检查保留但不再例外。

---

### Q10-08（P1，创建顺序）项目创建先写本地库，再补结构；CLI `project add` 直接产生半成品

**证据**

- UI `createProject`：只建六角色目录、`src/_tmp/需求`、`项目信息.md`，随后立刻 `store.projects.push` + `writeStore`，没有项目铁律/协作准则/索引/角色卡：`src/main.js:2315-2335`。
- `project:create` 再调 `syncTeamProject`，失败也只写 warning，仍返回 `ok:true`：`src/main.js:2909-2936`；`ensureProjectReady` 的失败在 `src/team-tools.js:2797-2816`。
- CLI `project add` 只写 README、项目说明、项目铁律，然后 `generateIndex`：`团队/工具/lib/ops.mjs:228-244`、`团队/工具/lib/store.mjs:220-263`；探针确认没有六角色目录、没有项目信息/协作准则、`roleIndexes=0`。

**影响**

项目会先以“工作台项目”的身份出现在本地库/当前项目里，但六角色结构/索引/铁律还没齐；一旦 ensure 失败（工具缺失、目录冲突、权限），用户仍得到一个 `ok:true` 的半成品。CLI 更是完全绕过六角色创建，`boot` 还能成功，掩盖问题。

**建议**

创建顺序改为“建目录 + 六角色 + 铁律/准则/索引 + 校验通过 → 再登记本地项目”；ensure 失败回滚并返回失败；`project add` 要么删除，要么强制走 `workspace ensure` 的同一套 scaffold。

---

### Q10-09（P1，第二真相）本地 `workbench.json` 任务仍会写入/删除旧任务文件

**证据**

- UI 的任务 CRUD 仍只写本地库：`src/main.js:4010-4024`；写完后调 `mirrorToTeamBoard`：`:2618-2629`。
- `syncWorkbenchBoard` 会把本地任务写成旧 `任务/<id>.json`（`source:'workbench'`），本地任务删除时还会删掉旧文件：`src/team-tools.js:987-1053`。
- `publicProject` 注释说“阶段/需求/任务/boot 以旧团队状态为准”，但本地任务和旧任务仍双向存在：`src/main.js:1882-1886`；Round10 selftest 只清空本地 `requirements` 验证重建，没有测本地任务：`src/main.js:7578-7594`。

**影响**

本地任务不是“只读镜像”：它是旧任务文件的另一个写入者。若角色先用旧 CLI claim/done 了由本地同步过去的任务，`source:'workbench'` 仍保留；之后 UI 再 update/delete，会覆盖或删除角色的真实进度/证据。两个账本会互相回滚。

**建议**

团队项目登记后，任务页改为只读旧状态，或所有本地任务也走 `team.mjs task`；禁止 `syncWorkbenchBoard` 删除旧任务；给同步记录加版本/CAS，发现旧工具已修改就拒绝覆盖。

---

### Q10-10（P1，一致性）旧提交和本地 `工作流.json` 没有事务/补偿，失败会停在分叉状态

**证据**

- `devApply` 先执行旧 `apply`：`src/team-tools.js:4155-4159`，再写本地 `工作流.json`：`:4162-4183`；本地写失败时旧 commit 已经落盘，接口却返回失败。
- `doneWorkflowTask` 先旧 `task done`：`:3888-3911`，再写本地状态：`:3893-3914`。
- `ownerAccept` 先写本地 accepted：`:4289-4322`，再旧 `task done`：`:4327-4329`；旧任务失败只放在 `requirementTaskDone`，返回仍是 `ok:true`：`:4354-4360`。
- `createRequirement` 先旧 `req create`：`:3252-3260`，再写需求文档和本地状态：`:3291-3311`。

**影响**

会出现“文件已 apply，但工作流还在 dev_review”“Owner 已 accepted，但需求任务还 open”“旧需求已存在，但本地没有 workflow 记录”等分叉；重试时旧提案已 closed，用户会卡死。没有 outbox、补偿或幂等键。

**建议**

给跨存储写操作设计单一提交顺序 + 失败补偿/可重试记录；至少把旧命令结果和本地写入结果一起返回，不允许 `ok:true` 掩盖 `requirementTaskDone.ok=false`。

---

### Q10-11（P1，生命周期）新需求迭代/终止只改本地，旧任务、需求文档、需求总览不同步

**证据**

- `terminateWorkflow` 只遍历 `工作流.json` 的 requirements 改状态：`src/team-tools.js:3591-3603`；不写旧 `任务/*.json`，不释放任务锁。
- `ownerAccept` 的 `terminated` 分支只改当前一条需求：`:4310-4315`，其他 ready 需求仍在，`state.phase` 却是 `terminated`。
- `writeRequirementDoc` 只在首次创建时写，之后不更新状态/历史：`:3034-3062`；`00-需求总览` 只在创建时 append：`:3064-3073`。
- 旧 `task create` 完全不读 `工作流.json`；Q10-04 已实测旧 CLI 可以绕过工作流建任务/关任务。

**影响**

终止后旧看板仍有 open/working 任务，需求正文仍写“review”，索引/总览与工作流 phase 不一致；迭代只把 `queued` 清零，不会为新轮次创建文档/任务。所谓“终止/迭代”只影响壳的 UI。

**建议**

终止时同步更新所有旧任务状态、释放锁、写需求文档/总览；迭代时生成新轮次目录/任务并刷新索引；旧 CLI 至少拒绝在 `phase=terminated` 时建任务。

---

### Q10-12（P1，D 盘/真实状态）真实状态仍指向旧仓库，`activeProject` 是幽灵目录

**证据**

- `团队/状态/团队.json:7` 的 `activeProject` 是 `个人简历展示项目`；`项目\个人简历展示项目` 不存在（`Test-Path=False`）。
- `项目\项目清单.md:5-6` 仍指向 `D:\deepseek\工作台\项目\...`。
- `项目\六人敏捷工作区\项目索引.md:17-21` 自己标了项目铁律/项目信息/需求总览“缺文件”，`:64` 的 JSON 路径仍是旧 `D:\deepseek\工作台\项目\...`。
- `团队/README.md:81` 声称“`verify` 全绿 / 0 问题”；实际 `verify` FAIL 10 项、`doctor` 事件链 64 问题。

**影响**

新工作台打开就选不存在的当前项目；旧项目文件在旧根，状态在新根；`verify` 无法作为“唯一真相”的健康证明。D 盘“同盘”不等于“同一份状态”。

**建议**

迁移/重建真实项目目录，清空或重指 `activeProject`；所有索引重新生成；把 `verify` 作为启动前硬闸门；删除 README 里的“全绿”静态文案或改成动态结果。

---

### Q10-13（P2，结构约定）`src/` 和 `site/` 两套代码目录约定同时存在

**证据**

- 主程序项目模板写“代码目录：src/”：`src/main.js:1968-1970`；`createProject` 建 `src/`：`:2317`。
- `workspace.mjs` 建 `site/`，角色卡/协作准则写默认 `site/**`：`团队/工具/workspace.mjs:75,83,121,262-264`。
- 壳的 `ensureProjectStructure` 只补 `src/_tmp/需求`：`src/team-tools.js:2702`；Round10 selftest 用 `site/round10.txt`：`src/main.js:7452`。

**影响**

同一个项目里可能同时出现 `src/` 和 `site/`；程序员按项目信息写 `src/`，角色卡说 `site/`，提案授权/索引/验收路径容易对不上。两条创建路径生成不同的角色文档和目录，正好是“本地第二套真相”的结构来源。

**建议**

只保留一个代码目录常量（建议 `site/` 或 `src/`），由 `package.json`/项目信息/角色卡/索引/测试共用；创建时不要同时建两个。

---

### Q10-14（P2，并发）`工作流.json` 的读-改-写没有锁，六个 boot 并发会丢记录

**证据**

- `mutateWorkflowState` 先 `readWorkflowState`，再改内存，再 `writeWorkflowState`：`src/team-tools.js:2609-2619`；没有 `acquireLock`/CAS/rev。
- `bootRole` 每个角色都写 `state.boots[role]`：`:2907-2919`；六角色并发 boot 时后写覆盖前写。
- 现有锁只用于任务/提案/apply，`工作流.json` 的 Owner 决定/评审/终止也走同一读改写。

**影响**

并发 boot 可能只剩一个角色记录，`workflowBriefing` 会误报未 boot；并发评审/终止可能丢需求或覆盖 `ownerReview`。这是本地 JSON 状态机没有并发控制的直接风险。

**建议**

对 `工作流.json` 使用与任务相同的目录锁或带 `rev` 的 CAS；写入失败重读重试；selftest 增加并发六 boot/评审。

---

### Q10-15（P3，测试基础设施）“D 盘 selftest”默认会用 `%TEMP%`，并覆盖仓库根截图

**证据**

- `团队/工具/lib/selftest.mjs:32` 用 `os.tmpdir()` 建沙盘；Windows 默认就是 `%TEMP%`（本次为 `C:\Users\Admin\AppData\Local\Temp`），只有显式把 `TEMP/TMP` 指到 `_tmp` 才在 D 盘。
- Electron selftest 写仓库根 `selftest-flow.png` / `selftest.png`：`src/main.js:8042-8047`；即使 `AWB_SELFTEST_ROOT` 在 `_tmp`，截图仍写 `ROOT`。
- 本次已备份/恢复两张图，否则“只新增 docs/QA-ROUND10.md”会被测试破坏。

**影响**

“D 盘 selftest”不是自证的；`team.mjs selftest` 在别的机器/默认环境下会把临时目录放到 C 盘；跑一次 Electron selftest 就会改仓库根文件，CI/QA 边界不可重复。

**建议**

两个 selftest 都从 `AWB_SELFTEST_ROOT` 派生临时目录；截图写到沙盘根；`package.json` 的 `selftest` 显式设置 D 盘临时根，或在测试前拒绝非 D 盘。

---

## 四、优先级建议

| 优先级 | 问题 | 理由 |
|---|---|---|
| P0 | Q10-01 / Q10-02 / Q10-04 | 旧 CLI 可绕过需求评审/Owner；PM 可替 Owner 验收/关开发任务。 |
| P1 | Q10-03 / Q10-05 / Q10-06 / Q10-07 / Q10-08 | 需求空验收、派单不唤醒、boot 必读不全、索引令牌不失效、项目半成品。 |
| P1 | Q10-09 / Q10-10 / Q10-11 / Q10-12 | 本地任务反向写旧状态、跨存储分叉、终止/迭代不落地、真实 D 盘状态坏。 |
| P2 | Q10-13 / Q10-14 | 目录约定分裂、`工作流.json` 并发丢写。 |
| P3 | Q10-15 | 测试会写根目录/默认用到 C 盘临时目录，影响只读 QA 边界。 |

---

## 五、一句话总结

**这一版把“需求评审→PM派单→开发互审→测试→Owner验收”做成了壳里的 `工作流.json` 状态机，旧 CLI 仍是可写旁路；所以“唯一真相”“每轮强制 boot”“Owner 验收”目前都只能算界面流程，不是协议保证。**
