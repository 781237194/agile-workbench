# 第十一轮只读 QA 报告 · agile-workbench

- 仓库：`D:\deepseek\agile-workbench`
- 时间：2026-11-05 15:08–15:20（Asia/Shanghai）
- 边界：**只新增本文件**（`docs/QA-ROUND11.md`）。临时脚本/日志/沙盘全部在 `_tmp\qa11-*`；`TEMP/TMP` 显式指向 `_tmp`；未改 `src/`、`package.json`、旧仓库、真实 `团队\状态`。
- 方法：读源码 → `npm run check` → 隔离 Electron selftest（mock DSH）→ `团队\工具\team.mjs selftest` → 在 `_tmp` 沙盘里**直接 require `src/team-tools.js` 并调用真实函数**做针对性探针 → 只读 `verify`/`doctor` 检查真实状态。
- 与上一轮的关系：本轮源码在第十轮报告（14:30）之后又改过（`src/*` 14:49–15:05），所以本报告同时记录**已修复项**和**新增/仍然存在的问题**，不重复第十轮已给出且已修掉的结论。

---

## 一、结论速览

| 审计问题 | 结论 | 一句话证据 |
|---|---|---|
| 项目创建是否先建六角色目录/索引/铁律 | **主路径成立**（本轮已修） | `createProject` 先 `ensureProjectReady` 校验结构，通过后才写本地库；失败回滚目录/记录/团队登记（`src/main.js:2441-2468`）。 |
| boot 是否读项目信息/角色卡/索引/相关文档 | **成立，有哈希证据** | 沙盘实测 7 项哈希全 `true`；旧 `readDocSet` 强制项目信息/项目角色卡/需求总览，缺失直接拒绝 boot。 |
| 需求评审→PM派单→开发互审→测试→Owner验收是否真走旧工具 | **3 步真走，2 步不是** | `task create/send`、`show/review/sign/apply`、`task claim/done` 是旧 CLI；`req review`、`owner` 旧 CLI 仍不存在（`capabilities.missing=[workflow,owner,req review]`），评审与 Owner 写 `工作流.json`。 |
| 是否有本地假状态/假按钮 | **有，且比上一轮更隐蔽** | 顶层 Owner 闸门与需求级 Owner 闸门互不相通；本地任务页对团队项目已是纯装饰（`MIRROR_ONLY`）；`team:proposal-legacy` 永远调不通。 |
| 迭代/终止 | **不成立** | 终止只改 `工作流.json`；实测旧任务仍 `open`、需求总览仍 `open`、看板仍显示“待领取”。 |
| D 盘 | **程序数据在 D 盘；真实状态进一步恶化** | `verify` 120 问题（31 ❌/12 ⚠，事件链 64）；6 个登记项目里 2 个是幽灵目录、1 个目录未登记；`activeProject` 指向幽灵。 |

---

## 二、验证命令与结果

### 2.1 `npm run check`

```text
> node --check src/main.js && node --check src/preload.js && node --check src/renderer/app.js
  && node --check src/dsh-adapter.js && node --check src/team-tools.js

CHECK_EXIT=0
```

5 个入口语法通过。**它不跑行为测试**，不能作为流程正确的证据。日志：`_tmp/qa11-check.log`。

### 2.2 D 盘 Electron selftest（`npm run selftest`）

第一次按 `package.json` 的 `selftest` 脚本原样运行**直接失败**：

```text
app.setPath('userData', USER_DATA);
    ^
TypeError: Cannot read properties of undefined (reading 'setPath')
    at Object.<anonymous> (D:\deepseek\agile-workbench\src\main.js:82:5)
（退出码 1）
```

原因：本会话（由 DSH 派生）环境里带着 `ELECTRON_RUN_AS_NODE=1`，`electron .` 退化成纯 Node，`require('electron').app` 是 `undefined`。清掉该变量后重跑：

| 项 | 结果 |
|---|---|
| 退出码 | 0，`SELFTEST_OK` |
| STORE | 20 checks / 0 failed |
| COMPAT | 46 / 0 |
| MAPPING | 39 / 0 |
| ROUND5 / ROUND6 / ROUND9 | 4 / 17 / 8，全 0 failed |
| ROUND10 | 6 / 0；`driver="工作流.json（旧 shell 文件契约）"`，`missingCode/strictReview/strictOwner` 全 `LEGACY_PROTOCOL_REQUIRED`，`prompts 54→54` |

日志：`_tmp/qa11-electron/selftest.log`（失败）、`selftest2.log`（通过）。

**注意**：这次 selftest 又把仓库根 `selftest.png` / `selftest-flow.png` 覆盖了（见 Q11-13），已用 `_tmp\awb-ui\png-before` 的原件还原，哈希回到 `BA66B36F…CCD4` / `2017F6A9…BE2C`。

### 2.3 `团队\工具\team.mjs selftest`

```text
沙盘：D:\deepseek\agile-workbench\_tmp\team-selftest-RQtgBV
...
SELFTEST 25/25 PASS
TEAM_SELFTEST_EXIT=0
```

25 项里有几项正是上一轮的问题，现在通过了：

- `PASS project add：六角色目录/角色卡/文件索引/产出 + 根必备 + 索引五类产物`
- `PASS boot：read 证据固定顺序（铁律→信息→角色卡→索引→需求/他人文档）`
- `PASS 缺 项目信息.md：boot 拒绝 + project ensure 补回`
- `PASS 缺命令明确失败：workflow / owner / req review`
- `PASS req create：验收必填 + 生成 R-*.md/需求总览`
- `PASS task create：需求必须存在；boot 读到本轮相关需求 R-*.md`

但它仍然是**旧工具自己的**闭环测试，不覆盖“壳的工作流是否把这些串起来”，也不覆盖下面任何一个 Q11 问题。日志：`_tmp/qa11-team-selftest.log`。

### 2.4 沙盘探针（本轮主要证据）

在 `_tmp\qa11-sandbox` 里 `require('src/team-tools.js').create({teamRoot})`，直接调用壳的真实函数，走“建项目 → 六角色 boot → 建需求 → 评审 → Owner → 派单 → 终止”，并读回旧任务/需求文档/看板/工作流。原始输出：`_tmp/qa11-sandbox/probe.json`、`probe2.json`。

关键实测结果：

| 步骤 | 返回 | 说明 |
|---|---|---|
| `ensureProjectReady` | `ok:true, structureOk:true, missing:[]` | 六角色目录/铁律/项目信息/索引/需求总览齐全 |
| `bootRole('product')` | `complete:true`，7 项 `hashChecks` 全 `true` | 含 projectInfo / roleCard / projectIndex / requirementOverview |
| `createRequirement` | `ok:true`，`R-…-0b1d`，`driver:"team.mjs req create"` | 旧 `req create` 真的写了 `需求/R-*.md` |
| `reviewRequirement` | **`ok:false, code:RULES_CHANGED`** | 建需求后产品自己的 boot 立刻失效（见 Q11-05） |
| `ownerRequirementDecision`（**不传 role**） | `ok:false, code:PRODUCT_REVIEW_REQUIRED` | **不是**身份错误——证明这里根本没有身份校验（见 Q11-01） |
| `dispatchRequirement`（PM 未 boot） | `ok:false, code:BOOT_REQUIRED` | 闸门有效（正向） |
| `terminateWorkflow`（PM） | `ok:true, phase:terminated` | 只改 `工作流.json` |
| 终止后旧任务 | `status=open, owner=空` | 没同步（见 Q11-03） |
| 终止后看板 | `看板.md` 里该需求状态列 = **待领取** | 角色仍会去领已终止需求 |
| 终止后 `createRequirement` | `ok:false, code:WORKFLOW_TERMINATED` | 正向 |
| 终止后 programmer1 裸跑 `task create` | `exit 3, NOT_PM` | 旧 CLI 也收紧了（正向） |

### 2.5 真实状态只读检查（不写任何文件）

```text
node 团队\工具\team.mjs verify  → verify：❌ FAIL  项目 6 个 ｜ 事件 1212 条 ｜ 问题 120 ｜ 警告 12
node 团队\工具\team.mjs doctor  → 事件链问题 64 ｜ 试点 FAIL
```

日志：`_tmp/qa11-verify.log`、`_tmp/qa11-doctor.log`。

---

## 三、本轮已修复 / 已成立的部分（先给结论，避免误读）

| 上一轮问题 | 现状 | 证据 |
|---|---|---|
| Q10-08 创建先写库后补结构 | **修好** | `src/main.js:2441-2468`：`ensureProjectReady` → 结构必须 `ok:true` → 才 `store.projects.push`；DSH 登记失败 `rollbackCreatedProject` 并抛带 code 的错误。selftest ROUND10 `createRollback` 断言目录/记录/团队登记三样都回滚。 |
| Q10-06 boot 不读项目信息/项目角色卡/他人文档 | **修好** | `团队/工具/lib/store.mjs readDocSet` 强制 6 份必读（含项目信息、项目目录角色卡、需求总览），缺失 `MISSING_DOC`；顺序 1–5 固定；再读“本轮相关”（未读消息 + 未完成任务引用的需求 / 他人文件）。壳的 `bootRole` 逐项比对令牌 `docHashes`（`src/team-tools.js:2956-2972`），沙盘实测全命中。 |
| Q10-03 空验收需求 | **修好** | `src/team-tools.js:3429-3431` 强制验收；旧 `req create` 也生成 `需求/R-*.md` + 总览，沙盘实测 `driver:"team.mjs req create"`。 |
| Q10-04 任意需求 id、PM 随意关任务 | **部分修好** | 旧 CLI `task create` 现在校验需求存在（25/25 里 `PASS task create：需求必须存在`），且非 PM 建任务被拒（实测 `exit 3 NOT_PM`）。`task done` 仍允许 PM 关任何人的任务（`lib/store.mjs finishTask` 的 `role !== 'pm'` 旁路还在）。 |
| Q10-02 PM 替 Owner 验收 | **部分修好** | `ownerAccept` 现在 `accepted/rejected` 只允许 `owner`（`team-tools.js:4526-4528`）。但默认角色仍是 `owner` 且无身份核验（见 Q11-02）。 |
| Q10-09 本地任务反写旧任务 | **方向修好，但留下死列表** | `syncWorkbenchBoard` 直接返回 `MIRROR_ONLY`（`team-tools.js:987`），不再写旧 `任务/`；代价是本地任务变成纯装饰（见 Q11-09）。 |
| Q10-15 team selftest 默认用 `%TEMP%` | **修好** | `团队/工具/lib/selftest.mjs:33-38` 把沙盘固定到仓库 `_tmp`，本次实测沙盘就在 `_tmp\team-selftest-RQtgBV`。Electron selftest 写仓库根截图**仍未修**（Q11-13）。 |

---

## 四、问题清单

### Q11-01（P0，治理）需求级 Owner 决定没有任何身份校验，`by:'Owner'` 是写死的

**证据**

- `ownerRequirementDecision` 全文没有读 `input.role`，也没有会话/TTY/nonce：`src/team-tools.js:3618-3740`。唯一的“前置”是 **产品的** boot：
  ```js
  // Owner 是外部角色，没有自己的 boot；Owner 闸门以产品评审人的完整阅读为前提
  const gate = requireWorkflowBoot(ctx.name, ctx.projectPath, 'product', { requirementId });
  ```
  `src/team-tools.js:3634-3649`
- 落盘署名写死：`row.ownerReview = { status: decision, by: 'Owner', ... }`（`src/team-tools.js:3655`），`pushWorkflowEvent(..., role: 'owner', ...)`（`:3676`）。
- IPC 也不传身份：`ipcMain.handle('requirement:owner', ...)` 只透传 payload（`src/main.js:3870-3876`）。
- 沙盘探针用**不带 role** 的调用，返回的是 `PRODUCT_REVIEW_REQUIRED` 而不是 `ROLE_NOT_ALLOWED` —— 说明进入业务判断前根本没有身份分支（`_tmp/qa11-sandbox/probe.json`）。

**影响**

“Owner 决定”只是调用者自称。PM、程序员、或任何能执行 preload 的渲染层代码，只要先让产品 boot，就能把需求标成 `Owner approved` 并推进到派单。旧工具里 Owner 批准有真实 TTY 闸门（`owner-approve … 必须真实终端，无 TTY 拒绝`，见 `team.mjs help`），这里完全没有。

**建议**

`requirement:owner` 必须携带 Owner 身份（一次性 nonce / 终端确认 / Owner 会话 + 签名），`by` 只能由服务端解析；没有身份时返回 `OWNER_IDENTITY_REQUIRED`，不能默认当 Owner。

---

### Q11-02（P0，审计链）Owner 验收的“唯一真相”由 PM 代写，且失败被 `ok:true` 吞掉

**证据**

- 验收通过分支用 **pm** 跑旧 `task done`：
  ```js
  requirementTaskDone = await runLegacyCommand(ctx.name, 'pm', 'task done', (token) => [
    'task','done','--boot',token,'--id',requirementId,
    '--evidence', `Owner 验收通过${...}`
  ], { sessionId: '' });
  ```
  `src/team-tools.js:4577-4582`
- 旧任务因此记 `_by: 'pm'`（`lib/store.mjs finishTask`），但证据文本写“Owner 验收通过”。
- 该调用的结果只放进 `requirementTaskDone`，外层仍 `ok:true`（`src/team-tools.js:4606-4612`）；而 `app.js` 里 **`requirementTaskDone` 出现 0 次**（全文件检索），界面不可能提示这次失败。
- 同理 `ownerAccept` 的默认角色是 `owner`（`:4517`），`owner:accept` IPC 也默认 `'owner'`（`src/main.js:3940-3946`），没有任何身份核验。

**影响**

验收后旧账本上留下“PM 关闭了需求任务”的痕迹，而界面显示“Owner 已验收”。一旦 `task done` 失败（任务已 done、需求 id 不是任务 id、旧 CLI 报错），用户看到成功、旧任务却还开着，下一次派单/验收会被 `TEST_NOT_DONE` 或 `TASK_DONE` 卡住，且没有任何界面线索。

**建议**

验收的收口只能由 Owner 身份执行（或由壳以 `owner` 跑并在证据里带可验证的 Owner 决定 id）；`task done` 失败必须让整个验收返回失败或显式 `warning` 上升为界面可见错误。

---

### Q11-03（P1，生命周期）终止/迭代只改 `工作流.json`，三个账本当场分叉，看板还把已终止需求标成“待领取”

**证据（沙盘实测，同一时刻）**

| 账本 | 值 |
|---|---|
| `团队/状态/项目/项目甲/工作流.json` | `phase=terminated`，需求 `status=terminated`，`terminatedBy=pm` |
| `团队/状态/项目/项目甲/任务/R-…-0b1d.json` | `status=open`（完全没动） |
| 项目 `需求/00-需求总览.md` | 状态列 `open` |
| `团队/看板.md`（角色读的那张） | 该需求一行：优先级 `P2`、状态 **待领取**、子任务 `0/0` |

- 终止实现只遍历 `state.requirements` 改状态：`src/team-tools.js:3809-3832`，没有 `patchLegacyTask`、没有释放任务/派单锁、没有更新需求文档/总览。
- 迭代同样只改内存里的 round/queued：`:3761-3788`，不建新轮次目录、不产生新文档/任务。
- `writeRequirementDoc`/总览只在创建时写一次（`:3205-3247`），之后状态变化不回写。
- 旧 CLI 完全不读 `工作流.json`（`capabilities.missing` 里有 `workflow/owner/req review`），所以看板天然看不到 `terminated`。

**影响**

终止后角色仍会从看板/邮箱看到“待领取”的需求并去 claim；PM 的看板与 Owner 的界面各说一套。迭代同理：`round` 变成 2，但项目里没有任何“第 2 轮”的可读产物，需求文档仍写着第 1 轮。

**建议**

终止/迭代必须作为一次事务同时更新：旧 `任务/*.json`（关闭/释放）、`需求/R-*.md` 状态段、`00-需求总览.md`、索引、锁；旧 CLI 至少要识别 `工作流.json` 的 `terminated` 并拒绝相关写操作。

---

### Q11-04（P1，假按钮）顶层 Owner 闸门和需求级 Owner 闸门互不相通，界面上“Owner 通过”推不动派单

**证据**

- 界面「Owner 评审」弹窗调用 `window.workbench.ownerDecide`（`src/renderer/app.js:6836`）→ `owner:decide` / `workflow:owner` → 本地 `ownerDecide(project, status, …)`，只写 **`project.ownerReview`**（`src/main.js:2624-2633`），再调 `recordOwnerDecision`。
- `recordOwnerDecision → writeOwnerWorkflow` 只改 `工作流.json` 的**顶层** `ownerReview`（`src/team-tools.js:872-903`），从不碰任何需求的 `requirements[id].ownerReview`。
- 而 PM 派单检查的是**需求级**字段：
  ```js
  if (!meta.ownerReview || !['approved','skipped'].includes(String(meta.ownerReview.status)))
    return failure('OWNER_REVIEW_REQUIRED', ...);
  ```
  `src/team-tools.js:3962-3964`
- 需求级路径是另一个函数 `ownerRequirementDecision`（`:3618`），界面上是另一个入口（`data-legacy-req-action="owner-review"` → `wb.requirementOwner`，`app.js:4298`）。

**影响**

两个“Owner 评审”入口、两个字段、两套后果：在旧流程卡片里点“通过”，界面会显示本轮 Owner 已通过（`renderFlow` 读顶层 `ownerReview`），但工作流派单仍然 `OWNER_REVIEW_REQUIRED`。用户会认为“按钮坏了”或“系统在骗我”。

**建议**

只保留一个 Owner 闸门。要么把 `ownerDecide` 改成写需求级（并要求 `requirementId`），要么在界面明确标注“这是旧版项目级闸门，不参与需求派单”，并把两个入口合并。

---

### Q11-05（P1，可操作性）任意一条新需求会让全队 6 个角色的 boot 证据同时作废，在途需求也被卡住

**证据**

- 沙盘实测：`bootRole('product')` 成功后 `createRequirement` 成功，紧接着 `reviewRequirement` 直接失败：
  ```json
  {"ok":false,"code":"RULES_CHANGED",
   "message":"角色「产品设计师」boot 后必读文件已变化（项目索引、需求总览、本轮相关需求），旧阅读证据作废；请重新 boot"}
  ```
  原因：旧 `req create` 会重写 `项目索引.md`、追加 `00-需求总览.md`、新增 `需求/R-*.md`，三者都在 `requireWorkflowBoot` 的比对集里（`src/team-tools.js:3075-3089`）。
- 这不是偶发：ROUND10 selftest 自己就插了两次“全员重新 boot”（“需求后重新 boot” 6 个角色，`src/main.js:7617-7628`；“apply 后重新 boot” 6 个角色，`:7691-7702`），加上最开始那次，一轮流程实际跑了 **18 次 boot**。
- 失效是**全员**的：`requireWorkflowBoot` 用 `boot.requirementsHash` 与当前全部 `R-*.md` 比较，新增一条需求会让 PM 对**其它在途需求**的派单也一起被拒。

**影响**

“每轮 boot 一次”的叙事不成立——是“每次写文档全队重 boot”。界面每个角色都要手点一次 boot（6 次/需求），漏一个就卡在某个闸门；在途需求会被一条不相关的新需求打断。

**建议**

把“本轮相关需求”收窄到当前需求（或按需求 id 建哈希桶），不要用全量 `R-*.md` 哈希；索引/总览的变化不应作废“已读需求正文”的证据；界面上提供“一键全队重新 boot”。

---

### Q11-06（P1，派单）工作流派单不唤醒、不写回执锁，PM 可以连派多单

**证据**

- `sendWorkflowNotice` 固定 `--no-wake`，且始终不带 `--ack`：
  ```js
  'send','--boot',token,'--to',to,'--subject',subject,'--body',body,'--no-wake',
  ```
  `src/team-tools.js:3869-3873`
- 它被 `dispatchRequirement`（`:3980`）和 `dispatchTest`（`:4478`）复用。
- 旧 CLI 的“一次只能派一单”锁只在 `--ack` 时写入（`team.mjs help`：`send ... [--ack]`）；Electron selftest ROUND10 记录 `prompts before=54 / after=54`，证明全程没向任何 DSH 会话发唤醒。

**影响**

派单只落邮箱：空闲角色不会醒；PM 可以连续给多人派单而不触发 `PM_DISPATCH_PENDING`。工作流停在“已派单”，实际没人处理，而界面显示正常。

**建议**

工作流派单复用带 `--ack` 的 `sendDispatch`，由主进程显式 `dsh.prompt(wakeText)`，并把 `wake/ack` 结果写回 `comm` 和返回值；selftest 应断言至少一次 prompt/ack，而不是把 0 prompt 当成功。

---

### Q11-07（P1，签字链）开发互审和 PM 签字由壳一口气代跑，没有会话或人的证明

**证据**

- `devReview` 用互审角色直接连跑旧 `show` + `review`，且 `allowMissingSession: true`：
  `src/team-tools.js:4327-4333`
- `devApply` 一次调用里跑完 `show → review → sign → apply` 四步，全部以 `role:'pm'`：
  `src/team-tools.js:4386-4402`
- 两步都不要求调用者提供该角色的真实会话；`readProjectSessions` 只用来“尽量带上” sessionId（`:4326`、`:4385`），缺失也放行。

**影响**

“互审”“PM 签字”在审计上等于“点击者替这两个角色做了”。旧协议本来要求申请者/评审者/签字者各自 boot 并留回执，这里被折叠成一个按钮。高风险提案的 `sign --self`、风险级别确认也没有人类确认环节。

**建议**

`review`/`sign` 必须绑定对应角色的真实会话（或一次性签名 nonce），壳只做转发不代跑；至少把“本次由壳代跑”写进提案/提交的 actor 字段，让审计能区分。

---

### Q11-08（P2，闸门质量）占位符内容可以通过 boot 和产品评审，“先读后写”只校验了哈希和标题

**证据**

- 新建项目的 `项目信息.md` 是模板，正文就是 `（待项目经理填写）` / `（待填写）`（`src/team-tools.js:2647-2658`）；沙盘实测该文件 1146 字节、含两处占位符，`bootRole` 仍然 `complete:true` 且 7 项哈希全 `true`。
- 需求正文同样：`createRequirement` 只校验 `title` 非空、`acceptance` 非空（`:3429-3431`）；生成的需求文件里“场景 / 目标 / 用户故事”都是 `（待补）`（实测 `R-…md`），产品评审照样可以 `approve`。
- 评审只校验评审人 boot 与 verdict/理由长度（`:3547-3550`），不校验正文完整度。

**影响**

“每轮必读”“无验收不开发”变成了“有文件、有哈希、有一个标题”。新项目第一次评审可以在全是占位符的文档上通过，验收标准只有一行字也能进开发。

**建议**

boot 简报里标记占位符/未填写段落，并在关键闸门（产品评审、Owner 放行）拒绝“正文仍是模板”的需求；项目信息至少要求目标/边界两节非空。

---

### Q11-09（P2，第二真相）团队项目的“任务”页已变成纯本地装饰，界面却仍当作真任务

**证据**

- `syncWorkbenchBoard` 现在是硬编码空操作：
  ```js
  return { ok:true, code:'MIRROR_ONLY', skipped:true, direction:'none',
           truthSource:'legacy-workflow', counts:{tasks:0,...} };
  ```
  `src/team-tools.js:987-1002`
- 旧的写入实现 `syncWorkbenchBoardLegacyWrite`（`:1004`）**没有任何调用点**（全仓库检索只有定义行），是死代码。
- 但本地任务 CRUD 仍然只写 `workbench.json` 然后调 `mirrorToTeamBoard`，并照常返回 `{ok:true, task}`：
  `src/main.js:4159-4173`（create）、`:4175-4186`（update）、`:4191-4198`（delete）
- `publicProject` 直接 `...project`，所以本地 `tasks` 原样给界面（`src/main.js:1880-1882`）；`app.js` 里 **`MIRROR_ONLY` 出现 0 次**，界面不会解释“这些任务角色看不到”。

**影响**

用户（尤其 Owner）在任务页新建/改状态/删除任务，界面一路成功，但旧看板、旧 `任务/`、任何角色都看不到；而真正的任务在旧协议里。两套列表并存，用户无法判断哪个算数。

**建议**

团队项目登记后把任务页改成只读旧状态（或所有任务统一走 `task create/claim/done`）；至少对 `MIRROR_ONLY` 给出显式提示，并删掉死函数。

---

### Q11-10（P1/P2，D 盘真实状态）`verify` 120 个问题，2 个幽灵登记 + 1 个未登记目录，真实项目已无法 boot

**证据**

```text
verify：❌ FAIL
项目 6 个 ｜ 事件 1212 条 ｜ 问题 120 ｜ 警告 12
  ❌ EVENT_CHAIN count 64
  ❌ PROJECT_STRUCTURE 个人博客项目 项目信息.md / 项目铁律.md / 全角色目录 …
doctor：❌ 事件链问题 64 ｜ 阶段 team ｜ 试点 FAIL
```

- `团队/状态/团队.json` 的 `activeProject` = `个人简历展示项目`，但 `项目\个人简历展示项目` **不存在**（`项目\` 下是：六人敏捷工作区、团队工作台改造、小鱼、微光作品集、测试工作台项目）。
- `团队/状态/项目/` 登记 6 个：`个人博客项目`、`个人简历展示项目` 都没有目录（幽灵）；`项目\小鱼` 有目录但没登记（孤儿）。
- 真实项目 `项目\六人敏捷工作区` 缺 `项目信息.md`、`项目铁律.md`、`需求/00-需求总览.md`（三项 `Test-Path=False`），其 `项目索引.md:17-21` 自己也标了“缺文件”。
- 升级后的 `readDocSet` 对这三项是**硬拒绝**（`MISSING_DOC`/`PROJECT_STRUCTURE_INCOMPLETE`），所以这个真实项目现在**任何角色都无法 boot**。
- `项目\项目清单.md:5-6` 仍指向旧仓库 `D:\deepseek\工作台\项目\...`。

**影响**

新工作台一打开就选中一个不存在的当前项目；真实项目既不能 boot 也不能作为“唯一真相”的健康样本；`verify` 从上一轮的 10 个问题涨到 120 个，说明这段状态在持续劣化而不是被清理。

**建议**

清空/重指 `activeProject`；对幽灵登记执行 `project ensure` 或删除登记；补齐真实项目三份必读文档并重生成索引；把 `verify` 做成打开项目前的硬闸门，并把 `项目清单.md` 的旧路径统一改成新仓库根。

---

### Q11-11（P2，可重复性）`npm run selftest` 在带 `ELECTRON_RUN_AS_NODE` 的环境直接崩；`--user-data-dir` 形同虚设

**证据**

- 原样运行即失败（见 2.2）：`src/main.js:82` `app.setPath(...)`，`TypeError: Cannot read properties of undefined (reading 'setPath')`，退出码 1。本会话的 `ELECTRON_RUN_AS_NODE=1` 来自 DSH 的派生子进程环境；即“工作台是 DSH 的壳，但它的自测不能在 DSH 派生的终端里跑”。
- `package.json:14` 的脚本自带 `--user-data-dir=userdata-selftest`，而 `src/main.js:19` 又把 `USER_DATA` 固定成 `DATA_ROOT/userdata` 并 `app.setPath` 覆盖（`:82`）——命令行传的目录不生效。实测仓库根留下一个空的 `userdata-selftest\`（0 文件），真正的 profile 在 `AWB_SELFTEST_ROOT/userdata`。
- 追加 `-- --user-data-dir=...` 还会出现两个同名参数（`selftest.log` 里能看到两遍）。

**影响**

CI/容器/被 Electron 宿主托管的终端里自测直接不可用，且报错信息完全不指向真实原因；`--user-data-dir` 给人一种“已隔离”的错觉。

**建议**

`package.json` 里先 `set ELECTRON_RUN_AS_NODE=`（或 `cross-env` 清空），`main.js` 顶部检测到该变量时给出可操作的错误；删掉 `--user-data-dir` 或让 `USER_DATA` 真正读它；把自测输出目录统一到 `AWB_SELFTEST_ROOT`。

---

### Q11-12（P3，死接口）1 个 IPC 永远调不通，6 个 preload 桥在界面零引用

**证据**（脚本：`_tmp/qa11-ipc-map2.cjs`，结果 `_tmp/qa11-ipc-map2.json`）

- 主进程 73 个 `ipcMain.handle/on`，preload 73 个方法，`missingHandler=[]`（这点是好的）。
- `team:proposal-legacy` 有 handler（`src/main.js:4507`），但 preload 只转发 `proposal:legacy`（`src/preload.js:86`），**没有任何桥能到达这个 channel**，是确定的死接口。
- 在 `app.js` 里**零引用**的 preload 方法共 6 个：`teamLaunch`、`teamOpenProject`、`teamWorkspaceCreate`、`teamBoardProject`、`teamComm`、`workflowOwner`。
- 其中要区分两类：`teamComm` 只是冗余——同样的通信链数据由 `state` 里的 `message.comm` 提供（`main.js:1031` `commSnapshot`，界面在 `app.js:303-311` 读 `comm.wake`），所以“六会话通信链”本身在界面上是看得到的；而 `workflowOwner` 已被 `requirement:owner` 取代也不该再留。

**影响**

`team:proposal-legacy` 这类通道永远调不通；另外 5 个桥没有入口，读代码的人会以为它们是可用功能，维护时容易改错一边。相比 Q11-01/02，这是“接口卫生”问题，不影响主流程。

**建议**

删掉 `team:proposal-legacy`（或改名统一到 `proposal:legacy`）；对零引用桥逐个决定“补界面”还是“删掉”，并在 preload 注释里写清保留原因。

---

### Q11-13（P3，只读边界）自测仍写仓库根两张截图，任何一次 QA 都会改仓库

**证据**

```js
if (!img.isEmpty()) fs.writeFileSync(path.join(ROOT, 'selftest-flow.png'), img.toPNG());
...
if (!overviewImg.isEmpty()) fs.writeFileSync(path.join(ROOT, 'selftest.png'), overviewImg.toPNG());
```

`src/main.js:8287-8292`（`ROOT` 是仓库根，不受 `AWB_SELFTEST_ROOT` 影响）。

本次实测：跑一次 selftest 后

| 文件 | 跑前 SHA-256 | 跑后 |
|---|---|---|
| `selftest.png` | `BA66B36F…CCD4` | `984DA832…13CFD` |
| `selftest-flow.png` | `2017F6A9…BE2C` | `4A034AE1…8DB0E` |

已用 `_tmp\awb-ui\png-before` 的原件还原，哈希回到原值（见第六节）。

**影响**

“只读 QA 只新增一个 md”在技术上做不到，除非每次先备份再还原；CI 里跑测试会让工作区变脏（虽然 `selftest*.png` 在 `.gitignore` 里，但文件内容仍被改写）。

**建议**

截图写到 `SELFTEST_ROOT` 下（或 `AWB_ARTIFACT_DIR`），仓库根只保留“最近一次”软链/说明，不参与测试。

---

### Q11-14（P3，结构约定）创建时仍建空的 `src/`，而项目信息/角色卡/协作准则都写 `site/`

**证据**

- `ensureProjectStructure` 建 `['src','_tmp','需求']`：`src/team-tools.js:2730-2736`。
- 同一函数写入的 `项目信息.md` 模板写 `- 代码目录：site/`：`:2647-2651`。
- `协作准则.md` 与 `角色卡.md` 也只提角色目录/`site/**`（`:2661-2675`）；ROUND10 selftest 的提案目标也是 `site/round10.txt`。

**影响**

新项目里永远有一个没人用的空 `src/`；程序员按项目信息写 `site/`，索引/授权/验收也按 `site/`，但目录约定多一条“看起来像代码目录”的空壳，容易误放文件、误授权。

**建议**

删掉 `src/` 的创建，或把 `项目信息.md` 改成 `src/`；只保留一个代码目录常量，创建/模板/索引/授权共用。

---

## 五、优先级建议

| 优先级 | 问题 | 理由 |
|---|---|---|
| P0 | Q11-01 / Q11-02 | Owner 决定无身份；Owner 验收由 PM 代写且失败不可见。这两个直接击穿“Owner 闸门”和审计链。 |
| P1 | Q11-03 / Q11-04 / Q11-05 | 终止不落地导致看板骗人；两套 Owner 闸门；一条需求让全队 boot 失效。三者都会让用户“按流程走了但推不动”。 |
| P1 | Q11-06 / Q11-07 | 派单不唤醒不锁、互审/签字壳代跑——流程是“自动通过”而不是“人审”。 |
| P1 | Q11-10 | 真实 D 盘状态 120 问题、真实项目已无法 boot。 |
| P2 | Q11-08 / Q11-09 / Q11-11 | 占位符过闸、任务页装饰、自测环境崩。 |
| P3 | Q11-12 / Q11-13 / Q11-14 | 死接口、只读边界、`src` 残留。 |

---

## 六、只读边界与副作用（可复核）

- 新增文件：仅 `docs/QA-ROUND11.md`。
- 临时文件：`_tmp\qa11-*`（`qa11-check.log`、`qa11-electron\`、`qa11-team-selftest.log`、`qa11-sandbox\`、`qa11-verify.log`、`qa11-doctor.log`、`qa11-ipc-map*.json`、`qa11-probe*.cjs`）。全程 `TEMP/TMP` 指向 `_tmp\qa11-temp`，未使用 `%TEMP%`。
- 自测副作用（Q11-13）：`selftest.png`、`selftest-flow.png` 被覆盖，已从 `_tmp\awb-ui\png-before\` 还原：
  - `selftest.png` → `BA66B36FA452278DFB57C0BE85D1D61AE6B5C630C7338FB230F8A17B17CCCCD4`（296359 B）
  - `selftest-flow.png` → `2017F6A92F9AFD2ACBFBC4984195105D8DBA9DE6DEB949AA1B4B9D3A340ABE2C`（207740 B）
- 未修改：`src\**`、`package.json`、`docs\*`（除本文件）、`D:\deepseek\工作台\**`、真实 `团队\状态\**`。
- 未执行：真实 DSH agent 会话、`launch`（需要真实 DSH 登录）、任何写真实团队状态的 `boot`/`task`。

---

## 七、我没能证明的部分（避免过度结论）

- Electron selftest 的 DSH 是 mock，**没有真实 agent**；它只证明“壳能调通旧 CLI + 自己的一致性断言”，不证明“六个角色真的执行了”。ROUND10 的 `prompts 54→54` 也说明流程只写邮箱/文件。
- 需求级 Owner 与验收的真实失败组合（Q11-02 里 `task done` 失败的场景）是**源码路径**证明，未在沙盘里跑完整条 accepted 链（需要 tester 的完整测试收口），因此我按“风险 + 代码证据”定级，不声称已复现运行时分叉。
- 真实项目 `六人敏捷工作区` 的 boot 失败是“文件系统 + `readDocSet` 源码”推断，没有真的执行 boot（会写真实 `团队\状态\启动\`，超出只读边界）。

---

## 八、一句话总结

**这一版把“建项目”和“boot 读文档”真的修好了，但“Owner 决定/验收”仍然只是界面上的一个按钮：身份是字符串、证据由 PM 代写、终止不落到看板——所以“需求评审→派单→互审→测试→Owner 验收”在旧工具那半边是真的，在 Owner 那半边仍然是壳自己说了算。**
