# 第十二轮只读 QA · CORE 核心链路

- 仓库：`D:\deepseek\agile-workbench`
- 时间：2026-11-05 16:06–16:20（Asia/Shanghai）
- 只读边界：只新增 `docs/QA-ROUND12-CORE.md`；探针/沙盘/日志在 `_tmp\qa12-*`，selftest 只写 `.selftest-data\` 自测沙盘。未改 `src/**`、`package.json`、`package-lock.json`、`团队/状态/**`、旧仓库 `D:\deepseek\工作台`。
- 方法：读源码 → `npm run check` → D 盘 Electron selftest（隔离 mock DSH）→ 在 `_tmp` 沙盘直接 require `src/team-tools.js` 调真实函数（`probe1` 生产缺口、`probe2` 派单锁、`probe3` boot 闸门、`probe4` mock 全链）→ 只读 `team.mjs verify` 看 D 盘真实账本。
- 源码快照（SHA-256 前 16 位）：

| 文件 | 字节 | SHA-256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 462,149 | `437A3A64D962F323` | 15:53 |
| `src/team-tools.js` | 245,008 | `19F02AC2587528CE` | 16:02 |
| `src/preload.js` | 7,433 | `43D94AF143AB9823` | 13:47 |
| `src/renderer/app.js` | 440,887 | `B54173F1E4472E48` | 15:56 |
| `package.json` | 798 | `E14268B4B6B76214` | 02:56 |

## 一、结论

**不通过（P0-1，发版阻断）。**

发行物自带的 `团队\工具\team.mjs` 没有 `req review`、`owner`、`workflow` 三条命令；壳把这三条设成硬前置，任何能进入工作流写状态的路径都会在需求评审处返回 `LEGACY_PROTOCOL_REQUIRED`。因此“需求评审 → Owner 闸门 → 派单 → 互审 → 测试 → 验收 → 迭代/终止”在真实发行物上只能走到第 1 步（建需求）。

`npm run selftest` 的 `SELFTEST_ROUND10` 是绿的，但它在 `src/main.js:7534-7535` 把 `createWorkflowProtocolMock()` 注入 `teamTools`；同一个 selftest 的 strict 断言（`src/main.js:7897-7932`）又明确写出真实实例的 `LEGACY_PROTOCOL_REQUIRED`。所以这个绿只证明“如果旧工具以后有这三条命令，壳能走通”，**不证明今天的发行物能走通**。这不是“少一个按钮”，而是整条 CORE 在真实环境不可达。

## 二、检查表

| # | 检查项 | 结果 | 说明 |
|---|---|---|---|
| 1 | 项目创建目录 | **PASS** | 六角色目录、角色卡、文件索引、项目信息/铁律/协作准则/项目索引/需求总览齐全；DSH 登记失败会回滚目录+记录+团队登记（selftest `createRollback` 通过）。附注 P3-1。 |
| 2 | 必读 | **FAIL** | 正常 boot 会读 7 份文档；但旧令牌只覆盖 constitution/iron/roleCard/projectIndex/teamConfig，`projectInfo`/`requirementOverview` 无哈希时直接算 true，`roleCard` 实际对的是团队全局卡不是项目角色卡，界面却显示“全部命中”。见 P2-1。 |
| 3 | boot | **FAIL** | 六角色正常路径 `complete=true`；但 `bootRole` 先调 `ensureProjectStructure` 再读文档，删掉 `项目信息.md` 后 boot 会自动补一份“（待项目经理填写）”模板并返回 `complete=true`，缺失必读不再阻断。见 P1-1。 |
| 4 | 需求评审 | **FAIL** | `reviewRequirement` → 缺 `req review` → `LEGACY_PROTOCOL_REQUIRED`。见 P0-1。 |
| 5 | 派单 | **FAIL** | 被 P0-1 阻断；mock 下能派，但派单通知 `ackRequired:false`、不写 `派单锁.json`、不唤醒，第二单可直接派。见 P1-2。 |
| 6 | 互审 | **FAIL** | 被 P0-1 阻断；mock 下 `devReview` 能在**没有任何角色会话**时通过（`allowMissingSession:true`）。见 P2-2。 |
| 7 | 测试 | **FAIL** | 被 P0-1 阻断；mock 下 `dispatchTest → claim → done` 能走通，但派测试同样不写锁、不唤醒、不要求回执。 |
| 8 | 验收 | **FAIL** | 被 P0-1 阻断；mock 下 `ownerAccept` 能通过并关闭旧需求任务（Q11-02 的“失败被吞”已改成整体失败，这是正向），但 `role` 仍是调用方字符串，默认 `owner`。 |
| 9 | 迭代 | **FAIL** | 被 P0-1 阻断；mock 下 `iterateWorkflow` 能加轮次、解排队。 |
| 10 | 终止 | **FAIL** | 被 P0-1 阻断；mock 下 `terminateWorkflow` 能同时收口旧任务、回写需求文档（Q11-03 已修）。 |
| 11 | D 盘 | **PASS（附 P3-2）** | 仓库/数据/自测临时目录/截图都在 D；真实 `团队/状态` 未被 selftest 改动。真实账本 `verify` 仍有 9 个历史幽灵项目问题。 |

## 三、问题

### P0-1（阻断）发行物缺 `req review` / `owner` / `workflow`，CORE 在需求评审断开

**证据**

1. 真实实例能力探测（无 mock）：

```text
legacyCapabilities().missing = ["workflow", "owner", "req review"]
commands = { workflow:false, owner:false, reqReview:false }
```

2. 沙盘真实调用（`_tmp/qa12-probe/probe1.json`，`probe1.cjs`）：

| 动作 | 返回 |
|---|---|
| `reviewRequirement(product, approve)` | `ok:false, code:LEGACY_PROTOCOL_REQUIRED, requiredCommand:"req review"` |
| `ownerRequirementDecision(owner, skipped)` | `ok:false, code:LEGACY_PROTOCOL_REQUIRED, requiredCommand:"owner"` |
| `ownerAccept(owner, accepted)` | `ok:false, code:LEGACY_PROTOCOL_REQUIRED, requiredCommand:"owner"` |
| `iterateWorkflow(pm)` | `ok:false, code:LEGACY_PROTOCOL_REQUIRED, requiredCommand:"workflow"` |
| `terminateWorkflow(pm)` | `ok:false, code:LEGACY_PROTOCOL_REQUIRED, requiredCommand:"workflow"` |
| 失败后 `工作流.json` | `phase=requirement_review`，只有 1 条需求，`terminate` 事件 0 —— 壳没有写假状态，这点是对的 |

3. `npm run selftest` 的 ROUND10 报告（`_tmp/qa12-selftest.log`）：

```text
SELFTEST_ROUND10 {"checks":6,"failed":0,
  "report":{"requirement":{"driver":"team.mjs req review"},
  "final":{"missingCode":"LEGACY_PROTOCOL_REQUIRED",
    "strictReview":"LEGACY_PROTOCOL_REQUIRED",
    "strictOwner":"LEGACY_PROTOCOL_REQUIRED",
    "strictIterate":"LEGACY_PROTOCOL_REQUIRED",
    "strictTerminate":"LEGACY_PROTOCOL_REQUIRED",
    "strictAccept":"LEGACY_PROTOCOL_REQUIRED"}}}
SELFTEST_OK
```

`driver:"team.mjs req review"` 是 mock 返回的；`strict*` 才是真实工具。`legacyMock` 注入在 `src/main.js:7534-7535`，mock 分支在 `src/team-tools.js:2573-2588`。

4. `团队\工具\team.mjs` 自带 5,354 B（11-03 版本），`team.mjs help` 明确写“workflow · owner · req review 当前版本没有实现”；旧仓库 `D:\deepseek\工作台\团队\工具` 的同三条也仍是缺失。

**影响**

真实用户点“产品评审”“Owner 决定”“Owner 验收”“迭代”“终止”只会看到 `LEGACY_PROTOCOL_REQUIRED`。派单/互审/测试/验收的代码即使全部正确，也走不到。工作台不能作为“六角色完整流程”交付。

**建议**

二选一，不能再用 mock selftest 代替：

- 在**发行物自带**的 `团队\工具` 里真正实现 `req review` / `owner` / `workflow`（新代码、新测试、能力探测同步）；或
- 把这套需求/评审/Owner/迭代/终止的语义改为壳自己的“工作流文件驱动”，明确它是唯一真相，并删除“必须先有旧命令”的硬前置。

在 P0-1 修好前，`npm run selftest` 的绿色只能算“mock 场景通过”，不能作为发布/验收证据。

### P1-1 boot 自动补必读文件后放行，占位符可以满足“每轮必读”

**证据**

`bootRole()` 在 `src/team-tools.js:3026` 先调用 `ensureProjectStructure()`，该函数会补 `项目信息.md`/`项目铁律.md`/`协作准则.md`/角色卡/索引/需求总览（`:2789-2897`），之后才 `readBootDocs()`。沙盘实测（`probe1.json`）：

```json
{"bootAfterInfoDeleted":{"ok":true,"complete":true,"missing":[],
  "infoRecreated":true,
  "infoHead":"# 项目乙 · 项目信息\n\n## 一、目标\n\n（待项目经理填写）\n\n## 二、场景\n\n（待填写）"}}
```

删除 `项目信息.md` 后，boot 不是 `MISSING_DOC`，而是造一份模板再 `complete:true`。

**影响**

“必读”从硬闸门退化成自愈：项目信息没写、角色卡丢了、索引被删，boot 都能补模板后通过。审计上无法区分“角色真的读了项目信息”和“壳刚生成了一份占位符”。

**建议**

`bootRole` 应先 `readBootDocs`，缺失就 `MISSING_DOC` 停；只有项目创建/显式 ensure 才允许补模板。补完模板后必须要求重新 boot，且界面标记“模板未填写”。

### P1-2 派单不写旧派单锁、不要求回执、不唤醒；可以连续派多单

**证据**

`dispatchRequirement()` 的落点是 `sendWorkflowNotice()`（`src/team-tools.js:4176`），后者固定拼：

```js
'send','--boot',token,'--to',to,'--subject',subject,'--body',body,'--no-wake'
```

没有 `--ack`（`:4065-4069`）。沙盘实测（`probe2.json`）：

| 检查 | 实测 |
|---|---|
| 第一次派单通知 `ackRequired` | `false` |
| `派单锁.json` | 不存在 |
| 第一单未回执时第二次派单 | `ok:true`，第二单成功 |
| 两次派单后的邮箱 | 两条 `type:"dispatch"` 通知均 `ackRequired:false`（另有 `task create` 自动产生的 `note` 带 `ackRequired:true`，但它不是 `send --ack` 的派单锁） |
| 工作流 | 两个需求同时 `status=dev`，各有一个 task/messageId |

旧工具 `send` 的 `--ack` 才触发“PM 一次只能派一单”的锁（`团队/工具/lib/ops.mjs:347-351`：`pmDispatch = role==='pm' && args.ack && to!=='pm'`，锁文件 `派单锁.json`）。

**影响**

PM 可以同时把多条需求派给多人；目标角色不会被 DSH prompt 唤醒；没有回执也不会阻止下一次派单。这与 `团队/流程.md` 的“一次只叫一个角色、未回执不派下一个、没有回执=没发生”直接冲突。

**建议**

工作流派单复用 `sendDispatch()`：`--ack` + 主进程 `dsh.prompt(wakeText)`，把 `wake/ack` 结果写回 `comm`；selftest 至少断言一次 prompt 和一次 `派单锁.json`，不能把 `prompts 54→54` 当成功。

### P2-1 boot 的“哈希命中”证据不完整，界面/自测把它显示成“全部命中”

**证据**

沙盘 boot 令牌（`_tmp/qa12-probe/sandbox/团队/状态/启动/1e61...json`）只有：

```text
docHashes = { constitution, iron, roleCard, projectIndex, teamConfig }
```

没有 `projectInfo`、`requirementOverview`。`roleCard` 哈希 `692633ef…` 等于团队全局 `团队/角色/pm.md`，而项目角色卡 `项目甲/项目经理/角色卡.md` 是 `9f67e3bc…`，两者不同。

`bootRole()` 的 `hashCheck()`（`src/team-tools.js:3052-3060`）对 `roleCard` 直接 `return true`，对令牌里没有的 `projectInfo`/`requirementOverview` 也 `return true`；最终 `hashChecks` 七项全 true，界面和 selftest 都把它当“旧令牌哈希全部命中”。

**影响**

审计上会把“壳读了项目文件”误当成“旧令牌绑定了这些文件”。特别是项目角色卡，令牌实际绑定的是全局卡，不能证明角色读了本项目角色卡。

**建议**

在 `bootRead.hashChecks` 里区分 `tokenBound` / `shellRead` / `notApplicable`；界面不要把这几个默认 true 显示成“命中”。selftest 也不要断言 `roleCard === true` 就等于哈希命中。

### P2-2 互审/签字/验收没有会话或身份证明，一人可以代跑

**证据**

- `devReview()` 调旧 `show`/`review` 时显式 `allowMissingSession:true`（`src/team-tools.js:4524`、`:4528`）。
- `devApply()` 一次调用里跑完 `show → review → sign → apply`，四个动作全是 PM，且 `allowMissingSession:true`（`:4582-4596`）。
- `ownerAccept()` 的 `role` 只校验字符串，默认 `'owner'`；IPC `owner:accept` 也默认 `owner`（`src/main.js:3943-3949`）。
- `probe4.json` 的沙盘团队**没有任何角色会话**，全链 `devReview`、`devApply`、`ownerAccept` 仍然全部 `ok:true`。

**影响**

“另一名程序员互审”“PM 签字”“Owner 验收”在审计上只是点击者选择了另一个角色名；无法证明是另一名角色/会话执行的。若产品定位是单人编排台，这是可接受的设计，但必须在界面和文档里写明“壳代跑”；若要求旧流程的 A/B 独立性，则不成立。

**建议**

至少给 `review/sign/accept` 绑定当前项目的角色会话或一次性 nonce；没有就明确 `SESSION_ID_REQUIRED`，或者在返回/提案里写 `actor:"workbench-shell"`，不要显示成角色本人。

### P2-3 顶层 Owner 文件契约仍可写，与需求级账本分叉

**证据**

`recordOwnerDecision → writeOwnerWorkflow()`（`src/team-tools.js:875-904`）只写 `工作流.json` 顶层 `ownerReview`，不校验需求是否存在、是否产品评审。沙盘实测（对 `probe1` 的项目）：

```json
{"ok":true,"topOwner":"skipped","reqStatus":"review","productReview":null,"reqOwner":null}
```

`preload.js:48` 仍暴露 `workflowOwner`；虽然当前 UI 已不调用它，但旧入口/渲染层脚本仍可调用。

**影响**

界面/账本可以出现“Owner 已跳过”而需求还在 `review`、产品评审为 `null`。派单闸门仍读需求级 `ownerReview`，所以不会直接放行，但审计上会出现两套 Owner 结论。P0-1 修好后这会变成真正的误导源。

**建议**

`workflowOwner` 要么删除，要么必须带 `requirementId` 并校验产品评审已通过；只允许 `ownerRequirementDecision` 写需求级结论。

### P2-4 创建需求不校验创建者的 boot 阅读

**证据**

`createRequirement()` 没有 `requireWorkflowBoot`，只走 `runLegacyCommand → withBootToken` 自动 mint 令牌。沙盘实测（`probe3.json`）：全新项目、零角色 boot，`analyst` 直接建需求返回：

```json
{"ok":true,"code":"OK","id":"R-20261105-161312-8b26","bootsAfterCreate":[]}
```

**影响**

UI 会先要求角色 boot，但后端不强制；直接调 IPC 或旧脚本可以跳过“每轮先读”。这与“必读/boot”规则不一致。

**建议**

`createRequirement` 在写状态前加 `requireWorkflowBoot(ctx.name, ctx.projectPath, role)`（owner-create 用 pm 的 boot），与评审/派单一致。

### P3-1 创建项目多建空 `src/`，模板/角色卡/提案都写 `site/`

`ensureProjectStructure()` 建 `['src','_tmp','需求']`（`src/team-tools.js:2823`），但 `projectInfoTemplate` 写“代码目录：site/”（`:2744`），角色卡/协作准则/提案目标也都用 `site/`。沙盘创建出的目录同时有 `site/` 和空的 `src/`（`probe1.json.createdDirs`）。不影响功能，但会误导程序员把代码放错目录。建议删掉 `src/` 或统一模板。

### P3-2 D 盘真实账本仍有 9 个幽灵项目问题

只读 `node 团队\工具\team.mjs verify`（`_tmp/qa12-verify.log`）：

```text
verify：❌ FAIL ｜ 项目 6 个 ｜ 事件 1215 条 ｜ 问题 9 ｜ 警告 0
全部指向「个人简历展示项目」的缺失需求/产品/site/测试报告
```

`团队/状态/项目/` 还有 2 个无目录的登记（个人博客项目、个人简历展示项目），`项目/小鱼` 有目录未登记。它不是本轮 CORE 源码回归，但会让“D 盘账本健康”无法作为发布门槛；建议清理/归档幽灵登记。

### P3-3 能力面板文案仍承诺“文件契约”回退，后端已没有该回退

`app.js:3622` 写“缺 workflow/owner/req review 时，后端按旧 工作流.json 文件契约记录，并在返回里带 `LEGACY_COMMAND_MISSING` 警告”；实际 `reviewRequirement`/`ownerRequirementDecision`/`iterateWorkflow`/`terminateWorkflow` 在写状态前就返回 `LEGACY_PROTOCOL_REQUIRED`，没有文件契约回退。用户会先被告知“会记录”，再看到失败。建议改成“缺命令即失败，不写状态”，或真的实现回退（但回退必须明确是壳的语义，不是旧命令成功）。

## 四、已成立 / 正向证据

- `npm run check`：exit 0（5 个入口语法通过，日志 `_tmp/qa12-check.log`）。
- `npm run selftest`：exit 0，`SELFTEST_OK`；STORE 20/0、COMPAT 46/0、MAPPING 39/0、ROUND5 4/0、ROUND6 17/0、ROUND9 8/0、ROUND10 6/0（日志 `_tmp/qa12-selftest.log`）。
- 项目创建：六角色目录/角色卡/索引/项目信息/铁律/协作准则/需求总览齐全；DSH 登记失败会回滚目录、本地记录和团队登记（selftest `createRollback`，`probe1.setup`）。
- 闸门负例：未重新 boot 派单 → `BOOT_REQUIRED`；未评审派单 → `REQUIREMENT_NOT_APPROVED`；空验收建需求 → `ACCEPTANCE_REQUIRED`（`probe1`/`probe3`）。
- mock 全链：`probe4.json` 23 步全部 `ok:true`，覆盖建项目 → 六角色 boot → 需求 → 评审 → Owner 跳过 → 派单 → claim → 提案 → 互审 → 签字/apply → 开发 done → 派测试 → 测试 done → Owner 验收 → Owner 新需求 → 迭代 → 终止；验收后旧需求任务 `status=done`，终止关闭下一轮需求任务。
- 终止收口：mock 下 `terminateWorkflow` 返回 `closedTasks:["R-…"]`，旧任务变 `done`（Q11-03 已修）。
- 验收失败可见：`ownerAccept` 的 `task done` 失败现在整体返回失败（`src/team-tools.js:4774-4785`），不再“界面成功、旧任务没关”。
- 自测隔离：真实 `团队/状态` 的 `团队.json`/`事件.jsonl` 时间仍是 15:21，未被 selftest 改动；仓库根 `selftest*.png` 未被覆盖（selftest 截图写入 `.selftest-data/artifacts`）。
- D 盘：`ROOT`、`data/`、`.selftest-data/`、`TEMP_ROOT` 都在 D；真实状态未写到 C。

## 五、命令与证据索引

| 项 | 命令/文件 | 结果 |
|---|---|---|
| 语法 | `npm run check` | exit 0，`_tmp/qa12-check.log` |
| D 盘 selftest | 先清 `ELECTRON_RUN_AS_NODE`，再 `npm run selftest` | exit 0，`SELFTEST_OK`，`_tmp/qa12-selftest.log` |
| 生产缺口 | `node _tmp/qa12-probe/probe.cjs` | `probe1.json`；review/owner/accept/iterate/terminate 全 `LEGACY_PROTOCOL_REQUIRED` |
| 派单锁 | `node _tmp/qa12-probe/probe2.cjs` | `probe2.json`；无锁、`ackRequired:false`、可连派 |
| boot 闸门 | `node _tmp/qa12-probe/probe3.cjs` | `probe3.json`；未 boot 可建需求；缺项目信息 boot 自愈 |
| mock 全链 | `node _tmp/qa12-probe/probe4.cjs` | `probe4.json`；23 步全 ok |
| D 盘账本 | `node 团队\工具\team.mjs verify` | FAIL，9 个幽灵项目问题，`_tmp/qa12-verify.log` |

说明：本会话环境自带 `ELECTRON_RUN_AS_NODE=1`，直接跑 `npm run selftest` 会在 `app.setPath` 处崩（Q11-11 仍未修）；本轮是显式清空该变量后运行的。脚本自身没有清，`package.json` 的 `--user-data-dir=userdata-selftest` 也仍被 `main.js` 的 `app.setPath` 覆盖，只能算运行环境注意事项，不列入 CORE 阻断。

## 六、边界 / 未证明

- 没有真实 DSH agent 会话；selftest 的 DSH 是 mock，`session/prompt` 不产生真实角色执行。
- 没有“已实现三条命令”的旧工具，所以无法验证真实成功路径；`probe4` 的 PASS 只证明壳逻辑在有命令时成立。
- 未修改 `src/**`、`package.json`、`package-lock.json`、`团队/状态/**`、旧仓库；只新增本文件、`_tmp/qa12-*` 与 `.selftest-data/` 自测沙盘。
- 同机另有一份平行验收目录 `_tmp\acceptance-20261105-1618\REPORT.md`，结论同为 `FAIL_BLOCKED`（P0：缺 req review/owner）；本报告未依赖它，主要证据是上面的 `probe1-4` 与 selftest 日志。

## 七、一句话

**CORE 现在不是“逻辑写错了”，而是“发行物里没有能跑通的三条命令”；selftest 绿在 mock 上，先把命令或工作流驱动补进发行物，再谈通过。**

---

## 对账回执

- 对账人：只读 QA
- 复核人：待 PM / 开发
- 结论：**有异常，停手**
- 备注：P0-1 未修前，CORE 不能按“完整流程”验收；`npm run check` 与 D 盘 selftest 的绿色不能替代生产链路证据。
