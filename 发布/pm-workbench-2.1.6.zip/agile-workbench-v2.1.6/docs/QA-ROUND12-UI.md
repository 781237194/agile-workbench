# 第十二轮只读 UI QA · 界面与交互

- 仓库：`D:\deepseek\agile-workbench`
- 时间：2026-11-05 16:06–16:27（Asia/Shanghai）
- 边界：**只新增本文件**。临时脚本、沙盘、截图全部在 `_tmp\qa12ui\`；未改 `src/**`、`package.json`、`package-lock.json`、旧仓库 `D:\deepseek\工作台` 与 `D:\deepseek\luanyujia-workbench`；未写真实 `团队\状态\**`、真实 `data\**`、`.selftest-data\**`。
- 方法：读渲染层/主进程源码 → 在 `_tmp\qa12ui` 用**真实 `src/team-tools.js`**（非 mock）建一个六角色已 boot 的沙盘项目 → 用真实 Electron（`AWB_DATA_DIR`/`AWB_STORE`/`TEAM_ROOT` 全部指向沙盘）启动工作台 → 通过 CDP 读 DOM、点真实按钮、原生窗口截图 → 另起一个**无 preload** 的真实 renderer 窗口专门验证“缺 IPC”路径。
- 源码快照（本轮 UI 结论只对这个快照负责；QA 前后哈希一致）：

| 文件 | 字节 | SHA-256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 462,149 | `437A3A64D962F323` | 15:53 |
| `src/team-tools.js` | 245,008 | `19F02AC2587528CE` | 16:02 |
| `src/preload.js` | 7,433 | `43D94AF143AB9823` | 13:47 |
| `src/renderer/app.js` | 440,887 | `B54173F1E4472E48` | 15:56 |
| `src/renderer/index.html` | 46,481 | `C589694BE78CA127` | 15:36 |
| `src/dsh-adapter.js` | 9,464 | `99C0391D9C4652AE` | 10:21 |

> 与 `docs/QA-ROUND12-CORE.md`（16:19）的关系：CORE 已证明**后端**缺 `req review`/`owner`/`workflow` 是 P0-1，并已记录能力面板“文件契约”文案（P3-3）、boot 哈希默认 true（P2-1）、Owner 无身份（P2-2）。本报告**不重复判后端**，只判界面：这些已知缺口有没有被正确禁用、解释、归因，以及 boot 过期、preload 缺失、actor 字段缺失时界面给出什么。

---

## 一、结论速览

| 检查面 | 结论 | 一句话证据 |
|---|---|---|
| DSH 主画面 | **可用**，1 个 P3 | `#dsh-view` 实际加载 `http://127.0.0.1:52711/`（页面标题 `DeepSeek Harness`），`DSH 已连接 · 207 个会话`；离线/重连能切换；重连后旧“引擎没有连上”卡片会短暂残留。 |
| 六角色目录 / 必读 | **数据真、boot 真**；1 个 P1 + 1 个 P2 | 目录 6/6、角色卡 6/6、文件索引 6/6、boot 6/6 与旧令牌/哈希对得上；但 **boot 30 分钟过期后仍显示绿色“已读全/可推进”，且所有 boot 按钮被禁用，界面无法重新 boot**。 |
| 流程按钮 | **不通过（P1）** | 真相条已写“旧命令缺 3”，但“产品评审”“迭代”按钮仍是可点的；点击后分别返回 `LEGACY_PROTOCOL_REQUIRED`。 |
| 禁用态 | **一半正确** | 未 boot 时“产品评审”会禁用并给出原因（正向）；但**命令缺失**和**boot 过期**都没有进入禁用条件。 |
| 缺 IPC 提示 | **P2** | 整桥缺失时只有一次 toast；界面继续显示正常空状态，并把 DSH 说成“未连接/未配置”；控制台另有 2 个未捕获 TypeError。单项 IPC 缺失的 chip 机制是好的。 |
| 真实 actor | **大部分正确，1 个 P2** | 需求卡确实分列 `by=` 与 `actor=`，`actor=workbench-shell` 会如实显示；但团队台对**没有 `by` 的旧 Owner 记录**默认填成 `by=Owner`，同一记录的需求卡却写“执行者/记录人未记录”。 |

**UI 层结论：不通过（2 个 P1）。** 主链根因仍是 CORE P0-1；本报告的两个 P1 是界面在“已知后端缺口/已过期证据”面前仍然给出可点击入口。

---

## 二、沙盘与真实度

- 项目：`_tmp\qa12ui\projects\QA视觉项目`；团队根：`_tmp\qa12ui\team`（复制了真实 `团队\工具`、`角色`、`协议`、`模板` 和宪法/铁律）。
- 真实调用：`ensureProjectReady` → 六角色 `bootRole`（每角色 7 项 hashChecks 全 `true`）→ `createRequirement`（产品角色，需求 `R-20261105-161117-f787`，状态 `review`）。没有注入 `legacyMock`，没有改 `src` 里的 selftest 分支。
- 启动：`electron .`，`AWB_DATA_DIR=AWB_STORE=...\_tmp\qa12ui`、`TEAM_ROOT=...\_tmp\qa12ui\team`，`TEMP/TMP` 也在沙盘；CDP 端口 9347。
- DSH：`dsh.json` 指向真实 `http://127.0.0.1:52711`，只读调用 `session/list` 做状态探测；内嵌 webview 加载 DSH Web 页面，但**未在 DSH 页面内创建/唤醒/重命名任何会话，也未点任何会写数据的 DSH 按钮**。
- 缺 IPC：`_tmp\qa12ui\no-preload-main.cjs` 用同一个真实 `src/renderer/index.html` 起一个**不挂 preload** 的窗口（端口 9348），专门看 `window.workbench === undefined` 时的首屏。
- 截图目录：`_tmp\qa12ui\`；关键截图在正文就地引用。

---

## 三、DSH 主画面

### 3.1 正向

- 首屏 `#dsh-view` 的实际页面标题是 `DeepSeek Harness`，URL `http://127.0.0.1:52711/`；左侧栏 `DSH 已连接`、`已连接 DSH · 207 个会话`，顶栏 `DSH 已连接` 与之一致（`_tmp\qa12ui\01-main.png`、`18-dsh-connected-stale-card.png`）。
- 六角色会话没有被伪造：侧栏逐行写 `DSH 会话未创建`，顶部 `团队 0/6`、`会话 0`；团队台里也是“无会话 / DSH 存在 无映射”。这与沙盘项目没有真实 DSH 会话一致。
- 离线切换可复现：把地址改成 `http://127.0.0.1:63999` 后，顶栏变 `DSH 离线`、`#dsh-detail` 为 `DSH 连接失败：fetch failed`，主画面变空白；改回 `52711` 后恢复连接和 DSH 页面（`16-dsh-offline.png`、`17-dsh-restored.png`、`18-dsh-connected-stale-card.png`）。

### 3.2 P3：重连后旧的“引擎没有连上”卡片会短暂残留，且与“已连接”自相矛盾

**证据**

- 从 63999 改回 52711 后，`#btn-dsh` 已经是 `DSH 已连接`、`#dsh-detail` 已经是 `已连接 DSH · 207 个会话`，但 `#dsh-off` 仍显示：

  ```text
  DSH 引擎没有连上
  http://127.0.0.1:52711 · 已连接 DSH · 207 个会话
  ```

  截图：`_tmp\qa12ui\17-dsh-restored.png`（卡片在，详情写着已连接）。本轮复核时卡片仍在；等 webview 的 `did-finish-load` 触发并再次 `renderDsh` 后，`#dsh-off.hidden` 才变为 `true`（第二次复核已隐藏），窗口以 DSH 实际加载速度为准。

**源码路径**

- `openDshConfig` 里先 `renderDsh(s.status)`，再 `applyDshViewSrc()`：`src/renderer/app.js:7636-7640`。
- `renderDsh` 的显示条件是 `!online || dshViewFailed`：`:7325`。
- `dshViewFailed` 由 `did-fail-load` 置真（`:8483-8488`），要等 `did-finish-load` 才重新 `renderDsh`（`:8473-8476`）；`applyDshViewSrc()` 虽会把 `dshViewFailed=false`，但它在 `renderDsh` **之后**才执行，所以这一次渲染仍显示旧错误卡。

**影响**：重连过程中（DSH 会话多时可达数秒）用户看到“引擎没有连上”和“已连接 207 个会话”同屏，不知道该信哪个。

**建议**：`applyDshViewSrc()` 先于 `renderDsh`，或在 `applyDshViewSrc()` 内改完 `src` 后再 `renderDsh`；重连期间文案改成“正在重载 DSH 主画面”，不要复用失败卡。

### 3.3 边界观察（不单列问题）

`index.html:180` 把 webview 的 `src` 硬编码成 `http://127.0.0.1:52711`。在未配置/无 preload 时，`applyDshViewSrc()` 不会执行，这个默认地址仍会被加载；无 preload 窗口的 CDP 目标里确实看到 `http://127.0.0.1:52711/` 已加载，而 `#dsh-off` 写“地址未配置”。目前被离线卡遮住，用户看不到，但“未配置却加载了一个默认实例”这件事本身不干净；建议首屏 `src` 用 `about:blank`，等 `state.dsh.baseUrl` 确认后再设。

---

## 四、六角色目录 / 必读

### 4.1 正向：目录、角色卡、索引、boot 证据都是真的

- `#legacy-docs-summary` 实测：

  ```text
  目录 6/6 · 角色卡 6/6 · 文件索引 6/6 · 其他文档 0 份 · 项目索引 存在 · boot 6/6 · 只读
  ```

- 六角色表格逐行显示目录/角色卡/文件索引存在性、`已 boot / 已读全`；下方的 boot 证据卡显示 boot 时间、令牌哈希、旧令牌文件、会话 id，并列出宪法/铁律/项目信息/角色卡/索引/需求总览/规则哈希七项。截图：`08-roles.png`、`09-docs.png`。
- 文档页签能读到真实 `项目铁律.md` 全文（不是空壳/模板预览，`09-docs.png`）；角色卡/文件索引单元格的“存在”来自 `files:list` 的实际返回。
- 未 boot 的禁用态是有效的：把沙盘里 product 的 boot 删掉并刷新后，需求卡的“产品评审”变为 `disabled=true`，`title` 明确写“产品设计师 未 boot/未读全（workflow:briefing），后端会拒绝该动作，界面先禁用”；同时 `#legacy-boot-all` 变为 `全队 boot（缺 1）` 且可点（DOM 实测；`14-disabled-review.png` 展示的是产品评审被禁用）。这说明 **boot 这一维度的禁用链是通的**。

### 4.2 P1：boot 30 分钟过期后仍显示“已读全/可推进”，且界面没有任何重新 boot 的入口

**证据（沙盘实测）**

- 把沙盘 `工作流.json` 六条 `boots.*.at` 统一前移 40 分钟（等价于超过默认 30 分钟 TTL），刷新后：

  | 检查 | 实测 |
  |---|---|
  | 真相条 | `boot 6/6`（绿色） |
  | 本轮必读徽章 | `已 boot/已读 · 可推进`（绿色） |
  | 结果条 | `本轮必读已核验：六角色 boot 完成，可按角色推进` |
  | 六个角色 boot 按钮 | 全部 `disabled=true`，文字 `已 boot` |
  | `#legacy-boot-all` | `disabled=true`，文字 `六角色已 boot` |
  | PM 派单按钮 | `disabled=false`，可点 |
  | 点“PM 派单 → 执行” | `[BOOT_EXPIRED] 角色「项目经理」的 boot 已超过 30 分钟；请重新 boot` |

  截图：`_tmp\qa12ui\20-expired-boot-green.png`（绿色“可推进”+ boot 时间 15:31 + 全部“已 boot”按钮灰）；`19-dispatch-expired.png`（`BOOT_EXPIRED` 错误在弹窗里）。

**源码路径**

- 后端 `requireWorkflowBoot` 确实在 30 分钟后拒绝：`src/team-tools.js:3169-3174`；但只读的 `briefingStatus` 不返回 `expiresAt`/`expired`：`:3216-3270`。
- 渲染层 `legacyBootFor` 的 `ready` 只看 `complete/stale/roundMismatch`，不看 `boot.at`：`src/renderer/app.js:3358-3395`。
- 角色表 boot 按钮按 `boot.ready` 禁用（`:4151`、`:5605`）；“全队 boot”按 `pending = 未 ready` 判断（`:3907-3926`）。过期后 `ready` 仍为 true，于是**所有 boot 入口都变成禁用**。

**影响**

- boot 过期不是“动作失败一次”，而是**界面死锁**：六个角色都显示已读全、动作按钮可点、点下去全部 `BOOT_EXPIRED`，而“重新 boot”按钮因为“已 boot”被禁用；刷新/重启都不会清掉 `工作流.json` 的 boots，界面没有恢复路径。
- 这不是伪造状态：界面显示的是后端 `briefing` 的“complete”，只是**缺少时间维度**。

**建议**

- `briefingStatus` 返回每个角色的 `expiresAt`/`expired`（或 `secondsLeft`），`legacyBootFor.ready` 把过期算作未就绪；
- 过期角色在表格/徽章/真相条显示 `boot 已过期 · 需重新 boot`，并启用该角色 boot 与“全队 boot”；
- boot 按钮的 `disabled` 只在“真的可复用”时成立，不能只按 `complete`。

### 4.3 P2：模板占位警告与绿色“可推进”同屏，警告不降级闸门

**证据**

- 同一屏同时出现：
  - 警告条：`文档仍是模板占位：项目信息、需求总览。boot 哈希能通过，但正文没有写清目标/边界，产品评审与 Owner 闸门不应据此当“已读全”。`（`_tmp\qa12ui\02-overview.png`）
  - 绿色徽章：`已 boot/已读 · 可推进`（`:4082`）
  - 绿色结果条：`本轮必读已核验：六角色 boot 完成，可按角色推进`（`:4092`）
  - “产品评审”按钮仍可点（`disabled=false`）。
- 代码里 `legacyPlaceholderDocs()`（`:3350-3356`）只用于 `legacyIssueMarkup` 的警告行（`:4035`），没有进入 `legacyBootSummary`/`legacyRoleReady`，也没有进入任何动作的禁用条件。

**说明**：模板/哈希的根因在 CORE P1-1 与 P2-1 已判；这里**不重复判后端**，只记 UI 层的自相矛盾：界面一边说“不应据此当已读全”，一边把闸门标绿并允许点评审。

**建议**：至少把徽章降为 `warn` 并写“可推进（有模板占位）”；如果产品意图是“模板不得过评审”，则把 `legacyPlaceholderDocs().length` 接入评审/Owner 的禁用条件，并在点“全队 boot”时提示补正文。不要同时给绿色“已读全”。

---

## 五、流程按钮 / 禁用态

### 5.1 正向

- 流程页能展开旧流程节点、当前阶段高亮、需求队列、账本分叉条（`03-flow.png`）。
- 需求卡会按状态显示动作：`review` 只显示“产品评审”；`approved` 才显示“Owner 决定”；`ready` 才显示“PM 派单”（`legacyReqActions`，`:4794-4849`）。
- 产品评审失败时，错误在弹窗内可见，弹窗不关、错误码和文字都保留（`05-review-error.png`）；这比静默失败好。

### 5.2 P1：真相条已写“旧命令缺 3”，流程按钮仍然可点，点下去是确定失败

**证据**

- 同一屏 `#project-truth`：`preload 已加载 | IPC 齐全 | 文件 41 | workflow 已读 | briefing 已读 | 旧命令缺 3 | boot 6/6`（`02-overview.png`）。
- 能力面板明确列出 `req review 缺`、`workflow 缺`、`owner 缺`，但需求卡的“产品评审”`disabled=false`；点“执行”后：

  ```text
  [LEGACY_PROTOCOL_REQUIRED] 当前 team.mjs 缺少旧协议命令「req review」；
  请先升级团队工具，本工作台不会用本地文件伪造这一步
  ```

- “迭代（下一轮）”同样 `disabled=false`；点“执行”后：

  ```text
  [LEGACY_PROTOCOL_REQUIRED] 当前 team.mjs 缺少旧协议命令「workflow」；
  请先升级团队工具，本工作台不会用本地文件伪造这一步
  ```

  截图：`03-flow.png`（按钮）、`05-review-error.png`（review 失败）、`07-iterate-error.png`（iterate 失败）。

**源码路径**

- `legacyReqButton` 的 `ready` 只算 `legacyRoleReady(checkRole)`，完全没有读 `legacyCapabilityData().caps.missing`：`src/renderer/app.js:4780-4792`。
- “迭代/终止”在 `renderLegacyAdvance` 只按 `pmReady` 禁用：`:4097-4118`。
- 后端确实在写状态前硬拒绝：`reviewRequirement` 的 `requireLegacyCommand('req review')` 在 `src/team-tools.js:3648`；`ownerRequirementDecision` 在 `:3746`；`iterateWorkflow`/`terminateWorkflow` 在 `:3931`/`:3986`。
- 能力面板却写“缺 workflow / owner / req review 时，后端按旧 `工作流.json` 文件契约记录，并在返回里带 `LEGACY_COMMAND_MISSING` 警告”（`src/renderer/app.js:3622`）。这与运行时相反；该文案已由 CORE P3-3 记录，本报告只作为“按钮可点”的证据引用。

**影响**

- 在当前发行物上，实点到的“产品评审”“迭代”都是**可点击的死按钮**；Owner 决定/终止/验收走同一个 `legacyReqButton` 或同一套 `pmReady` 条件，源码上没有能力判断，按同一类处理（本轮未逐个点）。点击前没有任何“这条命令不存在”的拦阻，点击后才失败。
- 用户无法区分“后端缺命令”和“我填错了/需求状态不对”；这会把 P0-1 的后端问题伪装成操作错误。

**建议**

- `legacyReqButton` 增加能力参数：`caps.missing` 包含所需命令时直接 `disabled`，`title` 写“当前 team.mjs 缺 `req review`，先升级或切到工作流文件驱动”；
- “迭代/终止”同样按 `workflow` 能力禁用；
- 能力面板文案改成“缺命令即失败，不写状态”（与实现一致），不要承诺文件契约回退。

---

## 六、缺 IPC 提示

### 6.1 正向：单项 IPC 的缺口是显式的

- 正常应用里真相条显示 `preload 已加载` + `IPC 齐全`（`02-overview.png`）；能力面板（流程页底部）逐个列 19 个 `preload IPC` 的 `有/缺`。
- 代码对单项缺失有明确分支：`files:list` 缺 → “当前 preload 没有 files:list，无法读取六角色目录与必读文档”（`:3778-3781`）；`workflow:briefing` 缺 → `briefingError.code = IPC_MISSING`（`:3837-3838`）；团队台回执缺 → `team:receipts 缺失`（`:5048-5049`）。这些是正向的。

### 6.2 P2：整桥缺失时只有一次 toast，界面继续“正常空状态”，并把原因归给 DSH

**证据（无 preload 真实窗口）**

- 启动后 `window.workbench === undefined`；`refresh()` 只弹一次：

  ```text
  preload 没有加载，工作台 API 不可用
  ```

  然后 `state` 保持 `null`，`render()` 直接 return（`:897-901`、`:972-973`）。toast 消失后，界面显示正常的“未选择工作区 / 从第一个工作区开始”，没有任何持久横幅（`_tmp\qa12ui\12-nopreload.png`）。
- 同时 `#dsh-off` 显示：

  ```text
  DSH 引擎没有连上
  地址未配置
  ```

  但真实原因不是 DSH，而是 preload 没加载、根本读不到 `state.dsh`。用户会去重启 DSH，方向错了。
- 控制台两个未捕获 TypeError：

  ```text
  Uncaught (in promise) TypeError: Cannot read properties of undefined (reading 'teamWorkspaces')
      at app.js:1233
  Uncaught (in promise) TypeError: Cannot read properties of undefined (reading 'teamStatus')
      at app.js:6216
  ```

  对应 `loadWorkspaces` 的 `typeof window.workbench.teamWorkspaces`（`:1233`）和 `loadTeamStatus` 的 `typeof window.workbench.teamStatus`（`:6216`）：守卫只判断了方法，没有判断 `window.workbench` 本身。
- 顶栏“新建/建团队/刷新”和空状态“新建项目”没有被禁用；实点“新建项目”只会再次弹同一条 toast（其余按钮未逐个点，按同一 preload 缺失路径判断），不会进入任何可用功能。

**影响**：preload 语法错误、加载失败、被安全策略拦截时，用户看到的是一个“看起来正常、可以点、但什么都不发生”的工作台，并且被误导去检查 DSH。缺 IPC 的真实原因只在短暂 toast 和控制台里。

**建议**

- 启动时先判断 `window.workbench`；缺失就显示**持久**的红色横幅/模态：“preload 未加载（IPC 桥不可用），项目/团队功能全部禁用”，并禁用顶栏与空状态按钮；
- `loadWorkspaces`/`loadTeamStatus` 改成 `window.workbench?.teamWorkspaces` 形式，避免未捕获 rejection；
- DSH 状态文案在 IPC 缺失时改成“无法读取 DSH 状态（IPC 未加载）”，不要复用“DSH 引擎没有连上”。

---

## 七、真实 actor

### 7.1 正向

- 需求卡确实把记录字段和执行者分列：构造 `productReview.actor='workbench-shell'` 后，卡片显示：

  ```text
  产品评审 approve · 产品设计师（by=product · actor workbench-shell）
  ```

  截图：`21-actor-present.png`。
- Owner 记录只有 `by='Owner'`、没有 `actor` 时，卡片显示 `Owner（by=Owner · actor 未记录）`，没有补写成某个角色会话。
- 团队台的“评审 / 回执 · 真实 actor”区按 `by` / `actor` / `executor` / 身份来源分列；回执缺 `team:receipts` 时明确写“回执无法读取”（`:5048-5049`）；这条规则本身是对的（`index.html:436-440`）。

### 7.2 P2：团队台把没有 `by` 的旧 Owner 记录默认成 `by=Owner`，同一记录在需求卡却是“执行者/记录人未记录”

**证据**

- 在沙盘 `工作流.json` 里放一条旧形态记录：

  ```json
  "ownerReview": { "status": "approved", "opinion": "旧记录只有状态，没有 by/actor" }
  ```

  刷新后，同一个 `R-…` 在两个视图里说法不同：

  | 视图 | 实测 |
  |---|---|
  | 团队台「评审 / 回执 · 真实 actor」 | `R-… · Owner 评审` / `Owner · 通过` / `by=Owner · actor=执行者未记录` |
  | 需求卡 `legacyReqMeta` | `Owner approved · 执行者/记录人未记录` |

  截图：`_tmp\qa12ui\11-team-actor-fabricated.png`。

**源码路径**

- 团队台对 Owner 评审/验收用了默认值：

  ```js
  by: req.ownerReview.by || 'Owner',     // src/renderer/app.js:5005
  by: req.ownerAcceptance.by || 'Owner', // :5015
  ```

  而需求卡用的 `legacyActorText(by)` 在 `by` 为空时返回“执行者/记录人未记录”（`:3691-3694`、`:4856-4857`）。

**影响**：团队台本来是最强调“真实 actor”的页面，却会给一条**没有记录人字段**的旧记录补上 `by=Owner`；这既是两个视图的不一致，也违反页面自己的规则“只认后端字段，不猜成角色本人”。审计读者可能把它当成 Owner 真的做了决定。

**建议**：去掉 `|| 'Owner'`；`by` 缺失就显示 `by=未记录`，并在行上标“旧记录缺 by 字段”。如果后端确实保证 owner 记录总有 `by`，也应该在 UI 层如实显示缺失，而不是填默认值。

---

## 八、优先级

| 优先级 | 问题 | 理由 |
|---|---|---|
| **P1** | boot 过期后绿色“已读全/可推进”，所有 boot 按钮禁用，动作全部 `BOOT_EXPIRED` | 30 分钟后界面死锁；刷新/重启不能恢复；直接影响“必读/boot”这条最核心的规则。 |
| **P1** | 已知缺 `req review`/`owner`/`workflow`，流程按钮仍可点 | 产品评审/迭代实点为死按钮，Owner/终止按同一源码条件判为同类；且与能力面板“会按文件契约记录”的承诺直接矛盾。 |
| **P2** | 整桥缺 preload 只有 toast，界面继续正常空状态并把原因归给 DSH；2 个未捕获 TypeError | “缺 IPC 提示”在最严重的那一档失效；用户会被误导去查 DSH。 |
| **P2** | 团队台对缺 `by` 的旧 Owner 记录填 `by=Owner` | 与需求卡和页面自己的“真实 actor”规则矛盾，等于在 UI 里造记录人。 |
| **P2** | 模板占位警告不降级绿色闸门 | 同一屏同时说“不应据此当已读全”和“可按角色推进”；CORE P1-1/P2-1 的内容根因不重复判，这里只判呈现。 |
| **P3** | DSH 重连后旧“引擎没有连上”卡片短暂残留，与“已连接 207 个会话”同屏 | 数秒后自愈；不影响主链，但状态自相矛盾。 |

> CORE P0-1（发行物缺三条命令）仍是发版阻断的根因；P1“按钮可点”只是它的界面放大。CORE P3-3（能力面板文案）与本节 P1 同屏相关，本报告不重复计为独立问题。

---

## 九、只读边界与副作用

- 新增文件：仅 `docs\QA-ROUND12-UI.md`。
- 临时目录：`_tmp\qa12ui\`（沙盘 `team`/`projects`/`data`、CDP 脚本、截图、`nopreload.log`、`electron.log`）；所有 `TEMP/TMP` 都指向该沙盘。
- 启动了两个沙盘 Electron 实例（正常壳 9347、无 preload 窗口 9348）；QA 结束后已停止，并确认只剩用户原有的 14:51 工作台进程。
- DSH 只做了 `session/list` 读取状态；内嵌 webview 加载了 DSH Web 页面，但没有在页面内选择/创建/唤醒会话，也没有调用 `session/prompt`、`workspace/create`、`session/rename`。
- 未修改：`src\**`、`package.json`、`package-lock.json`、`docs\*`（除本文件）、真实 `团队\状态\**`、真实 `data\**`、`.selftest-data\**`、旧仓库 `D:\deepseek\工作台` 与 `D:\deepseek\luanyujia-workbench`。
- 源码 QA 前后哈希一致（见首表）；`npm run check`：exit 0（5 个入口语法通过，**不证明 UI 行为**）。
- 沙盘副作用：fixture 的 `工作流.json` 有 `.before-*` 备份；当前已还原为“六角色 boot、需求 review、无 owner 注入”的干净状态。

---

## 十、我没能证明的部分

- **没有真实六角色 DSH agent 执行**：沙盘只证明“界面如何读真实的 worktree/工作流文件”，不证明六个角色真的在 DSH 会话里开工；DSH 主画面里 207 个会话是用户真实实例，本报告没有驱动它们。
- **boot 过期**是把沙盘 `boots.*.at` 前移 40 分钟模拟的，等价于超过 30 分钟 TTL；没有真的等 30 分钟。
- **Owner 决定 / Owner 验收**没有在 `approved`、`test_done` 状态下逐个点（需要更多伪造状态）；它们与产品评审共用 `legacyReqButton`，所以按同一源码路径判为同类，但没有为它们各留一张运行截图。
- **单项 IPC 缺失**（例如只缺 `workflow:briefing`）是从源码分支判断的，没有真的改 preload 去逐个摘除；整桥缺失是实跑的。
- DSH 主画面只验证了容器/连接/重连，没有验证 `locateDshSession` 在真实 DSH 会话列表里是否点得准（沙盘项目没有真实角色会话）。

---

## 附：复验入口（选择器）

| 要复验的现象 | 入口 |
|---|---|
| 真相条 / 能力缺口 | `#project-truth`（`旧命令缺 3`、`boot 6/6`） |
| 必读闸门 / 绿色徽章 | `#legacy-gate-badge`、`#legacy-gate` |
| 产品评审 / 迭代按钮 | `button[data-legacy-req-action="requirement-review"]`、`button[data-legacy-req-action="iterate"]` |
| boot 按钮 / 全队 boot | `[data-legacy-boot]`、`#legacy-boot-all`、`#roles-boot-all`、`#team-boot-all` |
| DSH 状态 / 离线卡 | `#btn-dsh`、`#dsh-detail`、`#dsh-off`、`#dsh-view` |
| 真实 actor / 回执 | `#team-actor-list`、`#team-session-list`、`#team-receipts` |

沙盘生成脚本：`_tmp\qa12ui\make-fixture.cjs`；启动脚本：`_tmp\qa12ui\launch-ui.cmd`；无 preload：`_tmp\qa12ui\no-preload-main.cjs` + `launch-nopreload.cmd`。这些脚本只写 `_tmp\qa12ui`，不属于应用代码。

---

## 十一、一句话

**DSH 主画面和六角色/必读的数据大多是真实的，但界面在“它自己已经知道”的三种情况下仍然给错状态：命令缺失仍可点、boot 过期仍显示已读全且无法重新 boot、preload 缺失时说成 DSH 未配置——再加上团队台会给旧 Owner 记录补一个 `by=Owner`，这版 UI 还不能按“真实、可禁用、可恢复”验收。**

---

## 对账回执

- 对账人：只读 UI QA
- 复核人：待 PM / 开发
- 结论：**有异常，停手**（UI 层 2 个 P1）
- 备注：CORE P0-1 未修前，主链仍不可完成；本报告的 P1 是界面没有把已知缺口/过期证据转成禁用和可恢复入口，不能替代 CORE 的后端判定。

