# QA-ROUND14 · dry-run 只读 / Full 壳层收口 / 投票发起人 / 驳回阶段

- 仓库：`D:\deepseek\agile-workbench`（D 盘）
- 时间：2026-11-06 08:50–09:10（Asia/Shanghai）
- 改动边界：**只改** `src/main.js`、`src/team-tools.js`。未改 `src/renderer/**`、`package.json`、`package-lock.json`、`团队/工具/**`（旧仓库/旧协议工具）、`data/**`。
  - 说明：`src/renderer/app.js|index.html|style.css` 在本时段有另一个会话的并发改动（`_tmp/ui-vote-fix/`，投票 UI + 显示层阶段兜底），**不是本会话所为**；本会话的后端修复与它兼容（见 §3.3）。
- 改动前基线（SHA-256）：`main.js 96B35E6B…F43014`、`team-tools.js BA2F782B…2D4E2`，已备份到 `_backup/shell-closeout-20261106-085452/`（含 `rollback.ps1`）。
- 改动后：`main.js C7F1AF67…27EC7`（622,096 B）、`team-tools.js 63B68C42…5CD6A`（414,966 B）。

## 一、结论

**通过。** 四项缺陷全部按“证据可验证”的方式修复，测试与 selftest 全绿：

| 验证 | 结果 |
|---|---|
| `npm run check`（六文件语法） | PASS |
| `npm run test:scripts`（入口脚本） | **SCRIPTS_OK 11/11** |
| 沙盘后端探针 `_tmp/shell-closeout-probe.cjs`（真实 team.mjs + 沙盘状态根） | **41/41 PASS** |
| D 盘 Electron selftest `npm run selftest` | **SELFTEST_OK**（exit 0，第 5/6/9/10/11/12/13/14 轮全绿） |

## 二、四项修复

### 1. `team:restore` / `team:open-project` 的 dryRun 在 `setProjectTeamMode` 之前返回

- 位置：`src/main.js:2321`（`statePayload` 增加 `readOnly`）、`src/main.js:3939`（restore）、`src/main.js:4066`（open-project）。
- 根因：两个 IPC 在算完 `restoreMode/openMode` 后**先** `setProjectTeamMode` 再判 dryRun；而 `setProjectTeamMode` 会写 `workbench.json`、同步 `团队.json` 名册，并调 `ensureProjectReady` 改 `项目.json/workspace.json`。dry-run 因此会“预览却改模式”。
- 修法：dryRun 分支在 `setProjectTeamMode` 之前直接返回：
  - 只跑旧 `launch.mjs --dry-run` 拿角色计划（旧工具该分支在读盘后立即返回，不写文件）；
  - 返回 `dryRun:true`、`writes:{projectConfig:false,store:false,roster:false}`、`mapping:null`、`reload:false`；
  - `state` 用 `statePayload({readOnly:true})`：跳过“过期派单锁释放 / 旧协议 read-ack 对账”这两步可能落盘的副作用。
- 证据（selftest ROUND14）：`{"dryRun":{"unchanged":true,"restoreMode":"fast","openMode":"fast","storedMode":"full"}}` —— full 项目以 fast 预览，dry-run 前后 **状态库 / 名册 / 项目.json / workspace.json 的 存在性+字节数+SHA 全等**，落盘模式仍是 full。

### 2. Full 模式的 Owner 决定/验收、workflow iterate/terminate 不再被旧命令缺失卡死

- 位置：`src/team-tools.js:5284`（`capabilitiesForProjectMode`）、`src/main.js:179`（`capabilitiesWithShellOwnedCloseout`）、`team-tools.js:5560`（`ownerRequirementDecision`）、`team-tools.js:7531`（`ownerAccept`）、`team-tools.js:6508`（`iterateWorkflow`）、`team-tools.js:6607`（`terminateWorkflow`）。
- 规则（“像 Fast 一样”，且**只在旧命令真缺失时**接管）：
  - Owner 动作：Fast 恒为壳层收口（历史契约不变）；Full 在 `commands.owner !== true` 时壳层收口；
  - iterate / terminate：两种模式同一规则——`commands.workflow !== true` 时壳层推进；
  - 旧命令真存在（升级后的 team.mjs / 自测 mock）→ 一律走旧协议，**不抢**。
- 不伪造：动作可用写进 `shellOwnedActions`（`owner-review/owner-accept/iterate/terminate`），命令真实性仍如实报告 —— `commands.workflow` 仍缺、`legacyCommandAvailable.owner=false`、`commandImplemented=false`；返回值显式 `OWNER_SHELL_OWNED` / `WORKFLOW_SHELL_OWNED`、`legacyCommandStatus:'SHELL_OWNED'`、`protocol:'shell'`、`driver:'workbench owner|workflow'`。
- 壳层收口不是“只改状态不做事”：iterate 真的把 `工作流.json.round` +1 并使旧 boot 失效；terminate 真收口旧任务、回写需求正文、`phase=terminated`；Owner 验收仍要求 tester boot + 旧任务 `task done`。
- 证据（selftest ROUND14，真实 team.mjs，owner/workflow 为 NOT_IMPLEMENTED）：
  - `{"owner":{"code":"OWNER_SHELL_OWNED","driver":"workbench owner","status":"ready"}}`
  - `{"caps":{"owner":true,"shellOwnedActions":["owner-review","owner-accept","iterate","terminate"],"missing":["workflow"]}}`
  - `{"workflow":{"iterateRound":2,"iterateCode":"OK","terminateCode":"WORKFLOW_SHELL_OWNED","phase":"terminated"}}`
- 沙盘探针另证：Full Owner 验收 `OWNER_SHELL_OWNED` 且需求 `accepted`；mock 场景（旧命令存在）`shellOwned=false`、`driver=team.mjs owner`，owner/workflow 命令确实被调用。

### 3. 投票发起人按实际发起人（analyst）写进 V 文件，UI/状态一致

- 位置：`src/team-tools.js:4973`（`stampVoteInitiator`）、`startVote` 内嵌调用、`teamVoteView`。
- 根因：旧 `team.mjs vote start` 只允许 PM 执行，V 文件 `createdBy` 被写成 pm；工作台随后只把 analyst 的票补进去，**归属字段仍是 pm**，界面就显示“发起人：项目经理”。
- 修法：在创建事务内（analyst 自动票之前）改写 V 文件归属：`createdBy=initiator=analyst`，另存 `createdByCommand=pm` 记录“谁执行的旧命令”（审计不伪造）；`teamVoteView.initiator` 读 `vote.initiator || vote.createdBy`，默认 analyst（与 UI 默认一致），并新增 `initiatorCommand/initiatedAt`。先落归属再 `vote cast`，使 team.mjs 重写的 `V-*.md` 派生视图也回到 analyst。
- 证据：
  - selftest ROUND13：V 文件 `createdBy=analyst、initiator=analyst、createdByCommand=pm`；`voteStart.vote.initiator='analyst'`。
  - 沙盘探针 E1–E6：V 文件 + `vote:status` 读回同一发起人。
  - 与并发 UI 修复兼容：UI 的 `voteInitiatorRoleId()` 对 `initiator!=='pm'` 直接采信，标题不再出现“PM 记录”提示。

### 4. 被驳回需求后 phase 进入 `requirement_review`，不停在 `requirement`

- 位置：`src/team-tools.js:109`（`REJECTED_REQUIREMENT_PHASE`）+ 六处驳回分支：需求评审驳回、Owner 打回、技术评审打回（镜像/命令两处）、投票驳回、Owner 验收打回；另把 iterate 后的阶段重算改为 `review|rejected → requirement_review`（与 `phaseFromRequirements` 同口径）。
- 理由：`requirement` 阶段没有任何可推进动作，界面看起来“卡死”；`requirement_review` 才是“改完重评”的入口，且与渲染层 `legacyPhaseFromRequirements`（rejected → requirement_review）一致。
- 证据：selftest ROUND14 `{"reject":{"phase":"requirement_review","status":"rejected"}}`，快照 `phase/stage` 与状态库一致；沙盘探针 F1–F3。

## 三、测试改动（测试随契约更新，不是放宽）

1. **第 10 轮负例改写**（`selftestRound10`）：原来断言“缺 owner/workflow → `LEGACY_PROTOCOL_REQUIRED`”，与新契约冲突。改为断言“不再被旧命令卡死”：要么壳层成功（必须 `shellOwned=true` 且真写状态文件），要么停在 boot/业务闸门；只有四者都失败时才要求 `工作流.json` 一字未改。`req review` 缺失仍必须 `LEGACY_PROTOCOL_REQUIRED`（未改动，仍强校验）。
2. **新增第 14 轮**（`selftestRound14`）：dry-run 写面哈希零变化、Full Owner 决定、Full 能力矩阵、驳回阶段、Full iterate/terminate；并在 `selftest()` 中接线（`SELFTEST_ROUND14`）。
3. **第 13 轮补断言**：投票发起人 `analyst` + `createdByCommand=pm`（IPC 返回与 V 文件双向核对）。
4. **沙盘后端探针** `_tmp/shell-closeout-probe.cjs`（不启 Electron，真实 team.mjs + 独立 `团队` 沙盘）：41 项，覆盖 A 能力矩阵 / B Owner 决定 / C Owner 验收 / D iterate+terminate / E 发起人 / F 驳回阶段 / G mock 不抢壳层。

## 四、回滚

```powershell
pwsh -File D:\deepseek\agile-workbench\_backup\shell-closeout-20261106-085452\rollback.ps1
```

- 只恢复 `src/main.js`、`src/team-tools.js` 两个文件；脚本内置基线 SHA-256 断言，不符即非 0 退出。
- 已按宪法第 4 条在沙盘演练：`_tmp/rollback-rehearsal/src/*` 先污染再回滚，恢复后哈希与基线完全一致（`ROLLBACK_OK`）。

## 五、残余风险 / 未覆盖

1. **渲染层是否真的显示 analyst**：由并发会话的 UI 补丁负责；本轮只保证 V 文件 + IPC + 快照三处同一份真相（后端不再写 pm）。两边合并后建议再跑一次完整 selftest。
2. **`V-*.md` 派生视图**：只有在 `requestedBy==='analyst'`（会补一票、触发 team.mjs 重写）时才自动刷新为 analyst；若 analyst 自动票失败，`.md` 仍是旧 PM 文案（JSON 已是 analyst），`warnings` 会给出 `INITIATOR_CAST_FAILED`。
3. **iterate 的顶层 `code` 仍是 `OK`**（Fast 既有契约），“壳层”通过 `legacyCommandStatus:'SHELL_OWNED'`、`shellOwned:true`、`warnings[WORKFLOW_SHELL_OWNED]` 三处明确；terminate/owner 用更显式的 `*_SHELL_OWNED` code。若后续要求 iterate 也改 code，需同步 UI 徽章与外部接口约定。
4. **并发工作区**：本仓当前有另一个会话在改 `src/renderer/**`（`_tmp/ui-vote-fix`）。本次 selftest 期间（09:03–09:06）渲染文件被写入过，但页面在写入前已加载，且第十四轮断言全部走 IPC/磁盘，不受影响。最终合并态需要再跑一次 selftest 作为发版证据。
