# 敏捷工作台 v0.1 · 第二轮只读验收报告

- 验收对象：`D:\deepseek\agile-workbench`（v0.1.0；Electron 33.4.11 / Node 24.22.1）
- 代码基线：`src/main.js` 69,306 B（2026-11-05 03:10:34）、`src/renderer/app.js` 41,440 B（03:00:48）、`src/preload.js`（02:54:40）、`package.json`（02:56:24）
- 验收时间：2026-11-05 03:11–03:22（Asia/Shanghai）
- 验收方式：通读当前源码与 [`QA-REPORT.md`](QA-REPORT.md)；`npm run check`；仓库自带 `--selftest`；九个**仓库外**探针（`%TEMP%\awb-qa2\probe`）直接调用真实 IPC handler，或在真实渲染进程里点真实按钮；本机 mock DSH 只监听回环端口，未向真实 DSH 发送 prompt
- 只读边界：未修改 `src/`、`package.json`、`docs/QA-REPORT.md`、`团队/` 与旧仓库；本文件之外没有新增/改动；自带自测会覆盖仓库根的两张截图，测后已按运行前字节还原（SHA-256 复原）；所有探针的状态库、团队根、项目目录都在 `%TEMP%`
- 结论：上一轮 5 个问题的主要路径均已修复，且有正向证据；仍剩 **1 个中等 + 4 个低**。当前存储格式下没有发现新的“数据被永久覆盖”路径（旧记录兼容见 3.1）。

---

## 一、结论速览

| 上一轮问题 | 结论 | 关键证据 |
|---|---|---|
| S1 状态库损坏 → 静默清零、被下次写入覆盖 | **主要修复，剩 P1**：原子写、`.bak`、损坏隔离、无备份拒绝写入均生效；但“隔离后重启”会丢失 `storeError`/写保护 | 截断后从 `.bak` 恢复并返回 `STORE_CORRUPT`；无备份时 `fatal:true` 且写入被拒；重启后 `storeError:null`、写入恢复 |
| S2 提案 apply 无版本校验 | **修复，剩 P4** | `baseHash`/`contentHash` 分离；评审后改文件 apply 返回 `CONFLICT` 且文件不动；同文件第二个 applied 被拒（但可被路径别名绕过） |
| S3 rollback 备份缺失“假成功” | **修复** | 删备份 → `BACKUP_MISSING`；篡改备份 → `BACKUP_CORRUPT`；apply 后改文件 → `CONFLICT`；三者都不改 `applied` 与文件 |
| S4 跨 `await` 丢写 | **修复** | 5 条真实 await→写路径（prompt / ensure / launch / provision / send）并发建任务/提案，全部保留 |
| S5 派单锁无 TTL/撤销、唤醒失败也置锁 | **修复，剩 P2/P3 界面层** | 10 分钟 TTL 自动释放、`team:cancel` 可用、唤醒失败即释放；无会话不再置锁 |

---

## 二、剩余真实问题（5 条，按严重级别）

### P1【中】状态库“损坏且无备份”被隔离后，重启变成静默空库，写保护也一起消失

**位置**：[`src/main.js:140`](../src/main.js#L140-L160) 缺文件分支、[`src/main.js:162`](../src/main.js#L162-L188) 损坏分支、[`src/main.js:191`](../src/main.js#L191-L206) `writeStore()`、[`src/main.js:240`](../src/main.js#L240-L254) `statePayload()`；渲染层 [`src/renderer/app.js:102`](../src/renderer/app.js#L102-L109)

**现象**

1. 损坏分支把坏文件改名为 `workbench.json.corrupt-<ts>`；若没有 `.bak`，只把 `storeFatal = true`（[`main.js:186`](../src/main.js#L186)）并返回空库，这个“致命”只是**进程内变量**。
2. 新进程启动时主文件已经不存在，走缺文件分支（[`main.js:140`](../src/main.js#L140)）：没有 `.bak`，也不扫描 `.corrupt-*`，直接 `return emptyStore()`（[`main.js:160`](../src/main.js#L160)）。`storeWarning` 为 null、`storeFatal` 回到 false。
3. 于是重启后 `state.projects = 0`、`state.storeError = null`，界面没有任何提示；`writeStore` 也不再被阻止，新建项目直接写出一份新库。坏文件仍在磁盘上，但 UI 与提示里没有任何入口指向它。

**复现（实测，两进程）**

1. `AWB_STORE` 指向临时目录，写入含 1 个项目（1 条任务）的库，**不产生 `.bak`**。
2. 应用启动后把文件截断一半，调用 `app:state` → `storeError {code:"STORE_CORRUPT", fatal:true}`、`projects:0`，原文件被隔离为 `workbench.json.corrupt-2026-11-04T19-17-11-543Z`。
3. 退出，重启同一目录 → `projects:0`、`storeError:null`；`project:create` 成功；`.corrupt-*` 仍在，界面上不可见。

**证据**：PROBE_C step1/step2（第六节）。

**建议**：启动时扫描 `workbench.json.corrupt-*`，在 `state` 回传 `storeError` 并保持 `fatal` 直到用户确认；或把“损坏待处理”持久化到旁路标记文件。这样才接得上上一轮建议里的“恢复模式”。

---

### P2【低】点“撤销派单”后，后端已清锁，界面却把“待回执”又画回来

**位置**：[`src/renderer/app.js:308`](../src/renderer/app.js#L308-L314)（关键在 312）、[`renderDispatch()`](../src/renderer/app.js#L296-L315)

**现象**：撤销按钮的回调在 `applyState(...)` 之后又调用了 `renderDispatch(p)`。`p` 是这个按钮渲染时闭包捕获的**旧项目对象**；`applyState` 已用新 state 重绘成“当前没有待回执消息”，紧接着这次旧对象重绘又用旧的 `pendingAck`/旧 `messages` 把“待回执 + 撤销派单”面板画了回去。

**复现（真实渲染进程，PROBE_F）**

1. 有 `sessions.analyst` 的项目派单成功 → `#dispatch-pending` 显示“待回执：需求分析师 · 撤销测试 …”。
2. 页面内 `window.confirm = () => true`，点击 `#dispatch-cancel`，等 800 ms。
3. 后端：`state.pendingAck === null`（`team:cancel` 成功）；界面：`#dispatch-pending.innerText` 仍是“待回执：需求分析师 · 撤销测试 撤销测试正文 记录回执 撤销派单”。

**影响**：用户会以为撤销失败；再点一次撤销是无害的 no-op，但“记录回执”仍可对这条已撤销消息写回执。刷新或下一次渲染后恢复。**修复**：`renderDispatch(activeProject())`，或直接删掉这句（`applyState → render()` 已经重绘）。

---

### P3【低】没有 DSH 会话时的派单不再加锁（正确），但消息在界面里完全不可见、也没有回执/撤销入口

**位置**：[`src/main.js:801`](../src/main.js#L801-L813) 无会话不置锁；[`src/renderer/app.js:302`](../src/renderer/app.js#L302-L305) 只渲染 `pendingAck` 指向的那一条；[`src/renderer/index.html:232`](../src/renderer/index.html#L232-L234) 只有 `#dispatch-pending` 一个派单展示位

**现象**：无 session 时只写 `message`、不写 `pendingAck`——这是修掉死锁的正确做法。但界面没有消息列表/事件列表，`renderDispatch` 在 `pendingAck` 为空时只显示“当前没有待回执消息”。于是这条消息只存在于 `workbench.json` 的 `messages`/`events` 里：用户看到 toast“派单已记录（DSH 未唤醒）”后，再也找不到它，也无法从 UI 回执或撤销。

**复现（PROBE_H，真实渲染进程）**：项目无 sessions → `team:send(analyst)` → `pendingAck:null`、`message.ack:false`；`#dispatch-pending` 文本“当前没有待回执消息。”；`document.body.innerText` 不含派单主题“无会话派单”；`#dispatch-ack` 不存在。

**影响**：低（不锁项目、不丢数据），但“已记录”在 UI 上没有落点。**建议**：给无会话派单一个 `pendingWake` 可见状态（显示“未唤醒”，可重发/取消），或补一个最小消息列表。

---

### P4【低】“同一文件只允许一个未回滚的 applied 提案”可被路径别名绕过（`./`、Windows 大小写）

**位置**：[`src/main.js:699`](../src/main.js#L699-L705) baseHash 校验、[`src/main.js:706`](../src/main.js#L706-L711) 同文件检查；文件路径在 [`main.js:696`](../src/main.js#L696-L698) 用 `path.resolve` 归一

**现象**：同文件检查比较的是 `proposal.fileRel` **原始字符串**（[`main.js:706`](../src/main.js#L706)），而读写/越界检查用的是 `path.resolve`（`./` 归一、Windows 大小写不敏感）。先应用 A（`case.md`）后，用 `CASE.md` 或 `./dot.md` 再建提案 B：B 的 `baseHash` 正是当前文件哈希，baseHash 校验通过；字符串不同让同文件检查放行；B 应用成功。两个提案同时 `applied:true`，同一物理文件被第二次覆盖。

**复现（PROBE_D）**

1. `case.md = BASE`，提案 A 内容 `ONE`，签字 apply → 文件 `ONE`。
2. 用 `CASE.md` 建提案 B（`baseHash === A.commit.afterHash`），签字 apply → **成功**，文件变 `TWO`，A、B 都 `applied:true`。
3. `./dot.md` 同样成功（跨平台可复现；大小写变体是 Windows 特有）。

**证据**：`alias.caseVariantBypassesSingleApplied`、`alias.dotVariantBypassesSingleApplied`、`alias.bothRemainApplied`（2 条 applied）。

**影响**：唯一 applied 不变量被破坏；先应用的 A 回滚会因 `afterHash` 不符被拒（`CONFLICT`），需要人工把文件恢复成 A 的 afterHash 才能回滚。**建议**：比较前把 `fileRel` 归一（`path.resolve` 后相对项目根 + Windows 下折叠大小写），或把归一后的路径存进 proposal/commit。

---

### P5【低】并发两次“启动团队”会重复创建 DSH 会话：12 建 6 存

**位置**：[`src/main.js:896`](../src/main.js#L896-L957) `dsh:provision`（循环 [`912`](../src/main.js#L912-L920)、最终合并 [`925`](../src/main.js#L925-L946)；[`main.js:913`](../src/main.js#L913) 的注释声称“不能重复建同一角色会话”）

**现象**：每个角色处理前会 `readStore()` 检查 `sessions`，但会话只在循环结束后统一写库。两个并发 `dsh:provision` 都看到空 `sessions`，都创建 6 个会话；最终合并只保留每角色第一个，另一组 6 个成为 DSH 侧孤儿。

**复现（PROBE_B，本机 mock DSH，`session/create` 100 ms 延迟）**：新项目并发两次 `dsh:provision` → 两次都 `ok:true`；`session/create` 调用 **12** 次；store 里 `sessions` **6** 个。

**证据**：`provision.concurrentDoubleCalls {bothOk:true, dshSessionsCreated:12, persisted:6}`。

**影响**：低（数据不丢、功能可用），但会污染 DSH 会话列表并浪费额度；UI 的 `#btn-team-start` / `#btn-provision` 在请求期间没有禁用，双击可触发。**建议**：按项目加 in-flight 锁，或每建一个会话就立即落库并在创建前二次检查。

---

## 三、兼容性与其他观察（不计入上面 5 条）

### 3.1 升级前的旧提案/旧提交没有迁移路径

上一版写入的提案没有 `baseHash`/`contentHash`，旧 commit 没有 `afterHash`/`backupHash`。用上一版字段形态构造记录后实测：

- 旧提案（文件从未改动）apply → `CONFLICT`“提案绑定的文件在评审后被修改”，**永远无法应用**（`currentHash !== null`，[`main.js:701`](../src/main.js#L701)）。
- 旧已应用提交（文件已被改成 `MODIFIED`）rollback → `ok:true`，文件被备份内容 `ORIG` **静默覆盖**（`if (commit.afterHash && ...)` 跳过了校验，[`main.js:748`](../src/main.js#L748)）。

**前提**：本机没有发现真实的旧 `workbench.json`（仓库 `data/` 只有 `.gitkeep`，`%APPDATA%` 下无 store），所以这是按旧字段构造记录复现的升级风险。若确认没有旧库，可只当迁移建议：对缺失 `baseHash`/`afterHash` 的记录做一次性回填，或在 UI 标“旧记录，需重新评审”。

### 3.2 “恢复项目”已不看 README，但含 `项目信息.md` 的目录仍会被写入团队布局

- README-only 目录：`project:adopt` 在 mkdir 之前就以“目录里没有 项目信息.md，无法确认是工作台项目”拒绝；目录条目前后完全一致（`README.md`、`main.py`），**零写入**。
- 含 `项目信息.md` 的目录：可以恢复；已有 `README.md` / `项目信息.md` **不被覆盖**（实测内容保持 `# 原有 README` / `# 原有信息`），但会新增 15–16 个条目（六角色目录、`site/`、`_tmp/`、`项目索引.md`、`协作准则.md`、`项目铁律.md`、`workspace.json`、需求池等）。
- 恢复弹窗写的是“不复制、不覆盖”（[`app.js:601`](../src/renderer/app.js#L601)），但没有二次确认“会向该目录写入团队布局”。若产品意图是“恢复不写任何东西”，这一条仍未达成；若“恢复 = 补齐团队布局”，则现状符合。

### 3.3 状态提示是一次性 toast

`warnStore()` 每个进程只提示一次（[`app.js:102`](../src/renderer/app.js#L102-L109)），`writeStore` 成功后会清空 `storeWarning`（[`main.js:205`](../src/main.js#L205)）。恢复成功后没有持久横幅；这与 P1 的“重启即失忆”是同一类问题。

---

## 四、上一轮 5 问题逐项验证

| # | 结论 | 实测证据 |
|---|---|---|
| S1 | 原子写、`.bak`、损坏隔离、无备份阻止写入均生效；**剩 P1 重启失忆** | 首写无 `.bak`；第二次写 `.bak` 是上一版（1 个项目，主库 2 个）；无 `.tmp` 残留；截断 → `STORE_CORRUPT`（`fatal:false`）+ 从 `.bak` 恢复 3 个项目 + 生成 `.corrupt-*` + 正式文件可解析；删主文件 → `STORE_RESTORED` 且重新落盘；删 `.bak` 再截断 → `projects:0`、`fatal:true`、`project:create` 被“阻止写入”拒绝、`.corrupt-*` 保留 |
| S2 | **已修复**，剩 P4 路径别名 | `baseHash=sha256(BASE)`、`contentHash=sha256(NEW)`、`hash===contentHash`；评审后改文件 → `CONFLICT` 且文件保持 `OTHER`、`applied:false`；恢复 BASE 后 apply → 成功，commit `backupHash=sha(BASE)`、`afterHash=sha(NEW)`、`existed:true`；同文件第二个已签字提案 → `CONFLICT`“未回滚”；重复 apply → “提案已经应用” |
| S3 | **已修复** | apply 后改文件 rollback → `CONFLICT`“应用后又被修改”，`applied` 仍 true、文件仍 `TAMPER`；删备份 → `BACKUP_MISSING`，`applied` 仍 true、文件仍 `NEW`；篡改备份 → `BACKUP_CORRUPT`；未 apply rollback → “没有可回滚的提交”；重复 rollback → 同；新文件提案：apply 创建、`backupPath:""`、rollback 删除 |
| S4 | **已修复** | 3 s `dsh:prompt` 期间在 A/B 两项目建任务：两条都在；1.5 s ensure 期间建任务+提案：都在且事件“团队项目已同步”；1.5 s launch 期间建任务：任务在、`sessions.pm` 在；`dsh:provision` 6 个会话期间建任务：任务在、6 会话在；3 s `team:send` 期间建任务：任务与派单都在 |
| S5 | **已修复**，剩 P2/P3 界面层 | 无会话派单：`wake.ok:false`、`pendingAck:null`、第二次派单 `ok`；唤醒失败（mock 500）：`pendingAck:null`、事件“唤醒失败，派单锁已释放”、下一次可派；成功：置锁、第二次被拒“还有一条派单未回执…”、未知回执被拒、`team:cancel` 清锁、撤销后回执可记录；TTL：`pendingAckAt` 改为 11 分钟前 → state 隐藏锁、下一次派单自动释放并落新锁、事件“超过 10 分钟，自动释放” |

---

## 五、本轮其它改动与已验证项（实测通过）

| 项 | 证据 |
|---|---|
| `npm run check` | 退出码 0；已包含 `src/team-tools.js`（上一轮 E 的检查覆盖洞已补，[`package.json:13`](../package.json#L13)） |
| 自带 Electron selftest | `SELFTEST_OK`，退出码 0；`SELFTEST_STORE {"checks":20,"failed":0}`；`SELFTEST_FLOW` 全绿：`applied:true, rolled:false, secondSendOk:true, lockAfterNoSession:null, cancelOk:true, acked:true, launchDryPlan:1, launchIpcOffline:true/DSH_OFFLINE, boardOk:true, teamIndex:true, teamRules:true, teamAdoptOk:true, wsProbeOk:true`；`SELFTEST_TEAM_OFFLINE` `DSH_OFFLINE`；`SELFTEST_TEAM_ERRORS` `TIMEOUT/PROJECT_DIR_MISSING/TOOL_MISSING`；`SELFTEST_TEAM_CLEANUP {"removed":["验证项目"]}` |
| 真实 DSH 探测 | selftest 中 `session/list` 连上 157 个会话（只读，未发 prompt） |
| 提案闸门 | 未签字 apply 拒；签字 rejected 后 apply 拒；重复签字拒（“不能重复签字”）且状态保持 rejected；作者自评 →“作者不能评审自己的提案”；空理由 →“评审必须写理由”；非法角色 →“评审角色无效”；非法结论 →“评审结论无效”；非法签字决定 →“签字决定无效”（PROBE_I） |
| `files:list` 目录缺失 / 显式 projectId | 正常项目 44 条；缺 projectId → “项目不存在”；显式错误 id → “项目不存在”；删掉项目目录 → “项目目录不存在：…”（不再 `ok:true, files:0`，渲染层 `loadFiles` 的 catch 会把它显示在文件区，[`app.js:523`](../src/renderer/app.js#L523-L535)）；`files:open` 错误 projectId → “项目不存在”；`../../workbench.json` → “路径越界”；`project:open` 错误 id → “项目不存在” |
| `requireProject` 显式 id | `task:update({projectId:'P-nope'})` → “项目不存在”，目标任务仍为 `todo`（不再回退改当前项目）；`task:update` 非法状态 → “任务状态无效”；`files:*` / `project:open` 错误 id 同样拒绝（PROBE_I + PROBE_A） |
| 阶段推导（上一轮 G） | Owner 未决时建 `programmer1` 任务 → 阶段仍 `owner`；Owner 通过后 → `dev`；再加未完成 `tester` 任务 → `test`（PROBE_I）；selftest 另给出 `intake → owner → dispatch → close` |
| `dsh:provision` 部分失败 | mock 第 3 个 `session/create` 失败 → 抛 `DSH_RPC`，`created` 2 条、`persisted:2`、message 含“已保留 2 个已建会话，可重试补建”，事件“启动 DSH 团队中断”；store 保留 2 个会话；重试只补 4 个（共 6，无重复） |
| `team:launch` dry-run | 不写 sessions、不加事件（事件仍只有“项目创建”） |
| `team:ensure-project` 失败分支 | 返回 `ok:true, ensured:false, team.code:"STUB_FAIL"`，并写事件“团队项目同步失败：STUB_FAIL” |
| 恢复项目 | README-only 拒绝 + 零写入；含 `项目信息.md` 接受、已有 README/项目信息不覆盖；重复恢复 → “这个目录已经登记” |
| 仓库完整性 | `团队/状态` 四个文件 SHA-256 运行前后一致；无 `.selftest-data` 残留；`selftest.png`/`selftest-flow.png` 自测后已还原（`7C172E70…` / `22F0043F…`）；`_backup/`、`userdata-ui-round2/` 未动 |

---

## 六、环境与复现方法

### 6.1 两个环境坑（不是产品缺陷，但影响复现）

1. 本会话继承 `ELECTRON_RUN_AS_NODE=1`：直接跑 `electron.exe . --selftest` 会被当成 Node，在 [`main.js:1403`](../src/main.js#L1403) 报 `TypeError: Cannot read properties of undefined (reading 'whenReady')` 并退出 1（本次已复现）。**先清空该变量**再跑才能 `SELFTEST_OK`。建议主进程启动时检测并给一句可操作提示。
2. 自测会覆盖仓库根的 `selftest.png` / `selftest-flow.png`（本次实测哈希变化），且 `--user-data-dir` 对应用状态无效（`AWB_STORE` 被强制到 `.selftest-data`）。本次用 `--user-data-dir=%TEMP%\awb-qa2-userdata` 避免在仓库里留 `userdata-selftest/`，测后还原两张截图。

### 6.2 本次运行过的命令

```powershell
cd D:\deepseek\agile-workbench
npm run check

$env:ELECTRON_RUN_AS_NODE = $null
.\node_modules\.bin\electron.cmd . --selftest --user-data-dir="$env:TEMP\awb-qa2-userdata"
```

### 6.3 九个仓库外探针（`%TEMP%\awb-qa2\probe`）

所有探针 `require` 真实的 `src/main.js`/`src/preload.js`，通过 `ipcMain._invokeHandlers` 调真实 handler（保留自定义 `e.code`），或加载真实 `src/renderer/index.html` 后点真实按钮；`AWB_STORE`、`TEAM_ROOT`、`DSH_HOME`、项目目录全部指向 `%TEMP%`。

| 探针 | 覆盖 |
|---|---|
| probe-a | 状态库原子写/`.bak`/损坏恢复/无备份阻止、提案 baseHash 与 apply/rollback 全部负路径、派单锁无会话/唤醒失败/撤销/TTL、`files:list`/`files:open`、恢复项目 README-only |
| probe-b | 跨 await 丢写：`dsh:prompt`（3 s）、`team:ensure-project`（1.5 s 替身）、`team:launch`（1.5 s 替身）、`dsh:provision`（6×120 ms）、`team:send`（3 s）；并发双开 provision |
| probe-c | 状态库“损坏+无备份”隔离 → 重启两进程 |
| probe-d | 提案路径别名（`./`、Windows 大小写）绕过唯一 applied |
| probe-e | provision 中途失败/重试、launch dry-run 不写库、ensure 失败分支 |
| probe-f | 真实渲染进程点“撤销派单”，检查 DOM 与后端 |
| probe-g | 旧字段提案/提交的升级行为；恢复混合目录不覆盖 README |
| probe-h | 无 DSH 会话派单在真实 UI 的可见性与回执入口 |
| probe-i | 显式错误 projectId 对 `task:update` 的拒绝与不落库、非法任务状态、评审/签字闸门 |

mock DSH：本机 `http.createServer`，按 `{type:"server-response", rpcId, result:{ok:true,value}}` 回包，`DSH_HOME` 放一个 43 字符假 secret；用于 3 s prompt 延迟、失败注入、6 个 session 创建。`team:ensure-project` / `team:launch` 的 1.5 s 延迟是在探针进程内替换 `teamTools` 的同名函数（只改测试进程，不动源码），以便制造确定的并发窗口；真实 `ensure` 由 selftest 与恢复项目测试覆盖，真实 `launch` 的成功路径仅由替身覆盖（selftest 覆盖其 dry-run 与离线分支）。

### 6.4 判定口径

- 每条“已验证”尽量用三类证据互相印证：调用返回/状态字段、磁盘文件内容或哈希、（涉及界面时）真实 DOM 文本；只有一类来源的条目已在表格里写明来源。
- “问题”只列本次能稳定复现、并能指出具体代码位置与失败表现的条目；上一轮已修但只在极端条件下不成立的点放进 P1/P4 或第三节，不重复灌水。
