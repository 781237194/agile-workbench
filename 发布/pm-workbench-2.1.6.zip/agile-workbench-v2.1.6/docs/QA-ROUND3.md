# 敏捷工作台 v0.1 · 第三轮只读最终验收

- 验收对象：`D:\deepseek\agile-workbench`（v0.1.0；Electron 33.4.11 / Node 24.22.1）
- 代码基线：`src/main.js` 132,316 B（2026-11-05 03:55:24）、`src/renderer/app.js` 95,295 B（04:05:06）、`src/renderer/index.html` 21,239 B（03:45:38）、`src/team-tools.js` 33,641 B（03:38:30）、`package.json`（02:56:24）
- 验收时间：2026-11-05 04:06–04:14（Asia/Shanghai）
- 验收方式：通读 [`OLD-CODE-AUDIT.md`](OLD-CODE-AUDIT.md)、[`QA-REPORT.md`](QA-REPORT.md)、[`QA-ROUND2.md`](QA-ROUND2.md) 与当前源码；`npm run check`；仓库自带 Electron `--selftest`；四个仓库外探针（全部在 `_tmp`，通过真实 IPC handler / 真实渲染层执行）；静态 DOM↔JS 差集
- 只读边界：未修改 `src/`、`package.json`、`团队/`、旧仓库；本文件之外只新增了 `_tmp` 下的测试脚本与日志；自测覆盖的两张仓库截图已按运行前哈希还原
- 结论：主流程与数据可靠性基础仍然成立，上一轮多数修复有正向证据；但本轮仍确认 **6 个高、7 个中、2 个低**，共 15 个可复现或可静态证明的问题，集中在“Owner 闸门/流程可达性、会话真实性、提案协议、项目重名、DSH 配置与嵌入页刷新、首屏死按钮”。

---

## 一、结论速览

| # | 级别 | 问题 | 主要证据 |
|---|---|---|---|
| S1 | 高 | Owner 闸门可被“把任务标记完成”绕过，直接进入收口 | 探针 `ownerGateBypass` |
| S2 | 高 | 本地会话记录不再向 DSH 核实，`dsh:provision` 直接报告“已存在” | 探针 `provision.staleSessions` |
| S3 | 高 | 新建/恢复项目的团队登记失败被静默吞掉，界面仍提示成功 | 探针 `teamSyncFailure.create` |
| S4 | 高 | 同名项目可并存；团队名被加哈希后缀，界面与团队/按名操作不一致 | 探针 `duplicateNames.*` |
| S5 | 高 | 提案无任何评审即可签字并 apply；签字也不限制 PM 角色 | 探针 `proposal.signWithoutReview`、`proposal.nonPmSign` |
| S6 | 高 | 首屏“＋ 新建项目”和侧栏“恢复项目”是死按钮 | DOM 探针 `deadButtons` |
| S7 | 中 | 8 阶段流程中的“需求 / 产品评审”永远不会成为当前阶段 | 静态 + 自测阶段序列 |
| S8 | 中 | 同一角色可以重复评审同一提案，评审计数可灌水 | 探针 `proposal.duplicateReview` |
| S9 | 中 | DSH 地址配置只存在内存，重启即回到默认地址 | 探针 `dshConfigure.*` |
| S10 | 中 | 刷新 / 建团队后不重载内嵌 DSH 页面 | DOM 探针 `refreshDoesNotReloadWebview` |
| S11 | 中 | Owner 弹窗可关闭，关闭后本轮不再自动弹出 | 静态（`closable: true` + `ownerPrompted`） |
| S12 | 中 | `team:members` 对不存在的 projectId 静默回退到当前项目 | 探针 `teamMembers.invalidProjectFallback` |
| S13 | 中 | 没有单实例锁，两个实例可同时写同一状态库与团队状态 | 全仓 grep + 旧壳对照 |
| S14 | 低 | 派单 TTL 过期只在 state 投影里隐藏，磁盘仍保留 `pendingAck` | 探针 `dispatch.ttlProjectionOnly` |
| S15 | 低 | 删除项目记录只删 store；团队登记、磁盘目录、discover 结果仍在 | 探针 `deleteRecord.leftovers` |

计数：高 ×6、中 ×7、低 ×2。

---

## 二、旧 vs 新：对照 `OLD-CODE-AUDIT.md`

### 2.1 上一轮审计中已经修复或有正向证据的

| 旧审计条目 | 本轮复核 |
|---|---|
| P0-2 六角色绕过 `launch.mjs` | 已改走 `teamTools.launchSessions`；selftest mock 计数 `sessionSelectModel:6`、`sessionPrompt>=6`、`sessionCreate:6`，说明模型选择与 seed-visible 都真实发生 |
| P0-4 派单锁无 TTL/撤销、唤醒失败仍锁 | selftest：无会话第二次派单可发、`lockAfterNoSession:null`、`cancelOk:true`、唤醒失败 `lock:null`；TTL 后新派单自动释放 |
| P1-2 Owner 闸门位置 | `deriveStage` 已把 Owner 放在 dev/test 之前（selftest `stageAfterApprove:dispatch`）；但仍有本轮 S1/S11 |
| P1-3 缺 `team:restore` | IPC 已存在；探针 `restore.byNameDryRun` 返回 `ok:true, plan:1`；`project:adopt` 对已有目录不覆盖 `项目信息.md` / `README.md` |
| S1 状态库原子写/备份/损坏隔离 | `selftestStore` 20 项全过；截断、缺文件、无备份阻止写入都在自测中覆盖 |
| S2/S3 提案 baseHash/回滚备份校验 | selftest 覆盖 `CONFLICT`、`BACKUP_MISSING`、`BACKUP_CORRUPT`、旧提案缺 baseHash 拒绝；路径大小写别名 `dupBlocked:true` |
| S4 跨 await 丢写 | `dsh:prompt`、`team:ensure-project`、`team:launch`、`dsh:provision`、`team:send` 均改为 await 后重读合并；selftest 并发 provision 6 个会话且只建 6 次 |
| P2-5 `team:launch` 默认 dry-run 反转 | 已改为默认真实启动（`dryRun: p.dryRun === true`），selftest dry-run 仍按显式参数工作 |
| P3-1 TTL 展示层问题 | 仍未真正落盘清理，见本轮 S14 |
| P3-2 任务默认角色 | 仍未修，`task:create` 仍默认 `pm`（本轮未单列，避免与 S1/S7 重复计数） |

### 2.2 仍然存在的旧差异（未全部单列为问题）

- **P0-1 场景/工作区清单**：渲染层仍不调用 `teamWorkspaces`；`teamWorkspaces`/`teamEnsureProject`/`teamLaunch`/`teamBoard`/`deleteProjectRecord` 在 `src/renderer/app.js` 中仍是死接口（全仓 grep 无调用，只有 selftest 使用）。新壳仍只有本地 `state.projects`。
- **P0-3 提案协议**：仍没有旧协议的 `show`/read receipt、评审人集合、风险/授权、签名绑定哈希、团队状态回写；本轮 S5/S8 是这条差异的直接用户可见后果。
- **P0-4 回执协议**：`team:ack` 仍是人在 UI 里代填，不校验角色/会话；派单消息不进 `团队/消息`，`team.mjs inbox` 看不到。TTL/撤销/唤醒失败已修，但“回执证据链”没有恢复。
- **P1-1 DSH 地址发现/持久化/cookie 重铸**：仍是固定 `DSH_WEB_URL` 或 `127.0.0.1:52711`；`dsh:configure` 不落盘；401/403 仍直接归一为 `DSH_OFFLINE`，没有“重铸 cookie 再试”。见 S9。
- **P1-6 团队看板浮窗**：仍是 `shell.openPath(看板.html)`，没有置顶窗口/折叠/缩放/项目切换。
- **P1-8 刷新嵌入页**：见 S10。
- **P1-9 单实例/删除项目**：单实例锁仍无（S13）；删除记录仍只删 store（S15）。
- **P2-6 数据落点/日志**：团队根仍默认 `<repo>/团队`；没有 `main.log`/`uncaughtException` 兜底；`.gitignore` 仍未忽略 `data/`（当前目录不是 git 仓库，故未单列）。

### 2.3 本轮新增确认

S1（Owner 完成即收口）、S2（幽灵会话）、S3（团队失败静默）、S4（同名项目）、S6（首屏死按钮）、S7（review 不可达）、S8（重复评审）、S9（配置不持久）、S10（不重载）、S11（Owner 可关）、S12（members 回退）、S13（无单实例）、S14（TTL 投影）、S15（删除残留）。

---

## 三、问题清单（按严重级别）

### S1【高】Owner 闸门可被“把任务标记完成”绕过，直接进入收口

**位置**：`src/main.js:520-531`（关键在 `526` 的 `if (!open.length) return 'close'`，Owner 判断在 `528`）

**现象**

`deriveStage()` 先判断“没有未完成任务”，再判断 Owner 状态。只要项目里最后一个未完成任务被标成 `done`，即使 `ownerReview.status` 仍是 `optional`、从未做过 Owner 决定，阶段就直接变成 `close`（收口）。Owner 闸门、派发、开发、测试全部被跳过。

**复现（真实 IPC，探针 `_tmp/probe/result.json` 的 `ownerGateBypass`）**

1. 新建项目“闸门项目”。
2. `task:create` 建一个 `analyst` 任务；`app:state` 的 `stage` 为 `owner`（正确：Owner 未决）。
3. 不调用 `owner:decide`，直接 `task:update` 把该任务置为 `done`。
4. 再读 `app:state`：`stage` 为 `close`，`ownerReview.status` 仍为 `optional`，`ownerReview.at` 为 `null`。

实测结果：`{stageAfterTask:"owner", stageAfterDone:"close", ownerStatus:"optional", ownerAt:null}`。

**影响**

- 用户在总览/看板点“下一步/完成”就会在没有任何 Owner 决策的情况下收口，流程高亮显示“收口”，但 Owner 卡片仍是“未选择”。
- 与 `docs/FEATURE-MATRIX.md` 的“Owner 阶段 已完成”和流程页“Owner 评审后进入派发”不一致；旧壳 `computeWorkflow()` 只有在 Owner 决策后才推进。
- 这是状态机级错误，不只是 UI 文案；后续所有基于 `stage` 的判断都会被带偏。

**建议落点**

把 Owner 判断移到“无未完成任务”之前：`owner.status` 不在 `approved/skipped` 时，即使所有任务都 `done` 也返回 `owner`；`close` 只有在“所有任务完成 **且** Owner 已通过/跳过”时可达。补一条 selftest：任务全部完成但 Owner 未决，阶段必须仍是 `owner`。

---

### S2【高】本地会话记录不再向 DSH 核实，`dsh:provision` 直接报告“已存在”

**位置**：`src/main.js:154-167`（`provisionTeamSessions` 的 `missing` 计算与 `if (!missing.length)` 提前返回）

**现象**

`provisionTeamSessions()` 只读状态库里的 `project.sessions` 计算缺失角色；六个角色在本地都有 id 时，函数在任何 DSH 调用之前直接返回 `{ok:true, reused:true, sessions:[...]}`。它不检查这些 id 在 DSH 是否还存在、是否属于本项目、是否已被归档。

**复现（真实 IPC，探针 `_tmp/probe/result.json` 的 `provision.staleSessions`）**

1. 新建项目“幽灵会话项目”。
2. 直接改写测试状态库，把 `sessions` 写成六个不存在的 id（`ghost-pm`…`ghost-tester`），模拟 DSH 重启后会话被清空/工作区被删。
3. `DSH_WEB_URL` 指向必然连不上的 `http://127.0.0.1:9`。
4. 调用 `dsh:provision`。

实测结果：`{ok:true, reused:true, created:0, sessions:6, dshBaseUrl:"http://127.0.0.1:9"}`——DSH 根本没有被访问，仍然返回成功。

**影响**

- DSH 重启、会话被删、工作区迁移后，用户点“建团队”只会看到“会话已存在”，实际一个可用会话都没有；随后唤醒全部失败。
- 这与旧 `launch.mjs --restore` 的“按标题+cwd 复用前先核实”语义相反；也是旧审计 P0-2 “从不向 DSH 核实”的残留。
- 叠加 S9：地址丢失时更容易出现“本地有记录、DSH 不在”的假成功。

**建议落点**

在 `if (!missing.length)` 之前调用 `dsh.listSessions()`（或直接走 `teamTools.launchSessions(project,{restore:true})`），逐个核实 id 存在且属于该 workspace；不存在的角色重新建，并把“重用 N 个/重建 M 个”写回状态库与事件。补 selftest：本地六 id 全为幽灵、DSH 离线时应返回失败而不是 `reused:true`。

---

### S3【高】新建/恢复项目的团队登记失败被静默吞掉，界面仍提示成功

**位置**：`src/main.js:871-875`（`project:create` 调用 `syncTeamProject` 后只返回，不落库）、`src/main.js:939-940`（`project:adopt` 同样）、`src/renderer/app.js:1195-1198`（`openNewProject` 忽略 `r.team`，直接 toast“项目已创建”）

**现象**

`createProject()` 先把项目写入 `workbench.json`，然后 `await syncTeamProject(p)`；无论 `team.ok` 是 true 还是 false，返回值里的 `team` 都没有写入 `project.teamName/teamSyncedAt`，也没有 `addEvent`。渲染层只读 `r.project`，完全忽略 `r.team`。恢复项目同样。

**复现（真实 IPC，探针 `_tmp/probe-bad/result.json` 的 `teamSyncFailure.create`）**

1. 在 `TEAM_ROOT/状态/团队.json` 放一段非法 JSON，使 `ensureInitialized()` 返回 `TEAM_STATE_BAD`。
2. 调用 `project:create` 新建“团队失败项目”。

实测结果：

```json
{
  "projectOk": true,
  "team": { "ok": false, "code": "TEAM_STATE_BAD" },
  "persistedTeamName": null,
  "persistedTeamSyncedAt": null,
  "events": ["项目创建"],
  "storeError": null
}
```

**影响**

- 用户看到“项目已创建”，实际团队目录/`项目索引.md`/`协作准则.md`/看板都没有生成；后续 `team:board`、`dsh:provision`、文件索引才发现缺东西。
- 失败既没有事件，也没有 `storeError`，界面无任何线索；只能去翻 `团队/状态`。
- 旧壳 `team:workspace:create` 失败会明确提示“工作区已创建，但六角色导入失败”；新壳没有等价反馈。

**建议落点**

`project:create`/`project:adopt` 在 `syncTeamProject` 后：成功时写 `teamName/teamSyncedAt` 并 `addEvent('团队项目已同步')`；失败时写 `addEvent('团队项目同步失败：CODE')` 并把 `team` 返回给渲染层。`openNewProject()`/`openRestoreModal()` 检查 `r.team && !r.team.ok`，toast 改为“项目已创建，但团队登记失败：CODE”。补 selftest：坏团队状态下创建项目必须出现失败事件。

---

### S4【高】同名项目可并存；团队名被加哈希后缀，界面/团队/按名操作不一致

**位置**：`src/main.js:598-633`（`createProject` 只在 `605` 检查路径，不检查项目名）、`src/main.js:915-940`（`project:adopt` 在 `926` 直接用 `path.basename`，不检查同名）、`src/team-tools.js:401-416`（同名不同路径加 sha1 后缀）、`src/main.js:719-726`（按名选择只取第一个匹配）

**现象**

同一个状态库里可以存在两个 `name` 完全相同的项目，只要 `path` 不同。团队工具为避免目录冲突，会把第二个项目的团队名改成 `原名-<sha1前6位>`；但状态库里的 `project.name` 仍是原名，且 `project.teamName` 没有落库（见 S3）。结果界面两个同名项目无法区分，团队看板/按名恢复只认其中一个。

**复现（真实 IPC，探针 `_tmp/probe/result.json` 的 `duplicateNames.*`）**

1. 分别在两个根目录下 `project:create({name:'同名项目', root:...})`。
2. 两次都 `ok:true`。
3. 团队登记为 `同名项目`（r1）与 `同名项目-1f90bb`（r2）；状态库两个项目的 `teamName` 都是 `null`，`name` 都是 `同名项目`。
4. `project:adopt` 对另一个 `path.basename` 相同的目录同样允许（只拦同路径）。

实测摘要：`p1team.name="同名项目"`、`p2team.name="同名项目-1f90bb"`；`state` 两条记录 `teamName:null`。

**影响**

- 左侧项目列表两个同名条目，只能靠路径 tooltip 区分；用户很容易选错。
- `team:restore({name:'同名项目'})`、`team:launch`、`team:board` 走 `findProjectByName`/`pickTeamProject` 时只返回第一个；第二个项目的团队操作无法按名字到达。
- 团队看板里的项目名与界面项目名不一致，PM/旧 CLI 会认为是两个不同项目。
- 与旧壳的 `PROJECT_NAME_CONFLICT`（同名不同目录）保护相反；旧审计 P1-3 的“同名冲突”仍成立。

**建议落点**

在 `createProject`/`project:adopt` 增加“同名不同路径 → `PROJECT_NAME_CONFLICT`”或“自动在显示名后加路径短后缀”的明确策略；把团队实际使用的 `teamName` 持久化到项目记录并在侧栏/页头显示；`findProjectByName`/`pickTeamProject` 遇到多个同名时返回歧义错误，而不是取第一个。补 selftest：同名不同根第二次创建必须被拒绝或得到可区分名称。

---

### S5【高】提案无任何评审即可签字并 apply；签字也不限制 PM 角色

**位置**：`src/main.js:1473-1495`（`proposal:sign`；`1479-1481` 只检查应用/重复签字/被拒；`1487-1488` 接受任意 `ROLES` 作为签字人）；渲染层 `src/renderer/app.js:913-915`、`1000-1023`（未评审也显示“PM 签字”）

**现象**

`proposal:sign` 不检查 `reviews` 是否为空、是否有至少一个 approve，也不要求签字人必须是 `pm`。因此“创建提案 → 直接签字 → apply”可以完全跳过评审；任何角色 id 也可以通过 IPC 签字。

**复现（真实 IPC，探针 `_tmp/probe/result.json`）**

1. `proposal:create` 创建“跳过评审”，`fileRel:'site/no-review.md'`、`content:'NO REVIEW'`。
2. 不调用 `proposal:review`，直接 `proposal:sign({decision:'approved'})`。
3. `proposal:apply`。

实测：`{reviews:0, status:"approved", applied:true, file:"NO REVIEW"}`。

4. 另一个提案由 `product` 作者创建，调用 `proposal:sign({decision:'approved', by:'analyst'})`。

实测：`{by:"analyst", decision:"approved", status:"approved"}`。

**影响**

- 提案页的“评审 / PM 签字”看起来是两道闸门，实际只剩“签字”一道；`FEATURE-MATRIX` 的“评审 已完成”不成立。
- 旧协议要求 `propose → show → review → sign → apply`，非作者签字前必须有同哈希 approve，且只有 PM 能签；新实现把审计属性全部丢掉（旧审计 P0-3）。
- 任何能调用 preload 的渲染层脚本都可以用 `by:'analyst'` 伪造 PM 签字。

**建议落点**

`proposal:sign` 增加：`proposal.reviews` 至少一条 `approve`（或按风险要求 N 条、指定评审人集合）、签字人必须是 `pm`（或 `requiredSigners`）、签名绑定 `proposalHash+baseHash+contentHash+ts+nonce`；`proposal:apply` 重新校验签字与评审仍对应当前哈希。UI 在无评审时隐藏“PM 签字”，或在签字弹窗里直接提示“先完成评审”。补 selftest：无评审签字必须被拒；`by:'analyst'` 必须被拒。

---

### S6【高】首屏“＋ 新建项目”和侧栏“恢复项目”是死按钮

**位置**：`src/renderer/index.html:179`（`#btn-empty-new`）、`:146`（`#btn-side-restore`）；`src/renderer/app.js:1956-1963` 只代理 `[data-open-new-project]` / `[data-open-restore]`，这两个 id 没有任何 `addEventListener`

**现象**

空状态大按钮 `#btn-empty-new` 与侧栏 `#btn-side-restore` 都存在于 HTML，但既没有直接绑定，也没有 `data-open-*` 属性，点击无任何反应。其它空状态按钮（`.side-empty` 里的 `data-open-new-project`）是好的，所以问题只在“首屏主 CTA”和“侧栏恢复入口”。

**复现（DOM 探针 `_tmp/probe-dom/result.json` 的 `deadButtons`）**

1. 用空状态 mock preload 加载真实 `index.html`。
2. 点击 `#btn-empty-new`，等 120ms：`#modal-root` 子节点数 `0`。
3. 点击 `#btn-side-restore`，等 120ms：仍为 `0`。
4. 正向对照：点击真正带 `data-open-new-project` 的按钮：`#modal-root` 子节点数 `1`，标题“新建项目”。

实测：`{modalAfterEmptyNew:0, modalAfterSideRestore:0, modalAfterDelegatedClick:1, emptyNewHasDelegationAttr:false}`。

**影响**

- 首次启动、还没有项目时，页面中央最大的“＋ 新建项目”是死的；用户会认为程序坏了。
- 侧栏“恢复项目”也是死的，必须去顶栏“恢复”或菜单里找。
- 这是旧审计 P0-0“UI 契约没有自检锁”的复发：HTML 改了/加了控件，JS 没同步，selftest 仍只检查 `display`，不会发现。

**建议落点**

给两个按钮加 `data-open-new-project` / `data-open-restore`，或在 `bind()` 中直接绑定；在 selftest 增加“空状态主 CTA 点击后出现 `#modal-root .modal`”“侧栏恢复点击后出现恢复弹窗”的断言。更彻底的做法是把旧壳的“选择器 + preload API”逐项断言搬进 selftest。

---

### S7【中】8 阶段流程中的“需求 / 产品评审”永远不会成为当前阶段

**位置**：`src/main.js:61-70`（`STAGES` 含 `intake/requirement/review/owner/dispatch/dev/test/close`）、`src/main.js:520-531`（`deriveStage` 实际只返回 `intake/owner/requirement(仅拒绝)/test/dev/dispatch/close`）

**现象**

`deriveStage()` 没有返回 `'review'` 的分支；`'requirement'` 只在 `owner.status === 'rejected'` 时返回。正常路径是：

- 空项目 → `intake`
- 建第一个任务 → `owner`
- Owner 通过 → `dispatch`
- 有 tester 未完成任务 → `test`
- 有 programmer 未完成任务 → `dev`
- 全部完成 → `close`

`review` 永远是“未到”，`requirement` 只有打回时才短暂出现。

**复现/证据**

- 探针 `ownerGateBypass`：建项目后 `stageAfterTask` 直接是 `owner`，没有经历 `requirement`/`review`。
- 自测 `SELFTEST_FLOW` 的阶段序列也是 `intake → owner → dispatch → close`；没有 `review`。
- 静态：`grep "return 'review'" src/main.js` 无命中；`STAGES` 里的 `review` 只在 UI 的 `flowMarkup()` 里被画出来。

**影响**

- 流程页宣称 8 阶段，常规路径实际只经过 `intake/owner/dispatch/dev/test/close` 6 个；`review` 永远不亮，`requirement` 只在打回时短暂出现，用户无法从流程上判断需求/评审是否完成。
- 旧壳 `computeWorkflow()` 会读需求/评审/提交推导 `requirement/review`；新壳丢掉了这条数据链（旧审计 P1-2/P0-5）。
- Owner 闸门出现在第一个任务之后，但需求/产品评审没有对应阶段，流程语义倒置。

**建议落点**

明确二选一：① 恢复旧 `computeWorkflow` 语义，从 `需求/R-*.md`、评审记录、提交推导 `requirement/review`；② 如果保留本地模型，补显式阶段推进 IPC（如 `stage:advance`）并在任务/提案事件上触发。不要继续画不可达的阶段。

---

### S8【中】同一角色可以重复评审同一提案，评审计数可灌水

**位置**：`src/main.js:1452-1472`（`proposal:review`，`1466` 直接 `push`，没有“同一 role 只能一次”的检查）

**现象**

提案处于 `review` 时，同一个角色可以连续提交多次评审；每次都 push 一条，`proposal.reviews.length` 随之增长，界面也会显示多条同名评审。第一次 approve 不会把状态改成 `approved`，所以第二次仍能提交。

**复现（真实 IPC，探针 `_tmp/probe/result.json` 的 `proposal.duplicateReview`）**

1. 创建提案“重复评审”。
2. `proposal:review({role:'product', verdict:'approve', comment:'第一次'})`。
3. 再调用一次同 role、同 verdict、不同 comment。
4. 读 state：`reviews.length === 2`，两条都是 `product/approve`。

实测：`{count:2, reviews:[{role:"product",comment:"第一次"},{role:"product",comment:"第二次"}]}`。

**影响**

- 评审数量/比例失真；如果后续按“至少 N 条 approve”做闸门，一个角色可以独自凑够。
- 与旧协议“评审人集合内、每人一条、作者不能自审”不一致。
- 界面“评审”按钮在第一次通过后仍然显示，用户可误点。

**建议落点**

`proposal:review` 对 `(proposalId, role)` 做唯一约束：已存在则拒绝或覆盖（并保留历史）；同时把“同角色二次评审”写进错误码。UI 对已评审角色隐藏/禁用选项。selftest 增加“同角色二次评审被拒”。

---

### S9【中】DSH 地址配置只存在内存，重启即回到默认地址

**位置**：`src/main.js:1772-1776`（`dsh:configure` 只 `new DshAdapter` + `installDshCookie`，不写任何配置文件）、`src/main.js:75`（启动时只读 `DSH_WEB_URL` 或硬编码 `127.0.0.1:52711`）

**现象**

用户在“DSH 适配器”弹窗里填写地址、点“保存并探测”，当前进程内有效；关闭应用再打开，地址回到 `DSH_WEB_URL` 或 `http://127.0.0.1:52711`。旧壳有 `config.json` + `config.local.json` 合并、端口发现和持久化。

**复现（两个 Electron 进程，探针 `_tmp/probe-bad/result.json`、`restart-result.json`）**

1. 进程 A 调 `dsh:configure('http://127.0.0.1:43219')`，返回 `ok:true`、`baseUrl:43219`。
2. 退出进程 A。
3. 进程 B 用同一个 `AWB_DATA_DIR`/`AWB_STORE`、不带 `DSH_WEB_URL` 启动，读 `app:state`。

实测：`{baseUrl:"http://127.0.0.1:52711", configured:true, online:false}`。

**影响**

- DSH 端口变化（旧壳端口是随机的）或用户使用非默认地址时，每次启动都要重新填；团队功能首屏离线。
- “保存并探测”按钮的“保存”是误导：没有保存。
- 与旧审计 P1-1 一致；叠加 S2，地址丢失时本地会话记录仍会被当成有效。

**建议落点**

新增 `data/dsh.json`（或 `config.local.json` 等价物），`dsh:configure` 原子写入；启动时读取并作为 `new DshAdapter()` 默认值；`app:state` 回传来源（env/config/default）。补 selftest：configure 后重启仍读到自定义地址。

---

### S10【中】刷新 / 建团队后不重载内嵌 DSH 页面

**位置**：`src/renderer/app.js:1477-1486`（`applyDshViewSrc()` 只在 src 为空/`about:blank`/与 baseUrl 不同时改 src）、`1817-1825`（顶栏刷新只 `refresh()+initDsh()`）、`2028-2041`（`startTeam()` 只 `dshProvision`，不 reload）

**现象**

DSH 面板已经加载了 `baseUrl` 时，点“刷新”不会 `reload` webview；建团队、建项目、恢复项目后也没有 reload。旧壳会在 700ms/1800ms 两次 `webview.reload()`，专门解决“会话投影比页面晚到”。

**复现（DOM 探针 `_tmp/probe-dom/reload-result.json` 的 `refreshDoesNotReloadWebview`）**

1. 用在线状态的 mock preload 加载 UI；DSH shell 显示，`#dsh-view` 的 src 与 baseUrl 都是 `http://127.0.0.1:9`。
2. 给 `#dsh-view` 挂 `did-start-loading` 计数器，等初始加载结束后清零。
3. 点击 `#btn-refresh`，等 1.2s。
4. src 仍为 `http://127.0.0.1:9`，`did-start-loading` 计数为 `0`。

实测：`{beforeRefreshSrc:"http://127.0.0.1:9", afterRefreshSrc:"http://127.0.0.1:9", reloadCountAfterRefresh:0}`。

**影响**

- 建完六角色后，用户在右侧 DSH 面板看不到新会话/新工作区，会误判“建团队失败”。
- 与旧审计 P1-8 完全一致；离线重试按钮只在离线时出现，在线时救不了。
- 叠加 S2/S9，用户很难判断是会话没建、地址不对，还是页面没刷新。

**建议落点**

抽一个 `reloadDshView(delays=[0,700,1800])`；在 `dsh:provision`、`project:create`、`project:adopt`、`team:restore`、`team:open-project` 成功和 `#btn-refresh` 后调用。`applyDshViewSrc` 保持“地址变化才换 src”，reload 单独做。

---

### S11【中】Owner 弹窗可关闭，关闭后本轮不再自动弹出

**位置**：`src/renderer/app.js:1349-1361`（`openOwnerModal()` 的 `openModal({... closable: true})`）、`368-374`（`render()` 把项目 id 加入 `ownerPrompted` 后不再弹；只有 `stage !== 'owner'` 才删除记录）

**现象**

Owner 弹窗右上角有 ×，Esc 也能关。关闭后 `ownerPrompted` 已经记录了该项目 id；只要阶段还停在 `owner`，自动弹窗不会再出现。用户只能自己找到“Owner 评审”按钮（总览/流程/页头各一个）才能重新打开。

**复现（静态 + 可手动）**

1. 建项目 + 任务，进入 `owner` 阶段。
2. 自动弹出的 Owner 弹窗按 Esc 或点 ×。
3. 刷新/切换页签/等待 `render()`：不会再弹；阶段仍是 `owner`，Owner 状态仍 `optional`。
4. 只有点“Owner 评审”按钮才会重开。

**影响**

- 误关一次就把 Owner 闸门藏起来；用户可能一直停在 Owner 阶段不知道下一步。
- 旧壳 `openOwnerModal` 是 `closable:false`，只有“跳过评审/开始评审”两条路；新壳的可关闭是明确的语义反转（旧审计 P1-2）。
- 与 S1 叠加：用户可能转而把任务标完成，直接绕过 Owner 收口。

**建议落点**

`openOwnerModal()` 传 `closable:false`，或在 `onClose` 里把该项目从 `ownerPrompted` 删除并显示一条“Owner 未决”横幅；至少不要在没有决定的情况下永久抑制弹窗。补 selftest：关闭 Owner 弹窗后再次 render 仍应提示/可重开。

---

### S12【中】`team:members` 对不存在的 projectId 静默回退到当前项目

**位置**：`src/main.js:1007-1023`（`if (payload && payload.projectId) project = store.projects.find(...) || null;` 之后没有“显式 id 未找到即报错”，继续走 currentWorkspace/active 回退）

**现象**

显式传入一个不存在的 `projectId` 时，`team:members` 不报“项目不存在”，而是依次回退到 `当前工作区.json`、`store.activeProjectId`、`store.projects[0]`，返回另一个项目的成员清单。

**复现（真实 IPC，探针 `_tmp/probe/result.json` 的 `teamMembers.invalidProjectFallback`）**

1. 选中“闸门项目”，并在其目录写一份 `团队会话.json`（2 个角色）。
2. 调用 `team:members({projectId:'P-not-exist'})`。

实测：`{ok:true, project:"闸门项目", roles:2, error:""}`。

**影响**

- 调用方拿错项目成员，可能把消息发给错误项目的会话；界面“成员”弹窗在项目 id 失效时也会展示别的项目。
- 与上一轮已修复的 `requireProject` 显式 id 拒绝不一致（`task:update` 已不再回退）。
- 旧审计 P2-2“错误码退化”的同类问题。

**建议落点**

`team:members` 开头：如果传了 `payload.projectId` 且找不到，直接返回 `{ok:false, code:'PROJECT_NOT_FOUND'}`；只有**没有**显式 id 时才允许回退到当前工作区/active。补 selftest：显式错误 id 必须失败。

---

### S13【中】没有单实例锁，两个实例可同时写同一状态库与团队状态

**位置**：`src/main.js` 全仓无 `requestSingleInstanceLock`、`second-instance`（`Select-String` 0 命中）；旧壳有（`OLD-CODE-AUDIT.md` P1-9 引 `外壳/main.js:18-26`）

**现象**

应用没有进程级互斥。两个实例可以同时打开同一 `AWB_STORE`/`TEAM_ROOT`，各自 `readStore()` 后在内存修改，再用原子 rename 覆盖；后写者覆盖先写者。`writeStore` 的 `.bak` 只是“写前复制”，不能解决并发丢失。

**复现（静态证明 + 可执行步骤）**

1. 设置同一个 `AWB_STORE`，用两个不同 `--user-data-dir` 启动两个实例（避免 Chromium profile 锁）。
2. 在 A 新建项目 A，在 B 新建项目 B；两边都基于旧快照写回。
3. 读 `workbench.json`：只可能保留其中一个新项目；`.bak` 也只保留某一版；没有任何冲突提示。

**影响**

- 并发建项目/任务/提案、并发 `team:send`、并发团队 ensure 都可能静默覆盖；与旧审计 P1-9 相同。
- 两个实例还会各自建 DSH 会话、各自写团队状态，造成孤儿会话/团队登记错乱。
- 这是数据安全问题，不是“未实现功能”；旧壳本来有这道保护。

**建议落点**

`app.requestSingleInstanceLock()`；拿不到锁直接 `app.quit()`；`second-instance` 时恢复/聚焦已有窗口。若确实要支持多窗口，至少给 `writeStore` 加跨进程文件锁或 storeVersion CAS。补 selftest：第二个实例不能拿到锁。

---

### S14【低】派单 TTL 过期只在 state 投影里隐藏，磁盘仍保留 `pendingAck`

**位置**：`src/main.js:540-544`（`publicProject()` 只改内存对象，不写回）、`src/main.js:1624-1629`（下一次 `team:send` 才真正清理）

**现象**

`pendingAckAt` 超过 10 分钟后，`app:state` 返回的 `pendingAck` 是 `null`，但 `workbench.json` 里仍是旧消息 id。UI 显示“当前没有待回执消息”，磁盘/下一次读取的另一条路径仍能看到锁；只有下一次派单或回执才会落盘清理。

**复现（真实 IPC，探针 `_tmp/probe/result.json` 的 `dispatch.ttlProjectionOnly`）**

1. 用 mock DSH 让 `team:send` 成功，`pendingAck` 写入。
2. 直接改测试 store 的 `pendingAckAt` 为 11 分钟前。
3. `app:state`：该项目的 `pendingAck` 为 `null`。
4. 直接读 `workbench.json`：`pendingAck` 仍是 `M-f26d71b5`。

实测：`{lockBefore:"M-f26d71b5", projected:null, diskAfterExpiry:"M-f26d71b5"}`。

**影响**

- 两个读取路径短暂不一致；诊断/备份/人工编辑时容易误判。
- 若在 TTL 后、下一次写之前崩溃，磁盘仍保留一个“已过期但未清理”的锁；下次启动 `publicProject` 仍会隐藏，但其他消费者（团队工具/旧壳）可能看到。
- 低风险，但属于“展示层修了、真相层没修”。

**建议落点**

在 `statePayload()`/`publicProject()` 检测到过期时用 `writeStore` 落盘清理（注意不要在每个 state 调用都写；可在 `app:state` 里做一次 CAS），或明确在 state 里返回 `pendingAckExpired:true`，不要直接伪装成 null。

---

### S15【低】删除项目记录只删 store；团队登记、磁盘目录、discover 结果仍在

**位置**：`src/main.js:1348-1355`（`project:delete-record` 只 `filter` store、改 `activeProjectId`、`writeStore`；不动目录、不删 `_backup`、不注销团队登记）；`src/preload.js:17` 暴露，`src/renderer/app.js` 无入口

**现象**

调用 `project:delete-record` 后，项目从 `state.projects` 消失，但目录仍在、`团队/状态/项目/<name>/` 仍在、`_backup/commits` 仍在；`project:discover` 会把它当作“未登记目录”重新列出来。界面没有删除入口，只有 preload API 能调。

**复现（真实 IPC，探针 `_tmp/probe/result.json` 的 `deleteRecord.leftovers`）**

1. 创建“同名项目”（已在团队登记）。
2. 调 `project:delete-record(P1)`。
3. 读 state：记录不在；检查磁盘目录、团队登记目录：都在。
4. 调 `project:discover`：该目录重新出现在恢复列表。

实测：`{stillInStore:false, diskExists:true, teamRegistrationExists:true, discoverListsIt:true}`。

**影响**

- “删除”是半删除：用户以为删了，恢复列表又出现；团队看板/索引仍引用它。
- 若将来补 UI 而不改语义，容易造成“删了又回来”的困惑；也可能误删团队登记后无法恢复。
- 旧审计 P1-9 的同一问题；当前至少应明确它是“移除登记”，而不是“删除项目”。

**建议落点**

把 IPC 改名为 `project:remove-record`，UI 二次确认文案明确“只移除登记，不删除磁盘目录/团队状态”；若需要彻底删除，提供独立 `project:delete-files`（默认不勾选，且先校验路径在项目根内）。短期不要在 preload 暴露无 UI 的“删除”。

---

## 四、必须检查项逐项结果

| 要求 | 结果 | 证据 |
|---|---|---|
| 1. 旧 vs 新功能差异 | 已逐项对照 `OLD-CODE-AUDIT.md`；P0-2/P0-4/P1-3/S1-S4 多数已修，P0-1/P0-3/P1-1/P1-6/P1-8/P1-9 仍存在 | 见 §二；selftest + 探针 |
| 2. 数据只落 D 盘 | 代码与运行均通过：`main.js:11-17` 把 `userData/sessionData/temp` 指到 `LOCAL_DATA`；默认为仓库 `data/`（D）；自测 store/team 在 `.selftest-data`（D）；本轮所有命令 `TEMP/TMP/npm cache/user-data-dir` 都在 `_tmp`（D） | 见 §五 |
| 3. 项目创建/恢复/删除/重名 | 创建、恢复（按名 dry-run）、已有目录登记、重复路径拒绝均通过；**同名不同路径未拒绝**（S4），**删除只删记录**（S15） | `_tmp/probe/result.json`、`_tmp/probe-restore/result.json` |
| 4. 任务/看板/流程/Owner | 任务四列、看板、Owner 决策、阶段推进基础可用；**Owner 完成即收口**（S1）、**review/requirement 不可达**（S7）、**Owner 可关闭**（S11） | 探针 + 静态 |
| 5. 提案 review/sign/apply/rollback 及冲突 | baseHash/CAS、路径别名、备份缺失/损坏、回滚冲突均通过 selftest；**无评审可签**、**非 PM 可签**（S5）、**重复评审**（S8） | `SELFTEST_COMPAT`、探针 |
| 6. 派单/回执/唤醒失败/TTL/撤销 | 无会话不锁、唤醒失败释放、TTL 自动释放、撤销、回执都通过；TTL 仅投影（S14） | `SELFTEST_COMPAT`、探针 |
| 7. 团队工具 init/ensure/board/launch dry-run | 全通过：`SELFTEST_TEAM_TEMP {"init":true,"ensure":true,"plan":1,"listed":true}`；`SELFTEST_FLOW teamEnsureOk/launchDryOk/boardOk/teamIndex/teamRules` 均 true；`launchDrySessions:0` | selftest 日志 |
| 8. DSH 在线/离线/会话状态 | 在线：真实 DSH `161` 个会话；离线：`DSH_OFFLINE`；错误归一 `TIMEOUT/PROJECT_DIR_MISSING/TOOL_MISSING`；**配置不持久**（S9）、**幽灵会话**（S2）、**不重载**（S10） | selftest 日志、探针 |

---

## 五、数据只落 D 盘核查

### 5.1 代码路径

- `src/main.js:11-17`：
  - `LOCAL_DATA = AWB_DATA_DIR || <repo>/data`；
  - `app.setPath('userData', LOCAL_DATA/userdata)`；
  - `app.setPath('sessionData', LOCAL_DATA/userdata)`；
  - `app.setPath('temp', LOCAL_DATA/tmp)`；
  - 启动时创建 `LOCAL_DATA`、`LOCAL_DATA/tmp`。
- `src/main.js:19-22`：`--selftest` 强制 `AWB_STORE=<repo>/.selftest-data/workbench.json`、`TEAM_ROOT=<repo>/.selftest-data/团队`。
- `src/main.js:2301`：selftest 根目录 `.selftest-data`，结束 `cleanupRoot()` 删除。
- `src/main.js:1814`：store 自测的 `mkdtempSync` 也在 `.selftest-data` 下，不使用 `os.tmpdir()`。
- `src/main.js:817`：文件树过滤 `.awb-tmp-`；没有把临时文件写到 `%TEMP%`。
- `src/dsh-adapter.js:18-20`：`dshHome()` 默认读 `os.homedir()/.dsh`（只读凭据），不写 C。

### 5.2 本轮实际运行

所有 Electron 进程都设置：

```powershell
$env:TEMP  = D:\deepseek\agile-workbench\_tmp\temp
$env:TMP   = D:\deepseek\agile-workbench\_tmp\temp
$env:npm_config_cache = D:\deepseek\agile-workbench\_tmp\npm-cache
$env:AWB_DATA_DIR = D:\deepseek\agile-workbench\_tmp\<probe>\data
$env:AWB_STORE    = D:\deepseek\agile-workbench\_tmp\<probe>\data\workbench.json
$env:TEAM_ROOT    = D:\deepseek\agile-workbench\_tmp\<probe>\team
```

- selftest：`AWB_DATA_DIR=_tmp/data-selftest`，`--user-data-dir=_tmp/userdata-selftest`；截图写仓库根（D）后已还原。
- 四个探针：`_tmp/probe`、`_tmp/probe-bad`、`_tmp/probe-dom`、`_tmp/probe-restore`，全部在 D。
- 未执行任何把项目/状态/临时文件写到 `C:\Users\...\AppData\Local\Temp` 的命令；`npm run check` 只做 `node --check`，且 npm cache 指向 `_tmp`。

### 5.3 C 盘残留说明

`C:\Users\Admin\AppData\Roaming\敏捷工作台` 存在一份 Chromium profile，最新时间戳为 `2026-11-05 02:13–02:33`，**早于本轮（04:06 起）**，本轮没有更新它；当前代码在 require 阶段就把 `userData` 指到 D，理论上不会再写该目录。若验收要求“机器上零 C 残留”，这是旧版本留下的历史目录，建议单独清理并在打包后复验，不应算作本轮运行写入。

---

## 六、本轮运行与正向证据

### 6.1 `npm run check`

退出码 0，5 个文件全部通过 `node --check`（含 `src/team-tools.js`）。

### 6.2 Electron selftest

命令（清空继承的 `ELECTRON_RUN_AS_NODE`）：

```powershell
$env:ELECTRON_RUN_AS_NODE = $null
electron . --selftest --user-data-dir=D:\deepseek\agile-workbench\_tmp\userdata-selftest
```

结果：`SELFTEST_OK`，退出码 0。关键输出：

- `SELFTEST_STORE {"checks":20,"failed":0}`
- `SELFTEST_STATE {"projects":0,"roles":6,"stages":8,"hasTeamApi":true,"teamToolExists":true}`
- `SELFTEST_DSH {"online":true,"sessions":161,"baseUrl":"http://127.0.0.1:52711"}`
- `SELFTEST_FLOW`：`stageAfterCreate:intake`、`stageAfterTask:owner`、`stageAfterApprove:dispatch`、`stageAfterDone:close`、`proposal:approved`、`applied:true`、`rolled:false`、`reviews:1`、`teamEnsureOk:true`、`launchDryPlan:1`、`launchDrySessions:0`、`boardOk:true`、`teamIndex:true`、`teamRules:true`
- `SELFTEST_TEAM_TEMP {"init":true,"ensure":true,"name":"中文 路径·验收","launch":true,"plan":1,"listed":true}`
- `SELFTEST_TEAM_OFFLINE {"ok":false,"code":"DSH_OFFLINE"}`
- `SELFTEST_TEAM_ERRORS {"timeout":true,"timeoutCode":"TIMEOUT","missing":"PROJECT_DIR_MISSING","noTools":"TOOL_MISSING"}`
- `SELFTEST_COMPAT {"checks":45,"failed":0}`，其中 `dupBlocked:true`、`legacyUnknownBlocked:true`、`legacyGuard:true`、`provisionCreated:6/provisionSessions:6`、`provisionAgain:0`、`wakeOk:false/lock:null`、`cancelOk:true`
- `SELFTEST_TEAM_CLEANUP {"removed":["兼容工作区","并发项目","离线项目","验证项目"]}`

### 6.3 探针覆盖

| 探针 | 覆盖 | 结果文件 |
|---|---|---|
| `_tmp/probe` | 同名项目、Owner 绕过、无评审签字、重复评审、非 PM 签字、幽灵会话、members 回退、TTL 投影、删除残留 | `_tmp/probe/result.json` |
| `_tmp/probe-bad` | 坏团队状态下 `project:create`、`dsh:configure` 内存态 | `_tmp/probe-bad/result.json`；重启对照 `restart-result.json` |
| `_tmp/probe-dom` | 首屏/侧栏死按钮、刷新不重载 webview | `_tmp/probe-dom/result.json`、`reload-result.json` |
| `_tmp/probe-restore` | 已有目录 adopt 不覆盖、按名 restore dry-run、重复路径拒绝 | `_tmp/probe-restore/result.json` |

### 6.4 本轮其它正向确认

- 状态库原子写、`.bak`、BOM、截断恢复、无备份阻止写入：selftest 20/20。
- 提案 baseHash/CAS、`./`/大小写别名唯一 applied、备份缺失/损坏、回滚后改文件拦截：selftest + `SELFTEST_COMPAT`。
- 派单：无会话不锁、第二次可发、唤醒失败释放、TTL 自动释放、撤销、回执清锁：`SELFTEST_COMPAT`。
- 恢复：`project:adopt` 对已有 `项目信息.md`/`README.md` 不覆盖，新增角色目录；重复同路径返回“这个目录已经登记”；`team:restore` dry-run 返回 `plan:1`。
- 团队工具：init/ensure/board/launch dry-run 均通过；中文/空格路径通过；离线/超时/目录缺失/工具缺失错误码归一。
- 文件：`files:list` 正常项目 37 条；`files:open` 越界/目录缺失有错误；文件树 UI 有展开/收起/刷新。
- DSH：真实 `session/list` 161 个会话（只读，无 prompt）；离线 `DSH_OFFLINE`。

---

## 七、只读边界与残留

- 本文件之外，本轮只在 `_tmp/` 下新增测试脚本、日志、探针数据和 Electron profile；`_tmp` 是任务允许的测试临时目录。
- `src/`、`package.json`、`团队/`、旧仓库未改：验收前后 `src/main.js`（03:55:24）、`src/renderer/app.js`（04:05:06）、`package.json`（02:56:24）的 mtime 与字节数未变。
- `团队/状态` 四个文件（`事件.jsonl`、`团队.json`、`看板.json`、`看板.md`）SHA-256 验收前后一致；`selftest.png`/`selftest-flow.png` 已按运行前哈希还原（`19BF87…` / `3E37D8…`）。
- `.selftest-data` 自测结束后已删除；仓库 `data/` 本轮未写入（所有测试 profile/状态都指向 `_tmp`）。
- 两张截图的 mtime 会因复制还原保留原值；内容哈希与验收前一致。

---

## 八、建议修复顺序

1. **S1 + S11**（Owner 状态机/不可关闭）——一处 `deriveStage` 调整 + 弹窗 `closable:false`，影响最大、改动最小。
2. **S2 + S3**（会话真实性、团队失败可见）——先让“建团队/建项目”不再假成功。
3. **S5 + S8**（提案评审/签字闸门）——恢复 `review → sign → apply` 的最小协议，至少挡住无评审签字、同角色重复评审。
4. **S4**（同名项目）——在写库入口做唯一性/冲突码，避免后续按名操作歧义。
5. **S6 + S10**（UI 契约与 DSH 刷新）——首屏可用性与“建完看不到”的误判。
6. **S9 + S13**（DSH 配置持久化、单实例）——运行环境稳定性与并发数据安全。
7. **S7**（流程可达性）——需要产品决策：恢复旧 `computeWorkflow` 还是删掉不可达阶段。
8. **S12 + S14 + S15**（API 严格性、TTL 落盘、删除语义）——低风险收尾。

---

**一句话结论**：数据可靠性底座（原子写、备份、提案 CAS、派单 TTL）已经比上一轮稳，但“状态机真实性”（Owner/流程/会话）、“协议闸门”（评审/签字）和“界面契约”（死按钮/配置/刷新）仍有 6 个高优先级缺口；当前版本可以演示主流程，但不应按“所有功能已完成”验收发布。
