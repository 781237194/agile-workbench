# 敏捷工作台 v0.1 · 第四轮只读验收（DSH 壳模型）

- 验收对象：`D:\deepseek\agile-workbench`（v0.1.0；Electron 33.4.11 / Node 24.22.1）
- 代码基线（验收前后 SHA-256 前 16 位、字节数、mtime 均未变）：
  - `src/main.js` 189,367 B · 2026-11-05 04:53:48 · `716C709A1290FA9A`
  - `src/renderer/app.js` 120,780 B · 04:55:22 · `609E48F694005A36`
  - `src/renderer/index.html` 26,360 B · 04:29:08 · `5268831D601A5EFC`
  - `src/renderer/style.css` 70,235 B · 04:44:56 · `E2C6836CF387790E`
  - `src/team-tools.js` 51,318 B · 04:29:04 · `11D631877FC5BD3C`
  - `src/dsh-adapter.js` 8,715 B · 04:29:10 · `3C1A2BE194A1832D`
  - `package.json` 798 B · 02:56:24 · `E14268B4B6B76214`
- 验收时间：2026-11-05 04:56–05:10（Asia/Shanghai）
- 验收方式：通读 `src/`、`团队/工具/`、`docs/OLD-CODE-AUDIT.md`、`docs/QA-ROUND3.md`；`npm run check`；仓库自带 Electron `--selftest`；一个仓库内探针（真实 IPC + 真实渲染层 + 本地 mock DSH，不含真实 DSH 写入）；静态 DOM / 调用图 / 数据文件核对
- 只读边界：未修改 `src/`、`package.json`、`团队/`、`data/`、旧仓库；除本文件外只新增 `_tmp/qa4/` 下的测试脚本、日志、mock 数据与 Electron profile；`selftest.png` / `selftest-flow.png` 运行前已备份、运行后按原哈希还原
- 结论：**DSH 作为主画面这一点已经成立**，项目 → workspace → 六角色会话的映射也有真实的自测证据；但“空会话可修复、旧看板与工作台同一真相、回执来自六个角色会话、项目/团队/工作区同名同体、看到的状态与 DSH 一致”这五件事仍然不成立。本轮确认 **4 个高、9 个中、3 个低，共 16 个可复现或可静态证明的问题**。

---

## 一、结论速览

| # | 级别 | 问题 | 主要证据 |
|---|---|---|---|
| S1 | 高 | “建团队”遇到空白会话（seed 失败）后永不修复，重复点击只报“会话已存在” | 探针 `blank.firstProvision` / `blank.retryProvision` |
| S2 | 高 | 旧版看板/流程与工作台数据脱节：工作台任务/提案只写 `workbench.json`，旧看板对它们恒 0，且看板不在 DSH 上浮 | 探针 `board.vsWorkbench`、`_tmp/qa4/probe/team/状态/看板.json`、`main.js:1885` |
| S3 | 高 | 回执/启动令牌由壳进程代跑：事件里的 `sessionId` 是壳环境，不是角色 DSH 会话；UI 可代人回执，名册还被最后一个项目覆盖 | 探针 `protocol.evidence`；`回执.jsonl` 无 sessionId；`团队.json` 成员是另一个项目的会话 |
| S4 | 高 | 删除记录留下团队登记/目录；同名重建被静默哈希成 `团队名-xxxxxx`，项目名/团队名/workspace 名不一致，旧目录再也登记不回来 | 探针 `deleteThenRecreate` |
| S5 | 中 | 额外会话检测只看 `团队·` 前缀：工作区 7 条会话，`extras` 仍报 0 | 探针 `extraSession` |
| S6 | 中 | 侧栏/顶栏“6/6 会话就绪”不核实 DSH：DSH 会话全删后仍 6/6、6 个绿点，只有角色行变“DSH 中找不到” | 探针 `render.countersBeforeLive/AfterLive` |
| S7 | 中 | 界面显示的“DSH 标题”是 `项目 · 角色`，实际会话标题是 `团队·角色`；按标题定位会话的分支永远匹配不上 | 探针 `render.titleMismatch`；`app.js:124` / `main.js:98` / `launch.mjs:62` |
| S8 | 中 | 刷新/建团队后不重载内嵌 DSH 页面，新建的六个会话不会出现在 DSH 左侧；只有手动“重载 DSH”/离线重试会 reload | `app.js:1793-1811`、`2334-2343`、`2601-2617`；旧审计 P1-8 |
| S9 | 中 | `team:workspaces` 在工作台界面仍是死接口：切换工作区只列本地 `state.projects`，DSH/团队已有工作区不可见、不可切 | `app.js` 无调用；`main.js:1460`、`preload.js:24`；旧审计 P0-1 |
| S10 | 中 | 降级到本地的派单/回执不标来源：`source=local` 的消息与旧协议消息在界面上无区别，toast 仍说“已发送并唤醒角色” | `main.js:2316-2333`；`app.js:2465`、`620-641` |
| S11 | 中 | DSH 地址硬编码 `52711` 且 `dsh:configure` 不落盘；重启回到默认地址 | 探针 `config.static`；`main.js:410`、`2568-2572`；`index.html:170` |
| S12 | 中 | Owner 弹窗可关闭且关掉后本轮不再自动弹；“产品评审”阶段在 `deriveStage` 里永远不可达 | `app.js:1677`、`431-436`；`main.js:957-969`；旧审计 P1-2/S11 |
| S13 | 中 | 六角色消息被收窄成“只能 PM 发给另外五个”：不能发给 PM，也不能角色之间互发；旧协议支持任意 active 角色 from/to | `main.js:2220-2221`；`app.js:1013`；`ops.mjs:339-412` |
| S14 | 低 | 派单 TTL 过期只在 `publicProject` 投影里清 `pendingAck`，磁盘仍保留 | `main.js:977-981`；旧审计 P3-1/S14 |
| S15 | 低 | 没有单实例锁；两个实例可同时写 `workbench.json` 与团队状态 | `src/main.js` grep `requestSingleInstanceLock` 0 命中；旧审计 P1-9/S13 |
| S16 | 低 | 标称“只读核对”的 `dsh:team-status` 实际调用 `workspace/create`；工作区丢失后仍靠 cwd 把 6 个会话判成 `inWorkspace` | 探针 `teamStatus.writeOnRead` |

计数：高 ×4、中 ×9、低 ×3。

> 来源说明：S8/S9/S11/S12/S14/S15 是上一轮已报、本轮复核仍存在（S9 在上一轮是“P0-1 未恢复”的非编号项）；S2/S3/S4 是旧审计同类问题的更具体证据；S1/S5/S6/S7/S10/S13/S16 是本轮新增或本轮首次单列。

---

## 二、DSH 壳模型逐项判定（对应任务里的 8 个重点）

| # | 要求 | 判定 | 依据 |
|---|---|---|---|
| 1 | 主界面是否仍被独立项目页占据 | **PASS** | `index.html:148-171` 的 `main#dsh-shell > .stage-body` 只以 `<webview id="dsh-view">` 为主画面；`#project-drawer` / `#team-drawer` 默认 `hidden`；`app.js:2656-2674` 启动调用 `showDshView(true)`；`setDrawer` 初始为 `null`。项目/团队是绝对定位浮层（`style.css:774-796`），不是场景切换。**保留意见**：抽屉宽 `min(790px, calc(100% - 52px))`，打开时 DSH 只剩很窄一条，但底座仍是 DSH。 |
| 2 | 项目与 workspace 是否真正一一对应 | **PARTIAL** | 结构上成立：`selftestMapping` 34/34，`diffWs:true`、`selectWs/selectCurrentWs` 一致、切 A/B 再切回 `backWs` 一致；`workspace.json` / `当前工作区.json` / 状态库三处有写入。但 S4（删除残留/哈希名）、S9（UI 不列团队/DSH 工作区）、S16（读接口重建 workspace）使“按名字/按 UI 看”不一一对应。 |
| 3 | 是否只有 6 个角色会话、是否有空/重复/额外会话 | **PARTIAL** | 首建 `created:6`、重复建 `created:0`、`teamTitled:6`、`workspaceSessions:6`（`SELFTEST_MAPPING`）。但 S1（空会话不修复）、S5（额外会话漏检 7→0）、S6（6/6 假象）分别覆盖空/额外/显示三类。 |
| 4 | 消息/回执是否走旧团队协议，是否仍只写本地 `workbench.json` | **PARTIAL** | 正向：`send.source='team'`、`ackSource='team'`、`teamMessageId` 与消息 id 相同、旧 `派单锁.json` 会清、`回执.jsonl` 有记录（探针 `model.dispatch`、`SELFTEST_MAPPING`）。反向：S3（回执身份是壳，不是角色会话；名册跨项目）、S10（本地降级不标注）、S13（只能 PM→5）、S2（任务/提案仍只写本地）。 |
| 5 | 切项目/切 workspace/恢复是否一致 | **PARTIAL** | 正向：`project:select` 会写 `activeProjectId`、重绑 workspace、写旧协议 `当前工作区.json`，切 A→B→A 的 workspaceId 一致（`SELFTEST_MAPPING`）。反向：S4（删记录后同名重建的哈希名）、S7（DSH 标题不匹配导致定位失败）、S8（不 reload）、S11（地址不持久）、S16（工作区丢失靠 cwd 兜底）。 |
| 6 | 旧版团队看板/流程是否浮在 DSH 上 | **FAIL（看板）/PARTIAL（流程）** | 旧看板由 `team:board` / `team:board-old` 生成后 `shell.openPath` 打开系统浏览器（`main.js:1885`、`1942`），没有 BrowserWindow/置顶/折叠/项目切换（旧审计 P1-6）。工作台自己的“流程”是右下角 `#flow-panel` 浮层（`app.js:959-969`），但数据是本地 `deriveStage`，与旧看板两套真相。见 S2、S12。 |
| 7 | 是否有自造 UI/功能偏离旧版 | **YES（需区分“壳的自造”与“旧功能丢失”）** | 自造：六页签项目抽屉（总览/看板/流程/提案/文件/角色）、Owner 弹窗、右下角流程浮层、新手引导、主题、CPU/GPU/MEM 指标、工作区切换弹层。丢失/偏离：旧看板浮窗（S2）、旧协作台/团队状态面板、旧运维层（余额/插件/技能/MCP/体检/更新/最近/网页 AI/盘容量，见 `OLD-CODE-AUDIT.md` P1-7）、旧 `team:workspaces` 三路合并清单（S9）。 |
| 8 | 数据只写 D 盘、不写 C 盘 | **PASS（应用自身）** | `main.js:15-26` 在 require 阶段把 `userData/sessionData/temp` 全部指到仓库 `data/`（D）；`--selftest` 指到 `AWB_SELFTEST_ROOT`；探针/自测实际 profile 都在 `_tmp/qa4`（D）。C 盘 `%APPDATA%\敏捷工作台` 最新写入仍为 02:33:40，早于本轮（04:56 起）；C Temp 只发现两个 0 字节 `.tmp`，时间点与本会话命令工具的调用一致，不能归因于工作台。见 §五。 |

---

## 三、问题清单（按严重级别）

### S1【高】“建团队”遇到空白会话（seed 失败）后永不修复，重复点击只报“会话已存在”

**位置**：`src/main.js:515-624`（`provisionTeamSessions`），关键在 `536` 计算缺失角色、`539-563` 的“齐了就提前返回”、`566-581` 的 launch、`583-591` 的落库；`团队/工具/launch.mjs:148-168` 的 seed 循环；`src/renderer/app.js:2601-2617` 的 `startTeam`。

**现象**

旧版建团队会给空白会话发一句“已就位”，让六角色在 DSH 左侧真正显示（`launch.mjs:48-50`、`148-168`）。新壳第一次建团队也会 seed；但只要某个角色的 seed 失败一次，第二次点“建团队”时 `inspectProjectSessions` 仍把这个“存在、且在本工作区”的空白会话算作 `reused`，`rosterStatus` 也只检查 `sessionId` 是否存在，于是 `missingRoles.size === 0`，函数在 `539` 直接返回 `{reused:true}`，根本不会再进 seed。

**复现（探针 `_tmp/qa4/probe/result.json` 的 `blank.firstProvision` / `blank.retryProvision`）**

1. mock DSH 对 `团队·测试人员` 的第一次 `session/prompt` 返回失败。
2. `dsh:provision` 建“空会话项目”：`created:6`，`seeds[5] = {role:"tester", ok:false, why:"RPC session/prompt 失败：seed prompt failed once for tester"}`，`dsh:team-status` 的 `tester.blank=true`。
3. 再点一次 `dsh:provision`：`created:0`、`reused:true`、`seeds:0`；`dsh:team-status` 的 `tester.blank` 仍然是 `true`。

实测：`{"first":{"created":6,"testerBlank":true},"retry":{"created":0,"reused":true,"seeds":0,"testerBlank":true}}`。

**影响**

- 界面显示 `6/6`，但 DSH 左侧少一个角色；用户以为建团队成功，实际该角色没有第一轮对话，DSH 默认不显示空白会话。
- `startTeam` 只看 `created.length`：第二次 `created=0`，toast 直接说“DSH 角色会话已存在”，把 seed 失败彻底掩盖。
- 旧版“空会话可见化”在“重试/补建”路径上失效；这正好是 S3（会话真实性）之外的另一条“有会话但不可用”。

**建议落点**

- `provisionTeamSessions` 的提前返回条件必须加上“六个角色都不是 blank”，或者对 `inspection` 里 `blank:true` 的角色补一次 seed；不能只数 `sessionId`。
- 把 `seedResults` 的失败并入 `warnings`/`ok`，让 `startTeam` 显示“6 个会话已存在，但 1 个仍未显示，已重试/失败”。
- 补一条 selftest：seed 失败后第二次 provision 必须触发补 seed，且 `blank` 变 `false`。

---

### S2【高】旧版看板/流程与工作台数据脱节：任务/提案只写 `workbench.json`，旧看板恒 0，且看板不在 DSH 上浮

**位置**：`src/main.js:1877-1896`（`team:board`，`1885` 的 `shell.openPath`）、`1936-1942`（`team:board-old`）、`1953-1966`（`task:create`）、`1991-2046`（`proposal:create`）；`src/renderer/app.js:2304-2309`（`openTeamBoardOld`）。

**现象**

- 任务、提案、提交、回执的“真相”仍分两套：`task:create` 只写 `workbench.json` 的 `project.tasks`；`proposal:create/review/sign/apply` 只写 `project.proposals`；`team:board` 却调 `teamTools.generateBoard`，从 `团队/状态` 的 `任务/*.json`、`提案/*.json`、`提交/*.json` 生成。工作台建的任务/提案永远不会出现在旧看板上。
- 提案链本身也仍是本地第二套实现：旧协议的多文件提案被直接拒绝（`main.js:2003`），没有 `show`/read receipt、风险分级、评审集合、授权，签名只存 `{by,decision,note}` 不绑哈希（`main.js:2089`）；旧 `team.mjs board` 的 `proposals` 因此恒为空。
- 旧版看板是置顶浮窗（`OLD-CODE-AUDIT.md` P1-6：无边框、`alwaysOnTop('floating')`、折叠/缩放/项目切换）；新壳只有 `shell.openPath(看板.html)`，实际是系统浏览器标签页，不是“浮在 DSH 上”。

**复现（探针 `board.vsWorkbench` + 生成物）**

1. 在“模型项目”里 `task:create` 一条 `T-b9117b4e`，`proposal:create` 一条 `P-1ce8acb0`。
2. `team:board({open:false})`：`boardSummary` 为 `{requirements:0,tasks:0,proposals:0,receipts:1}`。
3. 直接读 `_tmp/qa4/probe/team/状态/看板.json`：`tasks: []`、`proposals: []`、`commits: []`，`files` 有 25 条项目文件，`receipts` 有 1 条。
4. 注意：`SELFTEST_FLOW` 的 `boardSummary` 0 是在建任务/提案**之前**生成的，不能单独作为本问题证据；本问题是探针在该项目已有 `T-b9117b4e`/`P-1ce8acb0` 之后仍生成空板。

**影响**

- 用户点“旧版看板”，看到的是空板或上一轮旧数据；`FEATURE-MATRIX.md` 的“看板 已完成”不成立。
- 工作台流程页/阶段高亮（本地 `deriveStage`）与旧 `team.mjs board`/`verify` 两套结论；PM 在 CLI/旧协议里看不到工作台的任务和提案。
- “旧版团队看板浮在 DSH 上”这一条没有恢复：现在只是系统浏览器的一个 HTML 标签页，且会被浏览器拦截本地文件打开。

**建议落点**

- 二选一并写清楚：① `workbench.json` 只做 UI 缓存，任务/提案/回执全部落到 `团队/状态`；② 保留本地模型，但 `task:*`、`proposal:*` 同步写团队状态，并让 `team:board` 从工作台数据生成。
- 恢复旧看板浮窗（BrowserWindow + `alwaysOnTop('floating')` + 折叠/项目切换），或至少在新壳内嵌 `看板.html`，保留项目切换。
- 补 selftest：建 1 个任务后 `team:board` 的 `summary.tasks` 必须为 1。

---

### S3【高】回执/启动令牌由壳进程代跑：事件里的 `sessionId` 不是角色会话；UI 可代人回执；名册被最后一个项目覆盖

**位置**：`src/team-tools.js:875-908`（`bootToken`，`891` 调 `team.mjs boot` 且不带 `--session`）、`988-1028`（`ackDispatch`，注释写明“以派单目标角色身份走 team.mjs ack”）、`930-985`（`sendDispatch`，固定 `from:'pm'`）；`团队/工具/lib/ops.mjs:27-29`（`sessionOf` 回退到 `process.env.DSH_SESSION_ID` 或 `session-unknown`）；`src/main.js:2396-2454`（`team:ack` 接收 UI 手填 note）；`src/renderer/app.js:1032-1053`（回执弹窗只要求一段文字）。

**现象**

- 旧协议要求角色自己的会话先 `boot` 拿令牌，再 `send`/`ack`；“没有回执=没发生”依赖这条身份链。
- 新壳在主进程里替角色 `boot`，且不传 `--session`；`sessionOf` 于是把**壳进程的环境变量** `DSH_SESSION_ID` 当成会话 id。若从桌面快捷方式启动，通常没有这个环境变量，就会写成 `session-unknown`。
- `team:ack` 由操作者在 UI 里填一段文字，主进程用目标角色的 boot 令牌执行 `ack`。它不校验这条回执是否来自该角色的 DSH 会话。
- `团队/状态/团队.json` 是全局单例；`launch.mjs:229-237` 每次建团队都把六角色 `sessionId` 改成当前项目的。于是 A 项目的旧看板/名册会看到 B 项目的会话 id。

**复现（探针 `protocol.evidence`）**

- `team:send` → `ack`：`source:"team"`、`ackSource:"team"`、`ackId:"A-20261105-050510-278a6f"`、`ackNote:"壳代填回执"`。
- `事件.jsonl` 中该项目的 `boot` / `ack` 事件：`role:"analyst"`、`sessionId:"d0a78841-6caa-4541-a9e3-38bb7aca68c2"`。这个 id 是验收 shell 的环境变量 `DSH_SESSION_ID`，不是 mock 里 analyst 的 `mock-s-3`。
- 同一份 `团队.json` 的 `rosterAnalyst.sessionId = "mock-s-3"`；建完“空会话项目”后变成 `mock-s-8..13`，而模型项目自己的映射仍是 `mock-s-1..6`。
- `回执.jsonl` 的 analyst 记录有 `{id,msgId,from,to,project,note,log,ts}`，没有 `sessionId`；同一次 ack 还写了两行（一行基础、一行 `update:true`）。

**影响**

- “6 会话之间消息/回执严格照旧版”不成立：消息是壳以 PM 名义发的，回执是壳以 analyst 名义写的；六个 DSH 会话本身没有参与 boot/ack。
- 回执无法证明是哪个角色、哪个会话回的；操作者可以在 UI 里替任何未回执的角色写“已收到/已完成”。
- 名册跨项目串：旧看板/CLI 看到的 sessionId 可能属于另一个项目；出问题无法按会话追责。

**建议落点**

- 去掉主进程的 `bootToken` 代跑：把“先 boot、再 inbox/read/ack”的指令发给对应 DSH 会话（复用 `ops.mjs` 的唤醒文案），让角色自己回执。
- 如果保留 UI 的“记录回执”按钮，只能记成“人工确认（非旧协议回执）”，单独字段/单独展示，不能写成 `ack` 事件，也不能清旧协议锁。
- `boot` 必须带真实 `sessionId`；`team:ack` 必须校验 `sessionId` 属于该 role + 该项目，并与 `团队会话.json` 一致。
- 每个项目应有自己的名册视图（或至少按项目过滤），不能用一个全局 `团队.json` 覆盖。

---

### S4【高】删除记录留下团队登记/目录；同名重建被静默哈希，项目名/团队名/workspace 名不一致，旧目录再也登记不回来

**位置**：`src/main.js:1944-1952`（`project:delete-record` 只删 store）、`1045-1083`（`createProject`，`1055` 只检查 store 里的同名）、`1404-1419`（`project:adopt` 用 `path.basename` 做名字并拒绝同名）、`src/team-tools.js:423-438`（`resolveProjectName` 发现同名登记在另一个目录就用 sha1 后缀）。

**现象**

- `project:delete-record` 只从 `workbench.json` 摘掉记录；团队登记 `团队/状态/项目/<slug>/项目.json`、项目目录、`workspace.json`、六角色会话都还在。
- 之后新建同名项目（不同 root）：`createProject` 只查 store，通过；`syncTeamProject` → `resolveProjectName` 发现旧登记同名不同路径，返回 `重名项目-bbdb4b`；`project.teamName`、`workspace.name` 都变成哈希名，而 `project.name` 还是 `重名项目`。
- 旧目录再 `project:adopt` 会被“已有同名项目”拒绝，变成“磁盘有、团队有、壳里没有”的三态。

**复现（探针 `deleteThenRecreate`）**

1. 建“重名项目”（root `r1`）：`teamName:"重名项目"`。
2. `project:delete-record`。
3. 建“重名项目”（root `r2`）：`name:"重名项目"`、`teamName:"重名项目-bbdb4b"`、`workspaceName:"重名项目-bbdb4b"`、`workspaceId:"mock-ws-4"`。
4. `project:adopt({path: r1/重名项目})` → `"已有同名项目：重名项目；请先重命名或选择其他目录"`。
5. 团队登记同时存在 `重名项目`（r1）与 `重名项目-bbdb4b`（r2）。

**影响**

- 项目名（界面）≠ 团队名（旧看板/CLI）≠ workspace 名（DSH 左侧）；用户按名字找不到/对不上。
- 旧项目目录与六个会话被“留在”团队里，但工作台无法再登记；后续 `team:workspaces` 会把它列为 `inStore:false`。
- 这正是“项目与 workspace 一一对应”在名字层面的破口；即使路径映射仍 1:1，用户看到的不是同一个名字。

**建议落点**

- `project:delete-record` 要么连团队登记一起删（二次确认“只移除登记/同时移除团队登记”），要么拒绝删除并提示先处理团队登记。
- `createProject` / `project:adopt` 写入前同时检查 store 与团队登记；同名不同路径返回明确的 `PROJECT_NAME_CONFLICT`，不要静默哈希。
- 旧记录迁移时把 `teamName` 固定下来，显示/操作统一用 `teamName`；若必须哈希，UI 明确显示“项目名/团队名”。

---

### S5【中】额外会话检测只看 `团队·` 前缀：工作区 7 条会话，`extras` 仍报 0

**位置**：`src/main.js:2507-2517`（`extras` 过滤 `title.startsWith(SESSION_TITLE_PREFIX)`，`96` 的 `SESSION_TITLE_PREFIX='团队·'`）；`dsh:team-status` 整体 `2470-2526`。

**现象**

`dsh:team-status` 只把“标题以 `团队·` 开头、在当前 workspace、且不在六个映射里”的会话算作 extras。无标题会话、用户手动建的“临时会话”、重命名失败留下的会话都不会被报告。

**复现（探针 `extraSession`）**

1. 模型项目已有 6 个 `团队·角色` 会话。
2. 通过 mock 在同一个 workspace 再建一条会话并命名“临时会话”。
3. `dsh:team-status` 返回：`workspaceSessions:7`、`extras:0`、`items:6`、`mappingCount:6`。

**影响**

- 任务要求“是否只有 6 个角色会话、是否存在空/重复/额外会话”，当前接口无法回答“没有额外会话”；`SELFTEST_MAPPING` 的 `extras:0` 只证明“没有带 `团队·` 前缀的多余会话”。
- 重复建团队/rename 失败留下的孤儿会永久潜伏，用户看不到。

**建议落点**

- `extras` 应为“当前 workspace 全部会话 − 六个映射会话”，包含无标题/空白/非 `团队·` 标题；同时报告 `archived`/`blank`。
- 给 `dsh:team-status` 增加 `workspaceSessionCount` 与 `unmapped` 列表；selftest 加“7 条时 extras=1”。

---

### S6【中】侧栏/顶栏“6/6 会话就绪”不核实 DSH：会话全删后仍 6/6、6 个绿点

**位置**：`src/renderer/app.js:109-111`（`sessionReadyCount` 只数本地 `project.sessions`）、`544-558`（`renderSessions` 的 `ready`）、`679-698`（`renderHeader` 的 `#tb-team` / `#tb-sessions` / `#session-dots`）、`1122-1149`（`loadDshTeamStatus` 只改 `[data-role-live]` / `[data-team-role-live]` 的文本，不改计数）。

**现象**

启动时 `render()` 用本地映射算 `6/6`，不调用 `dsh:team-status`；只有打开项目抽屉/团队台时才 `loadDshTeamStatus`，而且它只把每行文字改成“DSH 中找不到”，计数和绿点保持原样。

**复现（探针 `render.countersBeforeLive` / `render.countersAfterLive`）**

1. 模型项目本地映射 6 个，DSH 在线。
2. 清空 mock DSH 的所有会话（相当于 DSH 重启/工作区被清）。
3. 渲染层 `refresh()` 后：`sessionCount:"6/6"`、`tbTeam:"6/6"`、`tbSessions:"6"`、`firstRoleState:"已建会话"`、`dotsOn:6`、`dshOnline:true`。
4. 手动 `loadDshTeamStatus()` 后：`sessionCount:"6/6"`、`tbTeam:"6/6"`、`firstRoleState:"DSH 中找不到"`、`dotsOn:6`。

**影响**

- 用户看到一个“满员、全绿”的团队，实际一个会话都不存在；只有逐个打开团队台才发现“DSH 中找不到”。
- `#tb-sessions` 数的是 `Object.keys(p.sessions).length`，不是“就绪数”，与 `#tb-team` 的 `6/6` 语义不同；多一个旧 key 就会显示 7。
- 与 S1/S5 叠加，UI 的“6 个会话”不可信。

**建议落点**

- 启动/刷新时调用 `dsh:team-status`（或至少 `dsh:status` + `session/list`），用 `items[].exists/inWorkspace/blank` 计算 `ready`、`unknown`、`missing`，不要只数本地 id。
- `#tb-team`、`#session-count`、`#session-dots` 同步更新；`#tb-sessions` 改名/改为“映射 6 / 在线 4”。
- selftest 加“DSH 清空后 UI 不得显示 6/6”。

---

### S7【中】界面显示的“DSH 标题”是 `项目 · 角色`，实际是 `团队·角色`；按标题定位永远匹配不上

**位置**：`src/renderer/app.js:124-127`（`roleSessionTitle` 返回 `${项目/团队名} · ${角色名}`）、`1082-1097`（角色弹窗把它当“DSH 标题”展示）、`1848-1903`（`locateDshSession` 用 `cfg.title` 做 `text === title || text.includes(title)`）、`1938-1972`（`focusDshWorkspace` 传的是 `roleSessionTitle`）；`src/main.js:98-101`（`roleTitle` = `团队·` + 角色名）；`团队/工具/launch.mjs:62`（实际 rename 成 `团队·${ROLE_NAMES[role]}`）。

**现象**

实际会话标题统一是 `团队·项目经理`；工作台 UI 生成的是 `模型项目 · 项目经理`。`locateDshSession` 的 `byTitle` 分支拿后者去匹配，永远匹配不到；`byParts` 要求同时包含项目名和角色名，DSH 行里只有 `团队·项目经理`，也匹配不到；最后只能靠 `short`（sessionId 前 10 位）或 `group`（点工作区再找）兜底。

**复现（探针 `render.titleMismatch`）**

- `uiTitle:"模型项目 · 项目经理"`
- `mappingTitle:"团队·项目经理"`
- `metaTitle:"团队·项目经理"`
- `roleTitleOfProject:"模型项目"`

**影响**

- “在 DSH 定位这个角色”按钮经常失败；失败时只 toast“DSH 未连接，或还没找到该会话”，用户无法判断是标题不对还是 DSH 没加载。
- `openRoleSessionModal` 的“DSH 标题”字段直接显示错的值；团队台 tooltip（`item.title`）显示 `团队·`，两处自相矛盾。
- 兜底的 `short` 会在 `nav *, aside *` 里找包含 sessionId 前 10 位的元素并点击，可能点到非会话行；没有点击后的身份校验。

**建议落点**

- 统一一个 `sessionTitle(role)`：全部使用 `团队·<角色名>`，映射、弹窗、定位、tooltip 都读它；删除 `roleSessionTitle` 的 `项目 · 角色` 形式。
- `locateDshSession` 点击后校验被点行确实包含目标 sessionId/标题，再返回成功；否则回退到工作区级定位。

---

### S8【中】刷新/建团队后不重载内嵌 DSH，新建的六个会话不会出现；只有手动重载/离线重试会 reload

**位置**：`src/renderer/app.js:1793-1802`（`applyDshViewSrc` 只在 src 为空/about:blank/与 baseUrl 不同时改 src，不 reload）、`2334-2343`（`#btn-refresh` 只 `refresh()` + `initDsh()` + `focusDshWorkspace`）、`2601-2617`（`startTeam` 只 `applyState` + focus）、`1836-1844`（`reloadDshView` 只由 `#btn-dsh-mode`/`#btn-dsh-off-reload` 调用）。

**现象**

`dsh:provision` 在后台建了 6 个会话，DSH 页面本身没有重新加载；`focusDshWorkspace` 只是往当前 DOM 里点，新建的会话行还没渲染出来。旧版在 `reloadEngine()` 里做 700ms/1800ms 两次 `webview.reload()`（`OLD-CODE-AUDIT.md` P1-8），新壳没有恢复。

**影响**

- 建团队后用户看不到左栏出现六个角色，误判“建团队失败”；再点一次（此时 S1 的提前返回）只会得到“已存在”，更容易误判。
- “刷新”按钮不能让 DSH 页面更新；只有用户知道去点“重载 DSH”才行，且会丢失当前页面状态。
- 与 S6 叠加，用户无法从 UI 判断“是会话没建，还是页面没刷”。

**建议落点**

- `dshProvision` / `project:create` / `project:adopt` / `#btn-refresh` 成功后调用 `#dsh-view.reload()`（沿用旧版双次延时），或在 `did-finish-load` 后焦点定位。
- 把“重载 DSH”做成唯一入口也可以，但必须在建团队成功的 toast 里明确提示。

---

### S9【中】`team:workspaces` 在工作台界面仍是死接口：切换工作区只列本地 `state.projects`

**位置**：`src/main.js:1460-1512`（`team:workspaces` 合并团队登记 + store 项目）、`src/preload.js:24`；`src/renderer/app.js:452-540`（`renderSidebar` / `renderWorkspacePopover` 只读 `state.projects`）；`src/main.js:1378-1403`（`project:discover` 只扫 `repo/projects` + 团队登记）。

**现象**

`team:workspaces` 存在、返回 `items/projects/current/dsh`，但渲染层没有任何调用。侧栏“切换工作区”、顶栏工作区弹层、`renderWorkspacePopover` 都只用本地库；DSH 里已有、团队登记过、但还没进 `workbench.json` 的工作区不可见，也不能从 UI 切过去。

**影响**

- 满足不了“项目 = 工作区，且能按工作区切换”的用户模型：用户只能看到自己新建/登记的项目。
- 旧审计 P0-1 的“三路合并清单”没有恢复；`team:workspaces` 的 `current`/`inStore`/`hasWorkspaceMeta`/`dshWorkspaceId` 全部浪费。
- 与 S4 叠加：删记录后的旧项目在团队里还在，但 UI 里完全消失。

**建议落点**

- 侧栏/工作区弹层改为 `team:workspaces` 的结果（按 path 去重、标 `current`/`inStore`/`exists`），本地项目只是其中 `source:'store'` 的一类。
- 对 `inStore:false` 的条目提供“登记为项目”；对 `exists:false` 显示“目录丢失”。
- 恢复“按名恢复”的 UI 入口时，允许从清单直接选。

---

### S10【中】降级到本地的派单/回执不标来源：与旧协议消息在界面上无区别，toast 仍说“已发送并唤醒角色”

**位置**：`src/main.js:2304-2314`（工具层错误只进 warnings）、`2316-2333`（本地降级消息 `source:'local'`、`degraded:true`、`reason`）；`src/renderer/app.js:2453-2466`（toast 只看 `r.wake`）、`620-641`（`renderTeamLog` 不渲染 `source/degraded/ackSource`）。

**现象**

当团队工具缺失/超时/`NO_TEAM`/`BOOT_FAILED` 时，`team:send` 会降级为本地消息，返回 `source:'local'` 与 `warnings`；只要目标会话存在且唤醒成功，界面仍 toast“派单已发送并唤醒角色”，消息行和回执行也与旧协议消息完全一样。回执 `ackSource:'local'/'team-local'` 同样不显示。

**影响**

- 用户无法知道这条消息只写进了 `workbench.json`，旧 `team.mjs inbox` 看不到；也无法知道回执没有进旧协议。
- 这正是“是否仍只写本地 workbench.json”的可见性问题：代码确实有降级，但 UI 把它伪装成成功。
- 与 S3 叠加，回执的来源（team/local）不可见，追责链更弱。

**建议落点**

- 消息行加 `source` 徽标（旧协议/本地降级/团队工具缺失）、`warnings`、`truncated`；回执行显示 `ackSource`。
- toast 按 `source` 区分：“已走旧协议并唤醒”“已记录本地，团队工具不可用”“已唤醒但未写入旧协议”。
- `team:send`/`team:ack` 的 `warnings` 至少在 toast 里给一条。

---

### S11【中】DSH 地址硬编码 `52711` 且 `dsh:configure` 不落盘；重启回到默认地址

**位置**：`src/main.js:410`（`new DshAdapter(process.env.DSH_WEB_URL || 'http://127.0.0.1:52711')`）、`2568-2572`（`dsh:configure` 只替换内存适配器 + 安装 cookie）、`src/renderer/index.html:170`（webview 静态 `src="http://127.0.0.1:52711"`）。

**现象**

`dsh:configure` 没有任何文件写入；重启后仍读 `DSH_WEB_URL` 或默认 `52711`。DSH 端口变化（旧审计 P1-1 说旧壳每次重启随机端口）或用户填了别的地址，重启后首屏又离线，必须重新配置。`installDshCookie()` 的返回值也没有被检查（`main.js:3653`）。

**复现（探针 `config.static`）**

- `dshDefault:"http://127.0.0.1:52711"`
- `htmlWebviewSrc:"http://127.0.0.1:52711"`
- `dshConfigureHandler` 只有 `dsh = new DshAdapter(...)` + `installDshCookie()`
- `src/` 没有 `dsh.json`/配置文件写入。

**影响**

- “DSH 是主画面”在端口变化后不成立：用户每次启动都要手配，配置也不持久。
- 401/403 被适配层归一为 `DSH_OFFLINE`，没有“重铸 cookie 再试”；secret 轮换后只能重启/重配（旧审计 P1-1）。

**建议落点**

- 增加 `data/dsh.json` 持久配置；`dsh:configure` 写盘并在启动时读取。
- 启动时做端口发现（tasklist/netstat + 试探）或至少读取上次成功地址；cookie 安装失败要显式报错。
- `dsh-adapter` 在 401/403 时重读 `.credentials.yaml` 重铸一次再重试。

---

### S12【中】Owner 弹窗可关闭且关掉后本轮不再自动弹；“产品评审”阶段永远不可达

**位置**：`src/renderer/app.js:1667-1679`（`openOwnerModal` 的 `closable: true`）、`431-436`（`render()` 在打开前先 `ownerPrompted.add`）、`2656-2674`（boot 也直接打开）；`src/main.js:957-969`（`deriveStage`）、`71-80`（`STAGES` 含 `review`）。

**现象**

- Owner 弹窗可 Esc/点 ×/点遮罩关闭；关闭后 `ownerPrompted` 已有该 id，只有 stage 离开 `owner` 才会删除，所以本轮不会再弹。用户只能自己找到“Owner 评审”按钮。
- `deriveStage` 的返回值只有 `intake/requirement/owner/close/test/dev/dispatch`，从不返回 `review`；但 `STAGES` 有“产品评审”，流程页会画一个永远不会高亮的阶段。
- `owner:decide` 只写 `workbench.json` 的 `ownerReview`，不写旧 `工作流.json`、不通知 PM、无 roundKey（旧审计 P1-2）。

**影响**

- Owner 误关弹窗后，阶段永久停在 `owner`，后续 dev/test 判定都被挡在前面；用户不知道还能从哪补。
- 8 阶段流程与真实可达阶段不一致；旧版“需求→产品评审→Owner 评审”的顺序没有恢复。
- Owner 决定不落团队状态，旧看板/PM 收件箱看不到。

**建议落点**

- `openOwnerModal` 传 `closable:false`；至少保留“跳过评审/开始评审”两个出口。
- 用 `roundKey`（项目+需求数+任务数+进行数）做“每轮一次”，而不是 `ownerPrompted` 永久集合。
- 实现 `review` 判据（产品/需求角色任务）或从 `STAGES`/流程页删掉该阶段；`owner:decide` 写 `工作流.json` 并调 `owner-note.mjs`。

---

### S13【中】六角色消息被收窄成“只能 PM 发给另外五个”：不能发给 PM，也不能角色之间互发

**位置**：`src/main.js:2220-2221`（`team:send`：`role === 'pm'` 直接抛“派单对象不能是项目经理”）、`2255-2263`（`sendDispatch` 固定 `from:'pm'`）；`src/renderer/app.js:1013`（派单下拉 `filter(r => r.id !== 'pm')`）；对照 `团队/工具/lib/ops.mjs:339-412`（`cmdSend` 用 `b.role` 作为 from，`--to` 可以是任意 active 角色，PM 也能收）。

**现象**

旧协议 `team.mjs send --boot T --to <角色>` 支持任意 active 角色发/收（PM 只是带 `--ack` 时有“一次一条”的锁）。新壳把发件人固定为 `pm`，并把 `pm` 从收件人下拉和 IPC 里排除；六角色之间（例如 tester → programmer1、product → pm）无法通过工作台发消息。

**影响**

- 任务要求“6 会话之间消息/回执严格照旧版”不成立：只有 PM→5 这一条通道，PM 收件箱和角色互评/互派都缺失。
- 旧协议里 `notify` 的 from/to 语义被改写；旧看板/`inbox` 看到的 from 永远是 pm。
- 与 S3 叠加，六角色协作仍是“壳代跑”，不是六个会话自己互通。

**建议落点**

- 派单表单增加 `from`（默认 pm），允许任意 active 角色作为收件人（含 pm）；只在 `from==='pm' && ack` 时套用 PM 单派锁。
- `sendDispatch` 接收 `from` 并原样传给 `team.mjs send`；UI 显示真实发件人。
- 补 selftest：product→pm、tester→programmer1 各一条。

---

### S14【低】派单 TTL 过期只在 `publicProject` 投影里清 `pendingAck`，磁盘仍保留

**位置**：`src/main.js:971-1008`（`publicProject` 里 `977-981` 清内存）、`1233-1247`（`pendingAckExpired`/`clearPendingAck`）。

**现象**

`publicProject` 发现 `pendingAck` 过期时，只把返回对象里的 `pendingAck/pendingAckAt` 置空，不写库；磁盘的 `workbench.json` 仍保留旧锁。只有下一次 `team:send` 或 `team:ack` 走到对应分支才会真正 `writeStore`。应用重启后 `state` 再次投影为空，但磁盘仍旧。

**影响**

- 旧 `pendingAck` 在磁盘/备份里长期存在；`team:cancel` 之外的直接读库（selftest、外部工具、排障）会看到“还在等回执”。
- 与旧协议 `派单锁.json` 可能不同步：本地锁过期但旧协议锁/消息还在，或反之；旧审计 P3-1/S14。

**建议落点**

- `readStore` 后做一次真正的 TTL 清理并落盘（注意原子写/并发），或在启动时 `reconcile` 本地 `pendingAck` 与旧 `派单锁.json`。
- selftest 加“TTL 后磁盘 pendingAck 为空”。

---

### S15【低】没有单实例锁；两个实例可同时写 `workbench.json` 与团队状态

**位置**：`src/main.js` 无 `requestSingleInstanceLock` / `second-instance`（grep 0 命中）；`createWindow` `2581-2594`。

**现象**

重复双击/命令行启动会得到两个独立 Electron 进程，各自读写同一份 `data/userdata/workbench.json` 与 `团队/状态`；原子写只能避免半截文件，不能避免丢更新/并发建会话。

**影响**

- 两个实例同时建团队会各自看到“没有会话”，可能重复建 12 个；同时改任务/提案会最后写入者覆盖。
- 旧审计 P1-9/S13 仍未修；与 S1/S5 的会话真实性问题叠加。

**建议落点**

- `app.requestSingleInstanceLock()`，`second-instance` 里 focus 已有窗口；自测里允许 `AWB_SELFTEST_ROOT` 隔离。

---

### S16【低】标称“只读核对”的 `dsh:team-status` 实际调用 `workspace/create`；工作区丢失后仍靠 cwd 判 `inWorkspace`

**位置**：`src/main.js:2470-2486`（注释“只读核对：不写状态库、不改工作区，只拿 workspaceId + 成员会话集合”，但 `2481` 调 `dsh.ensureWorkspace`，后者走 `workspace/create`）；`src/dsh-adapter.js:192-214`；`main.js:2499` 的 `inWorkspace` 还接受 `cwd` 相同。

**现象**

`dsh:team-status` 每次打开团队台/项目面板都会调 `ensureWorkspace(project.path)`；如果 mock/DSH 里这个 workspace 不在了，它会新建一个。随后 `items[].inWorkspace` 因为 cwd 相同仍为 true，UI 不会提示“工作区和会话已经失联”。

**复现（探针 `teamStatus.writeOnRead`）**

- 删掉 mock 里模型项目的 workspace：`workspaceRemoved:true`。
- 调 `dsh:team-status`：`workspaceCreateDelta:1`，`oldWorkspaceId:"mock-ws-1"` → `newWorkspaceId:"mock-ws-5"`，`itemsInWorkspace:6`。

**影响**

- “只读”承诺不成立：打开面板会写 DSH，可能把用户不想重建的工作区建回来。
- 工作区丢失被 cwd 兜底掩盖；六个会话被误判为仍在工作区，用户看不到“需要重新绑定”。

**建议落点**

- `dsh:team-status` 只用 `session/list` + 已记录的 `workspaceId`，不调 `workspace/create`；需要修复时提供显式“重新绑定工作区”按钮。
- `inWorkspace` 以 `workspaceId` 成员集合为准；cwd 只作为“疑似同目录”单独字段，不计入 `inWorkspace`。

---

## 四、其它观察（不单独计数）

1. **`project:create` 忽略 workspace 绑定失败**：`main.js:1334-1349` 把 `activation.warnings` 放进返回值，`app.js:1508` 的 `openNewProject` 只看 `r.team.ok`，DSH 离线时 `workspace.pending=true` 仍 toast“项目已创建”绿色成功。项目列表/`workspace-meta` 没有“pending”提示。建议至少把 `warnings[0]` 显示出来。
2. **同一次 ack 在 `回执.jsonl` 写两行**：一行基础记录、一行带 `receiptMessageId`/`update:true`。旧看板 `summary.receipts` 去重后是 1，但直接读文件的工具会看到 2 条。建议只在更新时原地替换或加 `revision`。
3. **`openMembersModal` 读的是 `团队会话.json` 清单，不是 live DSH**：`app.js:1151-1185` + `main.js:1525-1562`。DSH 会话被删/改名后，成员弹窗仍显示旧 id；与 S6 同源。
4. **自造 UI 与旧运维层**：六页签项目抽屉、Owner 弹窗、流程浮层、新手引导、主题、CPU/GPU/MEM 指标都是新壳自造；旧壳的余额、扩展（插件/技能/MCP/工具）、体检、更新、最近打开、网页 AI、盘容量等运维层没有恢复（`OLD-CODE-AUDIT.md` P1-7）。这不是本轮的主缺陷，但“逐像素旧界面”显然不成立。
5. **`npm run check` 只检查 5 个 JS 文件**，不检查 `index.html`/`style.css`，也没有旧壳式 UI 契约断言（`OLD-CODE-AUDIT.md` P0-0）。选择器漂移仍可能主界面白屏而自测通过。

---

## 五、数据只落 D 盘核查

### 5.1 代码路径

- `src/main.js:15-26`：
  - `LOCAL_DATA = AWB_DATA_DIR || <repo>/data`；
  - `app.setPath('userData', LOCAL_DATA/userdata)`；
  - `app.setPath('sessionData', LOCAL_DATA/userdata)`；
  - `app.setPath('temp', LOCAL_DATA/tmp)`；
  - 启动时创建 `LOCAL_DATA`、`USER_DATA`、`TEMP_ROOT`。
- `src/main.js:12-14`、`28-31`：`--selftest` 时 `SELFTEST_ROOT`（默认 `.selftest-data`，本轮用 `AWB_SELFTEST_ROOT` 指到 `_tmp/qa4/selftest-root`），`AWB_STORE`/`TEAM_ROOT` 都进沙盘。
- `src/main.js:2610`：store 自测的 `mkdtempSync` 在 `SELFTEST_ROOT` 下，不用 `os.tmpdir()`。
- `src/dsh-adapter.js:18-20`：`dshHome()` 默认 `os.homedir()/.dsh`，**只读**凭据，不写 C。
- `src/` 下 grep `os.tmpdir|process.env.TEMP|process.env.TMP`：0 命中（`src/main.js`、`src/dsh-adapter.js`、`src/team-tools.js`）。

### 5.2 本轮实际运行

所有 Electron 进程都设置：

```powershell
$env:TEMP  = D:\deepseek\agile-workbench\_tmp\qa4\temp
$env:TMP   = D:\deepseek\agile-workbench\_tmp\qa4\temp
$env:AWB_DATA_DIR = D:\deepseek\agile-workbench\_tmp\qa4\data
$env:AWB_SELFTEST_ROOT = D:\deepseek\agile-workbench\_tmp\qa4\selftest-root
$env:DSH_WEB_URL = http://127.0.0.1:9   # 探针启动瞬间，避免连真实 DSH
```

- selftest：`--user-data-dir=_tmp/qa4/userdata`；实际 Chromium `userData` 被 `main.js` 改到 `_tmp/qa4/selftest-root/userdata`（D）。
- 探针：`_tmp/qa4/probe`，状态库 `_tmp/qa4/probe/store/workbench.json`、团队根 `_tmp/qa4/probe/team`、数据根 `_tmp/qa4/probe/data`（D）。
- `npm run check` 只做 `node --check`；npm cache 指到 `_tmp/npm-cache`。
- 没有把项目/状态/临时文件写到 `%TEMP%`；selftest 的截图写到仓库根（D），已按原哈希还原。

### 5.3 C 盘核对

- `C:\Users\Admin\AppData\Roaming\敏捷工作台` 最新文件仍是 2026-11-05 02:33:40（早于本轮 04:56 起），本轮没有更新它；这是旧版本留下的 Chromium profile。
- `C:\Users\Admin\AppData\Local\Temp` 发现两个 0 字节 `.tmp`（05:02:40、05:03:43），文件被其它进程占用，时间点与本会话的命令工具调用一致；工作台自身 `userData/temp` 都在 `_tmp/qa4`（D），没有证据表明这两个文件由工作台写入。
- `C:\Users\Admin\AppData\Local\electron\Cache` 最新 01:56:34，早于本轮；不是本轮写入。
- 结论：**应用数据/配置/Chromium profile/临时文件都在 D**；C 盘只有旧版本遗留的 `%APPDATA%\敏捷工作台` 与本会话工具临时文件。若要求“机器零 C 残留”，需要单独清理旧目录后复验。

---

## 六、本轮运行与正向证据

### 6.1 `npm run check`

命令：`npm run check`；退出码 0；5 个文件全部通过 `node --check`（`main.js`、`preload.js`、`renderer/app.js`、`dsh-adapter.js`、`team-tools.js`）。

### 6.2 Electron selftest（D 盘）

命令：

```powershell
cmd /c ""D:\deepseek\agile-workbench\node_modules\electron\dist\electron.exe" . --selftest --user-data-dir=D:\deepseek\agile-workbench\_tmp\qa4\userdata > _tmp\qa4\selftest2.log 2>&1"
```

结果：`SELFTEST_OK`，退出码 0。关键输出：

- `SELFTEST_STORE {"checks":20,"failed":0}`
- `SELFTEST_STATE {"projects":0,"roles":6,"stages":8,"hasTeamApi":true,"teamToolExists":true}`
- `SELFTEST_FLOW`：`stageAfterCreate:"intake"`、`stageAfterTask:"owner"`、`stageAfterApprove:"dispatch"`、`stageAfterDone:"close"`、`provisionCreated:6`、`provisionMapping:6`、`provisionAgain:0`、`createWorkspaceId:"mock-ws-1"`、`messageSource:"team"`、`ackSource:"team"`、`boardOk:true`，`boardSummary:{"requirements":0,"tasks":0,"proposals":0,"receipts":0}`（注意：该看板在任务/提案之前生成，S2 由探针在任务/提案之后仍为 0 证明）。
- `SELFTEST_COMPAT {"checks":45,"failed":0}`：`provisionCreated:6`、`provisionSessions:6`、`provisionAgain:0`、`send1`/`ack2`/`lock1`/`lockAfterAck2:null`、`cancelOk:true`、`wakeOk:false/lock:null`。
- `SELFTEST_MAPPING_RESULT {"checks":34,"failed":0}`：`diffWs:true`、`createdSessions:6`、`createdAgain:0`、`extras:0`、`msgSource:"team"`、`ackSource:"team"`、`switchedToB:true`、`backToA:true`、`mappingCount:6`、`workspaceSessions:6`、`teamTitled:6`。
- `SELFTEST_TEAM_TEMP {"init":true,"ensure":true,"launch":true,"plan":1,"listed":true}`
- `SELFTEST_TEAM_CLEANUP`：删除沙盘项目登记，未动真实团队。

**正向结论**：状态库原子写/备份/损坏恢复 20/20；提案 baseHash/CAS/回滚/路径别名 45/45 + 34/34；项目 → workspace → 六角色映射、切 A/B、重复建团队不新建、派单锁、回执清锁、撤销都有真实 IPC 证据。

### 6.3 探针（`_tmp/qa4/probe`）

- 入口：`_tmp/qa4/probe/main.js`；真实 `require src/main.js`（真实 IPC、真实渲染层），本地 mock DSH（`http://127.0.0.1:<random>`），`DSH_HOME` 指向 `_tmp/qa4/probe/dsh-home`；启动时 `DSH_WEB_URL=http://127.0.0.1:9`，不碰真实 52711。
- 结果：`_tmp/qa4/probe/result.json`（16 条记录），日志 `_tmp/qa4/probe.log`（仅启动时 port 9 的 `ERR_UNSAFE_PORT`，无真实 DSH 请求）。
- 覆盖：模型项目建/建团队/状态、派单/回执/事件/回执文件、额外会话、空会话 seed 失败重试、旧看板 vs 工作台任务/提案、删记录后同名重建、`dsh:team-status` 写 workspace、渲染层计数/标题、DSH 配置静态常量。
- 探针结束后直接读 `_tmp/qa4/probe/team/状态/团队.json`：`members` 的 sessionId 全部是 `mock-s-8..13`（空会话项目），而模型项目映射是 `mock-s-1..6`；`activeProject` 仍显示“模型项目”。这直接证明全局名册被最后一个建团队的项目覆盖。
- 探针的 mock 工作区数据在 `_tmp/qa4/probe/team`、`_tmp/qa4/probe/work`，均为 D 盘临时目录。

### 6.4 正向确认（与上一轮相比）

- Owner 闸门：`deriveStage` 已把 Owner 判断放在“无未完成任务”之前（`main.js:962-965`），selftest `stageAfterApprove:"dispatch"` 有正向证据。
- 提案签字：`proposal:sign` 已有“必须至少一条 approve 评审 + 只有 pm 能签”（`main.js:2079-2087`）；同角色重复评审已被拒绝（`main.js:2062`）；selftest `reviews:1`。
- 同名项目：store 内同名已被拒绝（`main.js:1055-1057`）；同一路径/非空目录也被拒绝（`1052-1062`）。
- 项目恢复：`project:adopt` 对已有目录不覆盖 `项目信息.md`/`README.md`；`team:restore` 有 dry-run；本轮 selftest `teamAdoptOk:true`。
- 派单：无会话不置锁、唤醒失败释放、TTL 自动释放、撤销、回执清锁都有 selftest/探针证据；`secondRejected` 是旧协议 `PM_DISPATCH_PENDING`。
- 主界面：DSH `webview` 是 `stage` 的唯一主内容，项目/团队是抽屉浮层（§二第 1 项）。

---

## 七、只读边界与残留

- `src/main.js`、`src/renderer/app.js`、`src/renderer/index.html`、`src/renderer/style.css`、`src/team-tools.js`、`src/dsh-adapter.js`、`src/preload.js`、`package.json` 的 SHA-256 前 16 位与字节数在验收前后一致（见文首基线）。
- `团队/状态` 四个文件仍是 02:41/02:42 的 mtime；`data/` 最新仍是 04:46:31（早于本轮）；真实团队/数据未被本轮运行写入。
- 本文件之外，本轮只在 `_tmp/qa4/` 新增：`probe/`（探针源码、result、mock 数据）、`selftest2.log`、`probe.log`、`shots-backup/`、`dom-audit.js/json`、`real-state*.js`、`temp/`、`selftest-root/`、`probe/data` 等。`_tmp` 是任务允许的测试临时目录。
- `selftest.png` / `selftest-flow.png` 运行前哈希 `35B6269AE458CDA0…` / `46A0BA7A33463CE8…`，运行后已还原为同哈希；`selftest-dsh.png` 未变（`6F161512F8DA6EC9…`）。
- 仓库不是 git 仓库（`git status` 报 not a repository），无法用 diff 证明；以上用 SHA-256/字节数/mtime 作为只读证据。

---

## 八、建议修复顺序

1. **S1 + S3**（会话真实性/回执身份）：先让“建团队”真的把空白会话补齐，并让回执来自角色会话；这是用户模型“6 角色=6 会话、消息/回执照旧版”的根。
2. **S2 + S13**（数据同一真相/消息互通）：任务、提案、回执要么统一写 `团队/状态`，要么明确 `workbench.json` 是唯一真相并让旧看板从它生成；同时恢复任意 active 角色互发。
3. **S4 + S9**（项目/团队/工作区名字与清单）：删除记录/同名重建/按名恢复统一走冲突码；UI 改用 `team:workspaces` 的合并清单。
4. **S6 + S7 + S8**（UI 真话）：计数核实 DSH、标题统一 `团队·角色`、建团队/刷新后 reload webview。
5. **S5 + S16**（额外会话/只读写）：extras 改为全量差集；`team-status` 不再 `workspace/create`。
6. **S11 + S15**（配置/单实例）：DSH 地址持久化 + 端口发现 + 单实例锁。
7. **S12 + S14**（流程/TTL）：Owner 不可关闭/轮次去重/`review` 可达；TTL 真正落盘清理。
8. **S10**（降级可见性）：本地降级/回执来源在消息行和 toast 上明确标注。

---

**一句话结论**：DSH 壳的“主画面”已经立住，项目→workspace→六角色映射也能通过 34 项自测；但“空会话能补、旧看板与工作台同一份数据、回执来自六个角色会话、项目/团队/工作区同名同体、界面计数与 DSH 一致”仍不成立——当前版本可以演示，不应按“6 会话严格照旧版、所有功能已完成”验收发布。
