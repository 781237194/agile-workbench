# 敏捷工作台 v0.1 · 第五轮最终只读 QA（DSH 壳模型）

- 验收对象：`D:\deepseek\agile-workbench`（v0.1.0；Electron 33.4.11 / Chromium / Node 20.18.3）
- 代码基线（验收前后 SHA-256 前 16 位、字节数、mtime 均未变）：
  - `src/main.js` 228,475 B · 2026-11-05 06:47:39 · `656A2AC29E5992C3`
  - `src/renderer/app.js` 171,242 B · 06:49:40 · `07CA73D3A44A95C8`
  - `src/renderer/index.html` 30,525 B · 06:35:42 · `C807B7321FE3CF2D`
  - `src/renderer/style.css` 79,377 B · 06:49:41 · `577DC9518424D86B`
  - `src/team-tools.js` 71,463 B · 06:48:47 · `3F5E01B796679CDE`
  - `src/dsh-adapter.js` 9,366 B · 06:26:28 · `E4BAB0F86BB3CF2D`
  - `src/preload.js` 3,365 B · 03:45:51 · `D1EB37913A18A8CB`
  - `package.json` 798 B · 02:56:24 · `E14268B4B6B76214`
- 验收时间：2026-11-05 06:51–07:06（Asia/Shanghai）
- 方式：通读 `src/`、`团队/工具/`、`docs/QA-ROUND4.md`、`docs/PARITY-ROUND5.md`；`npm run check`；仓库自带 Electron `--selftest`（D 盘沙盘 + 本地 mock DSH）；`_tmp/qa5/probe` 真实 IPC/真实渲染层探针（不连真实 52711）；静态 DOM/调用图/数据文件核对。
- 只读边界：未修改 `src/`、`package.json`、`团队/`、`data/`、旧仓库；除本文件外只新增 `_tmp/qa5/`（探针、日志、沙盘、备份）。`selftest.png` / `selftest-flow.png` 运行前已备份，运行后按原哈希还原（见 §七）。
- 结论：**DSH 仍是主画面，项目/团队只是浮层**；六角色建会话、项目 ↔ workspace、切 A/B、回滚、看板写向同步都有真实自测证据。但“旧账本可继承、回执由角色会话自己跑、回执身份可核验、跨项目不串会话、删除项目不留 DSH 孤儿、看板/流程按当前项目说真话”仍不成立。本轮确认 **6 个高、8 个中，共 14 个可复现或可静态证明的问题**。

---

## 一、结论速览

| # | 级别 | 问题 | 主要证据 |
|---|---|---|---|
| H1 | 高 | 旧团队账本根未接入：旧项目/旧看板/旧回执在新壳全部不可见 | 新 `团队/状态/项目` 0 个、邮箱 0 个；旧根 6 个项目、392 个邮箱文件、86 KB 回执；旧看板 8 任务/6 提案/13 回执；探针 `ledger.roots` |
| H2 | 高 | 回执/派单仍由壳进程 `boot`/`ack` 代跑；唤醒文案不含旧四步，没有收件箱 | `main.js:2860`、`team-tools.js:1191-1229`、`1408-1410`、`1446`；`preload.js` 无 inbox；`app.js:1008` |
| H3 | 高 | 回执身份只校验本地映射字符串，不校验 DSH 会话是否还活着/属于本项目 | 删除 analyst 会话后 `team:ack` 仍 `source:"team"`、`ackSessionId:"mock-s-3"`，回执写 `identitySource:"role-session"`；探针 `ack.staleSession` |
| H4 | 高 | 旧协议锁可被“本机回执”吃掉：本地锁清了，旧 `派单锁.json` 还在；撤销再也释放不了 | 探针 `lock.deadlock`：`team-local` 回执后 `pendingAck=null`，`team:cancel.released=null`，下一次 PM 派单 `PM_DISPATCH_PENDING` |
| H5 | 高 | 跨项目名册污染：项目 B 没有 product 会话，却用项目 A 的 product 会话成功发件 | `main.js:249-267` 不清旧 session；`team-tools.js:1338-1341` 回退全局名册；探针 `roster.crossProjectSession` |
| H6 | 高 | 删除记录只清壳记录/团队登记，留下 DSH 工作区与六个会话；同名重建后会话翻倍 | 探针 `delete.orphan`：删除前后 11 会话/4 workspace 不变；同名重建后 17 会话/5 workspace，新项目 `extras:0` |
| M1 | 中 | 看板摘要读全局最后一份 `看板.json`：切到 C 项目仍显示 B 项目的任务数 | `team-tools.js:728-744`、`app.js:957-992`；探针 `board.globalSummary` |
| M2 | 中 | Owner 决定只写本地 `ownerReview`：不写 `工作流.json`、不通知 PM；弹窗可关闭且本轮不再自动弹 | `main.js:3017-3025`、`2353-2367`、`app.js:2473`、`534-539`；探针 `owner.localOnly` |
| M3 | 中 | 阶段推导顺序错：开发/测试同时未完成时显示“测试”；收口后新建提案又跳回“产品评审” | `main.js:1256-1271`、`133-142`；探针 `stage.mixedOpenTasks`、`stage.backwards`；selftest `close→review` |
| M4 | 中 | DSH 离线时新建项目仍返回 `ok:true`，界面绿色 toast“项目已创建”，warnings 不展示 | `main.js:1689-1718`、`app.js:2295-2300`；探针 `offline.create` |
| M5 | 中 | 旧版看板浮窗没有 preload/控制 IPC：折叠、缩放、最大化、切项目、文件预览全部无反应 | `main.js:2369-2390`；`团队/工具/lib/board.mjs:158、221、235-247` |
| M6 | 中 | 旧版看板窗口复用时不 reload：切项目后再打开，仍显示上一个项目的看板 | `main.js:2373-2378`；探针/静态调用图 |
| M7 | 中 | 提案回滚后旧看板仍显示提交：`rollback` 不删除 commit，`syncWorkbenchBoard` 仍写全部 commits | `main.js:2654-2708`、`team-tools.js:963-997` |
| M8 | 中 | “只写 D 盘”不是产品保证：数据根跟随应用目录；克隆/打包到 C 或在 asar 内运行会写 C 或启动失败 | `main.js:15、18-25`、`team-tools.js:284`；探针 `paths` 仅证明本次 D |

计数：高 ×6、中 ×8。

---

## 二、重点逐项判定（对应任务里的 8 个问题）

| # | 要求 | 判定 | 依据 |
|---|---|---|---|
| 1 | 工作台是否仍是 DSH 主壳，项目页是否又抢主位 | **PASS** | `index.html:154-177` 的 `main#dsh-shell > .stage-body > webview#dsh-view` 是唯一主内容；`#project-drawer` / `#team-drawer` 默认 `hidden`（`index.html:194、351`）；`app.js:451-473` 的 `setDrawer` 只切换绝对定位浮层；`app.js:2834-2841` 明确“DSH 永远是主画面”，启动 `showDshView(true)`（`app.js:3670-3671`）。保留意见：项目抽屉宽 `min(790px, calc(100% - 52px))`，打开时 DSH 只剩窄条，但底座没有换成项目页。 |
| 2 | 1 项目 = 1 workspace | **PARTIAL** | 正向：selftest `SELFTEST_MAPPING` 的 `diffWs:true`、`wsA/wsB` 不同、A→B→A 的 `backWs` 一致；`project:select` 会重绑并写 `当前工作区.json`（`main.js:1720-1740`）。反向：旧账本不可见（H1）、跨项目名册串会话（H5）、删除留 DSH 孤儿（H6）。 |
| 3 | 1 角色 = 1 会话、6 角色 = 6 会话 | **PARTIAL** | 正向：selftest `provisionCreated:6`、`provisionMapping:6`、`provisionAgain:0`、`statusAllExist:true`、`extras:0`；重复 provision 不新建。反向：回执可绑定已删除会话（H3）、跨项目用别人的会话发件（H5）、删除后旧六会话仍留在 DSH（H6）。 |
| 4 | 会话消息/回执是否真的走旧团队协议，是否仍有本地分叉 | **PARTIAL** | 正向：正常路径 `source:"team"`、`ackSource:"team"`、`teamMessageId` 与消息 id 相同、旧锁会清（selftest `SELFTEST_FLOW` / `SELFTEST_MAPPING`）。反向：`boot`/`ack` 由壳代跑且无 `inbox/read`（H2）；身份只校验字符串（H3）；旧锁可残留（H4）；旧协议 → 工作台没有读回（H2 影响）。 |
| 5 | 旧看板/流程/提案/任务同步 | **PARTIAL** | 正向：工作台任务/提案/提交/评审/签字能写入旧看板数据源，selftest `boardAfterSynced:{tasks:1,proposals:1,commits:1,reviews:1,signatures:1}`。反向：旧账本根本没接入（H1）；看板摘要跨项目（M1）；看板窗口能力退化（M5/M6）；回滚提交仍留在看板（M7）。 |
| 6 | 六角色互发/PM 收件/回执身份 | **PARTIAL** | 正向：selftest 已覆盖 `product→pm`、`tester→programmer1`，回执 `ackSource:"team"` 且 sessionId 与映射一致；`dispatch-from` 已渲染（`app.js:1612-1635`）。反向：没有 PM/角色收件箱（H2）；壳代跑（H2）；删除会话仍可回执（H3）；跨项目用 A 的会话发 B 的消息（H5）。 |
| 7 | 切换项目/恢复/删除/同名 | **PARTIAL** | 正向：selftest `switchedToB:true`、`backToA:true`、`adoptedMapping:6`；删除后同名重建不再哈希（`createProject` 会同时查 store 与团队登记，`main.js:1368-1384`）。反向：删除留 DSH 孤儿/删团队账本（H6）；看板复用不刷新（M6）；旧项目按名恢复找不到（H1）；离线新建仍报成功（M4）。 |
| 8 | 数据只写 D 盘、不写 C 盘 | **PASS（本次运行）/ 产品保证 PARTIAL** | 探针 `app.getPath`：`userData/sessionData/temp/logs/crashDumps` 全在 `D:\...\_tmp\qa5\probe\data`；`AWB_DATA_DIR`、`TEAM_ROOT` 均在 D；C 盘 `%APPDATA%\敏捷工作台` 最新仍是 02:33:40（旧版遗留 profile），本轮无新增。保留：M8 的数据根跟随应用目录问题。 |

---

## 三、问题清单（按严重级别）

### H1【高】旧团队账本根未接入：旧项目/旧看板/旧回执在新壳全部不可见

**位置**：`src/team-tools.js:284`（默认 `initialRoot = … path.join(repoRoot(), '团队')`）；`src/main.js:86-89`（只有 `--selftest` 才把 `TEAM_ROOT` 指到沙盘）；`src/main.js:1479-1494`（`findProjectByName` 只查 store / 新团队登记 / 仓库 `projects/`）；`src/main.js:1747-1771`（`project:discover` 只扫仓库 `projects/` + 新团队登记）；`src/main.js:2078-2135`（`team:restore` 的“按名恢复”同样走 `findProjectByName`）。

**现象**

- 新壳默认账本是仓库内的 `D:\deepseek\agile-workbench\团队\状态`：`项目/` 0 个目录、`邮箱/` 0 个文件、`团队.json` 只有 2 个空成员；`团队/状态/看板.json` 2,579 B。
- 旧账本 `D:\deepseek\工作台\团队\状态` 仍有 6 个项目登记、392 个邮箱文件、86,352 B `回执.jsonl`、779,000 B `事件.jsonl`；旧 `看板.json` 有 8 个任务、6 个提案、13 条回执；旧 `D:\deepseek\工作台\项目` 仍有 5 个项目目录（微光作品集等）。
- `team:workspaces` / `team:restore` / `project:discover` 都不会读旧根；工作台启动后侧栏看不到这 5 个旧项目，看板/流程/提案/任务也是新账本里的空数据。探针 `ledger.roots`：新根 5 个项目/3 个邮箱文件（沙盘），旧根 6 个项目/392 个邮箱文件，旧看板 8/6/13。

**复现/静态证据**

```text
Get-ChildItem D:\deepseek\agile-workbench\团队\状态\项目 -Directory            -> 0
Get-ChildItem D:\deepseek\工作台\团队\状态\项目 -Directory                    -> 6
Get-ChildItem D:\deepseek\工作台\团队\状态\邮箱 -Recurse -File                -> 392
D:\deepseek\工作台\团队\状态\看板.json                                        -> tasks 8, proposals 6, receipts 13
Get-ChildItem D:\deepseek\工作台\项目 -Directory                              -> 5
```

- `team-tools.js:284` 没有 `WB_WORKBENCH_DIR` / 旧根探测；`main.js` 只在 `IS_SELFTEST` 时覆盖 `TEAM_ROOT`。
- 探针 `_tmp/qa5/probe/result.json` 的 `ledger.roots` 复现了“新根/旧根两本账”。

**影响**

- 老用户升级后第一眼就是“项目/看板/回执全没了”；`FEATURE-MATRIX.md` 的“旧看板已恢复”只对新建项目成立。
- 旧项目不能按名恢复，旧回执不能追溯；开源发布后每个从旧版迁移的人都会踩。
- “旧看板/流程/提案/任务同步”只能在新账本内部自洽，不能证明与旧版同一份真相。

**建议落点**

- 在 `team-tools` 根解析里增加旧根探测（`WB_WORKBENCH_DIR` / `D:\deepseek\工作台\团队`），或者在首次启动时提供“导入旧账本”的显式迁移；不要静默使用空账本。
- `project:discover` / `team:restore` / `team:workspaces` 增加旧根来源；UI 标注“旧账本/新账本”。
- 若产品决定从零开始，README 与首次启动必须明确写“旧数据不自动迁移”，并给导出/导入入口；不能既不迁移又不提示。

---

### H2【高】回执/派单仍由壳进程 `boot`/`ack` 代跑；唤醒没有旧四步，也没有收件箱

**位置**：`src/main.js:2860`（唤醒只有一句“请先确认角色、任务和边界，完成后回执”）；`src/team-tools.js:1191-1229`（`bootToken` 在主进程 `team.mjs boot`）；`src/team-tools.js:1408-1410`（`ackDispatch` 主进程 `team.mjs ack`）；`src/team-tools.js:1446-1461`（`inboxFor` 存在但无调用者）；`src/preload.js:5-43`（没有 `team:inbox` / `team:read`）；`src/renderer/app.js:1008-1062`（团队台日志只读 `project.messages`）；`团队/工具/lib/ops.mjs:395-397`（旧版唤醒要求 `boot → inbox --all → read --id → ack`）。

**现象**

- 正常派单确实写进了旧邮箱：`team:send` 的 `sendDispatch` 用 `team.mjs send --ack --no-wake` 记账，主进程再用 `dsh.prompt` 唤醒目标会话。但唤醒文案没有旧版四步指令，角色收到后不知道要 `boot`、`inbox`、`read`、`ack`，也不会自己取令牌。
- 回执是操作者在团队台点“记录回执”，主进程用目标角色的映射 sessionId 调 `team.mjs boot` + `team.mjs ack`；角色自己的 DSH 会话从未执行 `boot/ack`。`team:ack` 的 `sessionId` 来自 `project.sessions`，不是来自当前 DSH 会话。
- 没有收件箱页：`team-tools.inboxFor` 无调用者，`preload` 也没有对应 IPC。`team:send` 只把“自己发的那条”写进 `project.messages`；角色/CLI 从旧邮箱发来的消息、旧 `回执.jsonl` 里的回执、旧任务/提案都不会被 UI 读回。

**复现/静态证据**

```text
main.js:2860  await dsh.prompt(sessionId, `【团队派单 …】… 请先确认角色、任务和边界，完成后回执；不要巡检全队。`);
team-tools.js:1408  const result = await withBootToken(projectName, role, async (token, boot) => {
team-tools.js:1410    const run = await runNode(layout.teamTool, ['ack', '--boot', token, '--id', messageId, ...]);
preload.js:5-43      teamStatus/members/workspaces/launch/restore/board/send/ack/cancel… 没有 inbox/read
app.js:1008          function renderTeamLog(p) { const all = Array.isArray(p?.messages) ? p.messages : []; … }
```

- 探针 `ack.staleSession` 进一步证明：回执事件里的 `sessionId` 完全由壳传入（删除 DSH 会话后仍写 `mock-s-3`），不是角色会话执行的结果。
- `SELFTEST_FLOW` 的 `ackSource:"team"` 只证明“壳成功调用了 team.mjs ack”，不能证明“角色会话回了执”。

**影响**

- 任务要求“会话消息/回执严格照旧版”不成立：旧协议要求收件角色自己 `boot` 后 `ack`，现在仍是壳在跑；“没有回执=没发生”只在壳的账本里成立。
- 六角色被唤醒后不会主动回执；用户必须逐个点“记录回执”，否则旧锁、旧消息一直悬着。
- 旧邮箱里的消息、旧回执、CLI 建的任务/提案不会出现在工作台，工作台只是“写向旧协议”的单向镜像。

**建议落点**

- 唤醒文案换成旧 `ops.mjs:395-397` 的四步模板（`boot` → `inbox --all` + `read --id` → `ack --id` → `task claim`），并明确“先读项目铁律”。
- 增加 `team:inbox` / `team:read` IPC + 团队台“收件箱”页；回执优先让角色会话自己执行，UI 的“记录回执”只能记成人工确认。
- 若保留壳代跑，必须在事件/回执里写 `actor:'workbench-shell'`，不能写 `sessionId` 冒充角色会话；并在 UI 明示“非角色回执”。

---

### H3【高】回执身份只校验本地映射字符串，不校验 DSH 会话是否还活着/属于本项目

**位置**：`src/main.js:2907-3015`（`team:ack`）；关键 `2919-2940` 只比较 `project.sessions[message.to]` 与 `p.sessionId`；`2960` 把 `mappedSession` 传给 `ackDispatch`；`src/team-tools.js:1399-1410` 用 `input.sessionId || member.sessionId` 生成 `boot`，没有 `session/list` 或 workspace 校验；`src/team-tools.js:1256-1285` 直接把 `usedSession` 写进 `回执.jsonl` 的 `sessionId` 并标 `identitySource:'role-session'`。

**现象**

- 在 mock 中删除 analyst 的 DSH 会话（`mock.deleteSession('mock-s-3')`）后，工作台仍能对一条待回执消息执行 `team:ack`：
  - 返回 `source:"team"`、`ackSessionId:"mock-s-3"`；
  - `回执.jsonl` 新增一行 `sessionId:"mock-s-3"`、`identitySource:"role-session"`；
  - DSH 里这个会话已经不存在。
- `team:ack` 的 UI 调用（`app.js:1774`）不传 `sessionId`，只传 `projectId/messageId/role/note/manual`，因此“身份”完全由本地映射决定；任何能操作界面的人都能替该角色写回执。

**复现/静态证据**

探针 `ack.staleSession`（`_tmp/qa5/probe/result.json`）：

```json
{
  "analystSession": "mock-s-3",
  "dshSessionRemoved": true,
  "ackSource": "team",
  "ackSessionId": "mock-s-3",
  "receipt": {
    "id": "A-20261105-065909-b06479",
    "sessionId": "mock-s-3",
    "identitySource": "role-session"
  }
}
```

代码：`main.js:2919` 之后没有任何 `listSessions` / `workspace` 校验；`team-tools.js:1399` 只判断字符串非空。

**影响**

- “回执身份”只是本地字符串；会话被删、被移到其他 workspace、或映射过期后，仍能写出看似合法的旧协议回执。
- 审计链断裂：`identitySource:'role-session'` 是假的，事后无法从 DSH 会话侧复核。
- 与 H5 叠加，可把 A 项目的会话写成 B 项目的回执。

**建议落点**

- `team:ack` 前用 `session/list` 校验：`exists`、`!archived`、`workspaceId`/成员快照属于当前项目；失败返回 `SESSION_IDENTITY_MISSING/MISMATCH`。
- `claimedSession` 应由角色会话侧提供（或从 DSH 当前会话事件取），不能由 UI 省略后默认用本地映射。
- 回执只写 `identitySource:'verified-session'` 时要带校验时间与 workspaceId；否则写 `identitySource:'local-mapping'`，不要冒充角色会话。

---

### H4【高】旧协议锁可被“本机回执”吃掉：本地锁清了，旧 `派单锁.json` 还在；撤销再也释放不了

**位置**：`src/main.js:2970-2984`（`team:ack` 遇到 `MESSAGE_NOT_FOUND` 等错误时降级 `team-local`）；`src/main.js:2985-3011`（`message.ack = true`、`clearPendingAck`）；`src/main.js:2885-2905`（`team:cancel` 只在 `project.pendingAck` 存在时释放旧锁）。

**现象**

1. PM 发一条要回执的派单：旧协议生成 `派单锁.json`，本机 `pendingAck` 也有值。
2. 模拟“邮箱消息文件被清理/团队状态重建”：删除 `状态/邮箱/tester/new/<...>.json`。
3. 点“记录回执”：`team.mjs ack` 返回 `MESSAGE_NOT_FOUND`，主进程走 `team-local` 降级路径，仍把 `message.ack=true` 并 `clearPendingAck`；旧 `派单锁.json` 原样保留。
4. 再点“撤销派单”：`team:cancel` 看到 `project.pendingAck` 已空，直接返回 `{ok:true,released:null}`，不会读旧锁。
5. 下一次 PM 派单被旧协议以 `PM_DISPATCH_PENDING` 拒绝；UI 无法再释放这把锁。

**复现/静态证据**

探针 `lock.deadlock`：

```json
{
  "lockBefore": {"messageId":"M-20261105-065909-650242","to":"tester"},
  "fallbackAckSource": "team-local",
  "fallbackAckWarnings": [{"code":"MESSAGE_NOT_FOUND"}],
  "pendingAfterFallback": null,
  "cancelResult": {"ok": true, "released": null},
  "lockAfterCancel": {"messageId":"M-20261105-065909-650242","to":"tester"},
  "nextSendError": "[PM_DISPATCH_PENDING] 上一条派单还没回执…"
}
```

代码：`main.js:2970-2984` 的降级分支没有调用 `releaseDispatchLock`；`main.js:3011` 无条件清本地锁；`main.js:2885-2889` 在没有本地 `pendingAck` 时提前返回。

**影响**

- PM 一次只能派一条的旧协议锁会永久卡住；用户看不出原因，只能手工删 `派单锁.json`。
- “撤销派单”在降级/重建后语义失效，UI 仍 toast“已撤销派单”。
- 与 H2 叠加：回执不是角色会话产生的，锁的释放也由壳决定，旧协议和本地两套状态越来越难对齐。

**建议落点**

- 降级 `team-local` 时不要清 `pendingAck`；保留它并在 UI 显示“旧锁未释放”，提供“强制释放旧锁”按钮。
- `team:cancel` 即使本地 `pendingAck` 为空，也要按 `message.teamMessageId` / 旧 `派单锁.json` 尝试释放。
- 启动时做一次 `pendingAck` 与旧锁的对账；`team:ack` 失败分支不要写 `ack=true`，应写 `ackFailed` 独立字段。

---

### H5【高】跨项目名册污染：项目 B 没有 product 会话，却用项目 A 的 product 会话成功发件

**位置**：`src/main.js:249-267`（`syncTeamRosterSessions` 只更新当前项目有值的角色，**从不清空当前项目没有的角色**）；`src/main.js:2744-2766`（`senderSession = project.sessions[from]` 为空仍传给 `sendDispatch`）；`src/team-tools.js:1338-1341`（`senderSession = input.sessionId || sender.sessionId`，回退到全局 `团队.json` 名册）；`src/main.js:2745` 的本地消息 `senderSessionId` 因此为空。

**现象**

1. 项目 A 已建团队：六个角色有会话 `mock-s-1..6`，`团队.json` 名册写入 A 的 session。
2. 新建项目 B（0 个角色会话），`project:select(B)`：`syncTeamRosterSessions({})` 不修改名册，A 的 product `mock-s-2` 仍在。
3. 在 B 的团队台选“发起=产品设计师，收件=项目经理”，发送：
   - 返回 `source:"team"`、`teamMessageId` 有值；
   - 本地消息 `senderSessionId:""`；
   - 旧协议 `团队.json` 的 product 仍是 A 的 `mock-s-2`；
   - B 的 `sessions` 仍为 0。
4. 对这条 B 的消息回执：`project.sessions.pm` 为空，返回 `SESSION_IDENTITY_MISSING`——消息能发，回执不能回，形成新的死信。

**复现/静态证据**

探针 `roster.crossProjectSession`：

```json
{
  "bSessionCount": 0,
  "source": "team",
  "from": "product",
  "senderSessionIdInLocalMessage": "",
  "aProductSession": "mock-s-2",
  "bProductSession": null,
  "rosterAfterProduct": {"role":"product","sessionId":"mock-s-2"},
  "crossAckError": "[SESSION_IDENTITY_MISSING] 这个角色还没有真实 DSH 会话，不能代写旧协议回执"
}
```

代码：`syncTeamRosterSessions` 的 `if (id && member.sessionId !== id)` 只改有值的角色；`sendDispatch` 的 `input.sessionId || sender.sessionId` 让空值回退到另一项目的名册。

**影响**

- 明确破坏“1 角色 = 1 会话 / 1 项目 = 1 workspace”：B 项目的消息被记成 A 项目的 product 会话发出。
- 旧协议事件/回执的 `sessionId` 属于另一个项目；追责和看板归属都会错。
- 发件成功但回执必然失败，用户会看到一条永远无法闭环的旧协议消息。

**建议落点**

- 名册按项目隔离（`团队.json.members` 带 project，或每个项目独立 roster）；`syncTeamRosterSessions` 切项目时清空当前项目没有的 sessionId。
- `sendDispatch` 只用当前 `project.sessions[from]`；为空直接 `SESSION_ID_REQUIRED`，绝不回退全局名册。
- `team:send` 在 `from` 无当前项目会话时直接拒绝，不要先写旧协议再让回执失败；selftest 加“B 无会话时 product→pm 必须拒绝”。

---

### H6【高】删除记录只清壳记录/团队登记，留下 DSH 工作区与六个会话；同名重建后会话翻倍

**位置**：`src/main.js:2392-2438`（`project:delete-record`）；关键 `2411` 递归删除 `团队/状态/项目/<slug>`（含任务/提案/提交/备份），但整个 handler 没有 `archiveSession`，也没有 workspace 删除/归档；`2435-2437` 只摘掉本地 store。

**现象**

1. 项目 D 建团队：6 个会话、1 个 workspace。
2. 点“移除记录”：`teamRegistrationExists:false`、`currentWorkspace.json` 被删、`activeProject` 清空；但项目目录、DSH workspace、6 个会话都还在。
3. 用同名“删除项目”在另一个根重建：新 workspace + 新 6 会话；此时 mock 里共有 17 个会话、5 个 workspace（删除前后 11 会话/4 workspace 不变）。
4. 新项目的 `dsh:team-status.extras` 为 0：旧 workspace 的 6 个会话不属于新 workspace，被“看不见”了。

**复现/静态证据**

探针 `delete.orphan`：

```json
{
  "beforeDelete": {"mockSessions": 11, "mockWorkspaces": 4, "workspaceD": "mock-ws-4"},
  "afterDelete": {
    "projectDirExists": true,
    "teamRegistrationExists": false,
    "mockSessions": 11,
    "mockWorkspaces": 4,
    "workspaceDStill": true
  },
  "afterRecreate": {"mockSessions": 17, "mockWorkspaces": 5, "extras": 0}
}
```

代码：`main.js:2392-2438` 没有任何 `dsh.archiveSession`/workspace 操作；`2411` 只删团队状态目录。

**影响**

- 每删一次、重建一次，DSH 就多 6 个孤儿会话和 1 个孤儿 workspace；长期使用后 DSH 左侧/存储越来越脏。
- “1 项目 = 1 workspace / 六角色 = 六会话”在删除路径上不成立；新项目的 `extras:0` 让用户看不到这些孤儿。
- 同时，删除团队登记会一并删除 `任务/提案/提交/备份`；对话框只说“团队登记会一起清理”，没有说账本业务数据也会删，误删不可恢复。

**建议落点**

- 删除记录时给明确二选一：①归档六个会话 + 删除/保留 workspace；②只摘本地记录，保留团队登记并标“已移除”，不要静默删账本。
- 删除前统计并显示“将删除 N 个任务/M 个提案/K 个提交/6 个会话”，二次确认。
- 增加孤儿会话扫描：按 workspace/`团队·角色` 找不属于任何 store 项目的会话，提供归档入口；selftest 加“删除后 DSH 会话数必须减少”。

---

### M1【中】看板摘要读全局最后一份 `看板.json`：切到 C 项目仍显示 B 项目的任务数

**位置**：`src/team-tools.js:728-744`（`teamStatus` 直接 `readJsonSafe(layout.boardJson)`，没有 project 参数）；`src/main.js:1905-1916`（`team:status` 不接收 projectId）；`src/renderer/app.js:957-992`（`renderBoardSummary` 用 `teamStatusUi.data.board` 给当前项目显示“需求/任务/提案/提交/回执/文件”）。

**现象**

- B 项目建 1 个任务，生成看板（`boardBSummary.tasks:1`）。
- 新建 C 项目（0 任务），`project:select(C)`，打开团队台：`team:status` 仍返回 B 的 `看板.json`（`board.name` 是 B、`tasks:1`），而当前项目 C 的 `tasks` 是 0。
- UI 的“看板摘要”会把 B 的任务数标在 C 项目下面；`teamActiveProject` 已是 C，但 `board` 还是 B。

**复现/静态证据**

探针 `board.globalSummary`：

```json
{
  "boardBName": "项目B",
  "projectCName": "项目C",
  "projectCTasks": 0,
  "teamStatusBoardName": {"name": "项目B", "dshWorkspaceId": "mock-ws-2"},
  "teamStatusBoardTasks": 1,
  "teamActiveProject": "项目C"
}
```

`team-tools.js:728-735` 的 `teamStatus()` 只有全局 `board`；`app.js:972` 直接把它当当前项目摘要。

**影响**

- 切项目后看板摘要不是当前项目的；用户会以为 C 已有任务/提案，或以为 B 的数据丢了。
- 旧看板本身是全局单文件，多项目同时存在时只能表示最后一次生成的项目；工作台却把它当成“当前项目事实”。
- 与 M6 叠加：看板窗口/摘要都停在旧项目。

**建议落点**

- `team:status` / `team:board` 接收 `projectId`，按项目读 `状态/项目/<slug>/` 或每次生成前切 activeProject 并写明“这是哪个项目”。
- UI 显示 `board.project`，与当前项目不一致时标“旧项目看板”并禁用计数；切项目时强制重新生成/刷新。
- 或让 `看板.json` 带 `project` 字段并在 `teamStatus` 校验，不匹配就不返回计数。

---

### M2【中】Owner 决定只写本地 `ownerReview`：不写 `工作流.json`、不通知 PM；弹窗可关闭且本轮不再自动弹

**位置**：`src/main.js:3017-3025`（`owner:decide` 只 `ownerDecide` + `writeStore`）；`src/main.js:2353-2367`（`workflow:owner` 返回 `notified:null`，不写工作流、不调 `owner-note`）；`src/renderer/app.js:2462-2478`（`openOwnerModal` 仍 `closable:true`）；`app.js:534-539`（`ownerPrompted` 按项目去重，只有 stage 离开 `owner` 才删除）。

**现象**

- Owner 通过/打回后，`ownerReview` 只出现在 `workbench.json`；`团队/状态/项目/<slug>/工作流.json` 不存在，PM 邮箱 `new/` 为 0，`workflow:owner` 的 `notified` 为 `null`。
- Owner 弹窗可以 Esc/×/遮罩关闭；关闭后 `ownerPrompted` 已经有该项目 id，本轮不会再次自动弹出，只剩顶栏一个小“Owner 待决定”入口。
- 旧版要求“只在 bossreview 弹、不可关、通过必须写意见、按 roundKey 每轮一次、owner-note 通知 PM”；当前只实现了“通过必须写意见”和“打回回需求”。

**复现/静态证据**

探针 `owner.localOnly`：

```json
{
  "ownerReview": {"status":"approved","opinion":"通过"},
  "workflowJsonExists": false,
  "pmInboxNew": 0,
  "ownerDecideKeys": ["ok","state"],
  "workflowOwnerNotified": null
}
```

`app.js:2473` 明确 `closable: true`；`app.js:534-538` 只在 `stage === 'owner'` 且未 prompted 时自动打开，关闭不会重置。

**影响**

- PM 收不到 `owner-review`，旧看板/流程看不到 Owner 决定；Owner 通过后旧协议仍可能认为“未评审”。
- 用户误关弹窗后阶段停在 `owner`，后续 dev/test 都被挡；只能自己找入口。
- 与 H1 叠加：旧账本里的 Owner 状态也不会同步回来。

**建议落点**

- `ownerDecide` 内联写 `工作流.json.ownerReview{required,status,by,at,roundKey,opinion}`，并调用旧 `owner-note.mjs`/`team:send` 通知 PM。
- `openOwnerModal` 改 `closable:false`，或关闭时保留“本轮未决”并自动重开；用 `workflowSnapshot().roundKey` 代替 `ownerPrompted`。
- 补 selftest：Owner 通过后 `工作流.json` 存在、PM 邮箱多一条 `owner-review`。

---

### M3【中】阶段推导顺序错：开发/测试同时未完成时显示“测试”；收口后新建提案又跳回“产品评审”

**位置**：`src/main.js:1256-1271`（`deriveStage`）；关键 `1268` 先判断 `tester`，`1269` 才判断 `programmer1/2`；`1263-1265` 把 `review` 放在 Owner 之后；`src/main.js:133-142` 的 `STAGES` 顺序是 `review` 在 `owner` 前；`src/renderer/app.js:1406-1410` 的 `FLOW_ROWS` 也按 `review → owner` 画。

**现象**

- 同时存在一个未完成开发任务（programmer1）和一个未完成测试任务（tester）时，`deriveStage` 返回 `test`，不是 `dev`；流程页直接高亮“测试”，跳过了开发。
- 所有任务完成（stage `close`）后再新建一个提案，`deriveStage` 因 `proposals.some(status==='review')` 返回 `review`；流程从“收口”跳回第 3 个节点“产品评审”，而 Owner 节点已 approved/完成，视觉上阶段倒退。
- 阶段数组是 `intake → requirement → review → owner → …`，但 `review` 只有在 Owner 放行之后才可达（`1262` 先要求 Owner approved/skipped），与数组顺序相反。

**复现/静态证据**

探针 `stage.mixedOpenTasks` / `stage.backwards`：

```json
{"openDev":"todo","openTest":"todo","stage":"test"}
{"stageAfterDone":"close","stageAfterProposal":"review","stageOrder":["intake","requirement","review","owner","dispatch","dev","test","close"]}
```

selftest 也输出 `stageAfterDone:"close"`、`stageAfterProposal:"review"`，与上述一致。

**影响**

- 流程页/阶段高亮说错当前进度；开发没完成就显示测试，PM 可能误派测试/误判收口。
- 收口后新增提案让整个流程“倒退”，与旧版 `intake → requirement → review → bossreview → dispatch → dev → test → close` 不一致。
- 阶段是 Owner 闸门/看板/任务判断的共同输入，错一次会连带影响后续判断。

**建议落点**

- 先判 `dev` 再判 `test`：有未完成 programmer 任务就返回 `dev`，全部开发完成才 `test`。
- `review` 要么放在 Owner 前（产品/需求评审任务判据），要么从 `STAGES`/`FLOW_ROWS` 删除；不要既画在前面又在 Owner 后才可达。
- 明确“提案在 close 后创建”是否应回到 review；若应，则流程节点要允许回退并在 UI 说明，不要静默倒退。
- selftest 加“dev+test 同时 open → dev”“close 后新建提案 → 预期阶段”的断言。

---

### M4【中】DSH 离线时新建项目仍返回 `ok:true`，界面绿色 toast“项目已创建”，warnings 不展示

**位置**：`src/main.js:1689-1718`（`project:create` 无论 `activation` 是否成功都 `return {ok:true,…warnings}`）；关键 `1702-1708` 把 `bindProjectWorkspace` 的失败放进 `warnings`；`src/renderer/app.js:2287-2303`（`openNewProject` 只看 `r.team.ok`，不读 `r.warnings` / `workspace.pending`，toast 仍是“项目已创建”）。

**现象**

- 把 DSH 指到必然连不上的 `127.0.0.1:9`，再新建项目：返回 `ok:true`、`warnings:[{code:'DSH_OFFLINE'}]`、`workspace:{id:null,pending:true,lastError:{code:'DSH_OFFLINE'}}`，项目记录已入库。
- 界面绿色 toast“项目已创建”，不显示离线告警；只有侧栏小字“工作区待绑定”，用户很容易以为项目已完全可用。
- 点“建团队”才会因 workspace 不可用失败；在此之前 `1 项目 = 1 workspace` 是 1:0。

**复现/静态证据**

探针 `offline.create`：

```json
{
  "ok": true,
  "warnings": [{"code":"DSH_OFFLINE","message":"DSH 连接失败：fetch failed"}],
  "workspace": {"id":null,"bound":false,"pending":true,"lastError":{"code":"DSH_OFFLINE"}},
  "projectExists": true,
  "teamOk": true
}
```

`app.js:2298` 的 toast 条件只有 `r.team && !r.team.ok`；`createProject` 的 `warnings` 没有进入 UI。

**影响**

- 离线/端口错误时得到“有项目、没 workspace”的 1:0，用户以为成功；后续建团队失败会误以为是团队工具问题。
- 与 M8 叠加：换机器/打包到无 DSH 环境时，第一次新建项目就进入 pending，没有明确恢复入口。
- selftest 只测了 `team:launch` 的离线错误码，没有测“新建项目 UI 必须告警”。

**建议落点**

- `openNewProject` 读 `r.warnings` + `r.project.workspace.pending`：红色 toast/侧栏 `#workspace-warn` 显示 `DSH_OFFLINE`，并提供“重试绑定”。
- `project:create` 在拿不到 workspaceId 时要么拒绝入库，要么明确 `pending` 并在 UI 禁用“建团队”，直到重试成功。
- selftest 加“离线 createProject → UI 不得绿色成功、必须显示 pending”。

---

### M5【中】旧版看板浮窗没有 preload/控制 IPC：折叠、缩放、最大化、切项目、文件预览全部无反应

**位置**：`src/main.js:2369-2390`（`team:board-old`）；关键 `2380-2386` 创建 440×760、`frame:false`、`alwaysOnTop:true` 的 `BrowserWindow`，`webPreferences` 只有 `contextIsolation/nodeIntegration/sandbox`，**没有 preload**；`团队/工具/lib/board.mjs:158` 渲染 `[data-win=collapse/zoom-out/zoom-in/maximize/close]`，`:235-239` 处理 `#project-select`，`:221` 处理文件预览，`:241-247` 全部先判断 `window.boardWin`。

**现象**

- 看板窗口能打开、能置顶，但：
  - 折叠/缩小/放大/最大化按钮点击后没有任何反应（`window.boardWin` 不存在，脚本静默 return）；
  - 项目下拉切换后没有反应（`selectProject` 不存在，脚本直接 return）；
  - 文件抽屉显示“当前窗口不支持预览”；
  - 窗口只有 440×760，与旧版 1120×780、透明/半透明/可缩放不一致；HTML 标题仍写“可拖动 / 缩放 / 半透明悬浮”。
- 关闭按钮是唯一可用的（fallback `window.close()`）。

**复现/静态证据**

```text
main.js:2380-2385  new BrowserWindow({ width:440, height:760, frame:false, alwaysOnTop:true, … webPreferences:{contextIsolation:true,nodeIntegration:false,sandbox:true} })
board.mjs:221      if (!window.boardWin || !window.boardWin.openFile) return open('文件','当前窗口不支持预览')
board.mjs:235-239  if (!window.boardWin || !window.boardWin.selectProject) return;
board.mjs:241-247  if (window.boardWin) await window.boardWin.control(...); else if (action==='close') window.close();
```

**影响**

- “旧版看板浮窗”只剩一个不可操作的静态 HTML；用户会认为看板坏了。
- 项目切换、文件预览、折叠/缩放这些旧入口全部失效；`FEATURE-MATRIX.md` 的“旧看板已恢复”不成立。
- 与 M6 叠加：即使看板内容更新，窗口也不刷新。

**建议落点**

- 挂回旧的 `board-preload.js`（或等价 contextBridge），补 `team:board-control` / `team:board-file` 两个 IPC，语义照旧 `main.js:599-651`。
- 尺寸/透明/opacity 对齐旧版；不打算实现的能力就从 HTML 移除，不要留死按钮。
- selftest 加“窗口存在 `window.boardWin` 且 control 能改变窗口尺寸”的断言。

---

### M6【中】旧版看板窗口复用时不 reload：切项目后再打开，仍显示上一个项目的看板

**位置**：`src/main.js:2369-2390`（`team:board-old`）；关键 `2373` 先 `generateBoard(project)`，`2375-2378` 若 `teamBoardWindow` 存在只 `show/focus` 并 `return {reused:true}`，没有 `loadFile`/`reload`；`2388` 只在新窗口时 `loadFile`。

**现象**

- 打开项目 A 的看板，窗口加载 A 的 `看板.html`。
- 切到项目 B，点“打开看板”：`generateBoard(B)` 会把 `看板.html` 重写成 B，但已有窗口只是 `show/focus`，DOM 仍是 A；标题、任务、提案、Owner 都是 A 的。
- 用户以为看板已切到 B，实际看到 A；项目下拉又是死的（M5），无法在窗口内切回。

**复现/静态证据**

```text
main.js:2373  const result = await teamTools.generateBoard(project);
main.js:2375  if (teamBoardWindow && !teamBoardWindow.isDestroyed()) {
main.js:2376    teamBoardWindow.show();
main.js:2377    teamBoardWindow.focus();
main.js:2378    return { ok: true, path: result.boardPath, reused: true };
main.js:2379  }
…
main.js:2388  await teamBoardWindow.loadFile(result.boardPath);
```

**影响**

- 切项目后看板显示错项目，和 M1（摘要）一起造成“看板/当前项目不一致”。
- 看板是旧协议人工核对的主要界面，错项目会直接导致误判/误操作。
- 与 M5 的项目下拉失效叠加，用户没有窗口内纠正手段。

**建议落点**

- 复用窗口时比较 `webContents.getURL()` 与 `result.boardPath`；不同就 `loadFile(result.boardPath)`，相同也 `reload()` 一次。
- 或在窗口内实现项目切换（M5 的 `selectProject`），由窗口自己 `team:board-project` 重生成。
- selftest 加“A 打开 → 切 B → 再打开，窗口 URL/标题必须是 B”。

---

### M7【中】提案回滚后旧看板仍显示提交：`rollback` 不删除 commit，`syncWorkbenchBoard` 仍写全部 commits

**位置**：`src/main.js:2589-2652`（`proposal:apply` 创建 `commit` 并 push）；`src/main.js:2654-2708`（`proposal:rollback` 只 `proposal.applied=false`，不删/不标记 commit）；`src/team-tools.js:963-997`（`syncWorkbenchBoard` 遍历 `project.commits`，无条件写 `提交/<id>.json`）；`src/team-tools.js:792-798`（`mapProposalStatus` 只看 `proposal.status`，不处理 `applied/rolledBack`）。

**现象**

- 应用提案 → 旧看板数据源出现 `提交/C-xxxx.json`，`summary.commits+1`。
- 回滚提案 → 文件恢复，`proposal.applied=false`；但 `project.commits` 仍保留该 commit，`syncWorkbenchBoard` 仍把它写回旧看板。
- 旧看板/CLI 继续看到一条“已提交”的记录，且 proposal 的 `status` 仍是 `approved`（apply 没有设 `status='applied'`），`mapProposalStatus` 也映射成 `approved`。

**复现/静态证据**

```text
main.js:2645  project.commits.push(commit);
main.js:2703  proposal.applied = false;          // 没有删除 commit
team-tools.js:963  const commits = Array.isArray(project.commits) ? project.commits : [];
team-tools.js:964  for (const commit of commits) { … writeJsonAtomic(file, record); counts.commits += 1; }
```

**影响**

- 旧看板的提交计数/文件状态与真实文件不一致；回滚后仍显示“已提交”，审计会误判。
- 与 H1/M1 叠加：旧看板本来就可能不是当前项目，再叠加回滚不清理，数据更不可信。
- `proposal.status` 在 apply 后仍是 `approved`，旧看板无法区分“已签字”和“已应用”。

**建议落点**

- `rollback` 时把 commit 标 `rolledBack:true` 或移出 `project.commits`；`syncWorkbenchBoard` 跳过/标注已回滚提交。
- `apply` 时设 `proposal.status='applied'`（或单独 `appliedAt`），`mapProposalStatus` 读取 `applied`；旧看板区分 approved/applied/rolledBack。
- selftest 加“apply 后 commits=1、rollback 后旧看板 commits=0（或 rolledBack=1）”。

---

### M8【中】“只写 D 盘”不是产品保证：数据根跟随应用目录；克隆/打包到 C 或在 asar 内运行会写 C 或启动失败

**位置**：`src/main.js:15`（`LOCAL_DATA = AWB_DATA_DIR || path.join(ROOT, 'data')`）；`src/main.js:18-25`（`DATA_ROOT/USER_DATA/TEMP_ROOT` 都在 `LOCAL_DATA` 下，并在 require 阶段 `mkdirSync`）；`src/team-tools.js:284`（团队根默认 `path.join(repoRoot(), '团队')`）。

**现象**

- 本次从 `D:\deepseek\agile-workbench` 运行，探针 `app.getPath` 显示 `userData/sessionData/temp/logs/crashDumps` 全在 D；这是“当前安装位置”的结果，不是代码硬保证。
- 若把仓库克隆到 `C:\...`，`ROOT` 变成 C，`data/`、`团队/` 都写 C；若打包成 asar 安装到 `C:\Program Files\...`，`fs.mkdirSync(LOCAL_DATA)` 在 require 阶段就可能失败（asar 只读/权限不足），应用起不来。
- 没有 `app.isPackaged` 分支，也没有 `app.getPath('userData')` 默认；`AWB_DATA_DIR` 是唯一外部覆盖。

**复现/静态证据**

```text
main.js:15   const LOCAL_DATA = process.env.AWB_DATA_DIR ? path.resolve(process.env.AWB_DATA_DIR) : path.join(ROOT, 'data');
main.js:18-25  DATA_ROOT = IS_SELFTEST ? SELFTEST_ROOT : LOCAL_DATA; USER_DATA/TEMP_ROOT = DATA_ROOT/...; mkdirSync(...)
team-tools.js:284  initialRoot = options.teamRoot || process.env.TEAM_ROOT || path.join(repoRoot(), '团队');
```

探针 `paths` 只证明本次 `AWB_DATA_DIR`/`TEAM_ROOT` 指向 D；C 盘 `%APPDATA%\敏捷工作台` 仍是 02:33:40 旧 profile，本轮没有新增，但这不是代码层面的 D 保证。

**影响**

- 开源用户把仓库放在 C 盘（默认下载目录）时，工作台数据/临时文件/团队状态都写 C，“只写 D”承诺失效。
- 打包分发到 Program Files 时，启动阶段就可能因数据目录不可写而崩；这是发布前必须处理的部署问题。
- 与 M4 叠加：离线/无 DSH 环境首次启动更容易进入 pending 且无明确提示。

**建议落点**

- 非自测模式默认用 `app.getPath('userData')`（或显式 `D:\deepseek\agile-workbench\data`，如果产品真的要求固定 D），不要在 `ROOT/data` 写；团队根同理，提供 `AWB_TEAM_ROOT` / 用户可配置目录。
- 打包模式检测 `app.isPackaged`，把数据/临时/团队根放到可写目录；启动失败时给出可操作错误，不要静默崩。
- README 明确“数据根”，selftest 加“把 AWB_DATA_DIR 指到只读目录时必须结构化报错”。

---

## 四、运行与正向证据

### 4.1 `npm run check`

命令：`npm run check`；退出码 0；5 个 JS 文件全部通过 `node --check`（`main.js`、`preload.js`、`renderer/app.js`、`dsh-adapter.js`、`team-tools.js`）。注意它不检查 `index.html` / `style.css` / DOM 契约，见 §六。

### 4.2 Electron selftest（D 盘沙盘）

命令（D 盘沙盘、mock DSH、临时目录都在 `_tmp/qa5`）：

```powershell
$env:TEMP='D:\deepseek\agile-workbench\_tmp\qa5\temp'
$env:TMP=$env:TEMP
$env:AWB_DATA_DIR='D:\deepseek\agile-workbench\_tmp\qa5\data'
$env:AWB_SELFTEST_ROOT='D:\deepseek\agile-workbench\_tmp\qa5\selftest-root'
$env:DSH_WEB_URL='http://127.0.0.1:9'
$env:DSH_HOME='D:\deepseek\agile-workbench\_tmp\qa5\dsh-home'
electron.exe . --selftest --user-data-dir=…\qa5\userdata
```

结果：`SELFTEST_OK`，退出码 0。关键输出：

- `SELFTEST_STORE {"checks":20,"failed":0}`
- `SELFTEST_STATE {"projects":0,"roles":6,"stages":8,"hasTeamApi":true,"teamToolExists":true,"dsh":true}`
- `SELFTEST_FLOW`：`stageAfterCreate:"intake"`、`stageAfterTask:"owner"`、`stageAfterApprove:"dispatch"`、`stageAfterDone:"close"`、`stageAfterProposal:"review"`、`provisionCreated:6`、`provisionMapping:6`、`provisionAgain:0`、`createWorkspaceId:"mock-ws-1"`、`messageSource:"team"`、`ackSource:"team"`、`boardAfterSummary:{tasks:1,proposals:1}`、`boardAfterSynced:{tasks:1,proposals:1,commits:1,reviews:1,signatures:1}`、`crossFromPm:"product"`、`crossToPmAckSource:"team"`、`crossToDevAckSource:"team"`。
- `SELFTEST_COMPAT {"checks":45,"failed":0}`；`SELFTEST_MAPPING_RESULT {"checks":39,"failed":0}`；`diffWs:true`、`createdSessions:6`、`createdAgain:0`、`statusAllExist:true`、`extras:0`、`readOnlyWorkspaceCreateDelta:0`、`switchedToB:true`、`backToA:true`。
- `SELFTEST_TEAM_TEMP` / `SELFTEST_TEAM_OFFLINE` / `SELFTEST_TEAM_ERRORS` 均按预期返回结构化错误；`SELFTEST_TEAM_CLEANUP` 只清理沙盘登记。

正向结论：状态库原子写/备份/恢复 20/20；旧协议兼容 45/45；项目 ↔ workspace ↔ 六角色映射 39/39；正常路径派单/回执/锁/撤销、看板写向同步、跨角色发件（product→pm、tester→programmer1）都有真实 IPC 证据。

### 4.3 探针（`_tmp/qa5/probe`）

- 入口：`_tmp/qa5/probe/main.js`；真实 `require src/main.js`（真实 IPC + 真实渲染层），本地 mock DSH（`http://127.0.0.1:<random>`），`DSH_HOME`、`AWB_STORE`、`TEAM_ROOT`、`AWB_DATA_DIR` 全在 `_tmp/qa5/probe`（D）；启动时 `DSH_WEB_URL=http://127.0.0.1:9`，不碰真实 52711。
- 结果：`_tmp/qa5/probe/result.json`；日志 `_tmp/qa5/probe2.log`。覆盖：六角色建团队、Owner、阶段、看板摘要、跨项目名册、删除/同名重建、回执身份、锁残留、离线新建、数据路径、旧/新账本。
- 关键结果见各问题条目；探针结束后 `_tmp/qa5/probe/team` 的 mock 数据只用于本轮，不写真实团队。

### 4.4 正向确认（与上一轮相比）

- 空会话补 seed：`provisionTeamSessions` 把 `inspection.blank` 并入 `missingRoles`；selftest `provisionCreated:6`、`provisionAgain:0`。
- 额外会话：`dsh:team-status` 现在按“当前 workspace 全部 live 会话 − 映射”算 `extras`；selftest 7 条时 `extras:1`，不再只看 `团队·` 前缀。
- 标题统一：`roleSessionTitle` 返回 `团队·角色`，selftest `teamTitled:6`。
- 派单互发：`team:send` 接受 `from`，UI 已渲染 `#dispatch-from` 并传 `from`；selftest cross 两项通过。
- 回执身份：`team:ack` 增加 `SESSION_IDENTITY_MISSING/MISMATCH` 与 `manual` 通道；正常路径 selftest `ackSource team` 且 sessionId 与映射一致。
- 看板写向：`boardAfterSynced` 任务/提案/提交/评审/签字均 ≥1；工作台任务/提案/提交能进旧看板数据源。
- 数据路径：本次运行 `userData/sessionData/temp/logs/crashDumps` 全 D；`team:status` 只读不再 `workspace/create`（selftest `readOnlyWorkspaceCreateDelta:0`）。
- 单实例、DSH 地址持久化 `data/dsh.json`、`team:status` 只读核对均已具备。

---

## 五、D 盘 / C 盘核查

### 5.1 代码路径

- `src/main.js:15`：`LOCAL_DATA = AWB_DATA_DIR || <repo>/data`；`:18`：自测用 `SELFTEST_ROOT`；`:19-20`：`USER_DATA = DATA_ROOT/userdata`、`TEMP_ROOT = DATA_ROOT/tmp`；`:82-84`：`app.setPath('userData'/'sessionData'/'temp')` 全部指向 D 的数据根。
- `src/main.js:23-25`：启动时创建 `LOCAL_DATA/USER_DATA/TEMP_ROOT`。
- `src/dsh-adapter.js:18-20`：`DSH_HOME` 或 `~/.dsh`，只读凭据，不写 C。
- `src/` 下 grep `os.tmpdir|process.env.TEMP|process.env.TMP`：0 命中；只有 `团队/工具/lib/selftest.mjs:32` 使用 `os.tmpdir()`，但应用不调用该工具的 selftest。

### 5.2 本轮实际运行

- selftest：`--user-data-dir=_tmp/qa5/userdata`；`main.js` 把 Chromium `userData` 改到 `_tmp/qa5/selftest-root/userdata`（D）。
- 探针：`_tmp/qa5/probe/{store,team,data,work}`（D）；`app.getPath` 实测：
  - `userData: D:\...\qa5\probe\data\userdata`
  - `sessionData: D:\...\qa5\probe\data\userdata`
  - `temp: D:\...\qa5\probe\data\tmp`
  - `logs: D:\...\qa5\probe\data\userdata\logs`
  - `crashDumps: D:\...\qa5\probe\data\userdata\Crashpad`
  - `appData: C:\Users\Admin\AppData\Roaming`（Electron 常量，本应用未用它写数据）
- npm cache 指到 `_tmp/qa5/npm-cache`；没有把项目/状态/临时文件写到 `%TEMP%`。

### 5.3 C 盘核对

- `C:\Users\Admin\AppData\Roaming\敏捷工作台` 最新文件仍是 **2026-11-05 02:33:40**（旧版本遗留 Chromium profile），本轮 06:51–07:06 没有更新。
- `C:\Users\Admin\AppData\Local\Temp` 最近两个 0 字节 `.tmp` 是 06:53:30 / 06:54:56，时间点与本会话命令工具（不是探针）的调用一致；探针 06:58–06:59 没有新增 C temp。
- `C:\Users\Admin\AppData\Local\electron\Cache` 最新 01:56:34，早于本轮。
- 结论：**本次运行应用自身数据/配置/Chromium profile/临时文件都在 D**；C 盘只有旧版遗留 profile 与会话工具的 0 字节 tmp。若要求“机器零 C 残留”，需要单独清理旧 `%APPDATA%\敏捷工作台`；产品层面的 D 保证见 M8。

---

## 六、其它观察（不单独计数）

1. **`npm run check` 只做 `node --check` 五个 JS**：不检查 `index.html` / `style.css`，没有旧壳式 UI 契约断言（选择器、弹窗字段、菜单项、看板按钮）。本次 selftest 只点了一个 `[data-tab="flow"]`；选择器漂移仍可能主界面白屏而 `SELFTEST_OK`。
2. **没有 `uncaughtException` / `unhandledRejection` / `main.log`**：主进程异常只进 stderr；开源发布后用户拿不到日志。旧版有 `main.log` 与 `uncaughtException`（`PARITY-ROUND5.md` P2-2）。
3. **仍有半死接口**：`team:open-project`、`team:launch`、`team:workspace:create` 在 `preload` 暴露，但渲染层没有调用；旧入口语义靠 `project:adopt` / `project:create` 替代。要么接回 UI，要么删除并写 README。
4. **抽屉宽度**：项目抽屉 `min(790px, calc(100% - 52px))`，打开时 DSH 只剩很窄一条；功能上 DSH 仍是底座，但“主画面”体验会被浮层压住。
5. **`team:status` 仍是全局单例**：`团队.json` 只有一个 `activeProject`；多项目同时存在时，名册/看板只能表示“最后一次 ensure/board”的项目。H5/M1 都源于这个结构。
6. **旧 `%APPDATA%\敏捷工作台` 未清理**：不是本轮写入，但换机/发布前应决定是否迁移/删除，避免用户误以为新壳还在用 C 盘。
7. **没有 `app.setName` 前的 `setAppUserModelId`**：Windows 任务栏/通知身份可能与旧版不同；不影响本轮四个模型，但发布前可补。

---

## 七、只读边界与残留

- 本文件之外，本轮只新增 `_tmp/qa5/`：`probe/`（探针源码、`result.json`、mock store/team/data）、`selftest2.log`、`probe2.log`、`selftest-root/`、`userdata/`、`temp/`、`shots-backup/`、`npm-cache/`。`_tmp` 是任务允许的测试临时目录；没有使用 `%TEMP%`。
- `src/` 七个文件 + `package.json` 的 SHA-256 前 16 位、字节数、mtime 在验收前后一致（见文首基线）；`package-lock.json` 未改。
- `团队/状态` 最新仍是 02:41/02:42 的 mtime；`data/` 最新仍是 04:46:31；真实团队/数据未被本轮运行写入。
- `selftest.png` / `selftest-flow.png` 运行前哈希 `6D230211BC89D012…` / `D2786F9D9A372603…`，selftest 会覆盖它们；运行后已从 `_tmp/qa5/shots-backup` 按原哈希还原（`selftest.png` 279,797 B `6D230211BC89D012`、`selftest-flow.png` 120,226 B `D2786F9D9A372603`）。`selftest-dsh.png` 未变（`6F161512F8DA6EC9`）。
- 仓库不是 git 仓库（`git status` 报 not a repository），无法用 diff 证明；以上用 SHA-256/字节数/mtime 作为只读证据。

---

## 八、建议修复顺序

1. **H2 + H3 + H4**（回执身份/锁）：先让角色会话自己 `boot → inbox → read → ack`，或至少校验会话存活/归属；降级回执不得清旧锁，`team:cancel` 必须能按旧锁释放。这是“6 会话严格照旧版”的根。
2. **H5 + H1**（名册/账本）：名册按项目隔离，禁止跨项目回退；旧账本根接入或明确迁移提示。
3. **H6 + M7**（删除/回滚）：删除时归档六会话/处理 workspace，明确团队账本数据去留；回滚时清理/标记 commit。
4. **M1 + M6 + M5**（看板真话/窗口）：`team:status` 按项目返回；窗口复用必须 reload；挂回 board-preload + control/file IPC。
5. **M2 + M3**（Owner/阶段）：Owner 写 `工作流.json` + 通知 PM、不可关/按 roundKey；阶段先 dev 后 test，review 位置统一。
6. **M4 + M8**（新建/数据根）：离线新建红色告警，数据根用可写 userData/D 固定目录，打包模式单独处理。
7. **P2 其他**：`npm run check` 增加 HTML/CSS/DOM 契约；补 `uncaughtException`/`main.log`；清理/接回半死 IPC。

---

**一句话结论**：DSH 主画面和“项目 → workspace → 六角色”的正常路径已经立住，自测 39/39、兼容 45/45、状态库 20/20；但**旧账本没接、回执仍由壳代跑、身份只认本地字符串、跨项目会串会话、删除会留 DSH 孤儿、看板/流程不按当前项目说真话**——当前版本可以演示，不应按“6 会话严格照旧版、所有功能已完成、旧数据可继承”验收发布。
