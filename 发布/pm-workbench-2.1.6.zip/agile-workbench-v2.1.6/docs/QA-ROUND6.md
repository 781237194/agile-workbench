# 敏捷工作台 v0.1 · 第六轮只读 QA（文件预览 / 看板浮窗 / Owner / 隔离 / 清理 / D 盘）

- 审计对象：`D:\deepseek\agile-workbench`
- 版本：0.1.0；Electron 33.4.11；运行时 Node 20.18.3
- 方式：只读代码审计 + `npm run check` + `npm run selftest`（D 盘沙盘）+ 现有团队状态/静态调用图核对
- 只读边界：未修改 `src/`、`package.json`、`node_modules` 或旧仓库；本文件是唯一新增的正式文件。临时产物见 §八。

## 一、结论速览

- `npm run check`：**PASS**（exit 0，5 个文件语法检查全过）。
- `npm run selftest`（`AWB_SELFTEST_ROOT=D:\deepseek\agile-workbench\_tmp\qa6-selftest-npm`）：**PASS**，`SELFTEST_OK`；状态库 20 项、兼容 45 项、映射 39 项、第五轮硬问题失败数均为 0。
- 本轮确认 **16 个真实问题：7 个高、9 个中**。其中既有“代码路径明确、可复现”的问题，也有“当前状态数据已经指向错误目录”的问题。
- 正向面：六角色 `6/0`（建 6、重复建 0）、`team:send`/`team:ack` 正常路径走旧协议、删除时归档 6 个会话、同名恢复复用 workspace 且 extras 0、看板 preload 的折叠/缩放/切项目/文件预览 API 能通。说明主链路不是空的。
- 关键缺口集中在五处：
  1. **文件预览的边界实际在渲染层被绕过**（4MB 覆盖 + `file://` 回退）。
  2. **删除项目会递归清掉旧团队账本里的任务/提案/提交/备份**，且 UI 对“会话保留”的承诺与后端归档行为相反。
  3. **DSH 离线时删除仍成功**，旧会话/workspace 留在 DSH；workspace 没有删除/归档调用，归档还传 `stopActivity:false`。
  4. **跨项目隔离仍可被旧 `团队会话.json` 污染**：一个项目目录里的旧清单能把另一个项目的 workspace/session 绑进来；收件人会话也没有核验。
  5. **异步 handler 用旧 store 覆盖新 store**，并发操作会丢任务/丢状态；旧流程的 inbox/read、角色自己 boot/ack 仍没有接回。

## 二、运行与正向证据

### 2.1 `npm run check`

```text
> agile-workbench@0.1.0 check
> node --check src/main.js && node --check src/preload.js && node --check src/renderer/app.js && node --check src/dsh-adapter.js && node --check src/team-tools.js
exit=0
```

### 2.2 `npm run selftest`（D 盘沙盘）

命令（先清掉继承的 `ELECTRON_RUN_AS_NODE`，见 §八）：

```powershell
Remove-Item Env:ELECTRON_RUN_AS_NODE
$env:AWB_SELFTEST_ROOT='D:\deepseek\agile-workbench\_tmp\qa6-selftest-npm'
npm run selftest
```

结果：

| 检查 | 结果 | 证据 |
|---|---|---|
| `SELFTEST_STORE` | 20 项，0 失败 | 原子写/备份/损坏恢复 |
| `SELFTEST_STATE` | 6 角色、8 阶段、team API 完整 | `SELFTEST_STATE` |
| `SELFTEST_FLOW` | 主流程可走 | 见下表 |
| `SELFTEST_COMPAT` | 45 项，0 失败 | 旧协议 45 项 |
| `SELFTEST_MAPPING_RESULT` | 39 项，0 失败 | 项目↔workspace↔角色映射 |
| `SELFTEST_ROUND5` | 0 失败 | `deleted.archived=6`、`recreated.sessionCount=6`、`extras=0` |
| 末尾 | `SELFTEST_OK` | exit 0 |

主流程关键字段（`SELFTEST_FLOW`）：

```text
stageAfterCreate   = intake
stageAfterTask     = owner
stageAfterApprove  = dispatch
stageAfterDone     = close
stageAfterProposal = review
provisionCreated   = 6
provisionAgain     = 0
messageSource      = team
ackSource          = team
deletedArchived    = 6
deletedRegistrations = 1
adoptedBefore      = 0
adoptedMapping     = 6
adoptedExtras      = 0
boardOk            = true
```

这组数据的含义：主链路（项目 → 六会话 → 任务 → Owner → 派单/回执 → 提案 → 删除 → 同名恢复）在 mock DSH 下是通的。**本报告的问题不是“主链路完全不能跑”，而是边界场景和承诺没有兑现。**

`SELFTEST_ROUND5` 的 `checks:2` 只统计 `round5.report` 的两个键（deleted/recreated），不是实际断言数；它的 `failures:0` 仍有效，但读日志时不要误以为只跑了 2 个断言。

### 2.3 静态证据的读法

本报告中的 `[静态]` 都是直接在源码里找到的调用路径，不是“看 UI 猜”。关键文件：

- `src/main.js`：IPC、store、删除/预览/会话核验。
- `src/renderer/app.js`：文件预览、Owner 弹窗、看板面板、警告 toast。
- `src/team-tools.js`：旧团队工具适配、Owner 落账、派单/回执、roster。
- `src/dsh-adapter.js`：DSH 只读/会话/workspace 协议。
- `团队/工具/lib/ops.mjs`、`团队/工具/lib/store.mjs`、`团队/工具/workspace.mjs`：旧协议真实语义。

## 三、问题清单（按严重级别）

| ID | 级别 | 主题 | 一句话 |
|---|---|---|---|
| H1 | 高 | 文件预览 | 渲染层把文本上限改成 4MB，并在 `files:read` 拒绝后回退 `file://`，绕过 realpath/大小限制 |
| H2 | 高 | 删除项目 | 删除记录递归删除旧团队状态目录（任务/提案/提交/备份/工作流），UI 只承诺清“团队登记” |
| H3 | 高 | 删除/DSH/workspace | DSH 离线仍删本地记录；归档 `stopActivity:false`，workspace 不删除，UI 不显示 warnings |
| H4 | 高 | 跨项目隔离 | 旧 `团队会话.json` 可直接把项目绑定到别的 workspace/session，`workspace.id` 命中即通过核验 |
| H5 | 高 | 派单/唤醒 | 只核验发件人；收件人没有会话仍能写旧邮件，`dsh:prompt` 直接按本地映射唤醒 |
| H6 | 高 | 并发写 | `team:send`/`ack`/`cancel`/删除跨 await 持有旧 store，最后整体覆盖，丢并发更新 |
| H7 | 高 | 旧流程 | 没有 inbox/read 入口；唤醒只有一句，旧四步被 `--no-wake` 丢掉；回执仍由壳进程代跑 |
| M1 | 中 | 看板浮窗 | 折叠后复用看板窗口只 `loadFile`，不恢复 bounds/resizable，切项目后停在 56px |
| M2 | 中 | Owner | 旧 `工作流.json` 写失败/PM 未通知时，UI 仍 toast 成功并推进阶段 |
| M3 | 中 | 新建/恢复 | DSH workspace 绑定失败的 warnings 不展示，离线仍绿 toast“项目已创建/已登记” |
| M4 | 中 | 旧派单锁 | 本地锁被自动清掉但旧 `派单锁.json` 仍在时，UI 没有“释放旧锁”入口，下一次派单永久 `PM_DISPATCH_PENDING` |
| M5 | 中 | 路径边界 | `project:create` 接受 `..`；`files:open` 只做字符串前缀；`team:open-project` 可向任意目录 scaffold |
| M6 | 中 | 旧账本同步 | 回滚不删 commit，旧看板仍计入；旧 `工作流.json` 只写不读 |
| M7 | 中 | 旧账本根 | 当前只是仓库内副本；`当前工作区.json`/两条登记指向不存在的 `项目\...`，旧 `项目/` 不被 discover |
| M8 | 中 | D 盘 | 数据根跟随 `__dirname`，没有 D 盘约束；asar/C 盘安装会写 C 或启动失败 |
| M9 | 中 | 阶段 | `requirement`/`review` 在正常路径不可达；Owner 通过后 `review` 才出现，收口后新提案又回退 `review` |

## 四、问题详情

### H1【高】文件预览边界在渲染层被绕过：4MB 覆盖 + `file://` 回退

**位置**

- `src/main.js:1385-1386`：默认文本 512KB、图片 8MB。
- `src/main.js:1445-1448`：`readProjectFile` 接受调用方传入的 `textMaxBytes`/`imageMaxBytes`，只判 `>0`，无上限。
- `src/main.js:2036-2044`：`files:read` 直接把 `p.textMaxBytes`/`p.imageMaxBytes` 传给 `readProjectFile`。
- `src/renderer/app.js:2890-2895`：预览主动传 `textMaxBytes: 4 * 1024 * 1024`、`imageMaxBytes: 8 * 1024 * 1024`。
- `src/renderer/app.js:2903-2915`：`files:read` 抛错后，对文本/图片/PDF **不重新抛出**，继续走 `projectFileUrl` + `file://`。
- `src/main.js:1407-1441`：`files:read` 本来有 `realpathSync` + 越界检查；但回退路径不会经过它。

**现象（静态可复现）**

1. 主进程默认 512KB，但界面打开预览时传 4MB；一个 1MB 的 `.md` 能正常显示，主进程的 512KB 上限在真实 UI 路径上不存在。
2. 一个 9MB 的 `.png`：`files:read` 拒绝 `FILE_TOO_LARGE`；`readProjectFileForPreview` 捕获后返回 `{ kind:'image', src: projectFileUrl(...) }`，`<img src="file:///...">` 仍然加载，8MB 上限失效。
3. 一个 `.pdf` 本来就不在 `FILE_TEXT_EXTENSIONS`/`FILE_IMAGE_MIME` 里，`files:read` 必然报 `FILE_TYPE_UNSUPPORTED`；回退路径直接 `<embed src="file://...">`，没有任何主进程校验。
4. 项目内放一个 Windows junction（普通用户可用 `mklink /J`）`out -> C:\Windows`，预览 `out/win.ini`：`files:read` 的 realpath 检查会拒绝（`FILE_PATH_OUTSIDE`），但回退的 `fetch(file:///.../out/win.ini)` 会跟随 junction 读到项目外的文件。图片/PDF 的 `<img>/<embed>` 同样跟随。
5. 任何渲染层调用者还可以直接给 `files:read` 传 `textMaxBytes: 1e12`，绕过 512KB；这不是“只有 UI 传 4MB”的问题，而是主进程把上限的控制权交给了调用方。

**影响**

- “只读预览只允许项目内、只允许安全大小”的承诺不成立；可读取项目外任意可预览文本/图片/PDF，可能泄露密钥、配置、系统文件。
- 4MB 文本会进入 DOM/Markdown 渲染，内存/卡顿风险；9MB 图片解码是典型的解压炸弹入口。
- 与 `files:read` 的 selftest 正向结果不矛盾：selftest 只测了默认 512KB 和 `../`，没有测 UI 覆盖、回退和 junction。

**建议**

- 删除 `files:read` 的 `textMaxBytes`/`imageMaxBytes` 入参，或主进程 `Math.min` 到硬上限；渲染层不得改变安全上限。
- 预览失败就显示结构化错误，**不要**在渲染层回退 `file://`；如果必须回退，回退前也要在主进程做 realpath + 大小 + 类型校验，并把结果返回。
- 对 SVG/PDF 这种主进程不支持的格式，不要直接 `<img>/<embed src=file://>`；要么主进程按二进制读并限大小，要么明确“用系统程序打开”。
- 增加 selftest：junction 指向项目外、1MB 文本、9MB 图片、PDF、`textMaxBytes:1e12`。

### H2【高】删除项目会递归清掉旧团队状态，UI 只承诺清“团队登记”

**位置**

- `src/main.js:2872-2888`：遍历 `团队/状态/项目/*/项目.json`，路径或名字匹配就 `fs.rmSync(path.join(projectsDir, entry.name), { recursive: true, force: true })`。
- `src/main.js:2885`：整目录删除，包含 `任务/`、`提案/`、`提交/`、`备份/`、`工作流.json`、`对账.*`、`产物.json`。
- `src/renderer/app.js:3944-3956`：删除确认文案只写“团队登记会一起清理”。
- `src/renderer/app.js:3953`：还写着“项目目录、文件、六角色 DSH 会话都会保留”。
- `src/main.js:2868-2870`：后端实际会归档六角色会话（与上面文案相反，见 H3）。

**数据证据**

当前 `团队/状态/项目/个人简历展示项目` 包含：

```text
任务/  备份/  提交/  提案/  产物.json  对账.json  对账.md  项目.json
```

`团队/状态/项目/个人博客项目` 还包含 `工作流.json`（ownerReview.status = skipped）。删除任一登记会把上述目录整体清掉。

**影响**

- 用户以为只是“移除本机记录/清理团队登记”，实际旧任务、提案、提交、备份、回执/工作流历史一起消失；重新登记也无法恢复。
- 删除前的 `_backup/commits` 在项目目录里可能还在，但团队账本中的 `提交/`、`备份/`、`对账` 已丢，审计链断裂。
- 如果 `fs.rmSync` 因文件占用失败，外层 `try/catch` 静默吞掉，`removed.registrations` 可能为空/不完整但 UI 仍显示成功；同名重建可能继续撞旧登记。

**建议**

- 把“移除登记”和“清除历史”拆成两个动作；默认只删 `项目.json`/索引，保留 `任务/提案/提交/备份/工作流` 并标记 `deletedAt`。
- 真正清除要二次确认，明确列出将删除的文件类型；失败要回传 warnings。
- UI 文案改成实际行为；如果决定归档会话，就不要再写“会话都会保留”。

### H3【高】DSH 离线仍完成删除；workspace 不清理，归档不停活动

**位置**

- `src/main.js:2867-2870`：`archiveProjectRoleSessions(project)` 失败也继续删除。
- `src/main.js:1587-1644`：`archiveProjectRoleSessions` 在 `dsh.listSessions` 失败时返回 `ok:false` + `failed`，但没有持久化待清理队列。
- `src/main.js:2920-2938`：只把 `workspace.json` 的 `dshWorkspaceId`/`engineUrl` 删掉，写 `previousWorkspaceId`；没有调用任何 workspace 删除/归档。
- `src/dsh-adapter.js:192-265`：适配层只有 `ensureWorkspace/createSession/prompt/rename/archiveSession`，没有 workspace 删除。
- `src/dsh-adapter.js:260-264`：`archiveSession` 固定 `stopActivity: false`。
- `src/main.js:2952`：删除结果带 `warnings`；`src/renderer/app.js:3967-3976` 完全没用 `r.warnings`，仍 toast“已移除本机记录”。

**现象**

- DSH 离线/凭据缺失：`archiveProjectRoleSessions` 返回失败；删除继续执行，store、团队登记、`团队会话.json`、`workspace.json` 绑定全部被清；六个会话留在 DSH，项目已从 UI 消失，用户没有入口再找到它们。
- DSH 在线但部分归档失败：同样 `ok:false`，删除继续；失败列表只在这一条 IPC 的返回值里，没有重试。
- 归档调用 `stopActivity:false`：正在运行的会话可能继续执行，删除项目后仍可能写项目目录/调用工具。
- workspace 本身不删除；如果项目目录被删/移动，workspace 指向不存在的路径。同名重建会按路径复用旧 workspace（selftest 已验证复用），但旧 workspace 里的残留会话/成员可能被一起带回来。

**影响**

- 孤儿 DSH 会话/运行中的 agent；无法在 UI 里定位、停止或清理。
- 删除的“成功”是本地记录层面的成功，不是 DSH 资源层面的成功；审计/隐私/资源都不闭环。

**建议**

- 归档失败时阻止删除或写 `pendingCleanup`（项目 id、teamName、sessionIds、workspaceId），恢复在线后重试；不要只返回 warnings。
- `archiveSession` 传 `stopActivity:true`（或先 stop 再 archive）。
- 如果 DSH 没有 workspace 删除 API，至少归档所有成员、清空 workspace 绑定，并在 UI 明示“DSH workspace 保留”；有 API 就调用。
- 删除确认里列出 DSH 侧影响；UI 展示 warnings 并提供“重试清理”。

### H4【高】旧 `团队会话.json` 可把项目绑定到别的 workspace/session

**位置**

- `src/main.js:604-617`：`sessionsFromManifest` 直接信任 `manifest.workspaceId`、`manifest.workspace`、`roles[].sessionId`，没有校验 manifest 是否属于当前项目路径。
- `src/main.js:540-549`：`activateWorkspace` 在项目没有 `sessions` 时调用它，并 `persistSessionMapping(project.id, restored.sessions, { workspaceId: restored.workspaceId, workspacePath: restored.workspacePath })`。
- `src/main.js:165-186`：`workspaceOf` 只要 `workspace.id` 存在就 `bound:true`。
- `src/main.js:335-341`：`bindProjectWorkspace` 看到 `current.bound && !current.pending` 直接返回 `WORKSPACE_ALREADY_BOUND`，不会向 DSH 核对 workspace 路径。
- `src/main.js:1490-1503`：`sessionInProjectWorkspace` 先看 `workspace.id`，相等就通过；cwd 只在没有 id 时兜底。
- `src/main.js:1512-1556`：`verifyProjectRoleSession` 依赖上面的判断。

**现象（静态可复现）**

1. 把项目 A 目录里的 `团队会话.json` 复制到项目 B 目录（或把 A 目录复制/改名为 B，旧清单还在）。
2. 删除 B 的本机记录后重新 `adopt`，或让 B 的 `sessions` 为空后 `project:select(B)`。
3. `sessionsFromManifest(B.path)` 读到 A 的 `workspaceId=A`、`workspace=A 的路径`、六个 A 的 sessionId；`persistSessionMapping` 把它们写成 B 的 `workspace.id`/`sessions`。
4. `bindProjectWorkspace` 因为 `workspace.id` 非空、`bound:true` 直接跳过 DSH；`verifyProjectRoleSession(B, from)` 看到 workspace id 相等，判定“属于当前项目”。
5. `team:send`/`team:ack` 因此可以拿 A 的会话在 B 名下操作；`dsh:team-status` 也会把 B 的 workspaceId 显示成 A。

当前真实数据里 `项目/微光作品集/团队会话.json`、`项目/测试工作台项目/团队会话.json` 都带 `workspace` 和 `workspaceId`，证明这个格式就在项目目录里，复制/迁移很容易触发。

**影响**

- 跨项目会话/数据泄露；B 的派单/回执/唤醒可能落到 A 的 agent。
- 目录移动后继续使用旧 workspace，agent 仍写旧 cwd；与“1 项目 = 1 workspace”冲突。

**建议**

- `sessionsFromManifest` 只在 `manifest.workspace` realpath 等于当前项目路径、且 `workspaceId` 能被 DSH 核对时才接受；否则丢弃并重新 `workspace/create`。
- `bindProjectWorkspace` 即使 `bound` 也要校验 `workspace.path` 与当前项目路径；路径变更时强制重新绑定。
- `sessionInProjectWorkspace` 不能只看 workspace id；至少同时要求 `workspace.path` 与 `project.path` 一致，或 cwd 一致。
- 在恢复/采纳时清掉旧清单或标记 `manifestSource`，并加 selftest 覆盖“B 目录有 A 的清单”。

### H5【高】派单只核验发件人；收件人无会话仍能写旧邮件，唤醒也没有核验

**位置**

- `src/main.js:3260-3268`：`sessionId` 只取收件角色映射；没有就往下走。
- `src/main.js:3281-3285`：发送前只 `verifyProjectRoleSession(project, from, senderSession)` 核验**发件人**。
- `src/main.js:3287`：`teamTools.syncRoster(teamName, project.sessions)` 把没有会话的成员写成空 sessionId，但保留 `status:'active'`。
- `src/team-tools.js:471-483`：`syncRoster` 只改 `member.sessionId`，不改 `status`。
- `src/team-tools.js:1426-1448`：`sendDispatch` 只检查 `recipient.status === 'active'`，不检查 `recipient.sessionId`。
- `团队/工具/lib/store.mjs` 的 `sendMessage` 同样只要求 `to.status === 'active'`。
- `src/main.js:3794-3801`：`dsh:prompt` 直接 `project.sessions[payload.role]` 后 `dsh.prompt`，没有 `verifyProjectRoleSession`。

**现象**

1. 当前项目只有 PM 会话（或部分角色），`team:send({role:'analyst'})`：`syncRoster` 把 analyst 的 sessionId 清空但 status 保持 active；`sendDispatch` 认为收件人 ready，旧 `team.mjs send` 写入 `邮箱/analyst/new/*.json` 并写派单锁；主进程因为 `sessionId` 为空，不置本地锁、不唤醒。返回 `ok:true`，`wake.ok:false`。
2. 这条消息之后无法被该角色回执：`team:ack` 查 `project.sessions.analyst` 为空，直接 `SESSION_IDENTITY_MISSING`。消息成为死信。
3. 如果 `project.sessions[role]` 是别的项目的旧会话（见 H4），`sendDispatch` 走 roster，`dsh.prompt` 直接唤醒该会话，没有 workspace 核验。
4. `dsh:prompt` 的“唤醒角色”同样只信本地映射，可向已归档/已属于别的项目的会话发 prompt。

**影响**

- PM 以为派单成功，实际收件人不存在；旧账本多一条永不回执的消息。
- 跨项目/过期会话收到任务；角色互发同样受影响。

**建议**

- `team:send` 在写旧协议前同时核验**收件人**：`verifyProjectRoleSession(project, role)`；收件人无会话直接 `SESSION_ID_REQUIRED`，不要写旧邮件。
- `sendDispatch` 要求 `recipient.sessionId` 非空且属于当前项目，不能拿 status 代替。
- `dsh:prompt` 使用同一核验；对已归档/不在 workspace 的会话返回结构化错误。
- 增加 selftest：只有 PM 的项目向 analyst 派单必须被拒绝；收件人映射指向别的 workspace 必须被拒绝。

### H6【高】异步 handler 持有旧 store，最后整体覆盖，丢并发更新

**位置**

- `src/main.js:3226-3229`：`team:send` 先 `readStore()` 并拿 `project` 对象。
- `src/main.js:3269`、`3281`：在写之前 `await ensureTeamName`、`verifyProjectRoleSession`（网络/子进程）。
- `src/main.js:3390`：最后 `writeStore(store)`，写回的是 await 之前的整库快照。
- `team:ack`：`3470-3472` 读，`3521/3524/3532` await，`3614` 写。
- `team:cancel`：`3419-3422` 读，`3434` await，`3466` 写。
- `project:delete-record`：`2854-2857` 读，`2870` await 归档，`2941` 写。
- `src/main.js:1095-1110`：`writeStore` 没有锁/版本号/CAS，临时文件名固定 `.tmp`。

**现象**

- 用户在 DSH 慢的时候点“派单”，再点“新建任务/改任务/建提案”：后一个 handler 已经写入 store；派单 handler 的 await 结束后用旧 `store` 整体 `writeStore`，后一个任务/提案被覆盖丢失。
- 删除与任务更新并发时，删除 handler 用旧 store 过滤后写回，可能把期间其他项目的更新一起回退；如果 `writeStore` 失败，前面的 `rmSync`/归档已经执行，无法回滚。
- `statePayload()` 里的 `reconcileExpiredLocks` 也会写 store，和业务 handler 并发同样可能互相覆盖。

**影响**

- 数据丢失是静默的；UI 只看到操作成功，刷新后任务/提案/消息消失。
- 锁状态/消息与 store 可能不一致，进一步触发 H4/H5。

**建议**

- 所有 store 写操作串行化（单一 mutation queue/async mutex）；await 之后重新 `readStore()`，只改目标项目/字段，再写。
- 用 `version`/`updatedAt` 做 CAS，冲突时重读重试；至少对 `pendingAck`/`sessions` 用按项目锁。
- 删除先做可回滚的本地标记，再执行 DSH 归档与目录清理；失败可恢复。
- 把 `writeStore` 的临时文件名改为唯一，避免并发写同一个 `.tmp`。

### H7【高】旧流程消息闭环仍缺：没有 inbox/read，唤醒四步被丢掉，回执仍是壳代跑

**位置**

- `src/team-tools.js:1578-1595`：存在 `inboxFor`，`1812` 也导出了。
- `src/preload.js`：没有 `teamInbox`/`teamRead`（grep 无 `inbox`）。
- `src/main.js`：没有 `ipcMain.handle('team:inbox')`/`read`；只有 send/ack/cancel。
- `src/team-tools.js:1461-1465`：`sendDispatch` 固定传 `--no-wake`，旧工具的唤醒文案被禁用。
- `团队/工具/lib/ops.mjs:394-397`：旧工具本来有 `boot --role` → `inbox --all` → `read --id` → `ack --id` 四步。
- `src/main.js:3394`：主进程自己只发一句“请先确认角色、任务和边界，完成后回执；不要巡检全队”，没有四步、没有令牌/命令。
- `src/main.js:3520-3546`：`team:ack` 调用 `teamTools.ackDispatch`，实际是主进程 `team.mjs ack`，不是角色会话执行。
- `src/main.js:3587`：降级/壳回执也可能写 `identitySource`；只有 `source==='team'` 才是 `verified-session`，但“verified”只证明会话存在，不证明角色执行了 ack。

**现象**

- 角色收到派单后，模型只看到一句“完成后回执”，不知道要 `boot`/`inbox`/`read`/`ack`；旧协议要求的四步不会发生。
- 工作台 UI 没有收件箱/已读页面；`邮箱` 里由旧 CLI 或别的角色写入的消息，团队台只读 `project.messages` 本地镜像，看不到。
- 用户点“记录回执”时，回执由壳进程写 `回执.jsonl`；`回执.jsonl` 里的 `sessionId` 是壳传入的映射，不是角色自己 boot 的 token。
- 旧工具 `send` 的 `--no-wake` 说明作者是有意让主进程唤醒；但主进程没有保留旧四步，导致“角色自己消费消息”的链路断掉。

**影响**

- “旧版最后跑通流程”不成立：消息能写，但没有角色消费/回执闭环；PM 收件箱在 UI 不可见；旧协议事件链的身份语义被壳替代。
- 一旦主进程崩溃/重启，邮箱消息和本地镜像可能分叉。

**建议**

- 增加 `team:inbox`/`team:read` IPC + preload + 团队台收件箱 UI；显示 `new/cur`、已读水位、消息详情。
- 唤醒文案恢复旧四步（或让角色通过工具自己 boot 拿 token）；不要在 `--no-wake` 后再发简化句。
- 回执要么由角色会话执行，要么在 `回执.jsonl` 明确写 `actor:'workbench-shell'`，不要用 `verified-session` 冒充角色执行。
- 增加端到端 selftest：角色收到派单 → 自己 inbox/read/ack → 回执身份可追溯。

### M1【中】看板浮窗折叠后复用不复位：窗口停在 56px

**位置**

- `src/main.js:1928-1941`：`collapse` 保存 `teamBoardExpandedBounds`，`setResizable(false)`，高度 56；`expand` 恢复。
- `src/main.js:2786-2792`：`team:board-old` 窗口存活时只 `loadFile` + `show/focus`，不重置 bounds/resizable。
- `src/main.js:2828-2845`：`team:board-select-project` 也只 `loadFile`。
- `src/main.js:2806-2811`：`closed` 才清 `teamBoardExpandedBounds`。

**现象**

1. 打开看板，点“—”（collapse）：窗口 56px，`resizable:false`，body 加 `collapsed`。
2. 不关窗口，点主界面的“独立浮窗”/看板内切项目：`team:board-old` 复用窗口，`loadFile` 新看板；新 HTML 的 body 没有 `collapsed`，但窗口仍是 56px、不可缩放。
3. 新看板只露出标题条；点击“—”会把 body 切成 collapsed，`teamBoardExpandedBounds` 仍是折叠前的旧 bounds；再点一次才恢复。用户看到的是“看板打不开/只有一条”。

**影响**

- 任务要求“折叠/展开/切项目真可用”只在单次窗口内成立；复用后不可用。
- selftest 只测了同一窗口内 collapse→expand，没有测“折叠后切项目/再次打开”。

**建议**

- 每次 `team:board-old`/`team:board-select-project` 加载新看板时重置：`teamBoardExpandedBounds=null`、`setResizable(true)`、恢复默认 bounds，再按需折叠。
- 折叠状态存到 `teamBoardState` 并随新 HTML 的 body class 同步，而不是只改窗口。
- 加 selftest：折叠 → 切项目 → 断言高度恢复、可缩放。

### M2【中】Owner 落账/PM 通知失败被 UI 吞掉

**位置**

- `src/main.js:2749-2771`：`owner:decide` 写本地后调用 `recordOwnerDecision`，返回 `warnings`。
- `src/team-tools.js:818-892`：`NO_TEAM_PROJECT`/`NO_TEAM_STATE`/`OWNER_NOTE_MISSING`/`OWNER_NOTE_FAILED` 都只变成 warning；`ok:true`。
- `src/renderer/app.js:3370-3379`：`submit` 只 `applyState` + toast 成功，完全不读 `r.warnings`。
- `src/renderer/app.js:3361-3367`：Owner 弹窗 `closable:true`，没有旧版 `bossreview` 自动闸门。

**现象**

- 删除团队登记后点“Owner 通过”：本地 `ownerReview` 变成 approved，阶段进入 dispatch，toast“已通过 Owner 评审”；旧 `工作流.json` 没有写，PM 收件箱没有 `owner-review`。
- `owner-note.mjs` 缺失/失败时同样静默；用户没有任何“旧账本没落”的提示。
- 弹窗可关闭且本轮不再自动弹，流程可能停在 owner 阶段无人处理。

**影响**

- 新壳阶段推进、旧账本仍是未评审；Owner 决定没有通知 PM，旧看板/流程看到的状态不一致。
- 没有重试/补偿，之后只能靠人工再点一次。

**建议**

- UI 必须展示 `warnings`；旧账本/PM 通知失败时不要 toast 成功，至少标黄并提供“重试同步”。
- `recordOwnerDecision` 返回 `pendingSync` 并持久化，下次启动/切项目重试。
- 统一走 `workflow:owner` 一个入口，避免 `owner:decide` 与 `workflow:owner` 漂移。
- 是否恢复自动闸门是产品决策；如果保持可关闭，至少要有显式“未落旧账”标记。

### M3【中】新建/恢复项目时 DSH 绑定失败不展示，离线仍绿 toast

**位置**

- `src/main.js:2090-2100`：`project:create` 返回 `warnings`（团队登记失败 + `activation.warnings`）。
- `src/main.js:2222-2234`：`project:adopt` 同样。
- `src/renderer/app.js:3187-3190`：创建成功 toast 只判断 `r.team && !r.team.ok`，不看 `r.warnings`。
- `src/renderer/app.js:3202-3204`：恢复登记 toast 固定“项目已登记”，不看 warnings。

**现象**

- DSH 离线时，`syncTeamProject` 仍可能成功（`workspace.mjs ensure` 是本地 scaffold/register），所以 `r.team.ok` 为 true；失败的是 `activateWorkspace` 的 DSH workspace binding，放在 `r.warnings`。UI 显示绿色“项目已创建”。
- 用户进入项目后“建团队/派单”才报 DSH 错误；项目状态是 pending workspace，但界面没有提示。
- 恢复项目同理，用户以为 DSH 会话已经接上。

**影响**

- 误判“项目/团队已就绪”；排障成本高；与 H5 的死信并发叠加。

**建议**

- `project:create`/`adopt` 的 toast/状态卡展示 `warnings` 与 `workspace.pending`；DSH 离线时明确“项目已建，DSH 工作区待绑定”。
- 在项目列表/顶栏加 pending 标记；提供“重试绑定”按钮。
- 增加 selftest：DSH 离线创建项目，UI 不得显示纯成功。

### M4【中】本地锁被清、旧 `派单锁.json` 还在时，UI 没有释放入口

**位置**

- `src/main.js:3244-3257`：`team:send` 过期分支只有在 `stale.teamMessageId && tool.available && project.teamName` 时才释放旧锁；否则直接 `clearPendingAck`，本地锁没了、旧锁还在。
- `src/main.js:1328-1343`：`reconcileExpiredLocks` 对过期本地锁同样先释放再清；`releaseOldDispatchLock` 失败（`NO_LOCK`/`LOCK_READ_FAILED`/`LOCK_MISMATCH`）只加 event，仍 `clearPendingAck`。
- `src/main.js:1559-1584`：`releaseOldDispatchLock` 在本地消息无 `teamMessageId` 时用 `expected=''`，会按当前旧锁自身 id 释放；如果旧锁属于别的消息，可能释放错锁。
- `src/renderer/app.js:1605`、`2241-2249`：只有 `message.id === p.pendingAck` 时才渲染“撤销派单”。
- `src/renderer/app.js:1648`：`cancelPending` 只有这个按钮会调。

**现象**

1. 旧记录没有 `teamName`（旧 store 常见），或消息没有 `teamMessageId`（降级本地消息），或 `releaseDispatchLock` 抛 `LOCK_READ_FAILED`。
2. 10 分钟 TTL 到/刷新 `app:state`：本地 `pendingAck` 被清；旧 `派单锁.json` 仍在。
3. UI 显示“当前没有待回执消息”，没有“撤销派单”按钮。
4. 下一次 PM 派单：`team.mjs send` 返回 `PM_DISPATCH_PENDING`；`team:send` 抛错告诉用户“先等回执、撤销”，但 UI 没有撤销入口。用户只能手工删 `团队/状态/项目/<slug>/派单锁.json`。

**影响**

- 项目被旧锁永久卡住；错误提示指向一个不存在的按钮。
- `team:cancel` API 本身能按旧锁释放，但没有 UI 入口；这是“后端有、产品不可用”。

**建议**

- 只有旧锁确认释放成功后才清本地锁；失败保留本地并显示“旧锁未释放”。
- 在团队台/派单卡片加一个不依赖 `pendingAck` 的“释放旧派单锁”入口，调用 `team:cancel({projectId})`（无 messageId 时按旧锁释放）。
- `team:send` 持久化 `ensureTeamName` 的结果，避免 `project.teamName` 为空导致过期分支跳过释放。
- 加 selftest：无本地 pending、只有旧锁时，UI/接口能一键释放。

### M5【中】路径边界三处不一致：`project:create` 接受 `..`，`files:open` 不 realpath，`team:open-project` 可向任意目录 scaffold

**位置 / 子问题**

1. **`project:create` 的 `.`/`..`**
   - `src/main.js:1114`：`cleanName` 只替换 `\/:*?"<>|`，不拒绝 `.`/`..`，也不去掉 Windows 末尾点/空格。
   - `src/main.js:1646-1651`：`target = path.resolve(root, name)`，没有 `isInsidePath(root,target)` 或 `.`/`..` 检查。
   - 对照 `src/main.js:2603`：`team:workspace:create` 明确拒绝 `.`/`..`，两个入口不一致。
   - 结果：`createProject({name:'..', root:'D:\\...\\_tmp\\empty\\child'})` 会把项目建到 `_tmp\\empty`（root 的父目录）；如果该目录为空，会创建六个角色目录/`项目信息.md` 并登记。`name:'.'` 会把 root 本身当项目。带末尾点的名字在 Windows 会被系统规范化，和 store 里的 path 字符串不一致。

2. **`files:open` 的 symlink/junction**
   - `src/main.js:2025-2034`：`target = path.resolve(root, rel)` 后只做 `startsWith(root + sep)` 字符串判断，`shell.openPath(target)`；没有 `realpathSync`，也没有 `statSync().isFile()`。
   - `src/main.js:1407-1441`：`files:read` 有 realpath/越界/普通文件检查，两个入口的安全等级不同。
   - 项目内 `out -> C:\\Windows` junction，`files:open({rel:'out/notepad.exe'})` 会通过前缀检查并由系统打开项目外文件；`.lnk`/`.bat` 也可被打开。
   - Windows 普通用户可以创建 junction（`mklink /J`，不需要管理员），所以这不是“需要管理员才能利用”。

3. **`team:open-project` 向任意目录 scaffold**
   - `src/main.js:2522-2572`：只检查目录存在、不是 `LOCAL_DATA`，然后 `launchSessions`。
   - `src/team-tools.js:launchSessionsUnlocked` 在 `!dryRun` 时调 `ensureProject`；`团队/工具/workspace.mjs:297-305` 的 `ensure` 调 `scaffold`。
   - `scaffold` 写入 `README.md`、`协作准则.md`、`项目信息.md`、`项目索引.md`、`项目铁律.md`、六个角色目录、`site/`、`_tmp/`、`需求/`。
   - 用户通过“打开已有项目文件夹”选中 `D:\\deepseek\\agile-workbench`（仓库根）、`C:\\Windows`（有权限时）或 `D:\\`，会被写入角色目录/项目文件；`createProject` 还会拒绝非空目录，但 `team:open-project` 故意不要求 `项目信息.md`，所以没有这层保护。

**影响**

- 写入项目根之外/系统目录/源码目录；`project:create` 可把项目建到父目录；`files:open` 可打开项目外程序/文件。
- 与“只读预览/项目内文件”的安全承诺冲突；也违反本次审计“不修改 src”的边界。

**建议**

- 抽出统一的 `resolveInsideProject()`：`path.resolve` + `realpathSync` + `path.relative` 不能以 `..` 开头 + `isFile`；`files:read`/`files:open`/`proposal:apply`/`proposal:rollback` 共用。
- `project:create` 拒绝 `.`/`..`、空名、末尾点/空格；校验 `target` 在 `root` 内；`root` 不能是 `ROOT/src`/`node_modules`/`团队`/`data` 等。
- `team:open-project` 只允许明确的项目根（`ROOT/projects`、`ROOT/项目` 或用户确认的外部目录）；外部目录要求空目录或已有 `项目信息.md`，不要默认 scaffold。

### M6【中】回滚后旧看板仍计入提交；旧 `工作流.json` 只写不读

**位置**

- `src/main.js:3216-3224`：`proposal:rollback` 只把 `proposal.applied=false`，不删除/标记 `project.commits` 里的 commit。
- `src/team-tools.js:1058-1092`：`syncWorkbenchBoard` 遍历 `project.commits` 全部写入 `提交/<id>.json`，不检查 proposal 是否已回滚。
- `src/team-tools.js:1157`：`generateBoard` 直接返回旧工具 `value.summary`；旧工具按 `提交/` 目录计数，因此回滚后仍会计入。
- `src/main.js:1842-1862`：`workflowSnapshot` 的 `ownerReview`/阶段完全读本地 `project.ownerReview`，没有读取 `<团队>/状态/项目/<slug>/工作流.json`。
- 真实旧数据：`团队/状态/项目/个人博客项目/工作流.json` 有 `ownerReview.status='skipped'`，但 adopt 后 `workflow:get` 只会返回本地 `optional`。

**现象**

- 应用提案 → 生成看板（commits=1）→ 回滚 → 再生成看板：`summary.commits` 仍为 1，旧看板“提交闭环”仍显示已回滚的提交；`提交/` 文件仍在。
- 旧项目的 Owner 决定（skipped/approved）在 adopt 后不回显；旧 UI 修改 `工作流.json` 也不会被新壳看到。新壳写入后，旧 UI 可能又覆盖，形成双向漂移。

**影响**

- 旧看板/统计虚高，审计链把已回滚的提交当成有效提交。
- 旧项目的 Owner 状态“看起来没做”，可能导致重复评审/重复派单。

**建议**

- 回滚时给 commit 加 `rolledBackAt` 或从 `project.commits` 移除；`syncWorkbenchBoard` 只写未回滚提交，并删除/标记对应的旧 `提交/<id>.json`。
- 读旧 `工作流.json` 作为迁移输入（带 `source:'legacy-workflow'`），或明确单向同步 + 冲突提示；不要让 `workflowSnapshot` 完全忽略它。
- 增加 selftest：apply→board→rollback→board，commits 必须下降；adopt 带 `工作流.json` 的项目，Owner 状态必须可见。

### M7【中】旧账本是仓库内副本，且当前指针悬空；旧 `项目/` 不被 discover

**位置**

- `src/team-tools.js:283-285`：`initialRoot = options.teamRoot || process.env.TEAM_ROOT || path.join(repoRoot(), '团队')`。
- `src/main.js:1763-1777`：`findProjectByName` 只查 store、团队登记、`ROOT/projects`，不查旧 `ROOT/项目`。
- `src/main.js:2131-2155`：`project:discover` 只扫 `ROOT/projects` + 团队登记，不扫 `ROOT/项目`。
- `src/team-tools.js:691-703`：`localProjectDirs` 只扫仓库 `projects/`。
- `src/team-tools.js:715`：`current = projects.find(item => item.current)` 不过滤 `exists:false`。
- `src/main.js:2281`：`team:workspaces` 的 `current` 同样不过滤。
- 旧工具基准：`团队/工具/lib/core.mjs:14-16,34` 的 `PROJECTS_ROOT`/`PATHS.projects` 是 `WORKSPACE/项目`（中文目录）。

**数据证据**

- 新仓库 `团队/状态` 有 665 个文件、约 1,658,740 B，最新 2026-11-05 07:05；旧仓库 `D:\deepseek\工作台\团队\状态` 也是 665 个文件、约 1,675,433 B，最新 2026-11-03 09:01。`团队.json` 两边 SHA-256 相同（B6990E…），说明是拷贝起点，但之后各自演化。
- `团队/状态/当前工作区.json` 的 `path` 是 `D:\deepseek\agile-workbench\项目\个人简历展示项目`，实际 `Test-Path` 为 false。
- `团队/状态/项目/个人简历展示项目/项目.json`、`个人博客项目/项目.json` 的 `path` 同样指向不存在的 `项目\...`。
- 新仓库 `项目/` 下只有 `六人敏捷工作区/团队工作台改造/小鱼/微光作品集/测试工作台项目`，没有上述两个目录。

**现象**

- 打开团队台/工作区清单，`current` 可能是 `个人简历展示项目`，但目录不存在；选择/生成看板/启动团队会走 `PROJECT_DIR_MISSING` 或写入悬空 `当前工作区.json`。
- 旧 `项目/` 下未登记的项目不会被 `project:discover`/`findProjectByName` 找到；按名恢复只查新 `projects/`。
- 新壳写新副本，旧壳写旧根；两本账不会同步，用户看到的是“拷贝那一刻”的旧数据。

**影响**

- “旧版最后跑通”的当前项目可能是幽灵；旧项目无法按名恢复；审计/回执可能写错根。
- 开源/迁移时 `团队/状态` 被 `.gitignore` 忽略，新用户不会看到这些；但如果仓库拷贝，用户会继承悬空指针。

**建议**

- 明确唯一账本根：要么配置 `TEAM_ROOT` 指向旧根并做只读/迁移，要么显式迁移到新根并在 UI 显示 `teamRoot/source`；不要默认“仓库副本”。
- 过滤/修复悬空 `current`；`listWorkspaces` 对 `exists:false` 标记“目录缺失”，不要当 current。
- 扫描 `项目/` 与 `projects/` 两处做迁移；`findProjectByName`/`project:discover` 都覆盖。
- 清理/迁移旧 `团队/状态/会话.json`（当前还指向旧项目）。

### M8【中】D 盘只是“当前仓库恰好在 D”，不是产品保证

**位置**

- `src/main.js:9-25`：`ROOT = path.join(__dirname,'..')`；`LOCAL_DATA = ROOT/data`；`USER_DATA = DATA_ROOT/userdata`；`TEMP_ROOT = DATA_ROOT/tmp`；`DSH_CONFIG_FILE = DATA_ROOT/dsh.json`。
- `src/main.js:82-84`：`app.setPath('userData'/'sessionData'/'temp')` 指到 `DATA_ROOT`。
- `src/team-tools.js:284`：`TEAM_ROOT` 默认 `repoRoot()/团队`。
- `src/main.js:1649`：新建项目默认 `ROOT/projects`。
- `package.json` scripts 未设置 `AWB_DATA_DIR`/`TEAM_ROOT`；`start.cmd` 只清 `ELECTRON_RUN_AS_NODE`；README 未说明这两个环境变量。
- 没有 Electron builder/asar unpack 配置；`fs.mkdirSync(LOCAL_DATA)` 在 `app.whenReady` 之前执行。

**现象 / 证据**

- 本次运行（仓库在 D）`data/`、`data/userdata/`、`data/tmp/`、`团队/状态/` 全部在 D；selftest 沙盘在 `_tmp/qa6-selftest-npm`，也在 D。这是正向的。
- C 盘仍有 `C:\Users\Admin\AppData\Roaming\敏捷工作台`：72 个文件、约 12.57MB，最新 2026-11-05 02:33:40；本轮 07:49/08:01 的 selftest 没有更新它。说明历史上确实落过 C；当前靠 `app.setPath` 避免，但没有产品级约束。
- 把仓库复制到 C 后 `npm start`：`ROOT` 变 C，所有数据/团队状态/DSH 配置写 C；`AWB_DATA_DIR`/`TEAM_ROOT` 没有文档，用户不会设。
- 打包成 asar 后：`__dirname` 在 `app.asar/src`，`ROOT/data`/`ROOT/团队` 在 asar 内，`fs.mkdirSync`/团队工具写文件会失败（asar 只读），应用可能在启动阶段就抛错。

**影响**

- “只写 D 盘”不是产品承诺，只是当前目录巧合；换机/换目录/打包就破。
- 数据和团队状态分裂在 `data/` 与 `团队/` 两个根，备份/迁移/清理都容易漏。

**建议**

- 定义单一 `DATA_ROOT`（默认 D 盘固定路径，如 `D:\deepseek\agile-workbench-data` 或用户选择），`workbench.json`、`dsh.json`、`teamRoot`、临时目录都在其下；用 `AWB_DATA_DIR`/`TEAM_ROOT` 覆盖并写进 README/start.cmd。
- 启动时校验根是否可写，给出明确错误；打包时把数据根放 asar 外（`asarUnpack`/外部目录）。
- 加 selftest 断言 `app.getPath('userData'/'temp')` 与 `TEAM_ROOT` 都在配置的 D 根，且不产生 C 盘新文件。

### M9【中】阶段 `requirement`/`review` 在正常路径不可达，收口后新提案又回退

**位置**

- `src/main.js:133-142`：`STAGES = intake → requirement → review → owner → dispatch → dev → test → close`。
- `docs/ARCHITECTURE.md:45-54`：同样写 `intake -> requirement -> review -> owner -> dispatch -> dev -> test -> close`。
- `src/main.js:1272-1287`：`deriveStage`：
  - 无任务 → intake；
  - Owner rejected → requirement；
  - Owner 未 approved/skipped → owner（**先于 review**）；
  - 有 proposal.status==='review' → review（**在 Owner 之后**）；
  - 全部完成 → close；
  - tester 未完成 → test；
  - programmer 未完成 → dev；
  - 否则 dispatch。
- `src/renderer/app.js` 的 `FLOW_ROWS`/流程图按 `state.stages` 顺序画（review 在 owner 前）。

**现象（selftest 已直接证明）**

- 新建项目：`intake`。
- 建第一个任务：`stageAfterTask = owner`（不是 requirement/review）。
- Owner approve：`dispatch`。
- 全部任务完成：`close`。
- 再建提案：`stageAfterProposal = review`（从 close 回退）。
- `requirement` 只有 Owner rejected 才会出现；`review` 只有在 Owner 已通过且仍有提案时出现。正常向前路径是 `intake → owner → dispatch → close`，`requirement/review` 不是可顺序走的阶段。

**影响**

- 8 阶段流程图与真实状态机不一致；用户无法看到“需求/产品评审”阶段，旧版 `computeWorkflow` 的 `requirement/review/bossreview` 语义无法对齐。
- 收口后新建提案会把阶段从 close 拉回 review，流程状态倒退；看板/Owner 闸门可能重复触发。

**建议**

- 先定 canonical 顺序：如果要旧版语义，`review` 应在 `owner` 前（有需求/产品任务或提案时），`owner` 只在 `bossreview`；如果要新语义，就把 `STAGES`/文档/流程图改成 `intake → owner → review → dispatch...`，不要画 8 个假阶段。
- `close` 后新建提案应进入显式的 `iterate`（旧版有）而不是回退 `review`。
- 增加完整序列 selftest：intake→requirement→review→owner→dispatch→dev→test→close；不要只测 `stageAfterTask=owner`。

## 五、按任务重点逐项判定

| 重点 | 判定 | 说明 |
|---|---|---|
| 文件预览安全/路径/大小 | **FAIL** | H1（UI 4MB + `file://` 回退）、M5（`files:open` 无 realpath）。`files:read` 本身的 realpath/默认上限是好的，但真实 UI 路径绕过了它。 |
| 看板浮窗控制是否真可用 | **PARTIAL** | selftest 的 preload/折叠/缩放/切项目/文件/关闭 API 都通过；M1 证明折叠后复用窗口会卡在 56px。独立窗口还把 `parent: mainWindow`，主窗最小化时会被带走。 |
| Owner 决定是否写旧工作流/通知 PM | **PARTIAL** | `recordOwnerDecision` 确实写 `工作流.json` + `owner-note.mjs`；但 M2 证明失败被 UI 吞掉、阶段仍推进；弹窗可关闭、无自动闸门。 |
| 跨项目名册隔离 | **PARTIAL** | 发件人核验已加强（round5 H5 修复）；H4 证明旧清单可污染 workspace，H5 证明收件人/`dsh:prompt` 没有核验。 |
| 旧派单锁释放 | **PARTIAL** | 正常路径、孤儿锁 API、降级回执释放都通过（selftest）；M4 证明“本地锁已清、旧锁仍在”时 UI 无入口。 |
| 删除项目/DSH 会话/workspace 清理 | **FAIL** | H2 递归删旧账本；H3 离线仍删/workspace 不清理/`stopActivity:false`/warnings 不展示。 |
| D 盘数据落点 | **PASS（本次运行）/ PARTIAL（产品保证）** | 本次所有新写入在 D；C 有 12.57MB 旧 profile 未被本轮更新。M8 证明数据根跟随应用目录，不是 D 保证。 |
| 旧版最后跑通流程 | **PARTIAL** | H7（无 inbox/read、唤醒四步丢失、壳代跑 ack）、M6（回滚/工作流不同步）、M7（旧账本副本/悬空）、M9（阶段不可达）。 |

## 六、旧版最后跑通流程还缺什么

按依赖顺序：

1. **收件箱/已读入口**：`inboxFor` 已实现但没有 IPC/UI；角色和 PM 都看不到邮箱里的旧消息。先补 `team:inbox`/`team:read`，再接团队台。
2. **角色自己 boot/inbox/read/ack**：`sendDispatch` 固定 `--no-wake`，主进程唤醒只有一句；旧 `ops.mjs` 的四步被丢掉。要么恢复四步，要么把 boot 令牌交给角色。
3. **回执执行者**：当前 `team:ack` 是壳进程 `team.mjs ack`；`identitySource:'verified-session'` 只证明会话存在。要严格照旧版，必须让角色会话执行，或在回执里明确 `actor:'workbench-shell'`。
4. **旧 `工作流.json` 读回**：`workflowSnapshot` 只读本地；旧项目的 ownerReview/阶段看不到；新壳写入后旧 UI 修改也不会回读。
5. **Owner 闸门**：旧版 `bossreview` 自动弹、`closable:false`；新壳 `closable:true`、不自动弹，且失败 warning 不显示（M2）。
6. **阶段模型**：旧 UI 10 节点里有 `devreview`/`iterate`；新 `STAGES` 只有 8 个，`requirement/review` 在正常路径不可达，close 后 proposal 回退 review（M9）。
7. **DSH 事件流/流程推送**：`FEATURE-MATRIX` 仍写“进行中”；没有 `fs.watch`/`workflow:changed`，`workflow:get` 是本地快照，不是旧版“改文件即推送”。
8. **旧场景页签/安装包/更新**：`FEATURE-MATRIX` 明确“场景页签 未完成”“安装包/更新 未完成”；这属于旧版最后跑通的产品缺口。
9. **看板提交闭环**：回滚提交仍进旧看板（M6）；`team:status` 仍返回全局最后一份 `看板.json`（UI 有同名保护，但其它调用者没有）。
10. **账本根**：旧根 `D:\deepseek\工作台\团队` 与新根 `agile-workbench\团队` 两本账；旧 `项目/` 不被 discover（M7）。这是“旧版最后跑通”的前置条件。

## 七、D 盘 / C 盘核查

### 7.1 代码落点

| 数据 | 代码落点 |
|---|---|
| `workbench.json` | `app.getPath('userData')/workbench.json`，`userData` 被 `app.setPath` 指到 `DATA_ROOT/userdata`（`main.js:939-941`、`82-84`） |
| `dsh.json` | `DATA_ROOT/dsh.json`（`main.js:22`） |
| Chromium userData/temp | `DATA_ROOT/userdata`、`DATA_ROOT/tmp`（`main.js:19-20`、`82-84`） |
| 团队账本 | `repoRoot()/团队`（`team-tools.js:284`） |
| 新建项目默认根 | `repoRoot()/projects`（`main.js:1649`） |
| 旧团队项目根 | `repoRoot()/项目`（`团队/工具/lib/core.mjs:14-15`） |

`DATA_ROOT` 由 `ROOT` 决定，`ROOT = path.join(__dirname,'..')`；没有 D 盘校验。`AWB_DATA_DIR`/`TEAM_ROOT` 可覆盖，但未写入 README/start.cmd。

### 7.2 本次运行

| 路径 | 状态 |
|---|---|
| `D:\deepseek\agile-workbench\data` | 存在；`userdata`/`tmp` 在 D |
| `D:\deepseek\agile-workbench\团队\状态` | 存在；665 文件，约 1.66MB |
| `D:\deepseek\agile-workbench\_tmp\qa6-selftest-npm` | 存在；selftest 沙盘，约 3.55MB |
| `D:\deepseek\agile-workbench\_tmp\qa6` | 存在；check/selftest 日志 |
| `C:\Users\Admin\AppData\Roaming\敏捷工作台` | 存在；72 文件，约 12.57MB，最新 2026-11-05 02:33:40；本轮 07:49/08:01 未更新 |

### 7.3 C 盘结论

- **本次运行没有新增 C 盘 profile**；`app.setPath` 生效，这是正向证据。
- 但 C 盘旧 profile 仍存在，说明历史版本确实落过 C；当前代码没有清理/迁移它的逻辑。
- “D 盘数据落点”目前依赖“仓库恰好在 D”；M8 的 asar/换目录场景会破。

## 八、只读边界与残留

- **未修改**：`src/`、`src/renderer/`、`package.json`、`package-lock.json`、`node_modules/`、旧仓库 `D:\deepseek\工作台`。
- **新增**：仅 `docs/QA-ROUND6.md`。
- **临时产物**：
  - `_tmp/qa6/selftest.log`、`_tmp/qa6/selftest-npm.log`、退出码文件。
  - `_tmp/qa6-selftest`、`_tmp/qa6-selftest-npm`（selftest 沙盘，各自约 3.55MB）。
- **selftest 自身产物**（应用行为，不在 `_tmp`）：
  - `selftest.png`、`selftest-flow.png` 被 `npm run selftest` 在 08:01:50 重写（`.gitignore` 的 `selftest*.png` 已忽略）；`selftest-dsh.png` 未变。
  - 根目录 `userdata-selftest/` 是 Electron `--user-data-dir` 参数创建的空目录（`userdata*/` 已忽略）。
  - 如果要求“除 docs 外零改动”，这两个截图文件是唯一需要说明的例外；它们是测试 harness 的固定输出，不是手工编辑。
- **没有**在 `%TEMP%` 写本次 QA 文件；selftest 的 `temp` 被指到 `DATA_ROOT/tmp`/沙盘。
- **运行环境备注（低，未计入 16 项）**：首次 `npm run selftest` 在继承 `ELECTRON_RUN_AS_NODE=1` 的环境下，Electron 被当成 Node 执行，`main.js:82` 报 `Cannot read properties of undefined (reading 'setPath')`；`start.cmd` 已 `set ELECTRON_RUN_AS_NODE=`，但 `npm start`/`npm run selftest` 没有清。清掉该变量后重跑通过。建议两个 npm script 显式清空该变量，或在 README 写明。

## 九、建议修复顺序

**P0（先修，影响安全/数据完整性）**

1. H1：移除 `files:read` 的调用方上限覆盖；删除 `file://` 回退；统一 realpath/大小/类型。
2. H2/H3：删除拆成“移除登记”与“清除历史”；默认保留旧账本；归档失败阻止删除/记 pendingCleanup；`stopActivity:true`；workspace 清理或明示。
3. H4/H5：旧 `团队会话.json` 必须校验 workspace 路径；`bindProjectWorkspace` 必核 workspace；`team:send`/`dsh:prompt` 同时核验收件人。
4. H6：store 写串行化/重读合并/CAS；await 后不要写旧快照。

**P1（旧流程可用性）**

5. H7：inbox/read IPC/UI；恢复旧四步唤醒；回执 actor 语义。
6. M1：看板窗口复用重置 bounds/resizable。
7. M2：Owner warnings 必须可见；失败不推进/可重试。
8. M3：create/adopt warnings 可见，DSH pending 状态可见。
9. M4：旧锁残留的 UI 释放入口；只有释放成功才清本地锁。

**P2（路径/旧账本/产品保证）**

10. M5：统一路径守卫；拒绝 `.`/`..`；`team:open-project` 限制/scaffold 确认。
11. M6：回滚提交从看板移除；旧 `工作流.json` 读回/迁移。
12. M7：账本根决策；清理悬空 current；扫描旧 `项目/`。
13. M8：单一数据根/ D 盘策略/ asar 处理；文档 `AWB_DATA_DIR`/`TEAM_ROOT`。
14. M9：阶段顺序/`devreview`/`iterate`；完整序列测试。

**测试建议**

- 在现有 `selftestRound5` 之外增加：junction 预览、1MB/9MB 文件、`textMaxBytes:1e12`、折叠后复用看板、收件人无会话派单、旧清单污染 workspace、DSH 离线删除、并发 send+createTask、旧工作流读回、完整 8 阶段序列。
- 不要只用 `node --check` 作为质量门；它只证明语法。
