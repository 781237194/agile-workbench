# 敏捷工作台 v0.1 · 第七轮只读 QA（收件箱/已读 · 四步唤醒 · 回执身份 · 跨项目 · 并发派单 · 旧锁 · 删除归档 · D 盘 · DSH 主壳）

> 范围：只回答本轮指定的九件事——①`inbox/read` 是否真实可用、session 核验是否成立；②`team:send` 唤醒是否四步、角色能不能自己回执；③回执 actor 是否冒充；④跨项目 manifest/workspace 污染；⑤并发 send/ack/cancel 是否丢写；⑥旧锁释放、删除归档；⑦D 盘数据；⑧DSH 主壳/六角色；⑨`npm run check` + D 盘 selftest 的正向证据。
> 只读边界：本轮**只新增本文件**。未修改 `src/`、`package.json`、`package-lock.json`、`node_modules/`、`团队/`、旧仓库 `D:\deepseek\工作台`。所有临时文件在 `D:\deepseek\agile-workbench\_tmp\qa7\`，未把 QA 文件写进 `%TEMP%`。
> 证据分级：**运行时**＝真实主进程 IPC（Electron 副本 + 本地 mock DSH + CDP）；**组件**＝直接调用 `src/team-tools.js`（旧协议 CLI 真跑）；**静态**＝只读源码/台账。凡标“运行时”的结论都有可重放的脚本和 JSON 输出，不靠截图。
> 快照：源码在 10:21–10:48 之间仍在变；本轮在 **S8（10:29:38 / 10:32:11 / 10:48:37）** 上跑完全部检查，结束时重新核对 6 个源文件哈希未再变化（见 §1.1）。

---

## 0. 结论速览（先看这 12 条）

1. **`npm run check` 通过；`npm run selftest` 通过（SELFTEST_OK，122 项 0 失败）。** 但这两条都不能证明本轮四个重点是对的——selftest 的 ROUND6 只测“壳代跑 ack”，没测“角色自己 ack 后本地锁”；并发只测 `send+createTask`，没测双 send；删除只断言 `archived=6`，没对照 UI 文案。
2. **收件箱这条链是真的**：E2E 里 `team:inbox` 返回 `identity.source=verified-session`、`sessionId=qa-session-3`、`workspaceId=qa-ws-1`；selftest 的 ROUND6 验证 `team:read` 把邮件从 `new` 移到 `cur`（`read1` 未读、`read2` 已读、`--all` 可见、`all:false` 不可见）；E2E 里角色 CLI 的 `ack` 也把邮件移入 `cur`；四步唤醒文案完整，并真的发到了角色会话（`wake.ok=true`）。**这部分给正向证据，不是缺口。**
3. **H1【高】角色按四步自己 `ack` 之后，工作台的本地 `pendingAck` 不清。** 运行时：角色 CLI `ack` 退出码 0、旧 `派单锁.json` 已删，`state.pendingAck` 仍是那条消息、`ack:false`；紧接着 PM 再派单被拒：“还有一条派单未回执……等 10 分钟超时”。旧协议主路径和工作台壳在这件事上没有对账。
4. **H2【高】回执身份会被壳“补写”成它核验的映射会话。** 运行时：角色自己 `ack` 写下的 `回执.jsonl` 两行本来没有 `sessionId`；壳点一次“记录回执”（旧协议返回 `already`）后，这两行被写成 `sessionId=qa-session-3`、`identitySource=verified-session`、`workspaceId=qa-ws-1`，而 `actor=null`。更矛盾的是回执弹窗仍写“壳不能代写”。审计无法从账本区分“角色自己 ack”和“壳核验后 ack”。
5. **H3【高】并发两次 `team:send` 会造“幽灵派单”。** 运行时：`Promise.all` 两个 send → IPC 抛 `[INTERNAL] ENOENT ... 状态\锁\events.lock\owner.json`；但邮箱里 `并发A`、`并发B` 两封都已落盘（`ackRequired=true`），本地库只记了 `并发B`。`并发A` 角色能看到、PM 看不到、无法回执/撤销。
6. **H4【中】`team:cancel` 在“本地消息没有 teamMessageId”时会释放当前任意旧锁。** 运行时：本地 pending=`并发B`、旧锁=`并发B`；用不存在的 `M-does-not-exist` 调 cancel → 返回 `released: LOCK_RELEASED/removed:true`、`cleared:false`，旧锁被删，本地锁还在。
7. **H5【高】删除项目的确认文案与实际行为相反。** 文案写“项目目录、文件、六角色 DSH 会话都会保留”（`app.js:4590`）；实际默认归档 6 个会话（`archiveSession(stopActivity:true)`）、删掉项目里的 `团队会话.json`、改写 `workspace.json`（`main.js:3031-3033`、`3095-3115`）。运行时 `deleteB`：`archived:6 / failed:0 / warnings:[]`、`manifestExists:false`、`workspace.json` 只剩 `previousWorkspaceId`。
8. **M6【中】收件箱按项目过滤，但 `read/ack` 不校验消息 `project`。** 组件探针：B 项目收件箱 0 条（过滤生效）；用 B 项目会话 `read` A 项目邮件成功，`ack` 也成功，回执行写成 `project=项目A / sessionId=S-AN-B / workspaceId=WS-B`，并清掉 A 的派单锁。
9. **M7【中】工具路径两套口径，`index` 失败被静默。** `buildLayout` 固定 `toolRoot=repoRoot()/团队/工具`（`team-tools.js:182`），渲染层却用 `state.team.teamRoot/工具/team.mjs`（`app.js:1785-1790`）；旧 `launch.mjs:222` 又用 `<TEAM_ROOT>/工具/team.mjs`。自定义 `TEAM_ROOT` 下：E2E 的 `dsh:provision` 返回 `ok:true` 但 warning 是一段被截断的 `MODULE_NOT_FOUND` 裸栈（stage=index），事件账 `launch_sessions errors=1`；UI 的“让角色自己 read/ack”指令路径不存在。
10. **M8【中】`inbox/read` 是写操作。** 每次首次读都 `boot`：E2E 的只读调用新增启动令牌、`阅读.jsonl` 行、`事件.jsonl` boot 行；对没登记团队的项目，`resolveProjectTeamRole` 还会先 `ensureProject`（组件探针显示会在裸项目目录生成 24 个文件）。
11. **M9【中】`pendingCleanup` 是死队列。** DSH 离线删除时写入队列并返回布尔，但全仓没有消费者（渲染层 0 处引用），会话永远不会补归档。
12. **M10【中】`回执.jsonl` 被全量读改写。** `annotateReceiptIdentity` 用 `writeTextAtomic` 重写整个 append-only 账本（`team-tools.js:1403`），Windows 上并发写者会直接 `EBUSY`（探针 3 复现）；未做压力下的一致性证明，但结构上会丢并发行。

其余：M11 删除清理整块静默 catch；L12 回滚提交仍进旧看板（round6 M6 复检未修）；L13 D 盘主线成立但运行期仍写 `%TEMP%`、`npm run selftest` 固定写根目录；L14 无 `project` 字段的旧邮件跨项目可见。

**一句话**：第七轮把“收件箱可见”补上了，但“角色自己回执”只完成了旧协议那一半——壳既不认角色的自回执，又在角色自回执之后往账本上补写自己的身份；并发派单还会造出壳不知道的幽灵邮件。

---

## 1. 快照、运行与证据

### 1.1 源码快照 S8（本轮绑定）

| 文件 | 字节 | SHA256 前 16 | 末次写入 |
|---|---:|---|---|
| `src/main.js` | 327,053 | `48776EAA2EF9AAE0` | 2026-11-05 10:29:38 |
| `src/team-tools.js` | 85,886 | `D3630F62C21038E3` | 2026-11-05 10:32:11 |
| `src/preload.js` | 4,547 | `B799FB5E26A7DAE2` | 2026-11-05 10:21:47 |
| `src/renderer/app.js` | 245,410 | `EAE9CAE2B64DA6A0` | 2026-11-05 10:48:37 |
| `src/renderer/index.html` | 35,000 | `140B926E48417179` | 2026-11-05 10:21:26 |
| `src/renderer/style.css` | 96,045 | `F87524A5FA08018D` | 2026-11-05 10:46:57 |

审计开始与结束时两次哈希一致；本轮所有行号都以这组哈希为准。`docs/PARITY-ROUND7.md` 记录的 S7 是 `main.js 325,560 / 98747196…`，之后又涨到 S8，所以本文件不引用 S7 的行号。

### 1.2 `npm run check`

```
> agile-workbench@0.1.0 check
> node --check src/main.js && node --check src/preload.js && node --check src/renderer/app.js
  && node --check src/dsh-adapter.js && node --check src/team-tools.js
```

退出码 0，无输出。它只证明语法，不证明行为（`docs/PARITY-ROUND7.md` 也这么说）。

### 1.3 D 盘 selftest（沙盘重定向，产物全在 `_tmp`）

官方脚本 `npm run selftest` 会做三件写仓库根目录的事：`--user-data-dir=userdata-selftest`、`main.js:6057/6061` 把 `selftest-flow.png`/`selftest.png` 写到 `ROOT`。为了守住“只新增 `docs/QA-ROUND7.md`”，本轮把 `src/`、`package.json`、`团队/`（不含 `状态/`）复制到 `_tmp/qa7/app`，`node_modules` 用 junction 指向仓库，再在该副本里执行**同一条 npm script**：

```powershell
$env:AWB_SELFTEST_ROOT='D:\deepseek\agile-workbench\_tmp\qa7\sandbox-npm'
cd D:\deepseek\agile-workbench\_tmp\qa7\app
npm run selftest        # electron . --selftest --user-data-dir=userdata-selftest
```

结果（`_tmp/qa7/selftest-npm.log`，47 KB）：

| 套件 | 断言数 | 失败 |
|---|---:|---:|
| `SELFTEST_STORE` | 20 | 0 |
| `SELFTEST_COMPAT` | 45 | 0 |
| `SELFTEST_MAPPING` | 39 | 0 |
| `SELFTEST_ROUND5` | 2 | 0 |
| `SELFTEST_ROUND6` | 16 | 0 |
| **合计** | **122** | **0** |

`SELFTEST_OK`，退出码 0。截图落在 `_tmp/qa7/app/selftest*.png`（11:21:46），仓库根的 `selftest*.png` 时间戳仍是 10:51，未被本轮触碰。

**selftest 的盲区（本轮据此设计探针）**：ROUND6 的 actor 断言只覆盖“壳代跑 ack”（`ack.actor=workbench-shell`），没有“角色自己 ack 后本地 pendingAck 应为空”；并发只做 `send+createTask`/`ack+createTask`/`cancel+createTask`，没有双 send；删除只断言 `archived=6`，没有对照“六角色会话都会保留”的 UI 文案；也没有在“自定义 `TEAM_ROOT`”下检查 `launch.mjs` 的 index 步骤。

### 1.4 端到端探针（真实主进程 + mock DSH + CDP）

为了验证“壳不认角色自回执”“并发幽灵派单”“删除文案”这类只有主进程才知道的行为，本轮起了一个**只实现 7 个 RPC** 的本地 mock DSH（`_tmp/qa7/mock-dsh.js`：`session/list`、`session/create`、`session/rename`、`session/selectModel`、`session/prompt`、`workspace/create`、`workspace/archiveSession`），再用 `_tmp/qa7/app` 以 `--remote-debugging-port=9333` 启动，数据根全部指向 `_tmp/qa7/e2e`，从渲染进程直接调 `window.workbench.*`（`_tmp/qa7/e2e.js`）。主进程 RPC 只连 mock；唯一的真实 DSH 接触是 webview 在拿到 state 前的初始 `src=52711`（见 L13），没有在该页面做任何操作，也没有向真实项目发 prompt。

关键时间线（2026-11-05，UTC+8）：

| 时间 | 动作 | 结果 |
|---|---|---|
| 11:12:20 | `createProject` + `dshProvision` | 1 工作区 `qa-ws-1`、6 会话 `qa-session-1..6`、映射 6/6 |
| 11:13:24 | `teamInbox(analyst)` | 0 条；`identity=verified-session / qa-session-3 / qa-ws-1` |
| 11:13:25 | `teamSend(PM→analyst)` | `source=team`、`lockTaken=true`、唤醒 `ok:true` |
| 11:13:26 | 角色 CLI `boot`+`ack`（模拟角色自己回执） | 退出码 0；旧锁被删；**本地 pendingAck 仍在** |
| 11:13:26 | 再派单 | 被拒：“还有一条派单未回执……” |
| 11:13:26 | 壳 `teamAck`（旧协议 already） | `already:true`、`actor=pre-existing`；回执行被补写 sessionId/verified-session |
| 11:13:26 | 并发两个 `teamSend` | `[INTERNAL] ENOENT … events.lock/owner.json`；两封邮件都进邮箱，本地只记一封 |
| 11:13:34 | `deleteProjectRecord(B)` | 归档 6 会话；删 `团队会话.json`；改 `workspace.json`；`warnings:[]` |

### 1.5 组件级探针（直接调用 `src/team-tools.js`）

- `_tmp/qa7/probe1.js`：在 `_tmp/qa7/probe1/team` 初始化团队，`sendDispatch` 后**逐字执行唤醒文案的四步**（boot→inbox→read→ack），检查令牌、事件、回执行的字段，再调 `ackDispatch` 模拟壳。
- `_tmp/qa7/probe2.js`：两个项目 A/B、两套会话；先用 B 的会话 `inbox`（0 条），再 `read`/`ack` A 的邮件。
- `_tmp/qa7/probe3.js`：并发写 `回执.jsonl`（一个进程 append，本进程 546 次 `annotateReceiptIdentity`）。

---

## 2. 问题清单（按严重级别）

| 级别 | 编号 | 问题 | 证据 |
|---|---|---|---|
| **高** | H1 | 角色自己 `ack` 后本地 `pendingAck` 不清，PM 被假锁挡住 10 分钟 | 运行时 |
| **高** | H2 | 回执身份补写把“角色自回执”写成壳核验的映射会话；UI 文案仍说“壳不能代写” | 运行时 + 静态 |
| **高** | H3 | 并发双 `team:send` → 旧工具锁 `ENOENT`、IPC 抛 `[INTERNAL]`、邮箱多出幽灵派单 | 运行时 |
| **高** | H5 | 删除确认文案承诺保留会话/文件，实际归档 6 会话、删清单、改 workspace.json | 运行时 + 静态 |
| 中 | H4 | `team:cancel` 在 `teamMessageId` 为空时释放当前任意旧锁，本地锁保留 | 运行时 |
| 中 | M6 | `read/ack` 不校验消息 `project`，B 项目会话可消费 A 项目邮件 | 组件 |
| 中 | M7 | 工具路径两套口径；自定义 `TEAM_ROOT` 下启动 index 静默失败、UI 指令路径不存在 | 运行时 + 静态 |
| 中 | M8 | `inbox/read` 有写副作用（boot 令牌/阅读/事件），未登记项目还会先 ensure 脚手架 | 运行时 + 组件 |
| 中 | M9 | `pendingCleanup` 只写不读，DSH 离线删除的会话永不补归档 | 静态 |
| 中 | M10 | `回执.jsonl` 全量读改写；Windows 并发写 `EBUSY` | 组件 |
| 中 | M11 | 删除时团队清理整块静默 catch，归档失败不进 warnings | 静态 |
| 低 | L12 | 回滚提交仍计入旧看板（round6 M6 复检未修） | 静态 |
| 低 | L13 | D 盘主线成立，但运行期仍写 `%TEMP%`；`npm run selftest` 固定写根目录；webview 初始硬编码 52711 | 运行时 + 静态 |
| 低 | L14 | 无 `project` 字段的旧邮件对任何项目都可见 | 静态 |

---

## 3. 问题详情

### H1【高】角色自己 `ack` 之后，本地 `pendingAck` 不清：PM 被假锁挡住 10 分钟

**位置**

- `src/main.js:1439-1465` `reconcileExpiredLocks`：只在 `pendingAckExpired`（10 分钟 TTL）时清锁；`statePayload` 每次读状态只调它（`1468-1470`）。
- `src/main.js:3525-3528` `team:send`：`pmDispatch && project.pendingAck && !expired` 直接抛“还有一条派单未回执”。
- `src/main.js:3987-4044` `team:ack`：只有壳自己走完 ack 才会 `clearPendingAck`。
- 全仓没有“读 `派单锁.json` 是否存在 → 反向清本地 pendingAck”的对账；`readDispatchLockState` 只在 send 的超时分支（`3530-3534`）和 cancel（`3784`）里用。

**运行时证据（E2E）**

角色按四步执行旧协议 CLI（`team.mjs boot --role analyst …` + `team.mjs ack --id M-…`）返回：

```
roleAck: { code: 0, stdout: "已回执 M-20261105-111325-b2cc2e（A-…）→ 已通知 pm" }
stateAfterRoleAck: { pending: "M-20261105-111325-b2cc2e", ack: false }
secondSend: { ok: false, error: "…还有一条派单未回执，先等回执、撤销，或等 10 分钟超时" }
```

同时旧账本侧 `状态/项目/E2E探针A/派单锁.json` 已被 `clearDispatchLock` 删除，`回执.jsonl` 已有该消息的两行回执（`id` 相同，一行 `update:true`）。

**现象**

- 旧协议已经闭环（锁没了、回执写了、PM 收到 `type:'receipt'` 回信），工作台却认为“未回执”。
- 界面继续显示“待回执 / 剩余 09:xx”，PM 无法派下一条；10 分钟后 `reconcileExpiredLocks` 还会去释放一把已经不存在的锁（`NO_LOCK`，无害但会多写一条事件）。
- 这段时间里角色可以继续按旧协议干活，壳完全不知道。

**影响**

- “角色自己回执”是旧协议的**设计主路径**（`ops.mjs` 的四步文案就是让角色自己 ack），但工作台只在“人点记录回执”时闭环。也就是说，按旧流程认真执行的角色反而会被工作台判成“没回执”。
- 单团队多项目时更明显：PM 切换项目回来后仍看到旧锁。

**建议**

- 在 `statePayload`/`team:status`/`team:send` 前加一次“旧锁对账”：`project.pendingAck` 存在但 `readDispatchLockState(teamName)` 为空，且 `回执.jsonl` 有该 `msgId` → 清本地锁并记事件 `角色自回执（旧协议锁已消失）`。
- 或者在 `回执.jsonl` 上做只读 tail（按 `msgId` 匹配）来清锁，别只依赖本地点击。
- selftest 增加：角色 CLI ack 后 `state.pendingAck === null`、下一条 send 成功。

---

### H2【高】回执身份补写：把“角色自己 ack”写成壳核验的映射会话，UI 仍说“壳不能代写”

**位置**

- `src/team-tools.js:1602-1614` `ackDispatch` 的 `already` 分支：`annotateReceiptIdentity(..., { sessionId, identitySource: 'verified-session', workspaceId, checkedAt })`，只把 `actor` 留空。
- `src/team-tools.js:1388-1391`：`identitySource==='verified-session'` 时**强制写** `identitySource/workspaceId/identityCheckedAt`；`1384` 只在 `!row.sessionId` 时补 `sessionId`。
- `src/main.js:3955-3957`、`4008-4015`：本地消息标 `identitySource='verified-session'`、`actor='pre-existing'`。
- `src/renderer/app.js:3008-3021` `openAckModal`：“回执会以收件角色「X」的真实 DSH 会话身份写进旧协议，**壳不能代写**。”

**运行时证据（E2E）**

角色 CLI 自己 `ack` 后，`回执.jsonl` 的两行（原始行 + `update:true`）是：

```json
{ "id": "A-20261105-111326-b2f640", "from": "analyst", "project": "E2E探针A",
  "sessionId": null, "identitySource": null, "actor": null }
```

随后壳点“记录回执”（旧协议已存在 → `already:true`），同两行变成：

```json
{ "id": "A-20261105-111326-b2f640", "from": "analyst", "project": "E2E探针A",
  "sessionId": "qa-session-3", "identitySource": "verified-session",
  "workspaceId": "qa-ws-1", "identityCheckedAt": "2026-11-05T03:13:26.144Z", "actor": null }
```

组件探针进一步证明这是“推断”而非“证据”：probe1 里角色 CLI 的 `boot`/`ack` 事件记录的是执行命令时继承的 `DSH_SESSION_ID`（`4cce7c51-…`），而壳事后给回执行补的是 `S-AN-A`（工作台映射），两者不是同一个会话。

**现象**

- 账本上出现“壳从未执行、但被标成 verified-session”的回执行。
- `actor` 仍是 `null`，`pre-existing` 只在本地消息里；旧看板/第三方只读 `回执.jsonl` 时看不出执行者。
- 回执弹窗的文案直接与实现相反：执行者确实是壳（`team.mjs ack` 由主进程 spawn），角色只是被“核验存在”。

**影响**

- 审计链被污染：`identitySource=verified-session` 本是“壳核验过会话归属”的标记，现在被套到角色自回执上；无法再用它区分“谁执行”。
- 如果角色用旧会话/别人的启动令牌 ack（旧协议只认令牌角色，不认执行者），壳会把回执记成映射会话，事后无法发现冒名。
- 这是本轮“回执 actor 是否冒充”的核心结论：**字段没有冒充成角色，但身份证据被冒充成了“壳核验”**。

**建议**

- `already` 分支不要再写 `sessionId/identitySource/workspaceId`；最多写 `identityCheckedBy:'workbench-shell'`、`identityCheckedAt`、`checkedWorkspaceId`，保留原执行信息。
- 如果一定要补 `sessionId`，必须先读 `事件.jsonl` 里该 `msgId` 的 `ack` 行，确认 `event.sessionId === 映射会话` 才写 `verified-session`，否则写 `session-unverified`。
- 修回执弹窗文案：明确“本次回执由工作台壳以该角色会话身份执行（actor=workbench-shell），不是角色本人点击”；角色自回执另走“让角色自己 read/ack”。

---

### H3【高】并发双 `team:send`：旧锁竞争 `ENOENT`、IPC 抛 `[INTERNAL]`、邮箱多出幽灵派单

**位置**

- `src/main.js:3497-3760` `team:send`：没有按 `projectId` 的发送互斥；`pendingAck` 检查在 `ensureTeamName`/`verifyProjectRoleSession` 两个 `await` 之前（`3525`），两个并发请求都能通过。
- `团队/工具/lib/core.mjs:316-327` 旧锁：`mkdirSync` 成功后写 `owner.json`；另一个进程 `EEXIST` 时读不到 `owner.json` 就判 stale 并 `rmSync` 整个锁目录 → 先到的进程写 `owner.json` 时目录已被删 → `ENOENT`。
- `src/main.js:3638-3640`：非白名单错误码直接 `throw codedError(teamResult.code …)`，`INTERNAL` 原样透出。

**运行时证据（E2E）**

```json
"concurrentSends": { "__error": "Error invoking remote method 'team:send':
  Error: [INTERNAL] ENOENT: no such file or directory, open
  '…\\e2e\\team\\状态\\锁\\events.lock\\owner.json'" }
```

随后的账本状态（同一时刻）：

- `邮箱/analyst/new/`：`M-…-3789a1`（并发B，11:13:26.567）与 `M-…-ee6b67`（并发A，11:13:26.573），两封都 `ackRequired=true`；
- 本地 `project.messages`：只有 `M-…-3789a1`；`pendingAck=M-…-3789a1`；
- 旧 `派单锁.json`：`messageId=M-…-3789a1`；
- `M-…-ee6b67` 没有本地记录 → 界面看不到、不能回执、不能撤销。

**现象**

- 一封“幽灵派单”永久留在角色邮箱里；角色会按四步去读、去 ack，回执写进 `回执.jsonl`（`project=E2E探针A`），但 PM 界面没有这条消息，`clearDispatchLock` 也只会匹配 `3789a1`，幽灵的 ack 清不了任何锁。
- 错误码是 `[INTERNAL]` + 原始 Windows 路径，不是 `TEAM_*`；渲染层只能原样显示。
- 旧协议锁只保留后写的一封，前一封的锁被覆盖/删除。

**影响**

- 并发（双击、脚本、两个入口）会造出无法从 UI 收尾的邮件；对账只能去翻邮箱。
- 这是“并发 send 是否丢写”的实证：**本地库丢了一条，旧账本多了一条**，两边都不完整。

**建议**

- 主进程按 `projectId` 串行化 `team:send`/`team:ack`/`team:cancel`（一个 Promise 队列，像 `sessionCreateLocks`/`provisionLocks` 那样）。
- `send` 失败后回读邮箱与 `派单锁.json` 做一次对账：如果邮件已存在但本地没有，补一条 `source:'team/ghost-recovered'` 记录并标记 `needsAttention`。
- 把 `INTERNAL`/`ENOENT`/`LOCK_BUSY` 归一成 `TEAM_SEND_RACE` 之类的码，UI 给可操作提示（重试/撤销）。
- 旧工具侧修 `acquireLock`：`owner.json` 缺失且目录刚创建时应视为“占用中”，不能直接 stale 删除。

---

### H4【中】`team:cancel` 在 `teamMessageId` 为空时释放“当前任意旧锁”

**位置**

- `src/main.js:3779-3798`：`expected = messageNow.teamMessageId || ''`；只有 `expected && lock.messageId !== expected` 才拒绝；否则 `releaseDispatchLock(teamName, lockBefore.messageId)`。
- `src/renderer/app.js:1720`：UI 调 `teamCancel({ projectId })`，**不传 messageId**，完全依赖本地状态推断。

**运行时证据（E2E）**

在 `pendingAck=并发B`、旧锁=`并发B` 的情况下，调用：

```js
teamCancel({ projectId, messageId: 'M-does-not-exist' })
→ { released: { ok:true, code:'LOCK_RELEASED', removed:true,
                pending:{ messageId:'M-20261105-111326-3789a1' } },
    cleared: false,
    lock: { messageId:'M-20261105-111326-3789a1' },
    warnings: [] }
```

之后 `派单锁.json` 不存在，本地 `pendingAck` 仍是 `3789a1`。

**现象**

- 撤销一个不存在的消息，实际把**当前正在等回执的那把旧锁**释放了；本地锁却保留。
- 旧协议侧现在允许下一条 PM 派单，本地仍认为有锁；两本账分叉。
- 反过来，之后真正的回执到达时，`clearDispatchLock` 找不到锁（无害），但“撤销”按钮的行为已经不可预期。

**触发面**

- UI 正常路径下 `messageNow` 就是本地 `pendingAck`，`teamMessageId` 通常有值，所以不是每次点击都触发。
- 触发条件是 `messageNow` 为空或该消息没有 `teamMessageId`：旧记录/降级消息/本地库被修过/上一轮幽灵态。属于“异常状态下的二次破坏”，故列中。

**建议**

- `cancel` 必须带目标：`requestedId` 要么等于 `pendingAck`，要么等于 `lock.messageId`；两者都不匹配就拒绝（`LOCK_TARGET_MISMATCH`），不要“按锁自身 id 释放”。
- UI 调 `teamCancel({ projectId, messageId: p.pendingAck })`，把意图传清楚。
- 释放成功后如果 `cleared=false`，必须在 UI 提示“旧锁已释放、本地锁保留”，不能只弹“已撤销”。

---

### H5【高】删除确认文案与实际相反：承诺保留六角色会话/项目文件，实际归档 6 会话、删清单、改 workspace.json

**位置**

- `src/renderer/app.js:4581-4597` 文案：
  - “只移除本机状态库里的项目记录”；
  - “项目目录、文件、六角色 DSH 会话都会保留；团队登记会一起清理”。
- `src/main.js:3031-3033`：`archiveSessions === false ? skip : archiveProjectRoleSessions(project)` → 默认归档；
- `src/main.js:3095-3115`：删 `<项目>/团队会话.json`、`团队会话.md`，把 `workspace.json` 的 `dshWorkspaceId/engineUrl` 删掉、留 `previousWorkspaceId`；
- `src/main.js:1744-1801` + `src/dsh-adapter.js:260-265`：对六个会话调 `workspace/archiveSession`，`stopActivity:true`。

**运行时证据（E2E）**

```json
"deleteB": {
  "ok": true,
  "sessions": { "ok": true, "archived": 6, "failed": 0, "skipped": 0 },
  "warnings": [],
  "removed": { "registrations":[...], "archivedTo":"…\\_deleted\\2026-11-05T03-13-34-875Z-E2E探针B" }
},
"deleteBAfter": {
  "manifestExists": false,
  "workspaceJson": { "previousWorkspaceId": "qa-ws-2", "removedAt": "…" }  // 无 dshWorkspaceId
}
```

selftest 的 ROUND6 也记录 `deleted: { archived: 6, stopActivity: 6, projectDirKept: true }`——即“项目目录在，但会话被归档、项目内清单被删”。

**现象**

- 用户被明确告知“六角色 DSH 会话都会保留”，实际全部归档（`stopActivity:true`，会停止活动）。
- “项目目录、文件都会保留”也不成立：`团队会话.json` 被删、`workspace.json` 被改写。
- 结果 `warnings:[]`、toast 是“已移除本机记录；项目文件仍在磁盘上”，用户没有任何提示。

**影响**

- 破坏性操作与承诺不符；归档虽然可 unarchive，但 UI 没有入口，用户只能去 DSH 侧恢复。
- 项目目录被改后，“同名重建”不会复用旧会话（这是设计意图），但与“文件都保留”的承诺冲突。

**建议**

- 对话框逐条列出将要发生的动作（归档 N 个会话 / 归档团队项目到 `_deleted` / 删除 `团队会话.json` / 改写 `workspace.json`），默认**不归档会话**，需要归档时显式勾选。
- 返回结果里展示 `archived` 列表；toast 与文案保持一致。
- 如果保留“归档”默认，至少提供“恢复会话”入口。

---

### M6【中】收件箱按项目过滤，但 `read/ack` 不校验消息 `project`

**位置**

- `src/team-tools.js:1625-1667` `inboxFor`：只核验角色/会话/名册，旧工具 `listInbox` 自带 `project` 过滤（`团队/工具/lib/store.mjs:391`）。
- `src/team-tools.js:1673-1715` `readFor`：直接 `team.mjs read --id`；旧 `readMessage(role,id)`（`store.mjs:417-428`）只按角色邮箱找，**不校验 `msg.project`**。
- `src/team-tools.js:1529-1616` `ackDispatch`：同样只按角色/名册/会话，不校验消息 `project`；`ackMessage`（`store.mjs:435-475`）也不校验。
- `src/main.js:3464-3496` `team:read` 接受任意 `messageId`。

**组件证据（probe2）**

| 步骤 | 结果 |
|---|---|
| B 项目 `inboxFor(analyst)` | `count:0`（项目过滤生效） |
| B 项目 `readFor(messageId=A 的邮件)` | `ok:true`，`messageProject:"项目A"`，`alreadyRead:false`（邮件被移到 cur） |
| B 项目 `ackDispatch(A 的邮件)` | `ok:true`，`ackId=A-…`，`already:false` |
| 回执行 | `project:"项目A"`、`sessionId:"S-AN-B"`、`workspaceId:"WS-B"` |
| A 的 `派单锁.json` | 被清空（`lockA_afterCrossAck:null`） |

**现象**

- 收件箱层做了项目隔离；读/回执层没有。用 B 项目的合法会话可以消费 A 项目的邮件，并写出“project=A、workspace=B”的混合回执。
- `readFor`/`ackDispatch` 的错误文案却声称“拒绝跨项目读取/回执”（`1639`、`1547`），只对会话做校验。

**影响**

- 跨项目边界不完整：邮件正文/附件可能被另一项目的会话读走；回执账本出现项目/工作区错配，审计难查。
- 在“同一角色服务多个项目”的旧协议里，这是真实可达的（B 项目会话是合法的，消息 id 也是合法的）。

**建议**

- `readFor`/`ackDispatch` 先按 `id` 定位消息，校验 `msg.project === projectName` 且 `msg.to === role`；不匹配返回 `MESSAGE_PROJECT_MISMATCH`/`MESSAGE_ROLE_MISMATCH`。
- `team:read` 的 `messageId` 只能来自当前项目收件箱的可见列表（主进程再校验一次，别只信渲染层）。
- 旧工具的 `readMessage/ackMessage` 加可选 `project` 参数，壳传当前项目。

---

### M7【中】工具路径两套口径：自定义 `TEAM_ROOT` 下启动 index 静默失败、UI 指令不可执行

**位置**

- `src/team-tools.js:182`：`toolRoot = path.resolve(toolsDir || path.join(repoRoot(), '团队', '工具'))` —— **工具永远从仓库根找**，与 `layout.root`（`TEAM_ROOT`）无关。
- `src/team-tools.js:1731`：唤醒文案 `const tool = layout.teamTool`（上面那条 repo 路径）。
- `src/renderer/app.js:1785-1790`：UI 的 `teamToolPath()` 用 `state.team.teamRoot + '\\工具\\team.mjs'`。
- `团队/工具/launch.mjs:222`：`spawnSync(process.execPath, [path.join(PATHS.teamRoot, '工具', 'team.mjs'), 'index', …])` —— 又用 `TEAM_ROOT`。
- `src/main.js:4202-4226` `dsh:provision` 把 launch 的 `errors` 当 warnings 返回。

**运行时证据（E2E，`TEAM_ROOT=_tmp/qa7/e2e/team`）**

- `state.team.teamRoot = D:\…\_tmp\qa7\e2e\team`；`teamToolPath()` 推导的 `…\e2e\team\工具\team.mjs` **`Test-Path = False`**。
- 唤醒文案里的路径是 `…\_tmp\qa7\app\团队\工具\team.mjs`（repo 副本），与 `teamRoot` 不是同一棵。
- 官方 selftest 的 `wakeText` 也是这条 repo 路径（`_tmp\qa7\app\团队\工具\team.mjs`），而同一份 `SELFTEST_ROUND6` 报告里的 `teamRoot` 是 `_tmp\qa7\sandbox-npm\团队`——测试自己就处在“两棵树”状态，只是没断言。
- `dsh:provision` 返回 `ok:true`、`created` 0（第二次），但 `warnings[0]` 是：

```
stage: "index"
message: "dule._resolveFilename (node:internal/modules/cjs/loader:1232:15) … code:'MODULE_NOT_FOUND' … Node.js v20.18.3"
```

（消息被 `.slice(-400)` 截断，开头就是半截 `dule._resolveFilename`，用户看不懂。）

- `事件.jsonl` 里两次 `launch_sessions` 都是 `created=6 errors=1`，错误正是上面的 index。项目索引在 11:13:15 建项时生成后没有被 launch 刷新；我 11:16:52 手工执行同一条 `team.mjs index --project E2E探针A --json` 才成功（`files:25 / roleIndexes:8`），说明命令本身可用，失败只发生在 launch 的子进程调用方式上。

**现象**

- 只要 `TEAM_ROOT` 不是“应用根/团队”（selftest 沙盘、CI、把团队数据搬家的用户），`launch` 的 index 步骤一定找不到 `team.mjs`：项目索引不刷新，但 `dsh:provision` 仍报成功。
- UI 的“让角色自己 read/ack”会生成一条指向不存在文件的命令；照抄执行必然 `Cannot find module`。
- 唤醒文案里的命令在角色自己的 shell 里不继承 `TEAM_ROOT`，会去读默认的仓库 `团队`，而不是当前配置的团队根——两本账。

**影响**

- 在项目自己的 selftest 形状下（`AWB_SELFTEST_ROOT` 沙盘），“启动团队”一直带着一个被吞掉的 index 失败；测试也没断言 `errors=0`。
- 用户配置/迁移团队根后，四步唤醒和 UI 指令都可能指向错账本。

**建议**

- 统一一个 `toolsDir` 解析函数：优先 `<TEAM_ROOT>/工具`（存在时），否则 `<app>/团队/工具`；`buildLayout`、`launch.mjs`、渲染层都用它。
- 唤醒/UI 命令显式带环境（`set TEAM_ROOT=…` 或 `TEAM_ROOT=… node …`），或者统一用实际存在的 `layout.teamTool`。
- index 失败归一成 `INDEX_REFRESH_FAILED`，在 `dsh:provision` 结果里作为可读 warning，并让 selftest 断言 `errors.length === 0`。

---

### M8【中】`inbox/read` 是写操作：每次首次读都 boot，未登记项目还会先 ensure 脚手架

**位置**

- `src/main.js:728-746` `resolveProjectTeamRole`：先 `ensureTeamName(project)`（`733`）→ 未缓存团队名时走 `syncTeamProject` → `teamTools.ensureProject`。
- `src/team-tools.js:1647` `inboxFor` / `1696` `readFor`：都走 `withBootToken` → `bootToken` → `team.mjs boot`。
- `团队/工具/lib/store.mjs:307-326` `createBootToken`：每次 boot 写 `状态/启动/<token>.json`；`ops.mjs:284` 还写一条 `阅读.jsonl`、`290-294` 写一条 `事件.jsonl` boot。
- 没有令牌清理器（真实账本 91 个启动令牌，全部过期）。

**运行时证据（E2E）**

- 2 次只读调用（`teamInbox`）中，第一次就新增了 `启动/` 令牌 1 个（analyst，11:13:24.876，后续 30 分钟内复用）；本次探针期间共 3 个令牌（inbox 1、PM 派单 1、角色 CLI 1）、`阅读.jsonl` 3 行、`事件.jsonl` boot 3 条。
- 组件探针 probe1：对一个只有 `README.md` 的裸项目目录执行 `ensureProject`，生成 **24 个文件**：`项目信息.md`、`项目索引.md/json`、`协作准则.md`、`项目铁律.md`、六角色 `角色卡.md`+`文件索引.md`、`需求/*`、`workspace.json` 等。

**现象**

- 打开收件箱（只读视图）会往共享团队账本写令牌/阅读/事件；令牌越积越多。
- 对一个“旧记录/未登记团队”的项目，打开收件箱会先把它登记进旧账本并铺 24 个文件，然后才可能报 `TEAM_ROLE_NOT_READY`。

**影响**

- “只读入口”有隐藏写副作用；对共享账本的写入会干扰旧工具/旧看板；令牌目录无上限增长。
- 在别人维护的团队账本上点一下收件箱，就可能改 `activeProject`/名册。

**建议**

- 收件箱改“无 boot 只读”：直接读 `状态/邮箱/<role>/new|cur` 并做项目过滤（只读文件，不签令牌）；需要 `read` 时再 boot。
- `resolveProjectTeamRole` 不要在 inbox 路径里 `ensureProject`；未登记就明确报 `TEAM_NOT_REGISTERED`。
- 增加过期令牌清理（读时/启动时）。

---

### M9【中】`pendingCleanup` 只写不读：DSH 离线删除后会话永不补归档

**位置**

- `src/main.js:3121-3143`：DSH 归档失败时构造 `pendingCleanup`、push 进 `fresh.pendingCleanup`（截 50 条）；
- `src/main.js:3155-3157`：只作为返回值 `pendingCleanup`/`warnings` 的一部分；
- 渲染层 `app.js` 对 `pendingCleanup` **0 处引用**；没有重试 IPC/定时器/启动钩子。

**证据**

`grep -n pendingCleanup src/main.js src/renderer/app.js` 共 10 处，全部是“构造/写入/返回/断言”，没有“读取并重试”。

**现象**

- DSH 离线时删除项目：本地记录摘掉，六个会话保持“未归档”，队列里留一条死数据；DSH 恢复后没有任何路径去补归档。
- 用户看到删除成功的 toast（`warnings` 可能带一条，但 `pendingCleanup` 不展示）。

**影响**

- 会话泄漏；项目目录被复用/重建后，旧会话可能仍在运行并写文件；状态库长期积累死数据。
- 这与 round6 H3 的“归档不停活动”修复方向一致，但只做了一半。

**建议**

- 启动时/切项目时扫描 `pendingCleanup`，重试 `archiveProjectRoleSessions`，成功则移除条目。
- UI 在项目页/团队页显示“待清理 N 个会话”，提供手动重试。
- selftest 增加：DSH 离线删除 → 恢复 → 队列被消费。

---

### M10【中】`回执.jsonl` 被全量读改写；Windows 并发写 `EBUSY`

**位置**

- `src/team-tools.js:1361-1408` `annotateReceiptIdentity`：`readFileSync` 全文 → `rows.map` → `writeTextAtomic(layout.receiptsFile, next.join('\n'))`（`1403`）。
- `src/team-tools.js:449-459` `writeTextAtomic`：`renameSync` 失败时退化为 `copyFileSync(tmp, file)`（非原子覆盖）。
- 旧工具是 append-only：`appendLine(PATHS.receipts, …)`（`store.mjs:455/472`）。

**组件证据（probe3）**

- 一个子进程 `appendFileSync` 写 `回执.jsonl`，主进程循环 546 次 `annotateReceiptIdentity`（每次改 `workspaceId` 触发重写）。
- 第一次 append 就失败：`EBUSY: resource busy or locked, open '…\回执.jsonl'`（Windows 下 rename/copy 与 append 的句柄冲突）。
- 文件最终 3 行；`annotate` 侧 546 次写成功。

**现象**

- 壳把旧协议“append-only”账本变成了“读-改-写”；任何并发写者（角色 CLI 的 ack、旧看板、另一个工作台实例）都可能被覆盖或撞上 `EBUSY`。
- 本次没有复现“丢行”（因为子进程先崩了），但结构决定：只要另一个写者在 `readFileSync` 与 `writeTextAtomic` 之间 append，它的行就会被 `next` 覆盖。

**影响**

- 回执账本可能丢行/撕裂；`rename` 退化为 `copy` 时读者会看到半写文件。
- 与旧工具/旧看板共享账本时风险更高。

**建议**

- 身份信息单独 append 一行（`{...ack, update:true, identitySource, sessionId, workspaceId, identityCheckedAt}`），保持 append-only；旧看板已按 `id` 去重，不会重复计数。
- 或者加文件锁 + 重试，禁止 `copyFileSync` 退化覆盖。
- 给 `annotateReceiptIdentity` 加“只改本进程刚写的那两行”的边界（按 `id` + `ts` + `from`），避免碰历史行。

---

### M11【中】删除时团队清理整块静默 catch，归档失败不进 warnings

**位置**

- `src/main.js:3036-3093`：`try { … 归档项目目录/清 activeProject/清名册/清当前工作区 … } catch { /* 团队状态清理失败不阻断本地删除 */ }`。
- 同一函数里 `removed` 只记录成功项；失败不写 `warnings`，也不进 `pendingCleanup`。

**现象**

- `renameSync(sourceDir, archiveDir)` 在 Windows 上可能因目录被占用（看板打开、编辑器、杀软）失败；失败后：
  - 本地项目记录已被删除；
  - 旧账本登记仍在、项目目录未归档；
  - 用户看到“已移除”，没有任何警告。
- 后续同名重建可能命中旧登记（`findTeamRegistrationByName`）或复用旧账本。

**影响**

- “归档而不是删除”的承诺在失败路径上不成立；没有可重试记录。
- 排查只能靠猜（日志里也没有事件）。

**建议**

- 把整块拆成逐项可失败的操作，失败收集到 `warnings`/`pendingCleanup`，删除结果里展示。
- 归档失败时默认保留项目记录（或至少保留登记），让用户能重试。
- 删除前检查目录占用（`团队/看板.html` 被打开时提示先关闭）。

---

### L12【低】回滚提交仍计入旧看板（round6 M6 复检未修）

**位置**

- `src/team-tools.js:1058-1092` `syncWorkbenchBoard`：只把 `project.commits` 写进 `提交/<id>.json`，**从不删除/标记**已回滚的提交。
- `src/main.js:3424-3429` `proposal:rollback`：只把 `proposal.applied=false`，不把 commit 移出 `project.commits`，也不删旧文件。
- `src/team-tools.js:1157` `generateBoard` 直接返回旧工具 `value.summary`（旧工具按 `提交/` 目录计数）。

**现象**

- 应用提案 → 生成看板（commits=1）→ 回滚 → 再生成看板：`summary.commits` 仍为 1；`提交/<id>.json` 还在。
- 本轮未单独跑该序列（时间给了四个重点），按 round6 M6 的代码路径复检，未发现修复。

**建议**

- 回滚时给 commit 加 `rolledBackAt` 并从 `project.commits` 过滤；`syncWorkbenchBoard` 删除对应 `提交/<id>.json`（或写 `rolledBack:true` 让旧看板过滤）。
- selftest 增加 apply→board→rollback→board 的计数下降断言。

---

### L13【低】D 盘主线成立，但运行期仍写 `%TEMP%`；`npm run selftest` 固定写根目录；webview 初始硬编码 52711

**位置**

- `src/main.js:15-25`：`LOCAL_DATA = AWB_DATA_DIR || ROOT/data`；`USER_DATA/TEMP_ROOT` 在其下；`82-84` `app.setPath`。
- `src/renderer/index.html:179`：`<webview id="dsh-view" src="http://127.0.0.1:52711" allowpopups>`；`app.js:4120-4128` 在拿到 state 后才改成配置地址。
- `package.json:14`：`selftest` 固定 `--user-data-dir=userdata-selftest`；`main.js:6057/6061` 把截图写 `ROOT`。

**运行时证据（E2E，数据根 `_tmp/qa7/e2e`）**

- `app.getPath('userData')` 生效：`C:\Users\Admin\AppData\Roaming\Electron` 最后写入 10:31（本轮 11:12 启动未更新）；`C:\…\Roaming\敏捷工作台` 最后 02:33（未更新）。
- `_tmp/qa7/e2e/data/tmp` 为空。
- 但 `%TEMP%` 出现两个本轮创建的临时文件：`75bcc067-…tmp`（0 B，11:12:20）与 `7d9f0a9c-…tmp`（83,582 B，11:13:55）；应用退出后两个文件**消失**。说明 Chromium 层仍会用 `%TEMP%`，只是正常退出会清理。
- 启动瞬间 CDP 的 webview 目标是 `http://127.0.0.1:52711/`（本机真实 DSH），随后才切到配置的 `50493`。

**影响**

- “D 盘保证”仍是“仓库恰好在 D + setPath”，不是产品约束；崩溃/强杀会在 C 盘留临时文件。
- 启动瞬间可能加载另一个 DSH 实例的界面（本机 52711 是真实 GUI），有串会话的观感风险。
- `npm run selftest` 会写仓库根两张 PNG 和 `userdata-selftest/`，无法用环境变量改到 `_tmp`（本轮只能复制应用规避）。

**建议**

- webview 初始 `src="about:blank"`，拿到 state 后再设地址。
- selftest 的输出目录用 `AWB_SELFTEST_OUT` 之类参数；默认仍可写根，但 CI/QA 可重定向。
- README 明确“数据默认随应用目录；`%TEMP%` 仍会被 Chromium 使用”。

---

### L14【低】无 `project` 字段的旧邮件对任何项目都可见

**位置**

- `团队/工具/lib/store.mjs:391`：`if (project && msg.project && msg.project !== project) continue;`
- 旧版 `sendMessage` 允许 `project` 为空（`store.mjs:369`），系统/欢迎/对账类邮件可能没有 project。

**现象**

- 按项目过滤时，`msg.project` 为空的邮件不会被跳过 → 每个项目的收件箱都能看到。

**影响**

- 跨项目看到系统/欢迎/对账邮件；数量少，但会干扰“本项目未读”的计数。

**建议**

- `if (project && String(msg.project || '') !== project) continue;`，对 `from=system` 明确例外并标注。

---

## 4. 按任务重点逐项判定

| 重点 | 判定 | 依据 |
|---|---|---|
| `inbox/read` 真实可用 | **PARTIAL** | 运行时可用：`team:inbox` 返回真实邮箱与 `verified-session` 身份，`team:read` 能 `new→cur`，重复 read 幂等；但 `read` 有写副作用（M8），且不校验消息项目（M6）。 |
| session 核验 | **PASS（角色/工作区）** | inbox/read/send/ack 都核验 `project.sessions[role]` + DSH `session/list` 存在/未归档 + workspace/cwd；错误会话被 `SESSION_IDENTITY_MISMATCH` 拒绝（selftest 与 E2E 均复现）；坏 `workspace.path` 被 `WORKSPACE_PATH_MISMATCH` 拒绝。 |
| `team:send` 唤醒是否四步 | **PASS（文案与投递）** | 文案含 `boot`/`inbox --all`/`read --id`/`ack --id` 四步，mock 收到 `session/prompt`；`wake.ok=true`。但工具路径口径有坑（M7）。 |
| 角色能否自己回执 | **PARTIAL/FAIL（闭环）** | 旧协议侧可以：角色 CLI `ack` 退出码 0、回执落盘、旧锁清除；工作台侧不认：本地 `pendingAck` 不清（H1），并且壳会补写身份（H2）。 |
| 回执 actor 是否冒充 | **FAIL** | 新回执的 `actor=workbench-shell` 是诚实的；但 `already` 路径把角色自回执补成 `sessionId=映射会话 + identitySource=verified-session`（H2），且 UI 文案说“壳不能代写”。 |
| 跨项目 manifest/workspace 污染 | **PASS（清单）/ PARTIAL（消息）** | `团队会话.json` 的 `workspace` 必须 realpath 等于项目目录，复制 A 的清单到 B 被 `MANIFEST_WORKSPACE_MISMATCH` 拒绝，伪造清单的 send 被 `SESSION_IDENTITY_MISMATCH` 拒绝（selftest + E2E）；但 read/ack 不校验消息项目（M6）。 |
| 并发 send/ack/cancel 丢写 | **FAIL（send/cancel）/ PASS（store 合并）** | 双 send 造幽灵邮件 + `[INTERNAL]`（H3）；cancel 误释放活锁（H4）；`writeStore` 的“await 后重读合并”在 send+createTask/ack+createTask/cancel+createTask 下不丢（selftest ROUND6 `concurrency`）。 |
| 旧锁释放 | **PARTIAL/FAIL** | 正常 ack/cancel 能按 `messageId` 精确释放；超时释放也 OK；但 `expected` 为空时会释放任意当前锁（H4），角色自回执后本地不认（H1）。 |
| 删除归档 | **PARTIAL** | 项目状态目录归档到 `_deleted/<ts>-<slug>`，`stopActivity:true`，DSH 离线写 `pendingCleanup`；但清理失败被吞（M11），队列无消费者（M9），UI 文案与实际相反（H5）。 |
| D 盘数据 | **PASS（本次运行）/ PARTIAL（产品保证）** | 本轮 QA 与工作台数据都在 `D:\deepseek\agile-workbench\_tmp\qa7`；真实账本/真实 profile 未被写；但 Chromium 运行期仍写 `%TEMP%`，selftest 固定写根目录（L13）。 |
| DSH 主壳/六角色 | **PASS（6/6）** | 一个项目 = 一个 workspace（`qa-ws-1`），六角色 `qa-session-1..6`，标题 `团队·角色`，重复 provision 不新建；但启动时 index 刷新失败被吞（M7），webview 初始硬编码 52711（L13）。 |

---

## 5. 做对了什么（正向证据，不要只报坏消息）

1. **`npm run check` / `npm run selftest` 全绿**：122 项断言 0 失败，`SELFTEST_OK`，退出码 0（§1.3）。
2. **收件箱是真的**：`team:inbox` 走旧协议 `inbox --all`，`team:read` 走 `read`，不是拿本地镜像假装；E2E 的 `identity` 是 `verified-session`，selftest 的 `inboxAfter` 能读到刚派的邮件（`box:new`），read 后 `box:cur`。
3. **四步唤醒是真的**：`wakeMessageFor` 生成 9 行文案，包含 `boot`/`inbox --all`/`read --id`/`ack --id`，并真的通过 `dsh.prompt` 投递；E2E 的 mock 计数到 prompt。
4. **会话核验是同一把尺子**：send/ack/inbox/read/dsh:prompt 都走 `verifyProjectRoleSession`；E2E 用错误会话调 inbox 被 `SESSION_IDENTITY_MISMATCH` 拒绝；`workspace.path` 与项目目录不一致时直接 `WORKSPACE_PATH_MISMATCH`。
5. **manifest 跨项目防线有效**：复制 A 的 `团队会话.json` 到 B → `MANIFEST_WORKSPACE_MISMATCH`，不恢复 session/workspace；伪造清单能写进映射，但 send 时被 `SESSION_IDENTITY_MISMATCH` 拒绝（selftest `forgedManifest`）。
6. **store 并发合并**：`team:send`/`team:ack`/`team:cancel` 都在 `await` 后 `readStore()` 再合并，selftest 的 `send+createTask`/`ack+createTask`/`cancel+createTask` 不丢任务、不丢锁。
7. **删除是归档不是物理删除**：旧项目状态进 `_deleted/<ts>-<slug>`；会话归档带 `stopActivity:true`；DSH 离线有 `pendingCleanup` 字段（虽然没消费）。
8. **D 盘主线**：`app.setPath('userData'/'sessionData'/'temp')` 生效，本轮 `Roaming\Electron`/`Roaming\敏捷工作台` 未被更新；真实账本 11-03 的 `团队.json`/`回执.jsonl` 未被触碰。
9. **六角色映射**：一个项目一个 workspace，六会话标题 `团队·角色`，重复 provision 0 新建（selftest `provisionAgain:0`）。

---

## 6. 真实账本与 D/C 盘核查

### 6.1 真实账本（本轮未写）

`D:\deepseek\agile-workbench\团队\状态`（07:05 从旧仓库整目录拷贝）：

| 指标 | 数值 |
|---|---:|
| 邮箱 `.json` 总数 | 392 |
| `new/`（未读） | 128（pm 59 / analyst 18 / tester 17 / programmer2 13 / programmer1 12 / product 9） |
| `cur/`（已读） | 264 |
| `回执.jsonl` 行数 | 328（其中 `update:true` 163 → 真实回执 165） |
| `回执.jsonl` 带 `identitySource` | **0 行** |
| `事件.jsonl` 行数 | 1,212 |
| `启动/<token>.json` | 91（全部过期，无清理器） |
| `项目/*/派单锁.json` | 0 |
| `状态/项目` 目录 | 6（`_deleted` 0） |

`identitySource=0` 说明：**工作台还从未在真实账本上成功写过一条回执身份**；本轮 E2E 的补写发生在 `_tmp` 沙盘。这也意味着 H2 的“补写”一旦在真实账本上用，就是第一次改这本 328 行的账。

文件时间：`团队.json` 2026-11-03 08:17:20（1,850 B）、`回执.jsonl` 2026-11-03 08:48:15（86,352 B）、`事件.jsonl` 2026-11-05 07:05:18（779,374 B）——本轮结束仍是这些时间，未被写。

### 6.2 本次运行落点

| 路径 | 内容 |
|---|---|
| `D:\deepseek\agile-workbench\_tmp\qa7\app` | 应用副本（`src/`、`package.json`、`团队/` 工具与模板；`node_modules` 为 junction） |
| `_tmp\qa7\sandbox` / `sandbox-npm` | selftest 沙盘（运行期存在，退出后 `团队/` 被清理） |
| `_tmp\qa7\e2e` | E2E 数据根（`data/`、`team/`、`projects/`、`userdata/`） |
| `_tmp\qa7\probe1..3` | 组件探针的团队根/项目 |
| `_tmp\qa7\*.js` / `*.log` | mock、CDP 驱动、探针、selftest 日志 |
| `_tmp\qa7\app\selftest*.png` | selftest 截图（11:21:46） |

`_tmp/qa7/app/node_modules` 是指向仓库的 junction；清理时用 `cmd /c rmdir` 删除链接本身，不要递归删到仓库。

### 6.3 C 盘

- `C:\Users\Admin\AppData\Roaming\敏捷工作台`：72 文件、约 12.57 MB，最后写入 2026-11-05 02:33:40——**本轮未更新**（历史遗留，来自早期版本）。
- `C:\Users\Admin\AppData\Roaming\Electron`：最后写入 10:31:03——**本轮 11:12 启动未更新**。
- `%TEMP%`：本轮应用运行期间出现 `75bcc067-…tmp`（0 B，11:12:20）与 `7d9f0a9c-…tmp`（83,582 B，11:13:55），应用退出后**自动消失**；`_tmp/qa7/e2e/data/tmp` 为空。结论：应用自己的 temp 在 D，Chromium 层仍会短暂用 C:%TEMP%。
- 根目录 `selftest*.png`：最后写入 10:51:52/53，本轮未动；`userdata-selftest/` 本轮未新增（副本里跑的是 `_tmp/qa7/app/userdata-selftest`）。

### 6.4 DSH 主壳与六角色（本轮实测）

适配层只使用公开 RPC（`src/dsh-adapter.js`）：

| 用途 | RPC | 备注 |
|---|---|---|
| 探活/列会话 | `session/list` | 每次请求重读 `.credentials.yaml`，401/403 重铸 cookie 重试一次 |
| 项目=工作区 | `workspace/create` | 按目录幂等，返回 `workspaceId/sessionIds/created` |
| 建角色会话 | `session/create` | 只传 `cwd` 或 `workspaceId` 之一 |
| 改标题 | `session/rename` | 标题固定 `团队·<角色>` |
| 唤醒 | `session/prompt` | `mode:'queue'`，文本是四步文案 |
| 归档 | `workspace/archiveSession` | `stopActivity:true` |

E2E 实测（mock）：

- `createProject` → 1 个 workspace `qa-ws-1`；`dshProvision` → 6 个会话 `qa-session-1..6`，`mapping.sessionCount=6`，标题全部 `团队·角色`，没有额外会话；
- 第二次 `dshProvision` → `created:0`（复用，不新建），但带 index 失败 warning（M7）；
- 角色会话与项目的绑定存 `project.sessions`，send/ack/inbox/read 都按它核验；
- 主壳 webview 在 state 到达后指向配置地址（50493），启动瞬间的 52711 见 L13。

本轮没有用真实 DSH 建会话/发 prompt；真实 DSH 是否总在 `session/list` 返回 `cwd/workspaceId` 未验证（§10）。

---

## 7. 只读边界与残留

- **新增**：仅 `docs/QA-ROUND7.md`。
- **未修改**：`src/`、`package.json`、`package-lock.json`、`node_modules/`、`团队/`、旧仓库 `D:\deepseek\工作台`、`D:\deepseek\luanyujia-workbench`。6 个源文件的 SHA256 在审计开始/结束一致（§1.1）；真实账本三个文件的 mtime 未变（§6.1）。
- **临时产物全部在** `D:\deepseek\agile-workbench\_tmp\qa7\`（约 12.6 MB，含 E2E 的 Chromium userdata 与 selftest 截图；不含 node_modules junction）。
- **未把 QA 文件写进 `%TEMP%`**。唯一一处 C:%TEMP% 是 DSH `grep` 工具自动生成的 spill 文件（`C:\Users\Admin\AppData\Local\Temp\dsh-spill-QknHhe\session-11de99ef80da\5177c0f4a8ce-grep-results.txt`，10:57），属于工具自身行为，不是我主动写的 QA 产物；已在此披露。
- 为守住“只新增 docs”边界，**没有直接在工作仓库根跑 `npm run selftest`**（它会写根目录 `selftest*.png` 与 `userdata-selftest/`），而是在字节一致的 `_tmp/qa7/app` 副本里跑同一条 npm script；E2E 的主进程 RPC 只连本地 mock（监听 `127.0.0.1` 随机端口），没有向真实 DSH 发 prompt/建会话；唯一的真实 DSH 接触是 webview 初始 `src=52711` 的闪现（L13），未在该页面操作。
- 未改动 `团队/状态`；所有旧协议写操作都指向 `_tmp` 下的沙盘团队根。

---

## 8. 建议修复顺序

**P0（先修，影响审计/数据完整性）**

1. **H3**：按项目串行化 `team:send/ack/cancel`；失败后回读邮箱对账；`INTERNAL/ENOENT/LOCK_BUSY` 归一成结构化错误码。
2. **H2**：停止在 `already` 回执上补写 `sessionId/identitySource/workspaceId`；改 `identityCheckedBy/At`；修回执弹窗文案（明确 actor=workbench-shell）。
3. **H1**：`pendingAck` 与旧 `派单锁.json` 对账（state/发送前/定时），角色自回执后立即清本地锁。
4. **H5**：删除对话框与行为一致（默认不归档会话，或逐条列出将发生的事）；结果展示 `archived`。
5. **H4**：cancel 只释放与本地 pending/目标 id 匹配的锁；不匹配就拒绝。

**P1（旧流程可用性）**

6. **M6**：`read/ack` 校验消息 `project`/`to`。
7. **M7**：统一 `toolsDir`；wake/UI 命令带 `TEAM_ROOT` 或统一用实际路径；index 失败可读、可断言。
8. **M8**：inbox 走无 boot 只读；不在 inbox 路径 ensure；清过期令牌。
9. **M9**：消费 `pendingCleanup`（启动/切项目重试 + UI）。
10. **M10**：回执身份 append-only；给 `annotateReceiptIdentity` 加边界。
11. **M11**：删除清理失败进 `warnings`/`pendingCleanup`。

**P2（一致性与边界）**

12. **L12**：回滚提交从旧看板移除/标记；补 apply→board→rollback→board 断言。
13. **L13**：webview 初始 `about:blank`；selftest 输出目录可重定向；文档写明 `%TEMP%` 例外。
14. **L14**：旧邮件 project 过滤改为严格匹配（system 例外）。

**测试建议（不要只断言 `checks:true`）**

- 加一条“角色 CLI 自回执”用例：角色 boot/ack 后，`state.pendingAck === null`，下一条 send 成功，`回执.jsonl` 的新行**没有** `identitySource` 或明确 `identityCheckedBy=workbench-shell`。
- 加双 `team:send` 并发用例：断言只产生一条本地消息、邮箱一封、错误码是 `TEAM_SEND_RACE` 且可重试。
- 加 `team:cancel` 传入不存在 id/无 `teamMessageId` 的用例：断言拒绝释放当前锁。
- 加 delete 用例：断言 `archived` 列表与 UI 文案一致；DSH 离线 → 恢复 → `pendingCleanup` 被消费。
- 加自定义 `TEAM_ROOT` 用例：`launch` 的 `errors.length === 0`，`teamToolPath` 文件存在。
- 加跨项目 read/ack 用例：B 会话读 A 邮件必须 `MESSAGE_PROJECT_MISMATCH`。

---

## 9. 复现方式（全部在 `_tmp/qa7`）

```powershell
cd D:\deepseek\agile-workbench
npm run check

# 1) D 盘 selftest（副本里跑，产物只落 _tmp）
$env:AWB_SELFTEST_ROOT='D:\deepseek\agile-workbench\_tmp\qa7\sandbox-npm'
cd _tmp\qa7\app
npm run selftest
# 期望：SELFTEST_OK；日志 _tmp\qa7\selftest-npm.log

# 2) 组件探针（四步唤醒 / 跨项目 / 回执并发）
cd D:\deepseek\agile-workbench\_tmp\qa7
node probe1.js
node probe2.js
node probe3.js

# 3) 端到端探针（真实主进程 + mock DSH）
node mock-dsh.js                       # 记下 MOCK_PORT
$env:AWB_DATA_DIR='D:\deepseek\agile-workbench\_tmp\qa7\e2e\data'
$env:TEAM_ROOT='D:\deepseek\agile-workbench\_tmp\qa7\e2e\team'
$env:DSH_WEB_URL='http://127.0.0.1:<MOCK_PORT>'
cd D:\deepseek\agile-workbench\_tmp\qa7\app
.\node_modules\.bin\electron.cmd . --remote-debugging-port=9333 --user-data-dir=..\e2e\userdata
# 另开一个终端
cd D:\deepseek\agile-workbench\_tmp\qa7
node e2e.js
```

`e2e.js` 的关键输出字段：`stateAfterRoleAck.pending`、`secondSend.error`、`receiptRows`、`concurrentSends.__error`、`deleteB.sessions.archived`、`deleteBAfter.manifestExists`。

---

## 10. 本轮没做的事（避免误读）

- 没有连真实 DSH（`127.0.0.1:52711`）发 prompt 或建会话；E2E 的六个会话来自本地 mock，`sessionId` 形如 `qa-session-N`。
- 没有对真实账本执行 send/ack/read/delete；所有旧协议写都在 `_tmp` 沙盘。
- 没有在真实项目目录跑 `ensureProject`/`launch`；`probe1` 的 24 个文件生成在 `_tmp/qa7/probe1/项目A`。
- L12 只做了代码复检，没有重跑 apply→rollback→board 的运行时序列；按证据等级标为“静态”。
- 没有验证真实 DSH 的 `session/list` 是否总带 `cwd/workspaceId`；会话核验的结论以 mock 和代码为准，真实 DSH 若字段缺失，`sessionInProjectWorkspace` 的 snapshot/cwd 回退需要另测。
