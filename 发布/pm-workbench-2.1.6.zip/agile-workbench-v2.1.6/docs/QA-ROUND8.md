﻿# 敏捷工作台 v0.1 · 第八轮只读 QA（回执 / actor / 看板 / Owner / 收件箱 / D 盘 / DSH）

> 范围：本轮只读检查 8 个指定面——①`team:receipts` 是否真正读旧 `团队/状态/回执.jsonl`，去重、过滤、安全；②回执 actor 是否冒充；③看板折叠 / 切项目 / 刷新 / 关闭；④Owner `warnings/workflowFile/notified`；⑤收件箱 UI 是否偏离旧版；⑥D 盘；⑦DSH 主壳 / 六角色；⑧`npm run check` + D 盘 selftest 的正向证据。
> 只读边界：本轮**只新增本文件** `docs/QA-ROUND8.md`；未修改 `src/**`、`package.json`、`package-lock.json`、`node_modules/**`、`团队/**`、`项目/**`、旧仓库 `D:\deepseek\luanyujia-workbench` 与 `D:\deepseek\工作台`。所有 QA 临时文件、日志、截图、端口与沙盘均在 `D:\deepseek\agile-workbench\_tmp\qa8\`；QA 自己的临时文件未写 `%TEMP%`。
> 证据分级：**运行时** = 真实主进程 IPC（Electron 副本 + 本地 mock DSH + CDP）；**组件** = 直接调用 `src/team-tools.js` / 临时账本；**静态** = 只读源码 / 旧版四文件对照。凡“运行时”结论都附 `_tmp/qa8` 可复跑脚本和 JSON 输出。

---

## 0. 结论速览（先看这 12 条）

1. **`npm run check` 通过；D 盘沙盘 selftest 通过（SELFTEST_OK，125 项断言 0 失败）。** 但这两项都**不能证明**本报告 H1/H2/H3 三条：selftest 的 ROUND6 只测“壳代跑 ack”，没有测“角色自己 ack 后本机 pendingAck 应为空”；也没有测回执账本并发追写、`team:cancel` 假 id。
2. **H1【高】角色自己按旧协议 ack 后，本机 `pendingAck` 不回收，PM 被假锁挡住 10 分钟。** 运行时：角色 CLI ack 退出码 0，旧工具 ack 已执行 `clearDispatchLock`，`回执.jsonl` 已写入；`state.pendingAck` 仍是该消息、`ack:false`，紧接着的第二次 `team:send` 被拒绝“还有一条派单未回执”。
3. **H2【高】`annotateReceiptIdentity` 全量读改写回执账本，会丢掉 read 与 rename 之间追加的回执。** 组件：在 read 返回后、atomic rename 前模拟另一个进程追加一条 `CONCURRENT`，`annotate` 返回 `IDENTITY_ANNOTATED changed:2`，但新行从账本消失（`lineCount=3`，`concurrentPresent=false`）。这是 append-only 审计账本的数据丢失，不只是并发报错。
4. **H3【高】`team:cancel` 用不存在的消息 id 可以释放当前任意旧 `派单锁.json`，本机 `pendingAck` 却保留。** 运行时：`M-QA8-DOES-NOT-EXIST` → `released.removed:true`、`cleared:false`、`pending` 仍是真实消息，旧锁文件从 true 变 false。之后本机锁和旧协议锁不一致，PM 可以再发出一条“看似不该发”的派单。
5. **H4【中高】回执 actor / 身份字段仍不能区分“角色自己 ack”和“壳代跑 ack”。** 运行时：角色自己 ack 的两行回执被补成 `sessionId=qa-session-3`、`identitySource=verified-session`、`workspaceId=qa-ws-1`，但 `actor=null`；随后壳点“记录回执”返回 `already:true`、`actor=pre-existing`，本机消息也写成 `pre-existing`。没有字段能回答“到底是谁执行的”，只能从注释猜。
6. **M5【中】`team:receipts` 的项目过滤会被 `includeUnassigned:true` 放大成跨项目可见。** 前端固定传 true；组件账本中一条空 `project` 的回执在“项目A”查询里出现（strict 2 条 → withEmpty 3 条）。当前真实账本空 project 行是 0，所以这是**潜伏**问题，一旦导入旧账本/老回执就会串项目。
7. **M6【中】Owner 的 PM 通知失败只活在本次 IPC 返回值里，刷新即丢。** 运行时：临时移走 `owner-note.mjs` 后，`workflowFile` 正常、`notified:null`、`warnings:[OWNER_NOTE_MISSING]`，但项目事件只有“项目创建 / 绑定工作区 / Owner 评审：approved”，没有通知失败；`ownerResults` 又是内存 Map，刷新后卡片消失。
8. **M7【中】看板“加载中切项目”会丢掉新选择，最后显示旧的看板项目。** 运行时：打开看板（当前项目 C）后 20ms 内选项目 B，2.5s 后 `select/subject` 仍是 C，`wanted=id:B` 被覆盖；`loadBoardPanel` 的 `if (boardUi.loading) return null` 在 subject 已被改掉之后直接返回。折叠 / 展开 / 关闭本身正常。
9. **M8【中】`team:read` 只校验角色会话，不校验消息的 `project`；B 项目会话可以消费 A 项目邮件。** `team:inbox` 有 project 过滤，`team:read` → `readFor` → 旧 `readMessage(role,id)` 按角色全局邮箱找 id，没有 `msg.project === project`。这是跨项目隔离缺口（静态证据）。
10. **M9【中】多处“壳不代写 / 壳不能代写”文案与主进程行为相反。** `.dispatch-rule`、`.inbox-rule`、`openAckModal` 都写“壳不代写”；但 `main.js:4153-4155` 明确以 `actor:'workbench-shell'` 执行 `team.mjs ack`，selftest 也断言 `actor=workbench-shell`。这会让审计者以为回执一定来自角色会话。
11. **L10【低/中，parity】严格对齐旧版时，收件箱仍是新增面，入口也仍在。** 旧版四文件 `inbox/收件/未读/team:send/team:ack/team:read` 全部 0 命中；当前 `#inbox-block` 虽然折叠并标“调试”，但 `#more-menu [data-more=inbox]`、角色卡 `[data-role-inbox]`、团队消息行 `[data-msg-inbox]` 仍可达；`#team-receipts` 也是旧版团队台没有的块。按旧版严格对齐，这些入口应删除或只留开发开关。
12. **L11【低】默认项目根写的是 `ROOT/projects`，仓库和文档用的是 `项目/`。** 当前根目录只有 `项目/`（5 个项目），没有 `projects/`；`state.defaultRoot`、`createProject`、`project:discover`、`team-tools.localProjectDirs` 都走 `projects/`，`docs/ARCHITECTURE.md:29` 与 `.gitignore` 不一致。UI 新建项目会落到另一个目录，形成第二套项目区（仍在 D 盘，但数据分裂）。

**一句话：** 回执列表能读到旧账本，旧看板口径计数也对；但“角色自己回执”和“壳代跑回执”两条路径仍然没有对账，账本本身又会在并发窗口丢行，`team:cancel` 还能制造本地锁/旧锁不一致。绿 check 与绿 selftest 都没有覆盖这三条主路径。

---

## 1. 快照、运行与证据

### 1.1 源码快照（审计开始与结束一致）

| 文件 | 字节 | SHA256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 342,991 | `36D9FA6F62B70690` | 2026-11-05 11:56:56 |
| `src/team-tools.js` | 92,744 | `714F2495F0D8F2A2` | 2026-11-05 11:56:43 |
| `src/preload.js` | 4,750 | `1955CC1DC8F79D63` | 2026-11-05 11:47:09 |
| `src/renderer/app.js` | 261,159 | `2B91FE3AAE73865B` | 2026-11-05 12:15:47 |
| `src/renderer/index.html` | 36,953 | `BB70686271D092F1` | 2026-11-05 11:49:56 |
| `src/renderer/style.css` | 101,066 | `73CCED0709A93B84` | 2026-11-05 11:54:29 |

> `docs/PARITY-ROUND8.md` 的 S8 快照是 `app.js 260,416 / 45AFE…`；本轮开始时已是 261,159 / `2B91…`，所以本报告**不引用 S8 的行号**，一律以当前符号和当前行号为准。审计期间源码未再变化（结束哈希与上表一致）。

### 1.2 `npm run check`

```powershell
PS D:\deepseek\agile-workbench> npm run check
> agile-workbench@0.1.0 check
> node --check src/main.js && node --check src/preload.js && node --check src/renderer/app.js
  && node --check src/dsh-adapter.js && node --check src/team-tools.js
EXIT=0
```

只证明语法，不证明行为。

### 1.3 D 盘 selftest（沙盘副本，避免写仓库根）

官方 `npm run selftest` 会 `electron . --selftest --user-data-dir=userdata-selftest`，且在 `main.js:6356/6360` 把 `selftest-flow.png` / `selftest.png` 写进 `ROOT`。为遵守“只新增 `docs/QA-ROUND8.md`”，本轮把 `src/`、`package.json`、`团队/工具|角色|模板|协议` 复制到 `_tmp/qa8/app`，`node_modules` 用 junction 指回仓库，再在副本执行**同一条 npm script**：

```powershell
$env:AWB_SELFTEST_ROOT='D:\deepseek\agile-workbench\_tmp\qa8\sandbox'
$env:ELECTRON_RUN_AS_NODE=$null
cd D:\deepseek\agile-workbench\_tmp\qa8\app
npm run selftest        # EXIT=0
```

| 套件 | 断言数 | 失败 |
|---|---:|---:|
| `SELFTEST_STORE` | 20 | 0 |
| `SELFTEST_COMPAT` | 45 | 0 |
| `SELFTEST_MAPPING` | 39 | 0 |
| `SELFTEST_ROUND5` | 4 | 0 |
| `SELFTEST_ROUND6` | 17 | 0 |
| **合计** | **125** | **0** |

`SELFTEST_OK`，`EXIT=0`。运行时报告：

```json
{"drive":"D:\\","teamRoot":"D:\\...\\_tmp\\qa8\\sandbox\\团队","testRoot":"D:\\...\\_tmp\\qa8\\sandbox"}
```

**selftest 的盲区（本轮据此设计探针）**：ROUND6 的 actor 断言覆盖“壳代跑 ack → receiptActor=workbench-shell”，没有覆盖“角色自己 ack → 本机 pendingAck 清空 / 角色回执 actor 不被补写”；也没有覆盖 `team:cancel` 假 id、并发写账本、看板加载中切项目。

### 1.4 真实主进程 E2E（只读探针）

脚本：`_tmp/qa8/e2e.js`；应用副本：`_tmp/qa8/app`；mock DSH：`_tmp/qa7/mock-dsh.js`；数据 / 团队 / DSH_HOME / TMP 全部指向 `_tmp/qa8/e2e`。

```powershell
$env:ELECTRON_RUN_AS_NODE=$null
node D:\deepseek\agile-workbench\_tmp\qa8\e2e.js
# EXIT=0；输出 _tmp/qa8/e2e.log
```

本次真实跑通：

- 新建 3 个临时项目，DSH mock 建 6 个角色会话（`qa-session-1..6`，workspace `qa-ws-1`）；
- PM→analyst 派单，`source=team`、`lockTaken=true`、唤醒 `ok:true`；
- 角色 CLI 自己 `boot` + `ack`（退出码 0）；
- 接着调 `state()` / 第二次 `teamSend` / 壳 `teamAck` / `teamReceipts`；
- `teamCancel` 假 id 探针；
- Owner 通知失败探针（只临时移走副本里的 `owner-note.mjs`，随即恢复）；
- 看板浮窗打开、加载中切项目、折叠/展开/关闭；
- DOM 入口与文案检查。

> 说明：e2e 的临时 `TEAM_ROOT` 只放了状态，没有把 `团队/工具` 联接进去，因此 `provision.warnings` 里出现一条 `launch.mjs` index 的 `MODULE_NOT_FOUND`；这是**临时根的工具路径没铺好**，不是本轮产品缺陷，真实默认 `TEAM_ROOT` 有工具。send/ack/看板/回执均不受影响。

### 1.5 组件探针

| 脚本 | 目的 | 输出 |
|---|---|---|
| `_tmp/qa8/probe-receipts.js` | 读真实旧 `回执.jsonl` 计数；合成空 project / 去重 / 过滤 | `_tmp/qa8/probe-receipts.log` |
| `_tmp/qa8/probe-rewrite.js` | 在 read 与 rename 之间模拟并发追加 | stdout JSON |

两个脚本都只读或只写 `_tmp/qa8` 下的临时账本。

---

## 2. 问题清单

| 级别 | 编号 | 问题 | 证据 |
|---|---|---|---|
| **高** | H1 | 角色自己 ack 后本机 `pendingAck` 不回收，PM 被假锁挡 10 分钟 | 运行时 |
| **高** | H2 | `annotateReceiptIdentity` 全量读改写，丢掉并发追加的回执行 | 组件（确定性交错） |
| **高** | H3 | `team:cancel` 用不存在的消息 id 释放当前旧锁，本地锁保留 | 运行时 |
| 中高 | H4 | 角色自回执行被补 `verified-session` 身份；`actor` 空 / 壳补记变 `pre-existing`，无法区分执行者 | 运行时 + 静态 |
| 中 | M5 | `includeUnassigned:true` 让空 `project` 回执跨项目可见 | 组件 |
| 中 | M6 | Owner 的 PM 通知失败只返回一次，不落项目事件；刷新即丢 | 运行时 |
| 中 | M7 | 看板加载中切项目丢选择，最终显示旧项目 | 运行时 |
| 中 | M8 | `team:read` 不校验 `message.project`，B 项目会话可读 A 项目邮件 | 静态 |
| 中 | M9 | “壳不代写”文案与 `actor=workbench-shell` 的实际 ack 行为相反 | 静态 + selftest |
| 低/中 | L10 | 收件箱 / 团队台回执块仍是旧版没有的新增面，三个入口仍在 | 静态 + DOM |
| 低 | L11 | 默认项目根 `projects/` 与仓库 / 文档的 `项目/` 不一致 | 静态 + 文件系统 |
| 低 | L12 | 回执列表不显示 `actor/executor/identitySource`，审计字段只存在于 IPC | 静态 + 运行时 |

> L10–L12 是 parity / 可审计性问题，不与 H1–H3 的数据正确性问题混级。

---

## 3. 问题详情

### H1【高】角色自己 ack 后，本机 `pendingAck` 仍是旧消息；PM 被假锁挡住 10 分钟

**位置**

- `src/main.js:1439-1466` `reconcileExpiredLocks`：只在 `pendingAckExpired`（10 分钟 TTL）时清本地锁；
- `src/main.js:1470` `statePayload` 每次只调它，没有“旧锁已消失 / 回执已有该 msgId → 反向清本地锁”的路径；
- `src/main.js:3732-3734` `team:send` 只看 `project.pendingAck` 是否过期；
- `src/main.js:4045-4049` `team:ack` 只在壳自己完成 ack 后（`4246-4249`）清 `pendingAck`；角色 CLI 自己 ack 不经过这里。

**运行时证据**（`_tmp/qa8/e2e.log`）

```json
"afterSend": {"pending":"M-20261105-122655-db08a5","ack":false},
"roleAck": {"code":0,"stdout":"{\"ok\":true,\"ack\":{\"id\":\"A-...-938260\",...}}"},
"afterRoleAck": {"pending":"M-20261105-122655-db08a5","ack":false,
                 "actor":"workbench-shell","identitySource":"verified-session"},
"secondSend": {"ok":false,
  "error":"Error invoking remote method 'team:send': Error: 还有一条派单未回执，先等回执、撤销，或等 10 分钟超时"}
```

同时 `团队/状态/项目/QA8自回执/派单锁.json` 已不存在（角色 CLI ack 删除了它），`回执.jsonl` 已有该 `msgId` 的两行回执。旧协议闭环完成，壳却仍认为没有回执。

**影响**

- 角色按旧协议主路径认真执行，反而被工作台判“没回执”；
- PM 无法派下一条，只能等 10 分钟 TTL，或点“撤销派单”制造一次不一致；
- 界面显示“待回执 / 剩余 09:xx”，与实际旧锁状态相反；
- 这正是 QA-ROUND7 H1 的复现；当前源码未修，且 selftest 仍不覆盖。

**建议**

- 在 `statePayload` / `team:send` 前加一次只读对账：`project.pendingAck` 存在，但 `readDispatchLockState(teamName)` 为空，且 `回执.jsonl` 中该 `msgId` 有 `!update` 行 → 清本机锁并记事件“角色自回执（旧协议锁已释放）”；
- 或提供 `team:reconcile` IPC，在打开团队台时触发；
- selftest 增加：角色 CLI ack 后 `state.pendingAck === null`、下一次 `teamSend` 成功。

---

### H2【高】回执账本全量读改写：并发追加的行会被静默丢掉

**位置**

- `src/team-tools.js:1395-1442` `annotateReceiptIdentity`：`fs.readFileSync(layout.receiptsFile)` 读全量 → `writeTextAtomic(layout.receiptsFile, next.join('\n'))` 覆盖；
- `src/team-tools.js:1437` 的写回不是 append，而是整文件替换；
- 调用点：`src/team-tools.js:1753-1763`（新 ack 后补身份）、`1765-1776`（already 后补身份）。

**组件证据**（`_tmp/qa8/probe-rewrite.js`）

在 `fs.readFileSync` 返回后、`writeTextAtomic` 的 rename 前，模拟另一个角色进程追加 `CONCURRENT`：

```json
{
  "injected": true,
  "annotate": {"ok": true, "code": "IDENTITY_ANNOTATED", "changed": 2},
  "lineCount": 3,
  "ids": ["TARGET", "OTHER", "TARGET"],
  "concurrentPresent": false
}
```

`annotate` 返回成功，新回执行消失。Windows 上并发写还可能直接 `EBUSY`（QA-ROUND7 M10 已探针复现），但本轮只证明更严重的一面：**rename 成功也会丢数据**。

**影响**

- `回执.jsonl` 是旧协议 append-only 审计账本；丢一行就少一条“谁在何时回执了什么”；
- 丢的恰好可能是另一个角色刚写的新回执；后续 `team:receipts` / 旧看板计数会对不上；
- 与 H1 叠加时，账本有回执、本机没 ack，进一步制造“有账无锁 / 有锁无账”。

**建议**

- 不要在 ack 路径重写全文件；改用 append-only 的身份侧车（如 `回执身份.jsonl`，按 `ackId` 追加），或对账本加跨进程锁并“读-合并-追加”；
- 若必须改写，先写临时文件再 rename 前重新 stat / 读尾，确认没有新行；失败时返回 `RECEIPT_WRITE_FAILED` 而不是成功；
- selftest 增加“annotate 期间并发 append”断言。

---

### H3【高】`team:cancel` 假消息 id 释放当前旧锁，本机锁却不释放

**位置**

- `src/main.js:3979-4005`：`requestedId` 不匹配任何本地消息时 `messageNow=null`、`expected=''`；
- `3992-4002`：只要 `lockBefore` 存在，就 `releaseDispatchLock(teamName, lockBefore.messageId)`，不要求 `expected` 非空；
- `4018-4029`：`target = requestedId || ...`，`cleared` 只在本机 `pendingNow === target` 时为 true；假 id 时 `cleared:false`。

**运行时证据**

```json
"fakeCancel": {
  "ok": true,
  "released": {"ok": true, "code": "LOCK_RELEASED", "removed": true,
               "pending": {"messageId": "M-20261105-122656-a7af74", "to": "analyst"}},
  "lock": {"messageId": "M-20261105-122656-a7af74", ...},
  "cleared": false,
  "warnings": [],
  "pending": "M-20261105-122656-a7af74"
},
"lockAfterFakeCancel": false
```

**影响**

- 本地仍认为有 pending，旧协议锁已经没了；此后 `teamSend` 本地锁会拒绝，PM 以为被锁，实际旧协议已经可再派；
- 反过来，如果先绕过本地锁，旧协议可再派一条，造成两套状态；
- `warnings:[]` 让调用者完全看不出“释放的不是请求的锁”。

**建议**

- `requestedId` 非空且找不到本地消息时，直接 `MESSAGE_NOT_FOUND`，不进入释放；
- 只有显式 `releaseOrphan:true` 才允许按 `lockBefore.messageId` 释放无主旧锁；
- 返回 `cleared:false` 时必须带 warning（“旧锁已释放但本地 pending 未清”），不能静默成功。

---

### H4【中高】回执 actor / 身份字段不能区分“角色自己 ack”和“壳代跑 ack”

**位置**

- `src/team-tools.js:1765-1776` `already` 分支：`annotateReceiptIdentity(..., actor: input.existingActor || '', executor: '')`，随后 `result.actor = result.ack.actor || 'pre-existing'`；
- `src/team-tools.js:1429-1431`：`actor` 只在 `!row.actor` 时写入；`executor` 同理；
- `src/main.js:4161-4162`：`already` 时 `ackActor='pre-existing'`；
- `src/main.js:4222-4223`：本机 `currentMessage.actor = ackActor`、`executor = ackActor === 'workbench-shell' ? ... : 'unknown'`；
- `src/renderer/app.js:1101-1113` `receiptMarkup` 不渲染 `actor/executor/identitySource`。

**运行时证据**

角色自己 ack 的两行回执：

```json
{"actor":null,"executor":null,"sessionId":"qa-session-3",
 "identitySource":"verified-session","update":false}
```

壳点“记录回执”（旧协议 `already`）：

```json
"shellAck":{"ok":true,"source":"team","actor":"pre-existing","already":true,
            "warnings":[{"code":"ACK_ALREADY","message":"...actor 不写 workbench-shell"}]}
"stateAfterShellAck":{"pending":null,"ack":true,"actor":"pre-existing",
                      "identitySource":"verified-session"}
```

**问题**

- `sessionId` / `identitySource` 是壳核验后补写的，读者很容易把它当成“执行者会话”；但真正执行的是角色 CLI，`actor` 却是 `null`；
- 壳随后把本机 actor 写成 `pre-existing`，抹掉了“这条回执到底是谁写的”；
- 如果此前有一条壳写过的 `actor=workbench-shell` 回执，重复点击也会被本机写成 `pre-existing`，丢失已有 actor；
- UI 的“最近回执”只看 `from`，不显示 actor，审计者无法从界面复核。

**建议**

- 明确拆字段：`executedBy`（`role-cli` / `workbench-shell` / `manual`）与 `verifiedBy`（DSH 核验）；不要把 `verified-session` 当成执行者；
- `already` 时保留旧行已有 actor；没有就写 `unknown`，不要写 `pre-existing` 再覆盖本机；
- 对角色自回执行不要补写 `sessionId` 作为“执行会话”；如果要补，写 `observedSessionId` 并标注 `observedBy: workbench-shell`；
- UI 回执行增加“执行者 / 核验来源”，或明确提示“审计字段需看 JSON”。

---

### M5【中】`includeUnassigned:true` 让空 `project` 回执跨项目可见

**位置**

- `src/renderer/app.js:1252-1256`：`teamReceipts({ projectId, project, includeUnassigned: true, limit: 50 })`；
- `src/team-tools.js:1496`、`1570-1576`：`if (!value) return includeUnassigned;`。

**组件证据**（`probe-receipts.log`）

| 查询 | 结果 |
|---|---|
| `{projects:['项目A'], includeUnassigned:false}` | 2 条（A1、A3） |
| `{projects:['项目A'], includeUnassigned:true}` | 3 条（多出 `project:""` 的 A2） |

```json
{"id":"A2","msgId":"M2","from":"tester","project":"","note":"无项目"}
```

**影响**

- 旧账本里 `project` 为空的历史回执，会出现在**每一个**当前项目的团队台；
- 回执备注可能包含任务/文件/边界信息，跨项目可见是隔离缺口；
- 当前真实 `回执.jsonl` 空 project 行 = 0，所以目前未暴露；一旦导入旧账本/手工补账就会发生。

**建议**

- 前端默认 `includeUnassigned:false`；只在“旧看板全量视图”显式开启；
- 开启时给每行加“未归属”标签，不要混入当前项目列表；
- 后端对空 project 行要求显式 `includeUnassigned`，并返回 `unassigned:true` 供 UI 区分。

---

### M6【中】Owner 的 PM 通知失败只活在返回值；刷新即丢

**位置**

- `src/main.js:4269-4313` `owner:decide`：`outcome = ownerTeamOutcome(...)`，返回 `warnings/notified/workflowFile`；
- `src/main.js:2075-2087` `noteOwnerWorkflowFailure` 只处理 `workflowWrite` 失败，**不处理 `OWNER_NOTE_MISSING/OWNER_NOTE_FAILED`**；
- `src/renderer/app.js:335-346` `rememberOwnerResult` 存内存 Map；`39` 定义；`311-331` 只渲染该 Map。

**运行时证据**（临时移走副本 `团队/工具/owner-note.mjs`）

```json
"ownerNotifyFail": {
  "ok": true,
  "workflowFile": "...\\QA8通知失败\\工作流.json",
  "workflowWrite": {"ok": true, "attempted": true, "code": "OK"},
  "notified": null,
  "warnings": [{"code":"OWNER_NOTE_MISSING",
                "message":"旧版 owner-note.mjs 不存在，PM 收件箱没有写入系统消息"}],
  "events": ["项目创建","新建并绑定 DSH 工作区：qa-ws-3","Owner 评审：approved"]
}
```

**影响**

- 用户在本次弹窗里能看到“决定已保存，但有告警”；关闭/刷新后 `ownerResults` 为空，`#owner-result` 消失；
- 项目事件没有通知失败记录，后续排查只看到 Owner approved，误以为 PM 已收到；
- 通知失败不会被重试，也不会在“Owner 状态”卡片持续提示。

**建议**

- 把 Owner 决定的 `workflowFile/workflowWrite/notified/warnings` 持久化到项目 `events` 或独立 `ownerOutcome` 字段（含 code/message/at），刷新后恢复；
- 通知失败要显式“未送达 / 可重试”，并在 Owner 卡片保留红色标记；
- 或让 `recordOwnerDecision` 在 `notified=null` 时返回 `ok:false`，由主进程决定是否仍保存本地决定。

---

### M7【中】看板加载中切项目丢选择，最终显示旧看板项目

**位置**

- `src/renderer/app.js:1628-1641` `loadBoardPanel`：`if (boardUi.loading) return null;` 在函数开头；
- `src/renderer/app.js:1676-1703` `boardSwitchSubject`：先改 `subjectId/subjectName`、清 `data`，再调 `loadBoardPanel`；
- `src/renderer/app.js:1481-1496` `renderBoardPanel` 在 `boardUi.open` 时继续按 `subjectId/subjectName` 写 UI。

**运行时证据**

```json
"boardRace": {
  "first":{"id":"P-88658e47","name":"QA8自回执"},
  "second":{"id":"P-d2f2698d","name":"QA8未登记Owner"},
  "wanted":"id:P-d2f2698d",
  "selected":"id:P-bc7e6fde",
  "subject":"QA8通知失败",
  "badge":"已生成"
}
```

打开看板时当前项目是 `QA8通知失败`（C），第一笔 `loadBoardPanel` 在飞；20ms 内选 B，`boardSwitchSubject` 已把 `subject` 改成 B，但 `loadBoardPanel` 因 `loading` 直接返回；C 的结果回来后又把 `subject/select` 写成 C。**用户的选择被静默丢弃，且界面不报错。**

**影响**

- 看板显示的不是刚选的项目，用户可能对着错误项目做 Owner 判断；
- 切换/刷新没有队列或请求序号，快速操作必现；
- 与回执列表同类：`app.js:1246` 的 `if (receiptsUi.loading) return null;` 也会在切项目时让新项目停在“尚未读取”。

**建议**

- 给看板加载加 `requestId/subjectKey`，每次切项目递增；旧请求返回时若 key 不匹配直接丢弃，不覆盖新 subject；
- `boardSwitchSubject` 若正在 loading，记录 `pendingSubject`，当前请求结束后自动发起最新一次；
- 回执列表同样加请求 token / 自动补发；
- selftest/E2E 增加“加载中切项目”断言。

**正向**：`boardControls` 的折叠 / 展开 / 关闭在本次运行中全部正确：

```json
"collapsed":{"bodyHidden":true,"label":"展开","aria":"false"},
"expanded":{"bodyHidden":false,"label":"折叠"},
"closed":{"panelHidden":true,"launcherExpanded":"false"}
```

---

### M8【中】`team:read` 不校验消息 `project`；B 项目会话可消费 A 项目邮件

**位置**

- `src/main.js:3614-3645` `team:read`：`resolveProjectTeamRole` 只核验 B 项目角色会话，然后 `readFor({projectName, role, messageId, sessionId})`；
- `src/team-tools.js:1836-1877` `readFor`：`projectName` 只用于 boot 令牌，没有把 `message.project` 与当前项目比较；
- 旧工具 `团队/工具/lib/store.mjs` 的 `findMessage(role,id)` / `readMessage(role,id)` 按角色全局邮箱（new/cur）找 id，不按 `msg.project` 过滤；`team:inbox` 的 `listInbox(..., project)` 则做了过滤。

**问题**

- 同一角色在不同项目间共用邮箱目录；B 项目只要知道 A 项目消息 id，就能让 B 会话执行 `team:read`，把 A 的 `new` 移进 `cur`；
- 这会改变 A 项目邮件的已读水位，B 的 UI 也认为“已读成功”；
- 与 QA-ROUND7 M6 同类；当前 `team:read` 仍没有 message.project 校验。

**建议**

- `readFor` 增加 `expectedProject`：找到消息后校验 `msg.project` 必须等于当前 `projectName`（或显式空 project 的兼容规则），不匹配返回 `CROSS_PROJECT_MESSAGE`；
- `ack` 的 CLI 路径同样加 project 校验（壳的 `team:ack` 已按本地消息 project 走，但角色自 ack 仍直接走旧工具）；
- 组件/E2E 增加 B 会话读 A 邮件的拒绝断言。

---

### M9【中】“壳不代写”文案与 `actor=workbench-shell` 的实际行为相反

**位置**

- `src/renderer/index.html:422` `.dispatch-rule`：“回执必须由收件角色自己的 DSH 会话发出，壳不代写”；
- `src/renderer/index.html:456` `.inbox-rule`：“read/ack 必须由角色自己的 DSH 会话执行……壳不代写”；
- `src/renderer/app.js:3342` `openAckModal`：“回执会以收件角色……会话身份写进旧协议，壳不能代写”；
- `src/main.js:4153-4155`：`teamTools.ackDispatch({... actor:'workbench-shell'})`，注释原文“壳进程执行 team.mjs ack：actor 必须是 workbench-shell，不能冒充角色”；
- selftest `SELFTEST_ROUND6` 也输出 `"ack":{"source":"team","actor":"workbench-shell","receiptActor":"workbench-shell"}`。

**问题**

- `.dispatch-rule` 和 `.inbox-rule` 的“壳不代写”在**用户点击“记录回执”时是假的**：主进程确实以收件角色会话执行旧 `ack`，只是把 actor 标成壳；
- 这会误导用户/审计者：以为回执一定来自角色本人，实际可能是壳代跑；
- 与 H4 叠加时，角色自回执和壳代跑回执的痕迹更难分清。

**建议**

- 文案改成可核对的语义：例如“壳会以收件角色会话身份代写旧协议 ack，`actor=workbench-shell`；角色自己执行时 actor 为空/待核验”；
- 或真让“记录回执”只发指令给角色，壳不落 ack（但那会改变现有产品行为）；
- 至少在弹窗中显示本次将写入的 `actor`。

---

### L10【低/中，parity】收件箱仍是旧版没有的新增面，三个入口仍在

**旧版证据**

旧壳四个文件（`main.js` / `preload.js` / `renderer/index.html` / `renderer/app.js`）对
`inbox|收件|未读|team:send|team:ack|team:read` 的命中数均为 **0**：

```text
main.js 0
preload.js 0
renderer/index.html 0
renderer/app.js 0
```

旧版回执只在独立看板 `团队/看板.html` 第 4 节；旧版没有团队台抽屉、没有 `#team-receipts`、没有 `#inbox-block`。

**当前证据**

- `index.html:434-457` `#inbox-block` 是 `<details class="debug-fold">`，默认折叠，标“旧版没有此面板”；
- 但 `#more-menu [data-more="inbox"]`（`index.html:101`）、角色卡 `[data-role-inbox]`（`app.js:3120`）、团队消息行 `[data-msg-inbox]`（`app.js:1984`）仍在；DOM 运行时 `inboxEntryMore=true`、`inboxEntryRole=true`；
- `index.html:380-392` `#team-receipts` 整块仍在团队台，旧版团队台没有；
- `#team-receipts` 的旧看板口径本身正确（见 §4），但“位置/入口”不是旧版。

**建议**

- 严格对齐：删除三个入口，`#inbox-block` 只允许开发开关打开；回执只保留旧看板窗口；
- 若产品坚持保留：在块标题和入口上明确“新增，不是旧版”，不要用“旧看板口径”暗示旧团队台有这张表。

---

### L11【低】默认项目根 `projects/` 与文档 / 现有数据 `项目/` 不一致

**位置**

- `src/main.js:1478` `defaultRoot: path.join(ROOT, 'projects')`；
- `src/main.js:1806` `createProject` 默认 `ROOT/projects`；
- `src/main.js:1930` `findProjectByName` 扫描 `ROOT/projects`；
- `src/main.js:2446` `project:discover` 扫描 `ROOT/projects`；
- `src/team-tools.js:204` `localProjectsRoot = repoRoot()/projects`；
- `docs/ARCHITECTURE.md:29` 却写 `项目/`；`.gitignore:4` 忽略 `projects/`。

**文件系统证据**

```text
D:\deepseek\agile-workbench\项目\        # 存在：六人敏捷工作区 / 团队工作台改造 / 小鱼 / 微光作品集 / 测试工作台项目 / 项目清单.md
D:\deepseek\agile-workbench\projects\    # 不存在
```

**影响**

- UI 新建项目默认落到 `D:\deepseek\agile-workbench\projects\<名字>`，与现有 `项目/` 分叉；
- `project:discover` 只扫 `projects/`，不会自动发现 `项目/` 下未登记目录；旧数据要靠团队登记/恢复；
- 文档、`.gitignore`、代码三套口径，开源使用者会踩空；
- 仍在 D 盘，不涉及跨盘写入，但“D 盘数据只有一个项目区”不成立。

**建议**

- 二选一：把默认根改回 `项目/`（与文档/现有数据一致），或正式迁移并更新文档、`.gitignore`、`project:discover`、`localProjectDirs`；
- 迁移前在恢复/新建 UI 明确当前根，避免用户把项目建到意外的第二目录。

---

### L12【低】回执列表不显示 `actor/executor/identitySource`

`team-tools.listReceipts` 已把 `actor/executor/sessionId/identitySource` 原样返回（`src/team-tools.js:1487-1488`、`1602`），但 `app.js:1101-1113` 的 `receiptMarkup` 只渲染：

```text
from（回执人） / to / project / msgId / note / time
```

因此 H4 的 actor 歧义在 UI 上不可见；用户只能打开 JSON。建议在回执行加“执行者 / 核验来源”小标签，或明确“此列表按旧看板字段，审计请开账本”。

---

## 4. 正向证据（不是只报坏）

### 4.1 旧 `回执.jsonl` 确实被读到，口径基本对齐

`_tmp/qa8/probe-receipts.log`：

```json
"actual": {"ok":true,"code":"OK","count":165,"total":165,"scanned":165,
           "superseded":163,"invalid":0,"tailOnly":false}
```

真实账本 **328 行原始记录**，按 `id` 合并 `update:true` 后 **165 条**，其中 163 条是 update 行；0 解析失败；未触发 8 MiB 尾部截断。项目计数：

| 项目 | 去重后 |
|---|---:|
| 团队工作台改造 | 115 |
| 个人简历展示项目 | 13 |
| 六人敏捷工作区 | 18 |
| 测试工作台项目 | 17 |
| 个人博客项目 | 2 |

`个人简历展示项目=13` 与旧看板第 4 节一致；说明 `team:receipts` 不是拿本机 messages 冒充。

### 4.2 路径 / 尾部 / 软链接保护

- 数据源固定 `layout.receiptsFile`，调用方不能传路径；
- `isInside(layout.root, file)` + `stat` 普通文件 + `realpath` 复核软链接；
- 只读尾部 8 MiB，截断首行，`tailOnly` 标识；
- 项目名在 main 侧拒绝 `\ / NUL`、`..`、盘符前缀；`limit` 夹在 1–500。

这些保护本身是正向的；本轮未发现路径穿越，只发现 `includeUnassigned` 的隔离缺口（M5）。

### 4.3 看板折叠 / 展开 / 关闭

E2E `boardControls` 全部正确（见 M7 末）。切换在**加载完成后**正常；问题只在加载中切项目的竞态。

### 4.4 Owner 成功路径

selftest ROUND5 与 E2E 都返回：

```json
"workflowWrite":{"ok":true,"attempted":true,"code":"OK"},
"workflowFile":"...\\工作流.json",
"notified":{"id":"M-...","from":"system","to":"pm",...}
```

即 `workflowFile` 和 `notified` 在成功路径是可用的；问题在通知失败时只返回一次（M6），不是字段没实现。

### 4.5 六角色 / DSH

- E2E `createProject` + `dshProvision` 成功建 `qa-session-1..6`，mapping 6/6，workspace `qa-ws-1`；
- `state.roles` 六角色；会话按 `团队·角色` 标题；
- `dsh:prompt` 绑角色映射并做 `verifyProjectRoleSession`；
- selftest `SELFTEST_MAPPING` 39 项全过，包含六角色会话与 workspace 隔离；
- 当前 DSH 主壳 webview 正常加载/失败提示路径由 `renderDsh` 处理；本轮不向真实 DSH 发 prompt。

### 4.6 D 盘 / selftest

- `drive:"D:\\"`、`teamRoot/testRoot` 都在 D；
- 官方 npm script 在 `_tmp/qa8/app` 副本执行，根目录截图未更新（仍为 12:17:06 的旧文件）；
- 临时数据都在 `_tmp/qa8`。

---

## 5. 未覆盖 / 边界

1. **未在真实用户项目上执行 ack / cancel / board 写操作**；E2E 只在 `_tmp/qa8` 的临时项目与 mock DSH 上跑。
2. **未做真实多进程同时 ack 的压测**；H2 用确定性交错证明窗口存在，未测 Windows `EBUSY` 概率。QA-ROUND7 M10 已有 EBUSY 探针记录，本轮不重复。
3. **未逐像素对比旧版 UI**；L10 只核对了旧版四文件关键字、旧版看板位置、当前入口。
4. **未验证真实 DSH 登录 / 会话模型**；六角色只在 mock 上验证 6/6。
5. **未测 `team:read` 的跨项目读取运行时**（M8 为源码 + 旧 store 证据）；建议补一个 B 会话读 A 邮件的 E2E。
6. **未将 `launch.mjs` 自定义 `TEAM_ROOT` 的 index `MODULE_NOT_FOUND` 计入产品问题**；E2E 临时根未铺工具联接，属于测试搭建问题；真实 selftest 已用 junction 规避。

---

## 6. 只读边界与可复现

### 6.1 只读边界

- 只新增 `docs/QA-ROUND8.md`；
- 未修改 `src/**`、`package.json`、`package-lock.json`、`node_modules/**`、`团队/**`、`项目/**`、旧仓库；
- 复制到 `_tmp/qa8/app` 的 `src` 未改；仅在副本中临时重命名 `团队/工具/owner-note.mjs` 做 M6 探针，随即恢复；
- 所有 QA 临时文件 / 日志 / 截图 / 沙盘 / TMP 在 `_tmp/qa8`，未向 `%TEMP%` 写 QA 文件。

### 6.2 可复现命令

```powershell
# 1) 语法检查（仓库根）
npm run check

# 2) D 盘 selftest（副本；官方同款 npm script）
$env:AWB_SELFTEST_ROOT='D:\deepseek\agile-workbench\_tmp\qa8\sandbox'
$env:ELECTRON_RUN_AS_NODE=$null
cd D:\deepseek\agile-workbench\_tmp\qa8\app
npm run selftest

# 3) 真实主进程 E2E（mock DSH + 临时项目）
$env:ELECTRON_RUN_AS_NODE=$null
node D:\deepseek\agile-workbench\_tmp\qa8\e2e.js

# 4) 只读账本口径 / 去重 / 过滤
node D:\deepseek\agile-workbench\_tmp\qa8\probe-receipts.js

# 5) 全量改写并发窗口
node D:\deepseek\agile-workbench\_tmp\qa8\probe-rewrite.js
```

### 6.3 验收断言（建议加入 selftest）

| 断言 | 对应 |
|---|---|
| 角色 CLI ack 后 `state.pendingAck === null`、`ack:true`，下一次 `teamSend` 成功 | H1 |
| 角色自回执行 `actor` 不被壳补写；`identitySource` 与 `executedBy` 分离 | H4 |
| `teamCancel({messageId:'不存在'})` 返回失败，旧锁不动 | H3 |
| annotate 期间并发 append 不丢行（或显式失败） | H2 |
| `team:read` 跨项目 message 返回 `CROSS_PROJECT_MESSAGE` | M8 |
| 加载中切看板项目，最终 subject 等于最后一次选择 | M7 |
| 空 project 回执默认不出现在当前项目列表 | M5 |
| Owner 通知失败刷新后仍有持久告警 | M6 |

---

## 7. 结论

本轮 `npm run check` 与 D 盘沙盘 selftest 都是绿的：**20 + 45 + 39 + 4 + 17 = 125 项，0 失败，SELFTEST_OK**；旧 `回执.jsonl` 也确实读到了 165 条（13/115/18/17/2 的项目计数与旧看板一致）。但绿测没有覆盖“角色自己回执”与“壳代跑回执”的对账，也没有覆盖账本并发写和撤销假 id：

- **H1** 让按旧协议认真执行的角色反而被本机假锁挡住；
- **H2** 让 append-only 审计账本可能少行；
- **H3** 让本地锁与旧锁分叉；
- **H4/M6/M7/M8/M9** 分别让 actor、Owner 告警、看板选择、跨项目读取和用户文案失真；
- **L10/L11/L12** 是旧版对齐、项目根、审计可见性的剩余缺口。

**建议优先级：H1 → H2/H3 → H4 → M5/M6/M7/M8 → L10/L11/L12。** 修 H1/H2/H3 之前，不建议把“回执已闭环”“selftest 全绿”当成发布证据。

---

*本文件只读审计产物；证据脚本与日志在 `_tmp/qa8/`。*


