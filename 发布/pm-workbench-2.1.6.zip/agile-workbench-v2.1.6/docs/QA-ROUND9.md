# 第九轮只读 QA 报告 · agile-workbench

- 仓库：`D:\deepseek\agile-workbench`
- 时间：2026-11-05 13:12–13:30（Asia/Shanghai）
- 边界：只新增本文件；临时文件全部在 `_tmp\qa9-*`；未修改 `src/`、`package.json`、旧仓库或真实 `团队\状态`。未使用 `%TEMP%`（运行前把 `TEMP/TMP` 指到 `_tmp\qa9-temp`）。
- 方法：读源码 + `npm run check` + Electron selftest（隔离沙盘）+ 在 `_tmp` 内直接驱动真实的 `团队\工具\team.mjs` + 只读探测真实 DSH（`session/list`，不创建、不 prompt、不归档）。

> 重要前提：本仓库根目录不是 git 仓库，`团队\状态` 是工作区里已经存在的一份旧工作台状态。下面的“真实状态”均指这份现状，不是克隆后的干净安装。

---

## 一、先回答五个问题

### 1) 六角色会话之间通信是否正常？证据？

**结论：不能判定为“正常”。新工作台只证明了“壳把邮件写进邮箱、壳把四步指令 prompt 给角色”，没有证明角色真的收了、读了、回了；仓库现状里也没有新工作台自己的真实六角色会话。**

证据分四层：

- **新工作台的消息路径是单向的。** `team:send` 先让 `team.mjs send` 把消息写进 `团队\状态\邮箱\<角色>\new\*.json`，再由主进程 `dsh.prompt(sessionId, wakeText)` 发一段“四步指令”（boot → inbox → read → ack）。`wake.state='sent'` 只代表 `session/prompt` 这个 HTTP 调用返回成功，不代表角色收到、理解或执行。
- **selftest 的“角色”不是 agent。** mock DSH 的 `session/prompt` 只做 `counters.sessionPrompt += 1` 和 `session.blank = false`，没有角色进程去执行 `team.mjs`。第九轮 selftest 里所谓的“角色自己 read/ack”，是主进程自己 `teamTools.bootToken(...)` 拿令牌后 `runTool(['read'...])`、`runTool(['ack'...])`（`src/main.js:6706-6712`），仍然是壳进程在跑。
- **真实 DSH 里没有本仓库的六角色会话。** 只读 `session/list` 探测（`_tmp/qa9-dsh-probe.json`）：共 185 个会话，其中 `团队·*` 54 个（42 个在旧 `D:\deepseek\工作台\项目\...`，6 个在旧 `D:\deepseek\工作台` 根，6 个在 `external-open-e2e-*`）；`.selftest-data` 下另有 6 个“独立工作台·…” + 1 个 dsh 会话，但不是 `团队·`。**cwd 在 `D:\deepseek\agile-workbench\项目\*` 的会话为 0 个**。本仓库 `项目\*` 下也没有新的 `团队会话.json` 能证明新工作台跑过真实六角色。
- **历史证据属于旧工作台，不属于新工作台。** 真实 `团队\状态\回执.jsonl` 有 328 条回执、覆盖 6 个角色/5 个项目，最新一条是 `2026-11-03T00:48:15.301Z`；这证明**旧工作台**曾经真实通信过。但 11-03 之后没有新回执，说明新工作台没有往这份真实账本里产生过一条角色回执。

| 环节 | 现有证据 | 能证明什么 | 不能证明什么 |
|---|---|---|---|
| delivered | `team.mjs send` 写出了 `邮箱/<角色>/new/*.json` | 邮件进了本机邮箱 | 角色看到了 |
| wake | `dsh.prompt` 返回成功；mock 计数 +1 | prompt 被 DSH 接受 | 角色收到/理解/执行 |
| read | 邮件从 `new` 移到 `cur` | 有人执行了旧协议 read | 执行者是角色本人（壳/人/别的进程都能做） |
| ack | `回执.jsonl` 新增 msgId | 有人执行了旧协议 ack | 执行者是角色本人（回执没有 actor/session） |

另外，第九轮的“六角色 from→to”矩阵只覆盖了 5 个非 PM 角色 → PM，以及一条 `tester → programmer1`；30 个有向对里实际只覆盖了 8 个（PM→analyst、PM→tester、5 个角色→PM、tester→programmer1），PM→其余角色和大部分角色互发都没有覆盖（`src/main.js:6787-6807`）。这是覆盖缺口，不是“通信正常”的证据。

### 2) 评审 propose/show/review/sign/apply 是否旧协议？

**结论：`proposal:legacy` 这条桥是真的旧协议；但主界面默认的评审/签字/apply 不是旧协议，而是工作台自己的另一套 `proposal:*`。两套并存，产品文案容易被读成“主流程就是旧协议”。**

- 真旧协议：`proposal:legacy` / `team:proposal-legacy` → `legacyProposalAction` → `团队\工具\team.mjs propose|show|review|sign|apply`（`src/main.js:3947-4009`、`src/team-tools.js:2126-2286`）。第九轮 selftest 确实跑通了 `propose → show → review → sign → apply`，并真的写出了 `legacy/review.txt`（`_tmp/qa9-selftest.log` 的 `SELFTEST_ROUND9.report.legacy`）。
- 主界面默认不是旧协议：`renderProposals` 对 legacy 卡片只给一个“刷新旧协议状态”按钮（只调用 `proposal:legacy show`，`src/renderer/app.js:4252`）；`openProposalModal` / `openReviewModal` / `openSignModal` / “应用提案”分别调用 `proposalCreate` / `proposalReview` / `proposalSign` / `proposalApply`（`src/renderer/app.js:4325`、`4352`、`4378`、`4266`），这些都是本地库操作。
- 本地写操作遇到 legacy 提案会被明确拒绝：`LEGACY_PROTOCOL_REQUIRED`（`src/main.js:1664-1671`、`3824-3830`）。selftest 也验证了这一点（`_tmp/qa9-selftest.log` 里 `localReject`）。
- 因此：**旧协议五步本身可用，但用户在界面上无法完成旧协议的 propose/review/sign/apply，只能做本地评审/签字/apply；界面上只有旧协议的 show。** README/FEATURE-MATRIX 里“提案 / 评审 / PM 签字 / apply”如果不注明“本地”，会被理解成旧协议，这是文案风险。
- 还有一个显示层推断：`legacyFlowOf` 把“有 review/signature/applied”反推为 `show` 已执行（`src/team-tools.js:2029-2044`），卡片的五步条会把 `show` 标成“已执行”。旧工具通常会强制 show，所以多数情况成立；但这是推断，不是独立的 show 证据。

### 3) 回执是否角色自己执行，还是壳代跑？

**结论：默认 UI 路径是壳代跑；所谓“角色自己执行”的标记是文件状态的默认推断，不是身份证据。任何本机进程只要拿到一个 boot 令牌，就能写出会被判成“角色自己”的回执。**

- 默认 API 确实有闸门：`team:ack` 在 `allowShellAck !== true` 时抛 `ROLE_ACK_REQUIRED`（`src/main.js:4642-4658`），这部分设计是对的。
- 但默认 UI 会显式授权壳代跑：`openAckModal` 只要用户不勾“人工确认”，就 `payload.allowShellAck = true`（`src/renderer/app.js:3916`）。随后 `ackDispatch` 以收件角色的 boot 令牌执行 `team.mjs ack`，`actor` 写成 `workbench-shell`（`src/team-tools.js:1783-1869`）。**这不是角色执行的，是壳执行的。**
- 唤醒文案与 UI 行为矛盾：`wakeMessageFor` 明确写“回执必须由你（角色会话）执行；工作台壳不会代你 ack”（`src/team-tools.js:2328`），但用户点默认“确认”就是壳代跑。角色如果没行动，壳的这次点击会释放派单锁，消息显示“已回执”。
- **最关键的证据**：旧协议原生 `ackMessage` 写出的回执只有 `id/msgId/from/to/project/note/log/ts`，没有 `actor`、`sessionId`、`identitySource`（`团队\工具\lib\store.mjs:445-454`）。而 `reconcileProjectCommStates` 对“没有 actor”的回执默认 `receiptActor = 'role-session'`，并令 `selfExecuted = true`（`src/main.js:964-965`）。
- 实测：真实 `回执.jsonl` 的 328/328 条都没有 `actor`；`_tmp\qa9-live.out.json` 里用 `boot --session fake-session-not-in-dsh` 拿到令牌并成功 ack，回执记录是 `{actor:null, sessionId:null}`，按上面的代码会得到 `selfExecuted=true`、`by=role`。
- 第九轮 selftest 自己的“角色自己 ack”回执也是 `sessionId:null`（`_tmp/qa9-selftest.log` 的 `selfExecution.ack`），却断言 `by=role`、`selfExecuted=true`。这不是角色身份，只是“主进程拿令牌跑了 CLI”。
- 还有一个顺序性假阳性：`team:read` 失败时可能已经把邮件从 `new` 移到 `cur`（见问题 Q9-06），下一次对账会把它记成“角色自己 read”。

**回答：不是角色自己执行；默认路径就是壳代跑。旧协议回执本身不携带执行者身份，工作台无法从回执证明是角色执行的。**

### 4) 哪些显示在骗人 / 只显示本地镜像？

大部分文案是诚实的：本地/旧协议、actor、source、`本地映射/DSH 已核验` 都做了区分。但下面几处仍然会让人得出错误结论：

1. **绿色“角色 read·cur / 已回执”**：来自 `comm.selfExecuted` / `by==='role'`，而它们又来自“回执里没有 actor”的默认值（Q9-01）。旧协议真实回执 328/328 都没有 actor，所以这些绿色标记没有身份证据；直接跑 `team.mjs` 的壳也会落到同一默认值。
2. **旧看板不是只读镜像，而是被本地任务反向覆盖**：`team:board` 生成前会 `syncWorkbenchBoard`，把本地 `project.tasks/proposals` 写进 `团队\状态\项目\<slug>\任务|提案`；旧协议角色点“完成”的任务，下一次看板刷新会被本地 `todo` 覆盖回 `open`，证据里连 `evidence` 都被清空（Q9-05）。这属于“显示在骗人”的更严重形态：看板上的完成状态会被刷新动作回滚。
3. **旧任务在做工作台任务页不可见**：工作台只把本地任务镜像到旧看板，不把旧协议任务读回本地。旧看板可以显示角色的旧任务，但工作台任务页/阶段只按本地 `project.tasks` 算，两个数字会长期不一致。
4. **团队项目清单里有幽灵项目**：`team:workspaces` 返回 6 个登记，其中 `个人简历展示项目`、`个人博客项目` 的目录不存在（`exists:false`）；`团队.json` 的 `activeProject` 正好是缺失的 `个人简历展示项目`。界面会标“目录不存在”，但首次打开就会看到一个不可用的“当前项目”。
5. **`从已有目录恢复` 不是所有目录都能恢复**：`project:adopt` 要求目录里有 `项目信息.md` 或已有团队登记（`src/main.js:2842-2843`）；`project:discover` 的默认目录扫描也只收有 `项目信息.md` 的目录（团队登记另算，`src/main.js:2805`）。本仓库 `项目\` 下 5 个目录里 3 个没有 `项目信息.md`（六人敏捷工作区、团队工作台改造、小鱼），其中 `小鱼` 既没有 `项目信息.md` 也没有团队登记，**无法被 discover / adopt**。`team:restore` 的兜底错误还指向不存在的 `ROOT\projects\...`（`src/main.js:3144`），而真实根目录是 `ROOT\项目`。
6. **旧协议卡片的 show 是推断**（见 Q2 最后一条），不是独立的 show 记录。

### 5) D 盘、跨项目、并发

**D 盘：**
- 仓库、`data\`、`.selftest-data\`、`_tmp\` 和 selftest 沙盘都在 `D:\`；selftest 的 `report.drive.expectedRoot` 是 `d:\`，这部分成立。
- 但 `assertDataDrive` 只比较“目标与团队根同一个盘符”，不是硬编码 D 盘：`path.parse(layout.root).root`（`src/team-tools.js:1986-1998`）。仓库换到 E 盘，它就允许 E 盘；`DATA_DRIVE_REQUIRED` 的文案也跟着变成“必须在 e: 盘”。
- **DSH 凭据仍在 C 盘**：`dshHome()` 默认 `os.homedir()/.dsh`（`src/dsh-adapter.js:18-19`），本机 `DSH_HOME=C:\Users\Admin\.dsh`，`readBrowserSecret` 读 `C:\Users\Admin\.dsh\.credentials.yaml`。应用可以做到“数据只写 D 盘”，但运行时仍依赖 C 盘的用户配置；D 盘独盘机器会直接 `DSH_AUTH_MISSING`。
- `project:adopt` / `project:create` 接受任意盘符的路径；本地提案可以创建/评审，但旧协议五步会在 `legacyProposalAction` 里才返回 `DATA_DRIVE_REQUIRED`（`src/team-tools.js:2143-2144`）。**没有在登记/创建时预检，用户会做到一半才发现旧协议不可用。**

**跨项目：**
- 正常路径的会话核验做得不错：`team:send` / `team:ack` / `team:inbox` 都会核验 session 属于当前项目 workspace；第九轮 selftest 也验证了 B 项目拒绝 A 的会话。
- 但 `readFor` 是例外：它先执行 `team.mjs read`（把邮件从 `new` 移到 `cur`），**之后**才检查 `message.project !== projectName` 并返回 `MESSAGE_PROJECT_MISMATCH`（`src/team-tools.js:1950-1960`）。实测：在项目 B 上下文用 A 的消息 id 调用，返回失败，但 A 的邮件已经变成 `cur`，A 下次对账会记成“角色自己 read”（`_tmp\qa9-live.out.json`）。
- 旧会话跨路径不可复用：`项目\测试工作台项目\团队会话.json` 和 `项目\微光作品集\团队会话.json` 把 workspace/路径写成了新仓库，但 DSH 里这些 session 的 cwd 仍是 `D:\deepseek\工作台\项目\...`。`sessionInProjectWorkspace` 要求 cwd 一致，所以这些“旧六角色”会被拒绝复用，恢复项目时只能新建六个空白会话，旧对话上下文留在旧路径。
- 全局名册 `团队\状态\团队.json` 是单例，`syncRoster` / `syncTeamRosterSessions` / `deleteProjectRecord` 三处都会改它；其中 `src/main.js:284` 和 `src/main.js:3583` 是直接 `fs.writeFileSync`，不是临时文件 + rename。两个项目切换/删除与 `team.mjs boot/send` 交错时，可能出现半截 JSON 被旧工具读到，或一个项目的切换把另一个项目的名册清空。

**并发：**
- 有单实例锁（`src/main.js:7379`）和 `dsh:provision` 的按项目锁（`src/main.js:5079-5091`），这两处是对的。
- 但 `team:launch` / `team:restore` 不走 `provisionLocks`，`team:launch` 可以真实建会话（`dryRun:false`）；与 `dsh:provision` 并发时可能各建一套。UI 目前主要用 `dsh:provision`，但 `teamLaunch` / `teamRestore` 都在 preload 暴露（`src/preload.js:41-42`）。
- `project:select` 在 `await activateWorkspace(...)` 之后无条件按“自己选的项目”同步名册（`src/main.js:2775-2777`）；如果两个 select 并发，后完成的那个可能把 `activeProjectId` 与 `团队.json` 的 activeProject 写成不同项目。
- `statePayload()` 每次读状态都会顺带对账并可能 `writeStore`（`src/main.js:1817-1836`）；并发读时以最后一次写为准，单进程同步写不会丢，但多窗口/多实例（selftest 绕过单实例锁）会互相覆盖。

---

## 二、验证命令与结果

### 2.1 `npm run check`

```text
> node --check src/main.js && node --check src/preload.js && node --check src/renderer/app.js && node --check src/dsh-adapter.js && node --check src/team-tools.js

EXIT=0
```

结论：5 个入口/模块语法检查通过。`check` 只做语法检查，不跑测试、不校验行为。

### 2.2 D 盘 selftest

运行方式（隔离根，避免碰真实状态）：

```powershell
$env:AWB_SELFTEST_ROOT='D:\deepseek\agile-workbench\_tmp\qa9-selftest'
$env:TEMP='D:\deepseek\agile-workbench\_tmp\qa9-temp'
$env:TMP=$env:TEMP
npm run selftest -- --user-data-dir=D:\deepseek\agile-workbench\_tmp\qa9-userdata
```

结果：`SELFTEST_OK`，退出码 0（日志：`_tmp\qa9-selftest.log`）。主要计数：

| 项 | 结果 |
|---|---|
| STORE | 20 checks / 0 failed |
| COMPAT | 45 checks / 0 failed |
| MAPPING | 39 checks / 0 failed |
| ROUND5 | 4 checks / 0 failed |
| ROUND6 | 17 checks / 0 failed |
| ROUND9 | report 8 个顶层键；`failed:0`；`report.checks` 13 项全 true；56 条 `expect` 断言 0 failed |
| DSH mock | `已连接 DSH · 0 个会话`（mock，不是真实 DSH） |

**selftest 通过不等于六角色真实通信通过。** mock DSH 没有 agent；Round9 的“角色自己 read/ack”是主进程自己 `bootToken` + `runTool`，不是角色会话。详见 Q9-01、Q9-03。

### 2.3 真实 DSH 只读探测

`_tmp\qa9-dsh-probe.js` 只调用 `session/list`：

| 统计 | 数值 |
|---|---|
| 总会话 | 185 |
| `团队·*` 标题 | 54 |
| cwd 在 `D:\deepseek\agile-workbench\项目\*` | 0 |
| cwd 在 `D:\deepseek\工作台\项目\*` 的 `团队·*` | 42 |
| cwd 在 `.selftest-data\six`、`.selftest-data\dsh` | 6 + 1（标题是“独立工作台·…”，不是 `团队·`） |

结论：真实 DSH 里没有本仓库新项目路径下的六角色会话；旧工作台的 `团队·*` 会话仍在旧 cwd。

### 2.4 真实团队状态只读检查

`_tmp\qa9-workspaces.json`（`teamTools.listWorkspaces()`，只读）：

| 项目 | 路径 | exists |
|---|---|---|
| 个人简历展示项目 | `D:\deepseek\agile-workbench\项目\个人简历展示项目` | **false** |
| 测试工作台项目 | `...\项目\测试工作台项目` | true |
| 个人博客项目 | `...\项目\个人博客项目` | **false** |
| 六人敏捷工作区 | `...\项目\六人敏捷工作区` | true |
| 团队工作台改造 | `...\项目\团队工作台改造` | true |
| 微光作品集 | `...\项目\微光作品集` | true |

`团队\状态\团队.json` 的 `activeProject` 是 `个人简历展示项目`（缺失目录）；`当前工作区.json` 也指向该缺失目录。`会话.json` 里 6 个 sessionId 对应真实 DSH 中的 cwd 是旧路径 `D:\deepseek\工作台\项目\个人简历展示项目`。

### 2.5 真实回执账本只读检查

`团队\状态\回执.jsonl`：

| 统计 | 数值 |
|---|---|
| 总行数/可解析 | 328 / 328 |
| 有 `actor` 字段 | **0** |
| 时间分布 | 2026-10-29: 224；10-31: 70；11-03: 34 |
| 最新 | `2026-11-03T00:48:15.301Z` |
| 角色分布 | pm 166、programmer1 58、tester 32、product 30、analyst 22、programmer2 20 |

这证明旧工作台曾有真实角色回执，也证明原生回执没有执行者身份；新工作台没有新增一条真实回执。

---

## 三、问题清单（按严重度）

> 行号为本次读取版本（`src/main.js` 400560 bytes / 2026-11-05 13:06:48）。

### Q9-01（高，实测+代码）回执“角色自己执行”是默认推断，不是身份证据

**证据：**

- `src/main.js:964-965`：

```js
const receiptActor = String(receipt.actor || (isLocal ? 'workbench-shell' : 'role-session'));
const selfExecuted = !isLocal && receiptActor !== 'workbench-shell';
```

- 原生 `团队\工具\lib\store.mjs:445-454` 的 `ackMessage` 回执记录没有 `actor` / `sessionId` / `identitySource`。
- 真实 `回执.jsonl` 328/328 条都没有 `actor`。
- `_tmp\qa9-live.out.json`：用 `boot --role analyst --project 项目A --session fake-session-not-in-dsh` 成功拿到令牌，随后成功 `ack`，回执记录 `actor:null, sessionId:null`；按上面代码 `selfExecuted=true`。
- `_tmp\qa9-selftest.log` 的 `selfExecution.ack`：`by:"role"`、`actor:"role-session"`、`sessionId:null`，而这次 ack 是主进程 `teamTools.bootToken(...)` + `_runNode` 跑的（`src/main.js:6706-6712`），不是角色会话。

**影响：** 界面上的“角色 read·cur / 已回执”绿色标记可以被“直接跑 `team.mjs`（绕过 `annotateReceiptIdentity`）的壳”、被人工 CLI、被任何本机进程制造出来；审计无法区分角色和壳。真实旧账本 328 条一旦进入本地 messages，都会被判成角色自执行。（正常走 `team:ack` 的壳回执会补 `actor=workbench-shell`，不会被判成角色；问题在于原生回执和绕过标注的路径。）

**建议：** 原生回执必须写入 `sessionId` + `actor` + `identitySource`，并让 `team.mjs ack` 在写回执时绑定 boot 令牌里的 session；`reconcile` 对“缺 actor”的回执应标 `unknown/legacy`，不能默认 `role-session`。selftest 应使用独立的“角色进程”执行，而不是主进程直接 `runTool`。

### Q9-02（高，代码）默认 UI 的“确认回执”就是壳代跑，与唤醒文案矛盾

**证据：**

- `src/renderer/app.js:3916`：

```js
if (!manual) payload.allowShellAck = true;
```

- `src/main.js:4718-4729`：`ackDispatch` 以收件角色 boot 令牌跑 `team.mjs ack`，`actor:'workbench-shell'`。
- `src/team-tools.js:2328`：唤醒文案写“工作台壳不会代你 ack”。

**影响：** 角色没有执行 ack，用户点默认“确认”后旧协议锁被释放、消息显示“已回执”；文案告诉用户“壳不会代跑”，实际默认按钮就是代跑。actor=workbench-shell 在明细里有，但“已回执”这个结论本身已经产生。

**建议：** 要么默认只允许“人工确认（不释放锁）”，把壳代跑放到明确的二次确认/权限开关；要么把唤醒文案改成“角色未回执时可由壳代跑，actor=workbench-shell”，不要让两句话互相打脸。

### Q9-03（高，实测+代码）六角色通信只证明了壳侧链路，没有角色侧证据；真实 DSH 没有本仓库六角色会话

**证据：**

- `src/main.js:4401-4425`：`team:send` 只在 `dsh.prompt` 成功后把 wake 标 `sent`。
- `src/main.js:5432-5440`（mock）：`session/prompt` 只计数、清 blank，没有 agent。
- `src/main.js:6706-6712`（Round9）：所谓“角色自己 read/ack”是主进程 `bootToken` + `runTool`。
- `_tmp\qa9-dsh-probe.json`：185 个真实会话，0 个 cwd 在 `agile-workbench\项目\*`；54 个 `团队·*` 全在旧路径/外部目录。
- 真实 `回执.jsonl` 最新 11-03，之后没有新回执。

**影响：** “六角色通信正常”目前只是壳写邮箱 + 发 prompt 的正常；角色是否收到、读了、回了没有证据。旧工作台的历史通信不能替新工作台背书。

**建议：** 在真实 DSH 里跑一次受控的六角色联调：给六个真实 session 发四步指令，等角色自己产出 `read/ack`，并把回执里的 session 身份写入账本；至少覆盖 PM→5 角色、5 角色→PM、角色互发各一条。selftest 应至少让一个独立的 Node 进程以“角色侧”身份执行四步，而不是主进程直接跑。

### Q9-04（高，实测+代码）旧协议五步是真的，但主界面评审/签字/apply 是本地协议

**证据：**

- 真旧协议：`src/main.js:3947-4009`、`src/team-tools.js:2126-2286` 调 `team.mjs`；selftest 真实写出 `legacy/review.txt`。
- 主界面：`src/renderer/app.js:4252` legacy 卡片只有 `data-proposal-legacy-show`；`src/renderer/app.js:4325/4352/4378/4266` 分别调 `proposalCreate/Review/Sign/Apply`。
- 本地写 legacy 提案被 `LEGACY_PROTOCOL_REQUIRED` 拒绝（`src/main.js:1664-1671`、`3824-3830`）。

**影响：** 用户点“评审/PM 签字/应用提案”时走的是本地 `proposal:*`，不是旧协议；旧协议只有“刷新旧协议状态”（show）。README/FEATURE-MATRIX 的“提案/评审/签字/apply”不注明“本地”就会误导。

**建议：** 要么在 UI 增加旧协议 propose/review/sign/apply 的入口（并标注需要角色会话），要么在功能矩阵/README 明确“主界面是本地提案；旧协议仅在 proposal:legacy 桥”。不要把两套状态都叫“提案评审”。

### Q9-05（高，实测）看板同步把本地任务反向写进旧协议，并会覆盖角色的完成状态

**证据：**

- `src/team-tools.js:954-1144` 的 `syncWorkbenchBoard` 直接写 `团队\状态\项目\<slug>\任务|提案|提交`，任务记录 `source:'workbench'`（`1006`），提案/评审/签字也写（`1065/1085/1102`）。
- `team:board` 生成前无条件调用它（`src/team-tools.js:1165-1180`）；本地任务/提案写操作后 `mirrorToTeamBoard` 也会调用（`src/main.js:2446-2457`）。
- 实测 `_tmp\qa9-task-clobber.out.json`：
  - 旧协议 `task claim` → `status:"working"`；
  - 旧协议 `task done --evidence "角色在旧协议里完成了"` → `status:"done"`、`evidence` 有值；
  - 再调用一次 `syncWorkbenchBoard` → 旧任务回到 `status:"open"`、`evidence:""`；本地仍是 `todo`。

**影响：** 角色在旧协议里完成的任务，下一次“刷新看板/打开看板”会被本地 `todo` 覆盖回 `open`，证据被清空。旧看板不是只读镜像，而是会被本地反向改写；工作台任务页又看不到旧任务，两个系统长期不一致。

**建议：** 同步前先读旧任务，若旧记录已被角色推进（`status` / `evidence` / `rev` 变化），不要用本地旧值覆盖；至少做双向合并/冲突提示。更彻底的做法是明确“任务真相在旧协议”，本地只读镜像，或反过来只允许本地任务、旧协议不接任务。

### Q9-06（高，实测）跨项目 `read` 先移动邮件再报错，污染另一项目的“已读”证据

**证据：**

- `src/team-tools.js:1950-1960`：先 `runNode team.mjs read --id ...`，再检查 `mailProject !== projectName` 并返回 `MESSAGE_PROJECT_MISMATCH`。
- 实测 `_tmp\qa9-live.out.json`：在项目 B 上下文读取项目 A 的 `M-...`，返回 `ok:false, code:"MESSAGE_PROJECT_MISMATCH"`，但 `commSnapshot` 显示该邮件 `box:"cur", project:"项目A"`。
- `team:read` 没有在调用 `readFor` 前校验 `messageId` 属于当前项目（`src/main.js:4056-4072`）；它只核验角色/session。

**影响：** 一个错误的跨项目读操作会把另一个项目的邮件标成已读；A 项目下一次 `reconcileProjectCommStates` 会看到 `cur`，记 `read.by='role'`、`selfExecuted.read=true`。这既是跨项目污染，也是 Q9-01 的假阳性来源。

**建议：** 在 `team.mjs read` 之前先读邮件并校验 `project`，或让旧工具支持 `--project` 并在工具内校验；`team:read` 先查本地消息/项目归属，再调用。失败的读不能产生副作用。

### Q9-07（高，实测）团队状态/登记与仓库现状不一致：2/6 项目目录缺失，activeProject 指向缺失目录，旧会话 cwd 仍指向旧工作台

**证据：**

- `_tmp\qa9-workspaces.json`：6 个登记，`个人简历展示项目`、`个人博客项目` `exists:false`。
- `团队\状态\团队.json`：`activeProject:"个人简历展示项目"`；`当前工作区.json` 同项目，路径不存在。
- `团队\状态\会话.json`：6 个旧 sessionId 写成新路径 `D:\deepseek\agile-workbench\项目\个人简历展示项目`；真实 DSH 里这些 sessionId 的 cwd 是 `D:\deepseek\工作台\项目\个人简历展示项目`。
- `项目\测试工作台项目\团队会话.json`、`项目\微光作品集\团队会话.json` 同样把 workspace 写成新路径，但真实 DSH 会话 cwd 是旧路径。

**影响：** 打开工作区清单/团队台就会看到一个不可用的“当前项目”（`当前工作区.json` 指向缺失目录）；从已有目录恢复时旧六角色会话因 cwd 不一致不能被复用，只能新建空白会话，旧对话上下文断开；用户会以为“恢复了”，实际是新建。

**建议：** 迁移时同时迁移/重写 DSH 会话的 workspace/cwd，或在恢复时明确提示“旧会话不可复用，将新建”；启动时对 `activeProject` 做存在性校验，缺失就清空/提示，不要静默保留幽灵项目。

### Q9-08（中高，代码+环境）D 盘约束是“同盘”不是 D 盘；DSH 凭据仍在 C 盘

**证据：**

- `src/team-tools.js:1986-1998`：`assertDataDrive` 只比较 `path.parse(layout.root).root` 与目标 root。
- `src/dsh-adapter.js:18-19`：`dshHome()` 默认 `os.homedir()/.dsh`；本机 `DSH_HOME=C:\Users\Admin\.dsh`，`readBrowserSecret` 读 C 盘 `.credentials.yaml`。
- `src/main.js:2158` / `3180-3188`：项目创建/恢复接受任意路径；`legacyProposalAction` 直到 `assertDataDrive` 才拒绝（`src/team-tools.js:2143-2144`）。

**影响：** 仓库搬到 E 盘后，“D 盘 only”的承诺失效，数据会写 E 盘；D 盘独盘机器没有 C 盘 `.dsh` 配置时 DSH 适配层直接不可用；跨盘项目可以登记成功，但旧协议评审/签字/apply 到后面才报 `DATA_DRIVE_REQUIRED`。

**建议：** 如果产品真要“只允许 D 盘”，显式检查 `D:` 而不是“同盘”；在创建/恢复时预检盘符并提示；把 `DSH_HOME` 的依赖写进启动自检（没有 C 盘配置时给明确错误，而不是 `DSH_AUTH_MISSING`）。

### Q9-09（中，实测谓词+代码）junction/symlink 可绕过项目内路径检查：`files:open`、`proposal:create/apply`

**证据：**

- `src/main.js:2695-2696`（`files:open`）和 `3728-3729`（`proposal:create`）、`3835-3836`（`proposal:apply`）都只用未解析的 `path.resolve(root, rel)` + `startsWith(root + sep)`。
- 对比 `files:read` 的 `resolveProjectFile` 会 `realpathSync` 后再次检查（`src/main.js:1917-1925`），说明作者知道这个风险，但只修了读预览。
- 实测 `_tmp\qa9-junction.out.json`：项目内 `link` 是指向项目外的 junction；`link/secret.txt` 的谓词返回 true，`realpath` 在项目外，读取内容为 `OUTSIDE-SECRET`。

**影响：** 如果项目目录里存在 junction/符号链接（共享素材、迁移目录很常见），`files:open` 可以打开项目外文件；`proposal:create/apply` 可以把项目外文件当作项目内文件读取/覆盖。`files:list` 不会递归（Dirent 把 junction 当非目录），但 `files:open`/提案路径仍然绕过。

**建议：** 所有项目内路径统一走 `resolveProjectFile`（realpath 后二次校验）；写入路径也要 realpath 父目录并确认仍在项目内。`files:list` 对 junction 至少标注/跳过。

### Q9-10（中，代码）全局团队名册被三处非原子改写，跨项目切换/并发可能互相覆盖

**证据：**

- `src/main.js:256-286` 的 `syncTeamRosterSessions`：`fs.writeFileSync(teamFile, ...)`（`284`）。
- `src/main.js:3565-3584` 删除项目时也直接 `fs.writeFileSync(teamFile, ...)`（`3583`）。
- `src/team-tools.js:492-526` 的 `syncRoster` 用临时文件 + rename，且会清空不在当前项目的 sessionId。
- `team:send` / `team:ack` 没有按项目锁；`dsh:provision` 有 `provisionLocks`，`team:launch`/`team:restore` 没有。

**影响：** 两个项目快速切换、删除项目与 `team.mjs boot/send` 交错时，`团队.json` 可能被半截写入、被另一个项目的快照覆盖，导致 `SESSION_ID_MISMATCH` 或角色会话指向错误项目。单进程同步写降低了概率，但文件级不是原子的，旧工具是独立进程，能读到中间状态。

**建议：** 所有 `团队.json` 写入统一走一个原子写函数；`syncRoster`、删除、项目切换共用同一把进程内锁（或文件锁）；`team:launch`/`team:restore` 也纳入 `provisionLocks` 的项目级串行。

### Q9-11（中，实测状态+代码）`从已有目录恢复` 对缺少 `项目信息.md` 的目录不可用；`projects/` 与 `项目/` 根目录不一致

**证据：**

- `src/main.js:2842-2843`：没有 `项目信息.md` 且没有团队登记时，`project:adopt` 直接拒绝。
- `src/main.js:2805`：`project:discover` 的默认目录扫描只推有 `项目信息.md` 的目录（团队登记另算）。
- `项目\` 现状：`六人敏捷工作区`、`团队工作台改造`、`小鱼` 都没有 `项目信息.md`；前两个有团队登记（可 adopt），`小鱼` 没有（不可 discover/adopt）。
- `src/team-tools.js:221`：`localProjectsRoot: path.join(repoRoot(), 'projects')`，但应用默认根是 `ROOT\项目`（`src/main.js:1830`、`2158`、`2798`）；`src/main.js:3144` 的 `team:restore` 兜底错误也写 `ROOT\projects`。
- `_tmp\qa9-workspaces.json` 没有 `小鱼`，`team:workspaces` 只列登记 + `projects/`（不存在）下的目录。

**影响：** 真实存在的 `项目\小鱼` 在主界面的“恢复/发现”流程里既不能出现，也不能被 adopt；`team:workspaces` 的本地目录补充逻辑当前扫不到 `项目\`。`team:restore` 报错路径会误导用户去不存在的 `projects\` 找。（`team:open-project` 是 preload 暴露但主界面未使用的旧入口，不在本次“恢复”主路径的口径内。）

**建议：** 统一默认项目根为 `ROOT\项目`；`project:discover`/`adopt` 对“已有目录但缺 `项目信息.md`”提供显式确认/补建流程，而不是直接拒绝；`team:restore` 的错误路径改成 `ROOT\项目`。

### Q9-12（低/中，代码）legacy 五步条把 `show` 标成“已执行”是推断

**证据：** `src/team-tools.js:2029-2044` 的 `legacyFlowOf`：`if (extraShow || reviewRows.length || signatureRows.length || status === 'applied') done.push('show')`。`src/renderer/app.js:4150-4160` 按 order 标“已执行”。

**影响：** 只要旧提案有 review/signature/applied，界面就认为 `show` 已执行。旧工具通常强制 show，所以多数情况成立；但这不是 show 的独立记录，审计上仍是推断。

**建议：** 如果旧工具能返回 show 的读回执，直接用读回执；否则在 UI 上写“推断已执行”，不要写“已执行”。

### Q9-13（中，代码）`team:cancel` 在旧派单锁未释放时仍会清本地锁

**证据：** `src/main.js:4512-4526` 在旧锁 `messageId` 与本次目标不一致时返回 `LOCK_MISMATCH`，不会释放旧锁；但同一处理器在 `4539-4546` 只要 `pendingNow === target` 就无条件 `clearPendingAck`，没有检查 `released.ok` / `released.removed`。`released` 为 `null`（团队工具不可用）时也一样。

**影响：** 本地 `pendingAck` 被清空、旧 `派单锁.json` 还在；下一次 PM 派单会通过本地检查，却被 `team.mjs send` 的 `PM_DISPATCH_PENDING` 挡住。界面表现为“没有待回执，但发不出去”，需要再点一次“撤销”（不带 messageId）才能释放，正是代码注释想避免的“本地清了、旧锁还在”。

**建议：** 只有 `released.ok` 或 `released.code === 'NO_LOCK'` 时才清本地锁；`LOCK_MISMATCH` / 工具不可用时应保留本地锁并提示先释放旧锁，或让 cancel 直接按旧锁 id 释放。

---

## 四、测试基础设施与只读边界

### 4.1 `npm run selftest` 会写仓库根目录的 `selftest*.png`

`src/main.js:7336` / `7340` 会写 `ROOT\selftest-flow.png` 和 `ROOT\selftest.png`，即使 `AWB_SELFTEST_ROOT` 指向 `_tmp`。本次运行前后哈希变化：

| 文件 | 运行前 | 运行后 |
|---|---|---|
| `selftest.png` | `47EC3D49…C19C` | `21E2CA52…0D55` |
| `selftest-flow.png` | `65A2A036…2A42` | `BBADD754…967F` |

我已把运行后的截图另存到 `_tmp\qa9-selftest-artifacts\`，并把根目录两张图恢复成运行前的内容（哈希回到 `47EC…` / `65A2…`）。但“只新增 docs/QA-ROUND9.md、临时文件放 `_tmp`”的边界和 selftest 当前行为是冲突的；建议 selftest 的截图也写到 `AWB_SELFTEST_ROOT`，或加 `--no-screenshot`。

### 4.2 继承 `ELECTRON_RUN_AS_NODE=1` 时 `npm run selftest` 直接崩

本次环境（DSH/Electron 宿主）里有 `ELECTRON_RUN_AS_NODE=1`。直接 `npm run selftest` 时，`electron .` 被当成 Node 跑，`require('electron')` 的 `app` 是 `undefined`：

```text
D:\deepseek\agile-workbench\src\main.js:82
app.setPath('userData', USER_DATA);
^
TypeError: Cannot read properties of undefined (reading 'setPath')
```

`start.cmd` 第 4 行有 `set ELECTRON_RUN_AS_NODE=`，但 `package.json` 的 `start` / `selftest` 没有清这个变量。清除后 selftest 才 `SELFTEST_OK`。建议在 npm script 或 `main.js` 入口处处理（例如启动脚本先清空），否则从 Electron 宿主里跑 QA 会得到一个看起来像产品崩溃的错误。

### 4.3 已做的只读核对

- `src/`、`package.json`、`package-lock.json` 的 mtime 在 QA 前后未变（`src/main.js` 仍 13:06:48）。
- 真实 `团队\状态` 下没有 13:10 之后被修改的文件；没有向真实 `回执.jsonl` / `团队.json` / `会话.json` 写入。
- 没有使用 `%TEMP%`；本次 `TEMP/TMP` 指向 `_tmp\qa9-temp`。
- 临时证据：`_tmp\qa9-check.log`、`qa9-selftest.log`、`qa9-live.out.json`、`qa9-task-clobber.out.json`、`qa9-junction.out.json`、`qa9-workspaces.json`、`qa9-dsh-probe.json`、`qa9-selftest-artifacts\*.png`。

---

## 五、优先级建议（只读 QA 视角）

| 优先级 | 问题 | 先做什么 |
|---|---|---|
| P0 | Q9-01 / Q9-06 | 回执身份落库 + read 先校验后移动；否则“角色已读/已回执”不可审计 |
| P0 | Q9-03 | 在真实 DSH 跑一次六角色联调；selftest 改用角色侧进程 |
| P1 | Q9-02 / Q9-04 | 统一“壳代跑”的 UI 语义；明确主界面是本地协议还是旧协议 |
| P1 | Q9-05 | 看板同步改为双向合并/只读，绝不能用本地旧值覆盖角色完成 |
| P1 | Q9-07 | 清理幽灵项目/旧 cwd；恢复时明确“新建会话” |
| P2 | Q9-08 / Q9-09 / Q9-10 / Q9-11 / Q9-13 | 盘符预检、realpath 统一、名册原子写、项目根统一、cancel 锁一致性 |
| P3 | Q9-12 / 4.1 / 4.2 | 显示措辞、selftest 产物位置、启动环境变量 |

---

## 六、一句话总结

**旧协议五步是真的，本地提案也是真的；但“六角色通信正常”和“回执是角色自己执行”目前都没有真实证据。新工作台最需要修的不是文案，而是：回执身份、跨项目 read 的副作用、以及看板同步对旧协议任务的反向覆盖。**
