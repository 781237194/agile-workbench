# QA-UX-TOKEN · Owner 免确认码 / owner:demand / 产品闸门 / 并行派单 / 精准投喂

- 仓库：`D:\deepseek\agile-workbench`
- 时间：2026-11-06 04:40–04:55（Asia/Shanghai）
- 只读边界：只新增本文件 `docs/QA-UX-TOKEN.md`；`npm run check` 无副作用；`npm run selftest` 只写 `.selftest-data\` 自测沙盘（跑完自动清理本轮项目）。未改 `src/**`、`团队/状态/**`、`package*.json`、旧仓库 `D:\deepseek\工作台`。
- 方法：读源码（main.js / team-tools.js / preload.js / renderer/app.js / 团队\工具\team.mjs）→ `npm run check` → D 盘 Electron selftest（隔离 mock DSH）逐条对照断言与落盘产物。
- 源码快照（SHA-256 前 16 位）：

| 文件 | 字节 | SHA-256 前 16 | 最后写入 |
|---|---:|---|---|
| `src/main.js` | 538,312 | `0FDDC4FFAEEA3892` | 11-06 04:34 |
| `src/team-tools.js` | 337,563 | `3887F3DD4C950845` | 11-06 04:25 |
| `src/preload.js` | 8,151 | `0814CB992576C452` | 11-06 04:21 |
| `src/renderer/app.js` | 510,789 | `2E97ABFC2184A733` | 11-06 04:37 |
| `package.json` | 1,376 | `7E9E160BABD778F6` | 11-06 02:46 |
| `团队/工具/team.mjs` | 7,191 | `475BE3DC930B0D44` | 11-05 19:23 |
| `团队/工具/lib/workflow.mjs` | 72,552 | `83A83DAB54981E2A` | 11-05 19:29 |

## 一、结论

**通过。** 五条指定验证项全部 PASS，`npm run check` 与 D 盘 selftest 全绿（exit 0，全部段落 0 failure）。上一轮（ROUND12-CORE）的 P0 阻断「发行物缺 `req review`/`owner`/`workflow`」已修复：真实 `团队\工具\team.mjs:89-90` 已注册 `owner`/`workflow` 命令、帮助文本含 `req review`（:35），selftest 真实命令段 `commands.missing = []`。

附 1 条低危问题（Q1：唤醒消息按角色上限 1200/1000 实际被 800 夹死，代码与注释不符），不阻断；另 2 条说明级边界（S1/S2）。

## 二、检查表

| # | 检查项 | 结果 | 实测证据 |
|---|---|---|---|
| 1 | Owner 无确认码直接通过 | **PASS** | `owner:challenge`/`owner:confirm` 只返回 `deprecated` 占位（main.js:4021-4059）；渲染层不再弹确认码输入框、一次点击直调 `requirement:owner`/`owner:accept`（renderer/app.js:5493-5502, 5539）；`requirement:owner` IPC 强制 `ownerConfirmed:true`（main.js:4122-4133）。selftest ROUND10 `ownerDirect.ok=true`、`deprecatedChallenge.code=OWNER_CHALLENGE_DEPRECATED`、负例不存在需求仍拒 `REQUIREMENT_NOT_FOUND`。 |
| 2 | Owner 无确认码通过后 actor 落盘 | **PASS** | team-tools.js:6240-6252 审计统一 `actor:'owner'`、`channel:'workbench'`、`at`，经 `mutateWorkflowState` 写回 `工作流.json`；ROUND10 断言 `ownerReview.actor==='owner' && channel==='workbench'`、验收 `ownerAcceptance.actor==='owner'` 通过（main.js:8567-8571, 8674-8678）；ROUND11 断言 `actor:'owner'/channel:'workbench'` 通过（main.js:9018）。 |
| 3 | Owner 提需求由 PM 建 R | **PASS** | `ownerDemand`（team-tools.js:4866-4941）：PM 自动 boot（失败整单失败，不降级）、`createRequirement({role:'pm', origin:'owner', demandRoundMode:'auto'})` 建档、跟进责任记 `followUp.by='pm'`。ROUND11 实测：`R-` 号需求、`origin==='owner'`、`pmBoot.complete=true`、直接进产品评审（status `review`、phase `requirement_review`）；在办期间第二条 demand 排队下一轮（`queued=true, round>=2`）。 |
| 4 | 产品评审闸门 | **PASS** | `validateDispatchTarget`（team-tools.js:5393-5422）四层：`status==='ready'`、`productReview.verdict==='approve'`、`ownerReview ∈ approved/skipped`、非本轮排队拒绝；Owner 决定本身也要求产品评审已过（:4704-4706）。ROUND11 负例：评审前派单被拒 `REQUIREMENT_NOT_APPROVED`/`PRODUCT_REVIEW_REQUIRED`（main.js:8996-9001）。 |
| 5 | 并行派单 | **PASS** | `dispatchRequirementBatch`（team-tools.js:5521-5587）：只准 PM、条目校验、A/B 不可重复、**任何一条未过闸门整批不派**（预检）、返回 `parallel:true`。ROUND11 实测 `dispatched:2`、两条分别归 programmer1/programmer2、同人重复派被拒 `DUPLICATE_DEV_OWNER`；双方各自 claim/提交、互审通过 + PM apply 后 `dev_done`（main.js:9060-9102）。 |
| 6 | buildRoleBrief 只传相关区块 | **PASS** | 分角色区块（team-tools.js:3866-3981）：需求清单+最近评审意见所有人可见；PM 加开放任务、product 加设计文档标题、开发只读自己任务+验收、测试只读测试任务、analyst 无额外区块；上限 800 字；只读不写状态（selftest `fileBefore===fileAfter`）。ROUND11 实测 briefChars：pm 256 / analyst 208 / product 238 / dev 330 / tester 208，均 ≤800 且未截断；唤醒消息只含简报+四步命令（main.js:9112-9129）。 |
| 7 | D 盘 | **PASS** | 仓库、`.selftest-data`、`dsh.json`、状态全部落在 `D:\deepseek\agile-workbench\...`；ROUND9 `drive` 七项检查全 `d:\`；ROUND11 `driveChecks` 通过（main.js:9154-9157）。真实 `团队/状态` 未被 selftest 触碰（TEAM_ROOT 隔离在沙盘，main.js:86-89）。 |

## 三、问题

### Q1（低危）唤醒消息的按角色上限 1200/1000 被 800 夹死，代码与注释不符

`wakeMessageFor` 预算公式 `budget = max(200, min(roleLimit, BRIEF_MAX_CHARS))`（team-tools.js:6429），`BRIEF_MAX_CHARS=800` 把 `programmer1/2`（1200）、`tester`（1000）全部夹到 800：`header + briefText + commandLines ≤ budget = 800`。而 :105-106 与 :6392-6393 注释声明「整条唤醒消息按角色输出上限（开发 1200 / 测试 1000）截断」，`buildRoleBrief` 返回的 `limit` 字段也报 1200/1000，但正文实际硬顶 800。

实测：ROUND11 `wakeChars.dev = 800`（恰好顶到 800 预算），`analyst 681 / tester 679` 未触顶。当前无实质损失（简报 330 字远低于上限），但 1200/1000 两档是死代码，且注释误导。修复二选一：预算改 `max(200, roleLimit)`（简报另夹 800），或删掉 1200/1000 档并同步注释与 `limit` 字段。selftest 现有断言 `totalChars <= ROLE_BRIEF_LIMITS[role]` 测不出此问题（800 恒 ≤1200），建议补一条「dev 简报超 800 时唤醒正文可达上限」的正例。

## 四、说明（非失败）

- **S1 免确认码后的身份边界**：`requirement:owner` 缺省 `role='owner'`（main.js:4128）、`owner:demand` 不校验调用方身份。确认码移除后，Owner 决定/提需求路径的防线是：产品评审闸门（未过产品评审 Owner 不能决定、不能派单）+ 状态机闸门（验收需 test_done 等）。单机本地应用可接受，但建议在 `工作流命令.md` 写明该边界，避免误读为「任何人可在任意时点替 Owner 放行」。
- **S2 旧协议内部仍换码**：壳对旧 `team.mjs owner` 仍静默走 `--owner-confirm`（team-tools.js:4718-4725，lib/owner-confirm.mjs），「免确认码」是 UX 层；旧命令内部校验失败会整单失败（不吞错）。ROUND10 真实命令段已证通。
- **S3 报告计数**：`SELFTEST_ROUND11 {"checks":1}` 是 `Object.keys(report).length`（report 只有 `final` 一个键）的计数假象，断言失败走 `failures[]`，实测为空，非问题。

## 五、运行证据

- `npm run check`：exit 0（7 个文件 `node --check` 全过）。
- `npm run selftest`（D 盘 Electron，隔离 mock DSH）：exit 0，末行 `SELFTEST_OK`。

| 段落 | checks | failed |
|---|---:|---:|
| SELFTEST_STORE | 20 | 0 |
| SELFTEST_COMPAT（含 owner:challenge/confirm 废弃形状） | 48 | 0 |
| SELFTEST_MAPPING_RESULT | 39 | 0 |
| SELFTEST_ROUND5 | 4 | 0 |
| SELFTEST_ROUND6 | 17 | 0 |
| SELFTEST_ROUND9（drive 全 d:\） | 8 | 0 |
| SELFTEST_ROUND10（真实命令：workflow/owner/req review 可用，missing=[]） | 8 | 0 |
| SELFTEST_ROUND11（本轮的 owner:demand/简报/并行派单） | failures=0 | 0 |

- ROUND11 `report.final`：`dispatched:2`、briefChars `{pm:256, analyst:208, product:238, dev:330, tester:208}`、wakeChars `{dev:800, analyst:681, tester:679}`、`demand2Queued:true`、全程 mock DSH `prompts.before===after===54`（零真实 prompt）。
- 运行日志中出现的 `Error occurred in handler` 全部为预期负例断言（DSH_OFFLINE、SESSION_IDENTITY_MISMATCH、FILE_PATH_OUTSIDE、FILE_TOO_LARGE、LEGACY_PROPOSAL、CONFLICT、BACKUP_UNVERIFIED、ROLE_ACK_REQUIRED、LEGACY_PROTOCOL_REQUIRED 等），对应检查均 PASS，不属回归。
- 收尾清理正常：`SELFTEST_TEAM_CLEANUP` 移除本轮全部沙盘项目（含「第十一轮闭环」），真实团队状态未动。
