#!/usr/bin/env node
'use strict';
/**
 * 端到端验收（Owner 2026-11-18 23:0x：「新起个测试项目，看看是否正常，状态对不对」）
 *
 * 做法：**真 Electron 实例 + 真 UI + 真新建项目链路**（不是 CLI 沙盘）：
 *   ① 隔离沙盘：AWB_DATA_DIR/AWB_STORE/TEAM_ROOT/TEAM_PROJECTS_ROOT 全指 _tmp；复制真实 workbench.json
 *      与团队状态/宪法/铁律（让界面像生产：已有历史项目）；
 *   ② 启动壳 → CDP 连渲染层 → 调 `project:create`（与界面「新建项目」同一 IPC）建 **验收测试项目**；
 *   ③ 读取 `app:state`（项目列表/团队模式/角色会话）、`docs:presence`（文档清单）、`team:presence`（团队在场行）、
 *      `workflow:state`（工作流快照），逐项核对；并核磁盘六张角色卡/铁律/索引真实生成；
 *   ④ 用团队 CLI 在沙盘给新项目 `boot pm` + `boot analyst`，证明新项目可正常开工（= 面板状态可推进）；
 *   ⑤ 截图 2 张（项目列表/团队面板）供人工复核；
 *   ⑥ 断言真实 团队/状态/团队.json 与 data/userdata/workbench.json sha256 前后不变。
 *
 * 跑法：node scripts/e2e-newproject-ui.cjs      （失败时保留沙盘：AWB_E2E_KEEP=1）
 * 产出：项目/工作台改造修复/程序员A/产出/证据-e2e/run-newproject-ui.json + *.png
 */
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const crypto = require('node:crypto');
const { spawn, execFileSync } = require('node:child_process');

const ROOT = path.resolve(__dirname, '..');
const EV = path.join(ROOT, '项目', '工作台改造修复', '程序员A', '产出', '证据-e2e');
const ELECTRON = path.join(ROOT, 'node_modules', 'electron', 'dist', 'electron.exe');
const PROJ = '验收测试项目';
const PORT = 9981;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const sha = (f) => { try { return crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex'); } catch { return ''; } };
const realTeam = path.join(ROOT, '团队', '状态', '团队.json');
const realWb = path.join(ROOT, 'data', 'userdata', 'workbench.json');
const before = { team: sha(realTeam), wb: sha(realWb) };
const out = { steps: [], asserts: [] };
const step = (kind, data) => { out.steps.push({ at: new Date().toISOString(), kind, ...data }); console.log('[e2e]', kind, JSON.stringify(data).slice(0, 220)); };
const ok = (cond, name, detail) => { out.asserts.push({ name, ok: Boolean(cond), detail: cond ? undefined : detail }); console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : ' · ' + JSON.stringify(detail)}`); if (!cond) process.exitCode = 1; };

const SB = path.join(ROOT, '_tmp', `e2e-newproject-${process.pid}-${Date.now().toString(36)}`);
const DATA = path.join(SB, 'data');
const TEAM = path.join(SB, '团队');
const AREA = path.join(TEAM, '项目区');
const PROJDIR = path.join(AREA, PROJ);

function copyDir(src, dst, filter) { fs.mkdirSync(dst, { recursive: true }); for (const e of fs.readdirSync(src, { withFileTypes: true })) { const a = path.join(src, e.name); const b = path.join(dst, e.name); if (filter && filter(a)) continue; if (e.isDirectory()) copyDir(a, b, filter); else fs.copyFileSync(a, b); } }
function seed() {
  fs.mkdirSync(path.join(DATA, 'userdata'), { recursive: true });
  fs.mkdirSync(PROJDIR, { recursive: true });
  // 复制**整个** 团队/（含 工具、模板、skill），但排除 邮箱/锁 —— 壳层会调用 团队/工具/team.mjs（缺了会子进程失败）。
  copyDir(path.join(ROOT, '团队'), TEAM, (p) => /[\\/]邮箱([\\/]|$)/.test(p) || /[\\/]锁([\\/]|$)/.test(p));
  fs.copyFileSync(realWb, path.join(DATA, 'userdata', 'workbench.json'));
}

class WS {
  constructor(url) { this.url = url; this.id = 0; this.pending = new Map(); }
  connect() { return new Promise((res, rej) => { this.ws = new WebSocket(this.url); this.ws.onopen = () => res(); this.ws.onerror = (e) => rej(new Error('ws ' + (e && e.message || ''))); this.ws.onmessage = (ev) => { let m; try { m = JSON.parse(ev.data); } catch { return; } if (!m.id) return; const p = this.pending.get(m.id); if (!p) return; this.pending.delete(m.id); m.error ? p.reject(new Error(JSON.stringify(m.error).slice(0, 200))) : p.resolve(m.result); }; this.ws.onclose = () => { for (const p of this.pending.values()) p.reject(new Error('ws closed')); this.pending.clear(); }; }); }
  send(method, params = {}, timeoutMs = 30000) { const id = ++this.id; return new Promise((res, rej) => { const t = setTimeout(() => { this.pending.delete(id); rej(new Error('ws timeout ' + method)); }, timeoutMs); this.pending.set(id, { resolve: (v) => { clearTimeout(t); res(v); }, reject: (e) => { clearTimeout(t); rej(e); } }); this.ws.send(JSON.stringify({ id, method, params })); }); }
  close() { try { this.ws.close(); } catch { /* ignore */ } }
}
function getJson(p) { return new Promise((res, rej) => { const req = http.get({ host: '127.0.0.1', port: PORT, path: p, timeout: 3000 }, (r) => { let b = ''; r.setEncoding('utf8'); r.on('data', (c) => { b += c; }); r.on('end', () => { try { res(JSON.parse(b)); } catch (e) { rej(e); } }); }); req.on('error', rej); req.on('timeout', () => req.destroy(new Error('http timeout'))); }); }

async function main() {
  fs.mkdirSync(EV, { recursive: true });
  seed();
  const env = {
    ...process.env, AWB_DATA_DIR: DATA, AWB_STORE: path.join(DATA, 'userdata', 'workbench.json'),
    TEAM_ROOT: TEAM, AWB_TEAM_ROOT: TEAM, TEAM_PROJECTS_ROOT: path.join(TEAM, '状态', '项目'),
    TEAM_SELFTEST: '1', AWB_BOARD_PREGEN_MS: '0', AWB_START_HIDDEN: '0',
  };
  delete env.ELECTRON_RUN_AS_NODE;
  const child = spawn(ELECTRON, ['.', `--remote-debugging-port=${PORT}`], { cwd: ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] });
  let logBuf = '';
  child.stdout.on('data', (d) => { logBuf += String(d); });
  child.stderr.on('data', (d) => { logBuf += String(d); });
  const childPid = child.pid;
  let cdp = null;
  try {
    let list = null; const listErrs = [];
    for (let i = 0; i < 80; i += 1) { try { list = await getJson('/json/list'); if (Array.isArray(list) && list.length) break; } catch (e) { listErrs.push(String((e && e.message) || e)); } await sleep(400); }
    if (!list) step('json-list-errors', { sample: listErrs.slice(0, 4), childExited: (() => { try { return child.exitCode; } catch { return 'n/a'; } })() });
    const page = (list || []).find((t) => t.type === 'page' && /renderer[\\/]index\.html/i.test(String(t.url || ''))) || (list || []).find((t) => t.type === 'page');
    if (!page) {
      step('cdp-targets', { count: Array.isArray(list) ? list.length : -1, targets: (list || []).slice(0, 12).map((t) => ({ type: t.type, url: String(t.url || '').slice(0, 80), title: String(t.title || '').slice(0, 40) })) });
      // 再等一轮（壳可能正在激活工作区）
      for (let i = 0; i < 60; i += 1) {
        await sleep(500);
        try {
          const l2 = await getJson('/json/list');
          const p2 = (l2 || []).find((t) => t.type === 'page');
          if (p2) { step('cdp-targets-late', { count: (l2 || []).length }); list = l2; break; }
        } catch { /* wait */ }
      }
    }
    const page2 = (list || []).find((t) => t.type === 'page' && /renderer[\\/]index\.html/i.test(String(t.url || ''))) || (list || []).find((t) => t.type === 'page');
    if (!page2) throw new Error('找不到渲染层页面（CDP）：list=' + JSON.stringify((list || []).slice(0, 6).map((t) => ({ type: t.type, url: String(t.url || '').slice(0, 60) }))));
    cdp = new WS(page2.webSocketDebuggerUrl); await cdp.connect();
    await cdp.send('Page.enable'); await cdp.send('Runtime.enable');
    try { await cdp.send('Page.bringToFront'); } catch { /* ignore */ }
    const evalJs = async (expr, timeoutMs = 120000, awaitPromise = true) => {
      const r = await cdp.send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise, timeout: timeoutMs }, timeoutMs + 5000);
      if (r && r.exceptionDetails) throw new Error('evaluate: ' + JSON.stringify(r.exceptionDetails).slice(0, 300));
      return r && r.result ? r.result.value : null;
    };
    // 等界面就绪
    for (let i = 0; i < 60; i += 1) { const ready = await evalJs("Boolean(window.workbench && document.querySelector('#projects, .project-list, body'))", 10000, false); if (ready) break; await sleep(300); }

    // ② 新建项目（界面同一 IPC）
    const create = await evalJs(`window.workbench.createProject(${JSON.stringify({ name: PROJ, root: AREA, teamMode: 'full' })})`);
    step('createProject', { ok: Boolean(create && create.ok), id: create && create.project && create.project.id, name: create && create.project && create.project.name, error: create && (create.message || create.code) });
    ok(create && create.ok, '① 新建项目成功（project:create 真链路）', { create: JSON.stringify(create || {}).slice(0, 400) });
    const pid = create && create.project ? create.project.id : '';

    // ③ 状态核对：项目列表 / 新项目字段 / 文档清单 / 团队在场 / 工作流
    const state = await evalJs('window.workbench.state()');
    const row = ((state && state.projects) || []).find((p) => p.id === pid) || null;
    step('appState', { projects: (state && state.projects || []).length, row: row && { name: row.name, teamMode: row.teamMode, roleIds: row.roleIds, path: row.path } });
    ok(Boolean(row), '② 新建项目出现在 app:state 项目列表', { count: (state && state.projects || []).length });
    ok(row && String(row.teamMode) === 'full', '③ 团队模式 = full（六角色）', { teamMode: row && row.teamMode });
    ok(row && Array.isArray(row.roleIds) && row.roleIds.length === 6, '④ 角色清单 = 6 个角色', { roleIds: row && row.roleIds });

    const docs = await evalJs(`window.workbench.docsPresence()`);
    const checks = (docs && docs.checks) || docs || {};
    step('docsPresence', { project: docs && docs.project, checks: Array.isArray(checks) ? checks.length : typeof checks });
    ok(docs && (docs.ok !== false), '⑤ docs:presence 可读（面板文档区不报错）', { docs: JSON.stringify(docs || {}).slice(0, 300) });

    const presence = await evalJs(`window.workbench.teamPresence(${JSON.stringify({ projectId: pid })})`);
    step('teamPresence', { ok: presence && presence.ok, rows: (presence && presence.rows || []).length, project: presence && presence.project });
    ok(presence && presence.ok !== false && Array.isArray(presence.rows) && presence.rows.length >= 1, '⑥ team:presence 返回团队成员行', { presence: JSON.stringify(presence || {}).slice(0, 300) });

    const wf = await evalJs(`window.workbench.workflowState(${JSON.stringify({ projectId: pid, teamMode: 'full' })})`);
    step('workflowState', { ok: wf && wf.ok, keys: wf ? Object.keys(wf).slice(0, 10) : null });
    ok(wf && wf.ok !== false, '⑦ workflow:state 可读（工作流面板不报错）', { wf: JSON.stringify(wf || {}).slice(0, 300) });

    // 磁盘核对：六卡 + 铁律 + 索引 + 项目信息
    const ROLES = ['项目经理', '产品', '需求分析师', '程序员A', '程序员B', '测试人员'];
    const KW = ['验收', '代管', '工装安全', '测量窗口', '文档维护', 'skill 升版'];
    const cardProblems = [];
    for (const d of ROLES) {
      const p = path.join(PROJDIR, d, '角色卡.md');
      const t = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : '';
      const miss = KW.filter((k) => t.indexOf(k) < 0);
      if (!t || miss.length) cardProblems.push({ dir: d, bytes: Buffer.byteLength(t), miss });
    }
    ok(cardProblems.length === 0, '⑧ 磁盘六张角色卡真实生成且含六条款', cardProblems);
    ok(fs.existsSync(path.join(PROJDIR, '项目信息.md')) && fs.existsSync(path.join(PROJDIR, '项目铁律.md')) && fs.existsSync(path.join(PROJDIR, '项目索引.md')), '⑨ 项目信息/铁律/索引齐全', {});

    // ④ 新项目可开工：boot pm + boot analyst（沙盘 CLI，同团队根）
    const cliEnv = { ...env, ELECTRON_RUN_AS_NODE: '1' };
    const runCli = (args) => { const r = require('node:child_process').spawnSync(process.execPath, [path.join(ROOT, '团队', '工具', 'team.mjs'), ...args], { cwd: ROOT, env: cliEnv, encoding: 'utf8', timeout: 180000 }); return { status: r.status, text: String(r.stdout || '') + String(r.stderr || '') }; };
    const bootPm = runCli(['boot', '--role', 'pm', '--project', PROJ, '--session', 'e2e-pm']);
    step('bootPm', { status: bootPm.status, tail: bootPm.text.slice(-160) });
    ok(bootPm.status === 0 && /令牌/.test(bootPm.text), '⑩ 新项目 boot pm 成功（可开工）', { status: bootPm.status, tail: bootPm.text.slice(-300) });
    const bootTester = runCli(['boot', '--role', 'tester', '--project', PROJ, '--session', 'e2e-tester']);
    ok(bootTester.status === 0, '⑪ 新项目 boot tester 成功', { status: bootTester.status, tail: bootTester.text.slice(-200) });

    // ⑤ 切到新项目 + 开团队台，截图并核对界面数字（Owner 要「状态对不对」）
    try { await evalJs(`window.workbench.selectProject(${JSON.stringify(pid)})`); } catch (e) { step('select-failed', { why: String((e && e.message) || e).slice(0, 160) }); }
    await sleep(2000);
    const uiText = await evalJs(`(() => {
      const t = (sel) => { const el = document.querySelector(sel); return el ? String(el.innerText || '').replace(/\\s+/g, ' ').slice(0, 160) : ''; };
      return { titlebar: t('#titlebar'), sidebar: t('#sidebar'), active: t('[data-active-project], #active-project'), body: t('body') };
    })()`, 30000, false);
    step('uiText-after-select', { titlebar: String(uiText && uiText.titlebar || '').slice(0, 200), sidebar: String(uiText && uiText.sidebar || '').slice(0, 200) });
    try {
      const shot = await cdp.send('Page.captureScreenshot', { format: 'png' }, 40000);
      fs.writeFileSync(path.join(EV, '02-切到新项目后.png'), Buffer.from(shot.data, 'base64'));
      step('screenshot2', { file: '02-切到新项目后.png' });
    } catch (e) { step('screenshot2-failed', { why: String((e && e.message) || e).slice(0, 160) }); }
    // 尝试打开「团队台」（按钮文案精确含「团队台」），并读取团队台内部文本核对状态
    try {
      const opened = await evalJs(`(() => {
        const els = Array.from(document.querySelectorAll('button, a, [role="tab"]'));
        const hit = els.find((el) => /团队台/.test(String(el.textContent || '').trim()) && String(el.offsetParent) !== 'null');
        if (!hit) return false; hit.click(); return true;
      })()`, 20000, false);
      step('open-team-drawer', { opened });
      await sleep(3000);
      const drawerText = await evalJs(`(() => {
        const el = document.querySelector('#team-drawer') || document.querySelector('#drawer') || document.querySelector('.drawer');
        if (!el) return { found: false };
        return { found: true, text: String(el.innerText || '').replace(/\\s+/g, ' ').slice(0, 1200) };
      })()`, 30000, false);
      step('team-drawer-text', drawerText);
      const shot = await cdp.send('Page.captureScreenshot', { format: 'png' }, 40000);
      fs.writeFileSync(path.join(EV, '03-团队台-新项目.png'), Buffer.from(shot.data, 'base64'));
      step('screenshot3', { file: '03-团队台-新项目.png' });
    } catch (e) { step('team-drawer-failed', { why: String((e && e.message) || e).slice(0, 160) }); }
    await sleep(600);
    try {
      const shot = await cdp.send('Page.captureScreenshot', { format: 'png' }, 40000);
      fs.writeFileSync(path.join(EV, '01-新建项目后界面.png'), Buffer.from(shot.data, 'base64'));
      step('screenshot', { file: '01-新建项目后界面.png' });
    } catch (e) { step('screenshot-failed', { why: String((e && e.message) || e).slice(0, 160) }); }

    out.result = { projectId: pid, projectPath: PROJDIR, bootPm: bootPm.status, bootTester: bootTester.status };
    out.pass = out.asserts.every((a) => a.ok);
    out.isolation = { realTeamSame: sha(realTeam) === before.team, realWbSame: sha(realWb) === before.wb };
    ok(out.isolation.realTeamSame && out.isolation.realWbSame, '⑫ 真实团队.json / workbench.json sha256 前后不变（隔离）', out.isolation);
    out.pass = out.asserts.every((a) => a.ok);
  } finally {
    out.childLogTail = logBuf.slice(-1500);
    fs.writeFileSync(path.join(EV, 'run-newproject-ui.json'), JSON.stringify(out, null, 2) + '\n', 'utf8');
    console.log(`\nE2E_NEWPROJECT ${out.asserts.filter((a) => a.ok).length}/${out.asserts.length} PASS → 证据-e2e/run-newproject-ui.json`);
    try { if (cdp) cdp.close(); } catch { /* ignore */ }
    try { if (childPid) spawnSyncTaskkill(childPid); } catch { /* ignore */ }
    if (process.env.AWB_E2E_KEEP === '1') console.log('KEEP_SANDBOX ' + SB); else { try { fs.rmSync(SB, { recursive: true, force: true, maxRetries: 3, retryDelay: 200 }); } catch { /* ignore */ } }
  }
}
function spawnSyncTaskkill(pid) {
  try { require('node:child_process').spawnSync('taskkill', ['/PID', String(pid), '/T', '/F'], { stdio: 'ignore' }); } catch { /* ignore */ }
}

main().catch((e) => { console.error('E2E_FAILED ' + String((e && e.message) || e).slice(0, 400)); process.exitCode = 2; });
